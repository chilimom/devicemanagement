import assert from "node:assert/strict";
import test from "node:test";

import {
  evaluateInspectionScheduleStatus,
  getVietnamToday,
} from "../src/services/inspectionScheduleStatus.js";
import type { DeviceInspectionPlan, InspectionRecord, InspectionResultStatus } from "../src/types/inspection.js";

function plan(weekdays: number[], createdAt?: unknown): DeviceInspectionPlan {
  return {
    id: "device-1",
    deviceId: "device-1",
    name: "Plan",
    isActive: true,
    version: 1,
    createdAt,
    tasks: [{
      id: "task-1",
      name: "Task",
      order: 1,
      frequency: "WEEKLY",
      weekdays,
      criteria: [],
      isActive: true,
    }],
  };
}

function record(
  date: string,
  type: "SCHEDULED" | "EXTRA" = "SCHEDULED",
  status: InspectionResultStatus = "PASS",
  createdAt?: unknown,
): InspectionRecord {
  return {
    id: `result-${date}-${type}-${status}-${createdAt && typeof createdAt === "object" && "value" in createdAt ? String(createdAt.value) : ""}`,
    deviceId: "device-1",
    planId: "device-1",
    planVersion: 1,
    inspectionDate: date,
    inspectionType: type,
    inspectorName: "Tester",
    recordedByUid: "uid-1",
    results: [{ taskId: "task-1", status, criteriaResults: [] }],
    createdAt,
  };
}

test("reports no plan", () => {
  assert.equal(evaluateInspectionScheduleStatus({ plan: null, records: [], today: "2026-11-09" }).state, "NO_PLAN");
});

test("reports due today when today's task has no scheduled result", () => {
  const status = evaluateInspectionScheduleStatus({
    plan: plan([1]),
    records: [record("2026-11-02")],
    today: "2026-11-09",
  });
  assert.equal(status.state, "DUE_TODAY");
});

test("reports completed today for a scheduled result", () => {
  const status = evaluateInspectionScheduleStatus({
    plan: plan([1]),
    records: [record("2026-11-02"), record("2026-11-09")],
    today: "2026-11-09",
  });
  assert.equal(status.state, "COMPLETED_TODAY");
  assert.equal(status.todayResultStatus, "PASS");
});

test("keeps schedule completion separate from a failed current result", () => {
  const status = evaluateInspectionScheduleStatus({
    plan: plan([1]),
    records: [record("2026-11-09", "SCHEDULED", "FAIL")],
    today: "2026-11-09",
  });
  assert.equal(status.state, "COMPLETED_TODAY");
  assert.equal(status.completedTodayCount, 1);
  assert.equal(status.todayResultStatus, "FAIL");
});

test("approved maintenance resolves a failed linked criterion in the main inspection status", () => {
  const failed = record("2026-11-16", "SCHEDULED", "FAIL");
  failed.results[0].criteriaResults = [{ criterionId: "criterion-1", status: "FAIL", note: "failed" }];
  const status = evaluateInspectionScheduleStatus({
    plan: plan([1]),
    records: [failed],
    approvedMaintenanceSources: [{ recordId: failed.id, taskId: "task-1", criterionId: "criterion-1" }],
    today: "2026-11-16",
  });
  assert.equal(status.todayResultStatus, "PASS");
});

test("uses the latest same-day result for the current outcome", () => {
  const status = evaluateInspectionScheduleStatus({
    plan: plan([1]),
    records: [
      record("2026-11-09", "SCHEDULED", "FAIL", { value: 1, toMillis: () => 1 }),
      record("2026-11-09", "EXTRA", "PASS", { value: 2, toMillis: () => 2 }),
    ],
    today: "2026-11-09",
  });
  assert.equal(status.todayResultStatus, "PASS");
});

test("reports overdue after a missed scheduled occurrence", () => {
  const status = evaluateInspectionScheduleStatus({
    plan: plan([1]),
    records: [],
    today: "2026-11-10",
    planCreatedDate: "2026-11-01",
  });
  assert.equal(status.state, "OVERDUE");
  assert.equal(status.overdueTaskCount, 1);
});

test("does not report an occurrence before the plan was created", () => {
  const status = evaluateInspectionScheduleStatus({
    plan: plan([1]),
    records: [],
    today: "2026-11-10",
    planCreatedDate: "2026-11-10",
  });
  assert.equal(status.state, "NO_SCHEDULE_TODAY");
});

test("an extra result after a missed occurrence clears the overdue alert", () => {
  const status = evaluateInspectionScheduleStatus({
    plan: plan([1]),
    records: [record("2026-11-10", "EXTRA")],
    today: "2026-11-10",
    planCreatedDate: "2026-11-01",
  });
  assert.equal(status.state, "NO_SCHEDULE_TODAY");
  assert.equal(status.overdueTaskCount, 0);
});

test("an extra result today completes today's scheduled task", () => {
  const status = evaluateInspectionScheduleStatus({
    plan: plan([1]),
    records: [record("2026-11-09"), record("2026-11-16", "EXTRA")],
    today: "2026-11-16",
  });
  assert.equal(status.state, "COMPLETED_TODAY");
  assert.equal(status.completedTodayCount, 1);
});

test("uses Vietnam calendar date", () => {
  assert.equal(getVietnamToday(new Date("2026-11-08T18:30:00.000Z")), "2026-11-09");
});
