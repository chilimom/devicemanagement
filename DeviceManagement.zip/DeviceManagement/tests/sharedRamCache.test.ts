import assert from "node:assert/strict";
import test from "node:test";

import {
  CACHE_POLICIES,
  SharedRamCache,
  createCacheScope,
  normalizeAreaIds,
  type CacheScope,
  type CacheScopeInput,
} from "../src/services/sharedRamCache.js";
import { beginScopedCacheRead } from "../src/services/sharedCollectionCache.js";

const devices = { collection: "devices", variant: "list" } as const;
const areas = { collection: "areas", variant: "list" } as const;
const policy = { freshForMs: 30, staleForMs: 120 } as const;

function input(overrides: Partial<CacheScopeInput> = {}): CacheScopeInput {
  return {
    projectId: "project-a",
    databaseId: "(default)",
    uid: "user-a",
    role: "USER",
    areaIds: ["area-b", "area-a"],
    isActive: true,
    ...overrides,
  };
}

function scope(overrides: Partial<CacheScopeInput> = {}): CacheScope {
  const result = createCacheScope(input(overrides));
  assert.ok(result);
  return result;
}

function deferred<T>() {
  let resolve!: (value: T) => void;
  let reject!: (error: unknown) => void;
  const promise = new Promise<T>((resolvePromise, rejectPromise) => {
    resolve = resolvePromise;
    reject = rejectPromise;
  });
  return { promise, resolve, reject };
}

test("normalizes areaIds by trimming, removing empty/duplicates and sorting", () => {
  assert.deepEqual(
    normalizeAreaIds([" area-b ", "", "area-a", "area-b", "   "]),
    ["area-a", "area-b"],
  );
});

test("creates a stable scope key from project, database, UID, role and areas", () => {
  const first = scope();
  const second = scope({ areaIds: ["area-a", " area-b ", "area-a"] });

  assert.equal(first.key, second.key);
  assert.equal(first.areaSignature, "area-a\u001farea-b");
  assert.deepEqual(first.areaIds, ["area-a", "area-b"]);
  assert.equal(createCacheScope(input({ isActive: false })), null);
});

test("AREA_ADMIN never reuses ADMIN or USER cache scopes", () => {
  const admin = scope({ role: "ADMIN" });
  const areaAdmin = scope({ role: "AREA_ADMIN" });
  const user = scope({ role: "USER" });
  assert.notEqual(areaAdmin.key, admin.key);
  assert.notEqual(areaAdmin.key, user.key);
});

test("distinguishes fresh, stale and expired values at TTL boundaries", () => {
  const cache = new SharedRamCache();
  const currentScope = scope();
  cache.activateScope(currentScope);
  cache.write(currentScope, devices, ["device-a"], policy, 1_000);

  assert.equal(cache.read(currentScope, devices, 1_029).state, "fresh");
  assert.equal(cache.read(currentScope, devices, 1_030).state, "stale");
  assert.equal(cache.read(currentScope, devices, 1_119).state, "stale");
  const expired = cache.read(currentScope, devices, 1_120);
  assert.equal(expired.state, "expired");
  assert.equal(expired.data, undefined);
});

test("returns cache hits only for the active scope", () => {
  const cache = new SharedRamCache();
  const userA = scope();
  const userB = scope({ uid: "user-b" });
  cache.activateScope(userA);
  cache.write(userA, devices, ["device-a"], policy, 100);

  assert.deepEqual(cache.read<string[]>(userA, devices, 110).data, ["device-a"]);
  assert.equal(cache.read(userB, devices, 110).state, "missing");
});

test("invalidates every variant in one collection without touching others", () => {
  const cache = new SharedRamCache();
  const currentScope = scope();
  cache.activateScope(currentScope);
  cache.write(currentScope, devices, [1], policy, 0);
  cache.write(
    currentScope,
    { collection: "devices", variant: "active" },
    [2],
    policy,
    0,
  );
  cache.write(currentScope, areas, [3], policy, 0);

  assert.equal(cache.invalidateCollection(currentScope, "devices"), 2);
  assert.equal(cache.read(currentScope, devices, 1).state, "missing");
  assert.deepEqual(cache.read<number[]>(currentScope, areas, 1).data, [3]);
});

test("collection invalidation prevents an in-flight request from committing", async () => {
  const cache = new SharedRamCache();
  const currentScope = scope();
  const pending = deferred<string[]>();
  cache.activateScope(currentScope);

  const load = cache.load(currentScope, devices, () => pending.promise, policy);
  cache.invalidateCollection(currentScope, "devices");
  pending.resolve(["late-device"]);

  assert.deepEqual(await load, { data: ["late-device"], committed: false });
  assert.equal(cache.read(currentScope, devices).state, "missing");
});

test("clearScope invalidates its scope and clearAll invalidates the active scope", () => {
  const cache = new SharedRamCache();
  const first = scope();
  cache.activateScope(first);
  cache.write(first, devices, [1], policy, 0);
  assert.equal(cache.clearScope(first), true);
  assert.equal(cache.read(first, devices, 1).state, "missing");

  const second = scope({ uid: "user-b" });
  cache.activateScope(second);
  cache.write(second, devices, [2], policy, 0);
  cache.clearAll();
  assert.equal(cache.getActiveScope(), null);
  assert.equal(cache.read(second, devices, 1).state, "missing");
});

for (const [name, overrides] of [
  ["UID", { uid: "user-b" }],
  ["role", { role: "ADMIN" as const }],
  ["areaIds", { areaIds: ["area-c"] }],
] as const) {
  test(`changing ${name} clears the previous scope`, () => {
    const cache = new SharedRamCache();
    const before = scope();
    const after = scope(overrides);
    cache.activateScope(before);
    cache.write(before, devices, ["old"], policy, 0);

    assert.equal(cache.activateScope(after), true);
    assert.equal(cache.read(before, devices, 1).state, "missing");
    assert.equal(cache.read(after, devices, 1).state, "missing");
  });
}

test("changing active to false clears the prior scope", () => {
  const cache = new SharedRamCache();
  const active = scope();
  cache.activateScope(active);
  cache.write(active, devices, ["old"], policy, 0);

  const inactive = createCacheScope(input({ isActive: false }));
  assert.equal(inactive, null);
  assert.equal(cache.activateScope(inactive), true);
  assert.equal(cache.read(active, devices, 1).state, "missing");
});

test("a request from an invalidated scope cannot commit after scope change", async () => {
  const cache = new SharedRamCache();
  const userA = scope();
  const userB = scope({ uid: "user-b" });
  const pending = deferred<string[]>();
  cache.activateScope(userA);

  const load = cache.load(userA, devices, () => pending.promise, policy, () => 50);
  cache.activateScope(userB);
  pending.resolve(["private-a"]);

  assert.deepEqual(await load, { data: ["private-a"], committed: false });
  assert.equal(cache.read(userA, devices, 51).state, "missing");
  assert.equal(cache.read(userB, devices, 51).state, "missing");
});

test("permission-denied evicts stale data and is not cached", async () => {
  const cache = new SharedRamCache();
  const currentScope = scope();
  const denied = Object.assign(new Error("denied"), {
    code: "firestore/permission-denied",
  });
  cache.activateScope(currentScope);
  cache.write(currentScope, devices, ["stale-private-data"], policy, 0);

  await assert.rejects(
    cache.load(currentScope, devices, () => Promise.reject(denied), policy),
    (error: unknown) => error === denied,
  );
  assert.equal(cache.read(currentScope, devices, 1).state, "missing");
});

test("concurrent loads in the same scope and dataset are deduplicated", async () => {
  const cache = new SharedRamCache();
  const currentScope = scope();
  const pending = deferred<string[]>();
  let calls = 0;
  cache.activateScope(currentScope);

  const loader = () => {
    calls += 1;
    return pending.promise;
  };
  const first = cache.load(currentScope, devices, loader, policy, () => 100);
  const second = cache.load(currentScope, devices, loader, policy, () => 100);

  assert.equal(first, second);
  assert.equal(calls, 1);
  assert.equal(cache.read(currentScope, devices, 50).state, "loading");
  pending.resolve(["device-a"]);
  assert.deepEqual(await first, { data: ["device-a"], committed: true });
  assert.equal(cache.read(currentScope, devices, 100).state, "fresh");
});

test("loading over a visible value reports refreshing", () => {
  const cache = new SharedRamCache();
  const currentScope = scope();
  const pending = deferred<string[]>();
  cache.activateScope(currentScope);
  cache.write(currentScope, devices, ["old"], policy, 0);
  void cache.load(currentScope, devices, () => pending.promise, policy);

  assert.equal(cache.read(currentScope, devices, 40).state, "refreshing");
  pending.resolve(["new"]);
});

test("reloading an expired value reports loading without returning old data", () => {
  const cache = new SharedRamCache();
  const currentScope = scope();
  const pending = deferred<string[]>();
  cache.activateScope(currentScope);
  cache.write(currentScope, devices, ["expired"], policy, 0);
  void cache.load(currentScope, devices, () => pending.promise, policy);

  const snapshot = cache.read(currentScope, devices, 120);
  assert.equal(snapshot.state, "loading");
  assert.equal(snapshot.data, undefined);
  pending.resolve(["new"]);
});

test("exports the approved initial TTL policies", () => {
  assert.deepEqual(CACHE_POLICIES.devices, {
    freshForMs: 30_000,
    staleForMs: 120_000,
  });
  assert.deepEqual(CACHE_POLICIES.areas, {
    freshForMs: 300_000,
    staleForMs: 900_000,
  });
  assert.deepEqual(CACHE_POLICIES.deviceCategories, {
    freshForMs: 600_000,
    staleForMs: 1_800_000,
  });
  assert.deepEqual(CACHE_POLICIES.deviceTypes, {
    freshForMs: 300_000,
    staleForMs: 900_000,
  });
});

test("shared collection adapter skips Firestore loader for fresh cache", () => {
  const cache = new SharedRamCache();
  const currentScope = scope();
  let calls = 0;
  cache.activateScope(currentScope);
  cache.write(currentScope, devices, ["cached"], policy, 0);

  const read = beginScopedCacheRead(
    cache,
    currentScope,
    devices,
    policy,
    async () => {
      calls += 1;
      return ["server"];
    },
    10,
  );

  assert.equal(read.snapshot.state, "fresh");
  assert.deepEqual(read.snapshot.data, ["cached"]);
  assert.equal(read.request, null);
  assert.equal(calls, 0);
});

test("shared collection adapter returns stale data and refreshes in background", async () => {
  const cache = new SharedRamCache();
  const currentScope = scope();
  cache.activateScope(currentScope);
  cache.write(currentScope, devices, ["stale"], policy, 0);

  const read = beginScopedCacheRead(
    cache,
    currentScope,
    devices,
    policy,
    async () => ["server"],
    30,
  );

  assert.equal(read.snapshot.state, "stale");
  assert.deepEqual(read.snapshot.data, ["stale"]);
  assert.ok(read.request);
  assert.equal((await read.request).committed, true);
});
