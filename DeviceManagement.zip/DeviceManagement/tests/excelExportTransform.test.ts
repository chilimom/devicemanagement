import assert from "node:assert/strict";
import test from "node:test";

import {
  EXCEL_APPROVED_COLUMNS,
  transformExcelExportData,
} from "../src/services/excelExportTransform.js";
import {
  createEmptyExcelExportDataSet,
  type ExcelExportDataSet,
} from "../src/types/excelExport.js";

const timestamp = (iso: string) => ({ toDate: () => new Date(iso) });

function baseData(): ExcelExportDataSet {
  const data = createEmptyExcelExportDataSet();
  data.areas.push({ id: "area-1", data: { code: "A1", name: "Khu A" } });
  data.deviceCategories.push({
    id: "category-1",
    data: { code: "CAT", name: "Điện" },
  });
  data.deviceTypes.push({
    id: "type-1",
    data: { code: "TYPE", name: "Máy biến áp", categoryId: "category-1" },
  });
  data.devices.push({
    id: "device-technical-id",
    data: {
      code: "TB-01",
      name: "Thiết bị 1",
      areaId: "area-1",
      deviceTypeId: "type-1",
      manufacturer: "ABB",
      model: "M-01",
      ipAddress: "10.20.30.40",
      status: "ACTIVE",
      createdAt: timestamp("2026-11-04T03:04:05.000Z"),
    },
  });
  return data;
}

test("uses exactly the approved 63 columns in the approved six-sheet order", () => {
  const output = transformExcelExportData(createEmptyExcelExportDataSet());
  assert.deepEqual(
    output.sheets.map((sheet) => sheet.name),
    [
      "DM_ThietBi", "DM_SuCo", "LS_KhacPhuc", "LS_XacMinh",
      "DM_TuanKiem", "KQ_TuanKiem",
    ],
  );
  for (const sheet of output.sheets) {
    assert.deepEqual(sheet.columns, EXCEL_APPROVED_COLUMNS[sheet.name]);
  }
  assert.equal(
    output.sheets.reduce((total, sheet) => total + sheet.columns.length, 0),
    63,
  );
});

test("exports no ID, UID, email or extra technical column", () => {
  const output = transformExcelExportData(baseData());
  const headers = output.sheets.flatMap((sheet) => [...sheet.columns]);
  assert.equal(headers.some((header) => /(^|\s)(ID|UID)(\s|$)/i.test(header)), false);
  assert.equal(headers.some((header) => /email/i.test(header)), false);
  for (const sheet of output.sheets) {
    for (const row of sheet.rows) {
      assert.deepEqual(Object.keys(row).sort(), [...sheet.columns].sort());
    }
  }
});

test("maps the nine approved device fields to readable values", () => {
  const row = transformExcelExportData(baseData()).byName.DM_ThietBi.rows[0];
  assert.deepEqual(
    {
      code: row["Mã thiết bị"],
      name: row["Tên thiết bị"],
      category: row["Lĩnh vực"],
      type: row["Loại thiết bị"],
      area: row["Khu vực"],
      maker: row["Hãng / Model"],
      ip: row["Địa chỉ IP"],
      status: row["Trạng thái"],
    },
    {
      code: "TB-01",
      name: "Thiết bị 1",
      category: "Điện",
      type: "Máy biến áp",
      area: "A1 - Khu A",
      maker: "ABB / M-01",
      ip: "10.20.30.40",
      status: "Hoạt động",
    },
  );
  assert.ok(row["Ngày tạo"] instanceof Date);
});

test("uses the final successful resolution actor, not the latest attempt actor", () => {
  const data = baseData();
  const deviceId = data.devices[0].id;
  data.incidents.push({
    id: "incident-1",
    data: {
      deviceId,
      deviceCode: "TB-SNAPSHOT",
      deviceName: "Tên snapshot",
      title: "Sự cố",
      description: "Mô tả",
      resolution: "Nội dung cuối",
      status: "RESOLVED",
      resolutionCount: 2,
      resolutionAttemptCount: 3,
      resolvedByUid: "uid-final",
      lastResolutionAttemptByUid: "uid-latest",
      reportedAt: timestamp("2026-11-01T01:00:00Z"),
      resolvedAt: timestamp("2026-11-02T02:00:00Z"),
    },
  });
  data.incidentResolutions.push(
    { id: "incident-1_2", data: { incidentId: "incident-1", deviceId, attemptNumber: 2, resolvedByUid: "uid-final", resolvedByName: "Người khắc phục cuối" } },
    { id: "incident-1_3", data: { incidentId: "incident-1", deviceId, attemptNumber: 3, resolvedByUid: "uid-latest", resolvedByName: "Người thử gần nhất" } },
  );

  const row = transformExcelExportData(data).byName.DM_SuCo.rows[0];
  assert.equal(row["Mã thiết bị"], "TB-SNAPSHOT");
  assert.equal(row["Tên thiết bị"], "Tên snapshot");
  assert.equal(row["Người khắc phục"], "Người khắc phục cuối");
  assert.equal(row["Nội dung khắc phục"], "Nội dung cuối");
  assert.equal(row["Trạng thái xác minh đóng sự cố"], "Chờ xác minh");
});

test("does not claim a CLOSED incident was verified without a valid verification", () => {
  const data = baseData();
  const deviceId = data.devices[0].id;
  data.incidents.push({ id: "closed", data: { deviceId, status: "CLOSED" } });
  assert.equal(
    transformExcelExportData(data).byName.DM_SuCo.rows[0][
      "Trạng thái xác minh đóng sự cố"
    ],
    "",
  );

  data.incidentVerifications.push({
    id: "closed",
    data: {
      incidentId: "closed",
      deviceId,
      attemptNumber: 1,
      note: "Đồng ý đóng",
      verifiedByUid: "verifier",
      verifiedByName: "Người xác minh",
      verifiedAt: timestamp("2026-11-03T03:00:00Z"),
    },
  });
  assert.equal(
    transformExcelExportData(data).byName.DM_SuCo.rows[0][
      "Trạng thái xác minh đóng sự cố"
    ],
    "Đã xác minh, đã đóng",
  );
});

test("keeps every resolution attempt and maps its actual outcome", () => {
  const data = baseData();
  const deviceId = data.devices[0].id;
  data.incidents.push({ id: "incident-1", data: { deviceId, title: "Sự cố" } });
  data.incidentResolutions.push(
    { id: "incident-1_1", data: { incidentId: "incident-1", deviceId, attemptNumber: 1, resolution: "Lần 1", outcome: "OPEN", resolvedByName: "A" } },
    { id: "incident-1_2", data: { incidentId: "incident-1", deviceId, attemptNumber: 2, resolution: "Lần 2", outcome: "RESOLVED", resolvedByName: "B" } },
  );
  const rows = transformExcelExportData(data).byName.LS_KhacPhuc.rows;
  assert.equal(rows.length, 2);
  assert.deepEqual(rows.map((row) => row["Lần khắc phục"]), [1, 2]);
  assert.deepEqual(rows.map((row) => row["Kết quả khắc phục"]), [
    "Chưa đạt — sự cố tiếp tục mở",
    "Đạt — chờ xác minh",
  ]);
});

test("exports each verification record without inventing a separate result", () => {
  const data = baseData();
  const deviceId = data.devices[0].id;
  data.incidents.push({
    id: "incident-1",
    data: { deviceId, title: "Sự cố", status: "CLOSED" },
  });
  data.incidentVerifications.push({
    id: "incident-1",
    data: {
      incidentId: "incident-1",
      deviceId,
      attemptNumber: 1,
      note: "Thiết bị vận hành ổn định",
      verifiedByUid: "verifier",
      verifiedByName: "Người xác minh",
      verifiedAt: timestamp("2026-11-03T03:00:00Z"),
    },
  });
  const row = transformExcelExportData(data).byName.LS_XacMinh.rows[0];
  assert.equal(row["Người xác minh"], "Người xác minh");
  assert.equal(row["Kết quả xác minh"], "Thiết bị vận hành ổn định");
  assert.equal(row["Trạng thái đóng sự cố"], "Đã đóng");
});

test("flattens every plan criterion into the approved plan columns", () => {
  const data = baseData();
  const deviceId = data.devices[0].id;
  data.deviceInspectionPlans.push({
    id: deviceId,
    data: {
      deviceId,
      name: "Kế hoạch A",
      isActive: true,
      createdAt: timestamp("2026-11-01T00:00:00Z"),
      tasks: [{
        id: "t1",
        name: "Hạng mục 1",
        criteria: [{ id: "c1", standard: "Chuẩn 1" }, { id: "c2", standard: "Chuẩn 2" }],
      }],
    },
  });
  const rows = transformExcelExportData(data).byName.DM_TuanKiem.rows;
  assert.equal(rows.length, 2);
  assert.deepEqual(rows.map((row) => row["Tiêu chí kiểm tra"]), ["Chuẩn 1", "Chuẩn 2"]);
  assert.equal(rows[0]["Trạng thái kế hoạch"], "Đang hoạt động");
});

test("uses only the historical plan snapshot for inspection result labels", () => {
  const data = baseData();
  const deviceId = data.devices[0].id;
  data.deviceInspectionPlans.push({
    id: deviceId,
    data: { deviceId, name: "Kế hoạch hiện tại", tasks: [{ id: "t1", name: "Tên hiện tại", criteria: [{ id: "c1", standard: "Chuẩn hiện tại" }] }] },
  });
  data.inspectionResults.push({
    id: "result-1",
    data: {
      deviceId,
      inspectionDate: "2026-11-04",
      inspectorName: "Kiểm tra viên",
      note: "Ghi chú phiếu",
      planSnapshot: {
        name: "Kế hoạch lịch sử",
        tasks: [{ id: "t1", name: "Tên lịch sử", criteria: [{ id: "c1", standard: "Chuẩn lịch sử", unit: "°C" }] }],
      },
      results: [{
        taskId: "t1",
        status: "WARNING",
        note: "Ghi chú hạng mục",
        criteriaResults: [{ criterionId: "c1", status: "FAIL", numericValue: 90, note: "Ghi chú tiêu chí" }],
      }],
    },
  });
  const row = transformExcelExportData(data).byName.KQ_TuanKiem.rows[0];
  assert.equal(row["Tên kế hoạch"], "Kế hoạch lịch sử");
  assert.equal(row["Hạng mục kiểm tra"], "Tên lịch sử");
  assert.equal(row["Tiêu chí kiểm tra"], "Chuẩn lịch sử");
  assert.equal(row["Giá trị/Kết quả ghi nhận"], "90 °C");
  assert.equal(row["Đánh giá"], "Không đạt");
  assert.equal(
    row["Ghi chú"],
    "Tiêu chí: Ghi chú tiêu chí | Hạng mục: Ghi chú hạng mục | Phiếu: Ghi chú phiếu",
  );
});

test("keeps missing and invalid values blank and protects formula-like text", () => {
  const data = baseData();
  data.devices[0].data.code = "=DANGEROUS()";
  data.devices[0].data.name = "+SUM(1,1)";
  data.devices[0].data.status = "UNKNOWN";
  data.devices[0].data.createdAt = "not-a-date";
  const row = transformExcelExportData(data).byName.DM_ThietBi.rows[0];
  assert.equal(row["Mã thiết bị"], "'=DANGEROUS()");
  assert.equal(row["Tên thiết bị"], "'+SUM(1,1)");
  assert.equal(row["Trạng thái"], "");
  assert.equal(row["Ngày tạo"], "");
});

test("never exports an email address as a person's name", () => {
  const data = baseData();
  const deviceId = data.devices[0].id;
  data.incidents.push({ id: "incident-1", data: { deviceId, title: "Sự cố" } });
  data.incidentResolutions.push({
    id: "incident-1_1",
    data: {
      incidentId: "incident-1",
      deviceId,
      attemptNumber: 1,
      resolvedByUid: "uid-email",
      resolvedByName: "person@example.com",
    },
  });
  data.users.push({
    id: "uid-email",
    data: { displayName: "profile@example.com" },
  });
  const row = transformExcelExportData(data).byName.LS_KhacPhuc.rows[0];
  assert.equal(row["Người khắc phục"], "");
});

test("does not mutate source data or perform Firestore work in the transformer", () => {
  const data = baseData();
  const before = JSON.stringify(data);
  transformExcelExportData(data);
  assert.equal(JSON.stringify(data), before);
});

test("preserves all history/result row counts", () => {
  const data = baseData();
  const deviceId = data.devices[0].id;
  data.incidents.push({ id: "i1", data: { deviceId } });
  data.incidentResolutions.push(
    { id: "i1_1", data: { incidentId: "i1", deviceId } },
    { id: "i1_2", data: { incidentId: "i1", deviceId } },
  );
  data.incidentVerifications.push({ id: "i1", data: { incidentId: "i1", deviceId } });
  data.deviceInspectionPlans.push({
    id: deviceId,
    data: { deviceId, tasks: [{ id: "t1", criteria: [{ id: "c1" }, { id: "c2" }] }] },
  });
  data.inspectionResults.push({
    id: "r1",
    data: { deviceId, results: [{ taskId: "t1", criteriaResults: [{ criterionId: "c1" }, { criterionId: "c2" }] }] },
  });
  assert.deepEqual(
    transformExcelExportData(data).sheets.map((sheet) => sheet.rows.length),
    [1, 1, 2, 1, 2, 2],
  );
});

test("groups rows stably by device code and shows STT only on the first row", () => {
  const data = createEmptyExcelExportDataSet();
  data.devices.push(
    { id: "device-b", data: { code: "TB-02", name: "Thiết bị B" } },
    { id: "device-a", data: { code: "TB-01", name: "Thiết bị A" } },
  );
  data.incidents.push(
    { id: "incident-b-2", data: { deviceId: "device-b", title: "Sự cố 2" } },
    { id: "incident-a", data: { deviceId: "device-a", title: "Sự cố A" } },
    { id: "incident-b-1", data: { deviceId: "device-b", title: "Sự cố 1" } },
  );

  const output = transformExcelExportData(data);
  assert.deepEqual(
    output.byName.DM_SuCo.rows.map((row) => row["Mã thiết bị"]),
    ["TB-01", "TB-02", "TB-02"],
  );
  assert.deepEqual(
    output.byName.DM_SuCo.rows.map((row) => row.STT),
    [1, 2, ""],
  );
  assert.deepEqual(
    output.byName.DM_SuCo.rows.map((row) => row["Tiêu đề sự cố"]),
    ["Sự cố A", "Sự cố 1", "Sự cố 2"],
  );
  assert.deepEqual(
    output.byName.DM_ThietBi.rows.map((row) => row.STT),
    [1, 2],
  );

  const reversed = structuredClone(data);
  reversed.devices.reverse();
  reversed.incidents.reverse();
  assert.deepEqual(
    transformExcelExportData(reversed).sheets,
    output.sheets,
  );
});

test("treats every row without a device code as a separate STT group", () => {
  const data = createEmptyExcelExportDataSet();
  data.devices.push(
    { id: "missing-2", data: { name: "Không mã B" } },
    { id: "missing-1", data: { name: "Không mã A" } },
  );
  const rows = transformExcelExportData(data).byName.DM_ThietBi.rows;
  assert.equal(rows.length, 2);
  assert.deepEqual(rows.map((row) => row["Tên thiết bị"]), ["Không mã A", "Không mã B"]);
  assert.deepEqual(rows.map((row) => row.STT), [1, 2]);
});
