import assert from "node:assert/strict";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import test from "node:test";

import ExcelJS from "exceljs";

import { transformExcelExportData } from "../src/services/excelExportTransform.js";
import {
  createExcelExportFile,
  createExcelExportFileName,
  createExcelExportWorkbook,
  EXCEL_MAX_ROWS_PER_SHEET,
  ExcelExportWorkbookError,
} from "../src/services/excelExportWorkbook.js";
import { createEmptyExcelExportDataSet } from "../src/types/excelExport.js";

function sampleTables() {
  const data = createEmptyExcelExportDataSet();
  data.areas.push({ id: "area-1", data: { code: "KV-01", name: "Khu vực Điện" } });
  data.devices.push({
    id: "device-000000000000000000000001",
    data: {
      code: "=DANGEROUS()",
      name: "Máy biến áp số 1",
      areaId: "area-1",
      serialNumber: "000000000000012345",
      ipAddress: "10.10.20.30",
      macAddress: "AA:BB:CC:DD:EE:FF",
      createdAt: new Date(2026, 10, 4, 14, 30),
    },
  });
  data.inspectionResults.push({
    id: "result-1",
    data: {
      deviceId: data.devices[0].id,
      inspectionDate: "2026-11-04",
      planSnapshot: { name: "Kế hoạch lịch sử", tasks: [] },
      results: [],
    },
  });
  return transformExcelExportData(data);
}

function toArrayBuffer(data: Uint8Array): ArrayBuffer {
  const result = new ArrayBuffer(data.byteLength);
  new Uint8Array(result).set(data);
  return result;
}

function columnIndex(worksheet: ExcelJS.Worksheet, header: string): number {
  const values = worksheet.getRow(1).values;
  if (!Array.isArray(values)) return -1;
  return values.findIndex((value) => value === header);
}

test("creates exactly six sheets in the approved order", () => {
  const workbook = createExcelExportWorkbook(sampleTables());
  assert.deepEqual(
    workbook.worksheets.map((sheet) => sheet.name),
    [
      "DM_ThietBi", "DM_SuCo", "LS_KhacPhuc", "LS_XacMinh",
      "DM_TuanKiem", "KQ_TuanKiem",
    ],
  );
});

test("keeps empty sheets with header, filter and frozen pane", () => {
  const workbook = createExcelExportWorkbook(sampleTables());
  const sheet = workbook.getWorksheet("DM_SuCo");
  assert.ok(sheet);
  assert.equal(sheet.rowCount, 1);
  assert.equal(
    sheet.getCell("A1").value,
    "STT",
  );
  assert.ok(sheet.autoFilter);
  assert.equal(sheet.views[0]?.state, "frozen");
  assert.equal(sheet.views[0]?.ySplit, 1);
});

test("preserves Vietnamese text and text-formatted identifiers", () => {
  const workbook = createExcelExportWorkbook(sampleTables());
  const sheet = workbook.getWorksheet("DM_ThietBi");
  assert.ok(sheet);
  const nameIndex = columnIndex(sheet, "Tên thiết bị");
  assert.equal(sheet.getCell(2, nameIndex).value, "Máy biến áp số 1");
  for (const header of ["Mã thiết bị", "Địa chỉ IP"]) {
    const index = columnIndex(sheet, header);
    assert.ok(index > 0, `missing column ${header}`);
    assert.equal(sheet.getColumn(index).numFmt, "@");
    assert.equal(typeof sheet.getCell(2, index).value, "string");
  }
});

test("uses the approved 63 columns with wrapping for long content", () => {
  const workbook = createExcelExportWorkbook(sampleTables());
  assert.equal(
    workbook.worksheets.reduce(
      (total, worksheet) => total + worksheet.columnCount,
      0,
    ),
    63,
  );
  const incidents = workbook.getWorksheet("DM_SuCo");
  assert.ok(incidents);
  const descriptionIndex = columnIndex(incidents, "Mô tả sự cố");
  assert.equal(incidents.getColumn(descriptionIndex).alignment?.wrapText, true);
});

test("formats STT as the first centered column without merged cells", () => {
  const workbook = createExcelExportWorkbook(sampleTables());
  for (const worksheet of workbook.worksheets) {
    assert.equal(worksheet.getCell("A1").value, "STT");
    assert.equal(worksheet.getColumn(1).width, 7);
    assert.equal(worksheet.getColumn(1).alignment?.horizontal, "center");
    assert.deepEqual(worksheet.model.merges, []);
  }
});

test("writes Date values with the expected Excel number formats", () => {
  const workbook = createExcelExportWorkbook(sampleTables());
  const devices = workbook.getWorksheet("DM_ThietBi");
  const results = workbook.getWorksheet("KQ_TuanKiem");
  assert.ok(devices && results);
  const createdIndex = columnIndex(devices, "Ngày tạo");
  const inspectionIndex = columnIndex(results, "Ngày kiểm tra");
  assert.ok(devices.getCell(2, createdIndex).value instanceof Date);
  assert.equal(devices.getCell(2, createdIndex).numFmt, "dd/mm/yyyy hh:mm");
  assert.ok(results.getCell(2, inspectionIndex).value instanceof Date);
  assert.equal(results.getCell(2, inspectionIndex).numFmt, "dd/mm/yyyy");
});

test("keeps protected dangerous strings as text, never formulas", async () => {
  const file = await createExcelExportFile(sampleTables(), new Date(2026, 10, 4, 9, 8, 7));
  const reopened = new ExcelJS.Workbook();
  await reopened.xlsx.load(toArrayBuffer(file.data));
  const sheet = reopened.getWorksheet("DM_ThietBi");
  assert.ok(sheet);
  const codeIndex = columnIndex(sheet, "Mã thiết bị");
  const cell = sheet.getCell(2, codeIndex);
  assert.equal(cell.value, "'=DANGEROUS()");
  assert.equal(typeof cell.value, "string");
  assert.equal(cell.formula, undefined);
});

test("rejects unprotected formula-like strings", () => {
  const tables = sampleTables();
  tables.byName.DM_ThietBi.rows[0]["Tên thiết bị"] = "+SUM(1,1)";
  assert.throws(
    () => createExcelExportWorkbook(tables),
    (error) => error instanceof ExcelExportWorkbookError &&
      error.message.includes("Chuỗi chưa được bảo vệ"),
  );
});

test("rejects a sheet that exceeds the Excel row limit including header", () => {
  const tables = transformExcelExportData(createEmptyExcelExportDataSet());
  tables.byName.DM_ThietBi.rows.length = EXCEL_MAX_ROWS_PER_SHEET;
  assert.throws(
    () => createExcelExportWorkbook(tables),
    (error) => error instanceof ExcelExportWorkbookError &&
      error.message.includes("vượt giới hạn"),
  );
});

test("serializes, saves and reopens a local XLSX test artifact", async () => {
  const now = new Date(2026, 10, 4, 9, 8, 7);
  const file = await createExcelExportFile(sampleTables(), now);
  assert.equal(file.fileName, "QuanLyThietBi_20261104_090807.xlsx");

  const artifactDirectory = path.join(
    process.cwd(),
    "node_modules",
    ".tmp",
    "excel-tests",
    "artifacts",
  );
  await mkdir(artifactDirectory, { recursive: true });
  const artifactPath = path.join(artifactDirectory, file.fileName);
  await writeFile(artifactPath, file.data);

  const reopened = new ExcelJS.Workbook();
  await reopened.xlsx.load(toArrayBuffer(file.data));
  assert.equal(reopened.worksheets.length, 6);
  assert.equal(reopened.getWorksheet("DM_ThietBi")?.rowCount, 2);
  assert.equal(reopened.getWorksheet("DM_SuCo")?.rowCount, 1);
});

test("creates the requested local-time filename", () => {
  assert.equal(
    createExcelExportFileName(new Date(2026, 0, 2, 3, 4, 5)),
    "QuanLyThietBi_20260102_030405.xlsx",
  );
});
