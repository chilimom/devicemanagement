import { readFileSync } from "node:fs";
import test, { after, before, beforeEach } from "node:test";
import * as rulesTesting from "@firebase/rules-unit-testing";
import * as firestore from "firebase/firestore";

const integrationTest = test;
let testEnvironment;

const ids = {
  admin: "admin-test",
  areaAdmin1: "area-admin-lg1-test",
  areaAdmin2: "area-admin-lg2-test",
  lg1: "user-lg1-test",
  lg2: "user-lg2-test",
  multi: "user-multi-test",
  none: "user-none-test",
  inactive: "user-inactive-test",
  area1: "area-lg1-test",
  area2: "area-lg2-test",
  device1: "device-lg1-test",
  device2: "device-lg2-test",
  incident1: "incident-lg1-test",
  incident2: "incident-lg2-test",
  legacy: "incident-legacy-test",
  plan1: "device-lg1-test",
};

function profile(role, areaIds, isActive = true) {
  return { role, areaIds, isActive, displayName: role, email: `${role}@test.local` };
}

async function seed() {
  await testEnvironment.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    const { doc, setDoc, serverTimestamp } = firestore;

    await Promise.all([
      setDoc(doc(db, "users", ids.admin), profile("ADMIN", [])),
      setDoc(doc(db, "users", ids.areaAdmin1), profile("AREA_ADMIN", [ids.area1])),
      setDoc(doc(db, "users", ids.areaAdmin2), profile("AREA_ADMIN", [ids.area2])),
      setDoc(doc(db, "users", ids.lg1), profile("USER", [ids.area1])),
      setDoc(doc(db, "users", ids.lg2), profile("USER", [ids.area2])),
      setDoc(doc(db, "users", ids.multi), profile("USER", [ids.area1, ids.area2])),
      setDoc(doc(db, "users", ids.none), profile("USER", [])),
      setDoc(doc(db, "users", ids.inactive), profile("USER", [ids.area1], false)),
      setDoc(doc(db, "areas", ids.area1), { code: "LG1", name: "LG1" }),
      setDoc(doc(db, "areas", ids.area2), { code: "LG2", name: "LG2" }),
      setDoc(doc(db, "subAreas", "lc1"), { factoryId: ids.area1, code: "LC1", name: "Line 1", status: "ACTIVE" }),
      setDoc(doc(db, "subAreas", "lc2"), { factoryId: ids.area2, code: "LC2", name: "Line 2", status: "ACTIVE" }),
      setDoc(doc(db, "deviceTypes", "type"), {
        code: "GLOBAL", name: "Global type", categoryId: "category-1", areaIds: [], isActive: true,
      }),
      setDoc(doc(db, "devices", ids.device1), { areaId: ids.area1, deviceTypeId: "type", isActive: true, code: "CAM-LG1" }),
      setDoc(doc(db, "devices", ids.device2), { areaId: ids.area2, deviceTypeId: "type", isActive: true, code: "CK-001" }),
      setDoc(doc(db, "deviceInspectionPlans", ids.plan1), {
        deviceId: ids.device1, isActive: true, version: 1, tasks: [], name: "LG1 plan",
      }),
      setDoc(doc(db, "deviceInspectionPlans", ids.device2), {
        deviceId: ids.device2, isActive: true, version: 1, tasks: [{ id: "task-lg2" }], name: "LG2 plan",
      }),
      setDoc(doc(db, "incidents", ids.incident1), {
        deviceId: ids.device1, title: "LG1 incident", status: "OPEN", resolution: "",
        resolvedAt: null, reportedAt: serverTimestamp(), resolutionAttemptCount: 0,
      }),
      setDoc(doc(db, "incidents", ids.incident2), {
        deviceId: ids.device2, title: "LG2 incident", status: "OPEN", resolution: "",
        resolvedAt: null, reportedAt: serverTimestamp(), resolutionAttemptCount: 0,
      }),
      setDoc(doc(db, "incidents", ids.legacy), {
        title: "legacy", status: "CLOSED", resolution: "old", resolvedAt: serverTimestamp(),
      }),
      setDoc(doc(db, "maintenances", "maintenance-lg2-test"), { deviceId: ids.device2 }),
      setDoc(doc(db, "maintenances", "maintenance-legacy-test"), { deviceCode: "OLD" }),
      setDoc(doc(db, "publicPortal", "current"), { generation: "test-generation", publishedAt: serverTimestamp() }),
      setDoc(doc(db, "publicDevices", ids.device1), {
        code: "CAM-LG1", name: "Camera", areaId: ids.area1, areaName: "LG1",
        categoryName: "CNTT", deviceTypeName: "Camera", status: "ACTIVE", isActive: true,
        inspectionState: "NO_PLAN", inspectionCount: 0, generation: "test-generation",
      }),
    ]);
  });
}

function userDb(uid) {
  return testEnvironment.authenticatedContext(uid).firestore();
}

function verifiedUserDb(uid, email) {
  return testEnvironment.authenticatedContext(uid, {
    email,
    email_verified: true,
  }).firestore();
}

function guestDb() {
  return testEnvironment.unauthenticatedContext().firestore();
}

before(async () => {
  testEnvironment = await rulesTesting.initializeTestEnvironment({
    projectId: "device-management-rules-test",
    firestore: {
      rules: readFileSync("firestore.rules", "utf8"),
    },
  });
});

beforeEach(async () => {
  await testEnvironment.clearFirestore();
  await seed();
});

after(async () => {
  if (testEnvironment) await testEnvironment.cleanup();
});

integrationTest("area/device/history access follows the device current area", async () => {
  const { collection, doc, getDoc, getDocs, query, where } = firestore;

  await rulesTesting.assertSucceeds(getDoc(doc(userDb(ids.lg1), "devices", ids.device1)));
  await rulesTesting.assertFails(getDoc(doc(userDb(ids.lg1), "devices", ids.device2)));
  await rulesTesting.assertSucceeds(getDoc(doc(userDb(ids.lg1), "incidents", ids.incident1)));
  await rulesTesting.assertFails(getDoc(doc(userDb(ids.lg1), "incidents", ids.incident2)));
  await rulesTesting.assertFails(getDocs(query(
    collection(userDb(ids.lg1), "incidents"), where("deviceId", "==", ids.device2),
  )));
  await rulesTesting.assertFails(getDocs(query(
    collection(userDb(ids.lg1), "devices"), where("code", "==", "CAM-LG1"),
  )));
  await rulesTesting.assertFails(getDoc(doc(userDb(ids.lg1), "incidents", ids.legacy)));
  await rulesTesting.assertSucceeds(getDoc(doc(userDb(ids.admin), "incidents", ids.legacy)));
  await rulesTesting.assertSucceeds(getDoc(doc(userDb(ids.multi), "devices", ids.device2)));
  await rulesTesting.assertFails(getDoc(doc(userDb(ids.none), "devices", ids.device1)));
  await rulesTesting.assertFails(getDoc(doc(userDb(ids.inactive), "devices", ids.device1)));
});

integrationTest("subareas stay scoped to their factory and device links must match", async () => {
  const { collection, doc, getDoc, getDocs, query, setDoc, where } = firestore;
  await rulesTesting.assertSucceeds(getDoc(doc(userDb(ids.lg1), "subAreas", "lc1")));
  await rulesTesting.assertFails(getDoc(doc(userDb(ids.lg1), "subAreas", "lc2")));
  await rulesTesting.assertSucceeds(getDocs(query(collection(userDb(ids.lg1), "subAreas"), where("factoryId", "==", ids.area1))));
  await rulesTesting.assertFails(getDocs(collection(userDb(ids.lg1), "subAreas")));
  await rulesTesting.assertSucceeds(setDoc(doc(userDb(ids.admin), "devices", "new-legacy"), {
    areaId: ids.area1, deviceTypeId: "type", isActive: true, code: "LEGACY", subAreaId: "",
  }));
  await rulesTesting.assertSucceeds(setDoc(doc(userDb(ids.admin), "devices", "new-linked"), {
    areaId: ids.area1, deviceTypeId: "type", isActive: true, code: "LINKED", subAreaId: "lc1",
  }));
  await rulesTesting.assertFails(setDoc(doc(userDb(ids.admin), "devices", "wrong-linked"), {
    areaId: ids.area1, deviceTypeId: "type", isActive: true, code: "WRONG", subAreaId: "lc2",
  }));
});

integrationTest("guest reads only current public summaries and cannot write business data", async () => {
  const { collection, doc, getDoc, getDocs, query, setDoc, where } = firestore;

  await rulesTesting.assertSucceeds(getDoc(doc(guestDb(), "publicPortal", "current")));
  await rulesTesting.assertSucceeds(getDocs(query(
    collection(guestDb(), "publicDevices"),
    where("generation", "==", "test-generation"),
  )));
  await rulesTesting.assertFails(getDoc(doc(guestDb(), "devices", ids.device1)));
  await rulesTesting.assertFails(setDoc(doc(guestDb(), "publicDevices", "forged"), {
    code: "X", name: "X", areaId: ids.area1, areaName: "LG1", categoryName: "CNTT", deviceTypeName: "X",
    status: "ACTIVE", isActive: true, inspectionState: "NO_PLAN",
    inspectionCount: 0, generation: "test-generation",
  }));
});

integrationTest("USER cannot create an incident or inspection result outside the current area", async () => {
  const { addDoc, collection, serverTimestamp } = firestore;
  const db = userDb(ids.lg1);

  await rulesTesting.assertFails(addDoc(collection(db, "incidents"), {
    deviceId: ids.device2, title: "forbidden", status: "OPEN", resolution: "",
    resolvedAt: null, reportedAt: serverTimestamp(),
  }));
  await rulesTesting.assertFails(addDoc(collection(db, "inspectionResults"), {
    deviceId: ids.device2, planId: ids.device2, planVersion: 1,
    inspectionDate: "2026-11-02", inspectionType: "EXTRA", inspectorName: "LG1",
    recordedByUid: ids.lg1, results: [], note: "", planSnapshot: {}, createdAt: serverTimestamp(),
  }));
});

integrationTest("inspection retest may link to a source result on the same device", async () => {
  const { collection, addDoc, doc, serverTimestamp } = firestore;
  const db = userDb(ids.lg1);
  const sourceId = "failed-inspection-source";

  await testEnvironment.withSecurityRulesDisabled(async (context) => {
    await firestore.setDoc(firestore.doc(context.firestore(), "inspectionResults", sourceId), {
      deviceId: ids.device1,
      results: [{ taskId: "task-1", criteriaResults: [{ criterionId: "criterion-1", status: "FAIL" }] }],
    });
  });

  await rulesTesting.assertSucceeds(addDoc(collection(db, "inspectionResults"), {
    deviceId: ids.device1,
    planId: ids.device1,
    planVersion: 1,
    inspectionDate: "2026-11-12",
    inspectionType: "EXTRA",
    inspectorName: "LG1",
    recordedByUid: ids.lg1,
    results: [{ taskId: "task-1", status: "PASS", criteriaResults: [{ criterionId: "criterion-1", status: "PASS" }] }],
    note: "Đã khắc phục",
    planSnapshot: { name: "LG1 plan", version: 1, tasks: [] },
    remediationSource: { recordId: sourceId, taskId: "task-1", criterionId: "criterion-1" },
    createdAt: serverTimestamp(),
  }));

  await rulesTesting.assertFails(setDoc(doc(db, "inspectionResults", "wrong-source-device"), {
    deviceId: ids.device1,
    planId: ids.device1,
    planVersion: 1,
    inspectionDate: "2026-11-12",
    inspectionType: "EXTRA",
    inspectorName: "LG1",
    recordedByUid: ids.lg1,
    results: [{ taskId: "task-1", status: "PASS", criteriaResults: [{ criterionId: "criterion-1", status: "PASS" }] }],
    note: "",
    planSnapshot: { name: "LG1 plan", version: 1, tasks: [] },
    remediationSource: { recordId: ids.incident2, taskId: "task-1", criterionId: "criterion-1" },
    createdAt: serverTimestamp(),
  }));
});

integrationTest("resolution transaction permits OPEN to OPEN or RESOLVED only with matching history", async () => {
  const { doc, serverTimestamp, writeBatch } = firestore;
  const db = userDb(ids.lg1);
  const batch = writeBatch(db);
  batch.set(doc(db, "incidentResolutions", `${ids.incident1}_1`), {
    incidentId: ids.incident1, deviceId: ids.device1, resolution: "retry", attemptNumber: 1,
    resolvedByUid: ids.lg1, resolvedByName: "LG1", resolvedByEmail: "", resolvedAt: serverTimestamp(), outcome: "OPEN",
  });
  batch.update(doc(db, "incidents", ids.incident1), {
    resolutionAttemptCount: 1, lastResolutionAttemptAt: serverTimestamp(), lastResolutionAttemptByUid: ids.lg1,
  });
  await rulesTesting.assertSucceeds(batch.commit());

  const resolved = writeBatch(db);
  resolved.set(doc(db, "incidentResolutions", `${ids.incident1}_2`), {
    incidentId: ids.incident1, deviceId: ids.device1, resolution: "fixed", attemptNumber: 2,
    resolvedByUid: ids.lg1, resolvedByName: "LG1", resolvedByEmail: "", resolvedAt: serverTimestamp(), outcome: "RESOLVED",
  });
  resolved.update(doc(db, "incidents", ids.incident1), {
    status: "RESOLVED", resolution: "fixed", resolvedAt: serverTimestamp(), resolvedByUid: ids.lg1,
    resolutionCount: 2, resolutionAttemptCount: 2, lastResolutionAttemptAt: serverTimestamp(),
    lastResolutionAttemptByUid: ids.lg1,
  });
  await rulesTesting.assertSucceeds(resolved.commit());

  const standalone = writeBatch(db);
  standalone.set(doc(db, "incidentResolutions", "standalone_1"), {
    incidentId: "standalone", deviceId: ids.device1, resolution: "forged", attemptNumber: 1,
    resolvedByUid: ids.lg1, resolvedByName: "LG1", resolvedByEmail: "", resolvedAt: serverTimestamp(), outcome: "RESOLVED",
  });
  await rulesTesting.assertFails(standalone.commit());
});

integrationTest("verification requires RESOLVED to CLOSED and its fixed incident ID", async () => {
  const { doc, getDoc, serverTimestamp, setDoc, writeBatch } = firestore;
  await testEnvironment.withSecurityRulesDisabled(async (context) => {
    await setDoc(doc(context.firestore(), "incidents", "resolved-test"), {
      deviceId: ids.device1, title: "resolved", status: "RESOLVED", resolution: "done",
      resolvedAt: serverTimestamp(), resolvedByUid: ids.lg1, resolutionCount: 1,
      resolutionAttemptCount: 1,
    });
  });

  const db = userDb(ids.lg1);
  const batch = writeBatch(db);
  batch.set(doc(db, "incidentVerifications", "resolved-test"), {
    incidentId: "resolved-test", deviceId: ids.device1, note: "verified", attemptNumber: 1,
    verifiedByUid: ids.lg1, verifiedByName: "LG1", verifiedByEmail: "", verifiedAt: serverTimestamp(),
  });
  batch.update(doc(db, "incidents", "resolved-test"), {
    status: "CLOSED", verificationCount: 1, lastVerifiedByUid: ids.lg1,
    lastVerifiedByName: "LG1", lastVerifiedAt: serverTimestamp(), closedAt: serverTimestamp(),
  });
  await rulesTesting.assertSucceeds(batch.commit());

  await rulesTesting.assertFails(setDoc(doc(db, "incidentVerifications", "resolved-test"), {
    incidentId: "resolved-test", deviceId: ids.device1, note: "repeat", attemptNumber: 1,
    verifiedByUid: ids.lg1, verifiedByName: "LG1", verifiedByEmail: "", verifiedAt: serverTimestamp(),
  }));

  await rulesTesting.assertFails(setDoc(doc(db, "incidentVerifications", "forged"), {
    incidentId: "forged", deviceId: ids.device1, note: "forged", attemptNumber: 1,
    verifiedByUid: ids.admin, verifiedByName: "admin", verifiedByEmail: "", verifiedAt: serverTimestamp(),
  }));

  await testEnvironment.withSecurityRulesDisabled(async (context) => {
    await setDoc(doc(context.firestore(), "incidents", "area-admin-resolved-test"), {
      deviceId: ids.device1, title: "resolved", status: "RESOLVED", resolution: "done",
      resolvedAt: serverTimestamp(), resolvedByUid: ids.areaAdmin1, resolutionCount: 1,
      resolutionAttemptCount: 1,
    });
  });
  const areaAdminDb = userDb(ids.areaAdmin1);
  await rulesTesting.assertSucceeds(getDoc(doc(
    areaAdminDb,
    "incidentVerifications",
    "area-admin-resolved-test",
  )));
  await rulesTesting.assertFails(getDoc(doc(
    userDb(ids.lg2),
    "incidentVerifications",
    "area-admin-resolved-test",
  )));
  const areaAdminVerification = writeBatch(areaAdminDb);
  areaAdminVerification.set(doc(areaAdminDb, "incidentVerifications", "area-admin-resolved-test"), {
    incidentId: "area-admin-resolved-test", deviceId: ids.device1, note: "verified", attemptNumber: 1,
    verifiedByUid: ids.areaAdmin1, verifiedByName: "Area Admin", verifiedByEmail: "", verifiedAt: serverTimestamp(),
  });
  areaAdminVerification.update(doc(areaAdminDb, "incidents", "area-admin-resolved-test"), {
    status: "CLOSED", verificationCount: 1, lastVerifiedByUid: ids.areaAdmin1,
    lastVerifiedByName: "Area Admin", lastVerifiedAt: serverTimestamp(), closedAt: serverTimestamp(),
  });
  await rulesTesting.assertSucceeds(areaAdminVerification.commit());
});

integrationTest("active scoped callers may check missing incident IDs without reading outside incidents", async () => {
  const { doc, getDoc, runTransaction, serverTimestamp } = firestore;
  await rulesTesting.assertSucceeds(getDoc(doc(userDb(ids.lg1), "incidents", "not-created-yet")));
  await rulesTesting.assertSucceeds(getDoc(doc(userDb(ids.areaAdmin1), "incidents", "not-created-yet")));
  await rulesTesting.assertFails(getDoc(doc(userDb(ids.lg1), "incidents", ids.incident2)));
  await rulesTesting.assertFails(getDoc(doc(guestDb(), "incidents", "not-created-yet")));

  const scopedDb = userDb(ids.lg1);
  const newIncidentRef = doc(scopedDb, "incidents", "inspection-source-test");
  await rulesTesting.assertSucceeds(runTransaction(scopedDb, async (transaction) => {
    const existing = await transaction.get(newIncidentRef);
    if (existing.exists()) throw new Error("Incident already exists in test data.");
    transaction.set(newIncidentRef, {
      deviceId: ids.device1,
      title: "Inspection failure",
      status: "OPEN",
      resolution: "",
      resolvedAt: null,
      reportedAt: serverTimestamp(),
    });
  }));
});

integrationTest("access is revoked and history follows a device transfer", async () => {
  const { doc, getDoc, setDoc } = firestore;
  await testEnvironment.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await setDoc(doc(db, "users", ids.lg1), profile("USER", []));
  });
  await rulesTesting.assertFails(getDoc(doc(userDb(ids.lg1), "incidents", ids.incident1)));

  await testEnvironment.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await setDoc(doc(db, "devices", ids.device1), { areaId: ids.area2, isActive: true, code: "CAM-LG1" });
  });
  await rulesTesting.assertFails(getDoc(doc(userDb(ids.lg1), "incidents", ids.incident1)));
  await rulesTesting.assertSucceeds(getDoc(doc(userDb(ids.lg2), "incidents", ids.incident1)));
});

integrationTest("AREA_ADMIN is scoped for device reads, creates and transfers", async () => {
  const { addDoc, collection, doc, getDoc, serverTimestamp, setDoc, updateDoc } = firestore;
  const db = userDb(ids.areaAdmin1);

  await rulesTesting.assertSucceeds(getDoc(doc(db, "devices", ids.device1)));
  await rulesTesting.assertFails(getDoc(doc(db, "devices", ids.device2)));
  await rulesTesting.assertSucceeds(getDoc(doc(db, "devices", "area-admin-unused-code")));
  await rulesTesting.assertFails(getDoc(doc(userDb(ids.lg1), "devices", "user-unused-code")));
  await rulesTesting.assertSucceeds(setDoc(doc(db, "devices", "area-admin-created"), {
    code: "AREA-ADMIN-CREATED", name: "Allowed", areaId: ids.area1,
    deviceTypeId: "type", isActive: true, status: "ACTIVE",
    createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
  }));
  await rulesTesting.assertSucceeds(addDoc(collection(db, "inspectionResults"), {
    deviceId: ids.device1, planId: ids.device1, planVersion: 1,
    inspectionDate: "2026-11-16", inspectionType: "SCHEDULED",
    inspectorName: "Area admin", recordedByUid: ids.areaAdmin1,
    results: [{ taskId: "task-1", status: "PASS", criteriaResults: [] }],
    note: "", planSnapshot: { name: "LG1 plan", version: 1, tasks: [] },
    createdAt: serverTimestamp(),
  }));
  await rulesTesting.assertFails(addDoc(collection(db, "inspectionResults"), {
    deviceId: ids.device2, planId: ids.device2, planVersion: 1,
    inspectionDate: "2026-11-16", inspectionType: "SCHEDULED",
    inspectorName: "Area admin", recordedByUid: ids.areaAdmin1,
    results: [{ taskId: "task-1", status: "PASS", criteriaResults: [] }],
    note: "", planSnapshot: { name: "LG2 plan", version: 1, tasks: [] },
    createdAt: serverTimestamp(),
  }));
  await rulesTesting.assertFails(setDoc(doc(db, "devices", "area-admin-forbidden"), {
    code: "AREA-ADMIN-FORBIDDEN", name: "Denied", areaId: ids.area2,
    deviceTypeId: "type", isActive: true, status: "ACTIVE",
    createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
  }));
  await rulesTesting.assertFails(updateDoc(doc(db, "devices", ids.device1), {
    areaId: ids.area2,
  }));
});

integrationTest("AREA_ADMIN cannot grant outside scope, grant ADMIN, edit ADMIN or self-escalate", async () => {
  const { doc, setDoc, updateDoc } = firestore;
  const db = userDb(ids.areaAdmin1);

  await rulesTesting.assertFails(setDoc(doc(db, "users", "outside-user"),
    profile("USER", [ids.area2])));
  await rulesTesting.assertFails(setDoc(doc(db, "users", "new-admin"),
    profile("ADMIN", [])));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.admin), { isActive: false }));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.areaAdmin1), {
    role: "ADMIN", areaIds: [ids.area1, ids.area2],
  }));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.lg1), {
    areaIds: [ids.area1, ids.area2],
  }));
  await rulesTesting.assertSucceeds(updateDoc(doc(db, "users", ids.lg1), {
    displayName: "Managed LG1", role: "USER", areaIds: [ids.area1],
    isActive: false, email: "USER@test.local",
  }));
});

integrationTest("AREA_ADMIN cannot get, lock, update or demote an ADMIN", async () => {
  const { doc, getDoc, updateDoc } = firestore;
  const db = userDb(ids.areaAdmin1);

  await rulesTesting.assertFails(getDoc(doc(db, "users", ids.admin)));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.admin), {
    displayName: "Compromised admin",
  }));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.admin), {
    isActive: false,
  }));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.admin), {
    role: "USER",
    areaIds: [ids.area1],
  }));
});

integrationTest("AREA_ADMIN cannot get or update another AREA_ADMIN", async () => {
  const { doc, getDoc, updateDoc } = firestore;
  const db = userDb(ids.areaAdmin1);

  await rulesTesting.assertFails(getDoc(doc(db, "users", ids.areaAdmin2)));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.areaAdmin2), {
    role: "USER",
    areaIds: [ids.area1],
    isActive: false,
  }));
});

integrationTest("AREA_ADMIN keeps self-profile get, may create scoped USER, and cannot delete users", async () => {
  const { deleteDoc, doc, getDoc, setDoc } = firestore;
  const db = userDb(ids.areaAdmin1);

  await rulesTesting.assertSucceeds(getDoc(doc(db, "users", ids.areaAdmin1)));
  await rulesTesting.assertSucceeds(setDoc(doc(db, "users", "direct-created-user"), {
    displayName: "Direct user",
    email: "direct@test.local",
    role: "USER",
    areaIds: [ids.area1],
    isActive: true,
  }));
  await rulesTesting.assertFails(deleteDoc(doc(db, "users", ids.lg1)));
});

integrationTest("ADMIN may directly create USER and AREA_ADMIN but not another ADMIN", async () => {
  const { doc, setDoc } = firestore;
  const db = userDb(ids.admin);
  await rulesTesting.assertSucceeds(setDoc(doc(db, "users", "admin-created-user"), {
    displayName: "Created user", email: "created-user@test.local",
    role: "USER", areaIds: [ids.area1], isActive: true,
  }));
  await rulesTesting.assertSucceeds(setDoc(doc(db, "users", "admin-created-area-admin"), {
    displayName: "Created area admin", email: "created-area-admin@test.local",
    role: "AREA_ADMIN", areaIds: [ids.area1], isActive: true,
  }));
  await rulesTesting.assertFails(setDoc(doc(db, "users", "admin-created-admin"), {
    displayName: "Created admin", email: "created-admin@test.local",
    role: "ADMIN", areaIds: [], isActive: true,
  }));
});

integrationTest("AREA_ADMIN direct profile create is limited to USER inside scope", async () => {
  const { doc, setDoc } = firestore;
  const db = userDb(ids.areaAdmin1);
  await rulesTesting.assertFails(setDoc(doc(db, "users", "area-created-area-admin"), {
    displayName: "Forbidden role", email: "forbidden-role@test.local",
    role: "AREA_ADMIN", areaIds: [ids.area1], isActive: true,
  }));
  await rulesTesting.assertFails(setDoc(doc(db, "users", "area-created-outside"), {
    displayName: "Outside", email: "outside@test.local",
    role: "USER", areaIds: [ids.area2], isActive: true,
  }));
});

integrationTest("provisioning activation requires matching profile in the same atomic batch", async () => {
  const { doc, serverTimestamp, setDoc, writeBatch } = firestore;
  const email = "direct-provision@test.local";
  const uid = "direct-provision-user";
  const db = userDb(ids.areaAdmin1);
  await rulesTesting.assertSucceeds(setDoc(doc(db, "accountProvisioningAttempts", email), {
    email, displayName: "Direct provision", role: "USER", areaIds: [ids.area1],
    status: "PENDING_AUTH", createdByUid: ids.areaAdmin1, targetUid: null,
    createdAt: serverTimestamp(), updatedAt: serverTimestamp(), errorCode: "",
  }));

  const standalone = writeBatch(db);
  standalone.update(doc(db, "accountProvisioningAttempts", email), {
    status: "ACTIVE", targetUid: uid, updatedAt: serverTimestamp(), errorCode: "",
  });
  await rulesTesting.assertFails(standalone.commit());

  const atomic = writeBatch(db);
  atomic.set(doc(db, "users", uid), {
    displayName: "Direct provision", email, role: "USER", areaIds: [ids.area1], isActive: true,
  });
  atomic.update(doc(db, "accountProvisioningAttempts", email), {
    status: "ACTIVE", targetUid: uid, updatedAt: serverTimestamp(), errorCode: "",
  });
  await rulesTesting.assertSucceeds(atomic.commit());
});

integrationTest("provisioning reads allow CHECK_ATTEMPT without exposing another manager's data", async () => {
  const { collection, doc, getDoc, getDocs, query, serverTimestamp, setDoc, where } = firestore;
  const db = userDb(ids.areaAdmin1);
  const ownEmail = "owned-provision@test.local";
  const otherEmail = "other-provision@test.local";

  await rulesTesting.assertSucceeds(getDoc(doc(db, "accountProvisioningAttempts", ownEmail)));
  await rulesTesting.assertSucceeds(setDoc(doc(db, "accountProvisioningAttempts", ownEmail), {
    email: ownEmail, displayName: "Owned provision", role: "USER", areaIds: [ids.area1],
    status: "PENDING_AUTH", createdByUid: ids.areaAdmin1, targetUid: null,
    createdAt: serverTimestamp(), updatedAt: serverTimestamp(), errorCode: "",
  }));
  await testEnvironment.withSecurityRulesDisabled(async (context) => {
    await setDoc(doc(context.firestore(), "accountProvisioningAttempts", otherEmail), {
      email: otherEmail, displayName: "Other provision", role: "USER", areaIds: [ids.area2],
      status: "PENDING_AUTH", createdByUid: ids.areaAdmin2, targetUid: null,
      createdAt: serverTimestamp(), updatedAt: serverTimestamp(), errorCode: "",
    });
  });

  await rulesTesting.assertSucceeds(getDoc(doc(db, "accountProvisioningAttempts", ownEmail)));
  await rulesTesting.assertFails(getDoc(doc(db, "accountProvisioningAttempts", otherEmail)));
  await rulesTesting.assertSucceeds(getDocs(query(
    collection(db, "accountProvisioningAttempts"),
    where("createdByUid", "==", ids.areaAdmin1),
  )));
  await rulesTesting.assertFails(getDocs(collection(db, "accountProvisioningAttempts")));
  await rulesTesting.assertSucceeds(getDocs(collection(
    userDb(ids.admin), "accountProvisioningAttempts",
  )));
});

integrationTest("AREA_ADMIN cannot change its own role, scope or active state", async () => {
  const { doc, updateDoc } = firestore;
  const db = userDb(ids.areaAdmin1);

  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.areaAdmin1), {
    role: "ADMIN",
  }));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.areaAdmin1), {
    areaIds: [ids.area1, ids.area2],
  }));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.areaAdmin1), {
    isActive: false,
  }));
});

integrationTest("AREA_ADMIN may update only USER profiles inside scope before and after", async () => {
  const { doc, updateDoc } = firestore;
  const db = userDb(ids.areaAdmin1);

  await rulesTesting.assertSucceeds(updateDoc(doc(db, "users", ids.lg1), {
    displayName: "Updated by area admin",
    isActive: false,
  }));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.lg2), {
    displayName: "Outside scope",
  }));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.lg1), {
    areaIds: [ids.area1, ids.area2],
  }));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.lg1), {
    areaIds: [ids.area2],
  }));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.lg1), {
    role: "AREA_ADMIN",
  }));
});

integrationTest("AREA_ADMIN cannot create an AREA_ADMIN through the invite path", async () => {
  const { doc, serverTimestamp, setDoc } = firestore;
  const db = userDb(ids.areaAdmin1);

  await rulesTesting.assertFails(setDoc(doc(db, "invites", "forbidden-admin@test.local"), {
    email: "forbidden-admin@test.local",
    displayName: "Forbidden area admin",
    role: "AREA_ADMIN",
    areaIds: [ids.area1],
    status: "PENDING",
    createdByUid: ids.areaAdmin1,
    createdAt: serverTimestamp(),
    acceptedByUid: null,
    acceptedAt: null,
  }));
  await rulesTesting.assertSucceeds(setDoc(doc(db, "invites", "allowed-user@test.local"), {
    email: "allowed-user@test.local",
    displayName: "Allowed user",
    role: "USER",
    areaIds: [ids.area1],
    status: "PENDING",
    createdByUid: ids.areaAdmin1,
    createdAt: serverTimestamp(),
    acceptedByUid: null,
    acceptedAt: null,
  }));
});

integrationTest("verified invite is accepted atomically and cannot be reused", async () => {
  const { doc, getDoc, serverTimestamp, setDoc, writeBatch } = firestore;
  const email = "invited@test.local";
  const invitedUid = "invited-user-test";
  await testEnvironment.withSecurityRulesDisabled(async (context) => {
    await setDoc(doc(context.firestore(), "invites", email), {
      email, displayName: "Invited", role: "USER", areaIds: [ids.area1],
      status: "PENDING", createdByUid: ids.admin, createdAt: serverTimestamp(),
      acceptedByUid: null, acceptedAt: null,
    });
  });

  const db = verifiedUserDb(invitedUid, email);
  const batch = writeBatch(db);
  batch.set(doc(db, "users", invitedUid), {
    displayName: "Invited", email, role: "USER", areaIds: [ids.area1], isActive: true,
  });
  batch.update(doc(db, "invites", email), {
    status: "ACCEPTED", acceptedByUid: invitedUid, acceptedAt: serverTimestamp(),
  });
  await rulesTesting.assertSucceeds(batch.commit());
  await rulesTesting.assertSucceeds(getDoc(doc(db, "users", invitedUid)));

  const reuse = verifiedUserDb("second-invited-user", email);
  const secondBatch = writeBatch(reuse);
  secondBatch.set(doc(reuse, "users", "second-invited-user"), {
    displayName: "Invited", email, role: "USER", areaIds: [ids.area1], isActive: true,
  });
  secondBatch.update(doc(reuse, "invites", email), {
    status: "ACCEPTED", acceptedByUid: "second-invited-user", acceptedAt: serverTimestamp(),
  });
  await rulesTesting.assertFails(secondBatch.commit());
});

integrationTest("unverified or uninvited users cannot create profiles", async () => {
  const { doc, setDoc } = firestore;
  const data = { displayName: "No invite", email: "none@test.local", role: "USER", areaIds: [ids.area1], isActive: true };
  await rulesTesting.assertFails(setDoc(
    doc(testEnvironment.authenticatedContext("unverified", { email: "none@test.local", email_verified: false }).firestore(), "users", "unverified"),
    data,
  ));
  await rulesTesting.assertFails(setDoc(doc(verifiedUserDb("uninvited", "none@test.local"), "users", "uninvited"), data));
});

integrationTest("ADMIN retains global business and user management access", async () => {
  const { doc, getDoc, updateDoc } = firestore;
  const db = userDb(ids.admin);
  await rulesTesting.assertSucceeds(getDoc(doc(db, "devices", ids.device1)));
  await rulesTesting.assertSucceeds(getDoc(doc(db, "devices", ids.device2)));
  await rulesTesting.assertSucceeds(getDoc(doc(db, "users", ids.areaAdmin1)));
  await rulesTesting.assertSucceeds(updateDoc(doc(db, "users", ids.lg2), { isActive: false }));
  await rulesTesting.assertSucceeds(updateDoc(doc(db, "users", ids.areaAdmin1), {
    displayName: "Managed by global admin",
    role: "AREA_ADMIN",
    areaIds: [ids.area1, ids.area2],
    isActive: true,
    email: "AREA_ADMIN@test.local",
  }));
});

integrationTest("AREA_ADMIN cannot manage users outside scope or list all users", async () => {
  const { collection, doc, getDoc, getDocs, updateDoc } = firestore;
  const db = userDb(ids.areaAdmin1);
  await rulesTesting.assertFails(getDoc(doc(db, "users", ids.lg2)));
  await rulesTesting.assertFails(getDocs(collection(db, "users")));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.areaAdmin2), { isActive: false }));
});

integrationTest("USER cannot update role, areaIds, active state or create invites", async () => {
  const { doc, serverTimestamp, setDoc, updateDoc } = firestore;
  const db = userDb(ids.lg1);
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.lg1), { role: "AREA_ADMIN" }));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.lg1), { areaIds: [ids.area2] }));
  await rulesTesting.assertFails(updateDoc(doc(db, "users", ids.lg1), { isActive: true }));
  await rulesTesting.assertFails(setDoc(doc(db, "invites", "forged@test.local"), {
    email: "forged@test.local", displayName: "Forged", role: "USER", areaIds: [ids.area1],
    status: "PENDING", createdByUid: ids.lg1, createdAt: serverTimestamp(),
    acceptedByUid: null, acceptedAt: null,
  }));
});

integrationTest("invite email must match verified token exactly", async () => {
  const { doc, serverTimestamp, setDoc, writeBatch } = firestore;
  const invitedEmail = "right@test.local";
  await testEnvironment.withSecurityRulesDisabled(async (context) => {
    await setDoc(doc(context.firestore(), "invites", invitedEmail), {
      email: invitedEmail, displayName: "Right", role: "USER", areaIds: [ids.area1],
      status: "PENDING", createdByUid: ids.admin, createdAt: serverTimestamp(),
      acceptedByUid: null, acceptedAt: null,
    });
  });
  const db = verifiedUserDb("wrong-email-user", "wrong@test.local");
  const batch = writeBatch(db);
  batch.set(doc(db, "users", "wrong-email-user"), {
    displayName: "Right", email: invitedEmail, role: "USER", areaIds: [ids.area1], isActive: true,
  });
  batch.update(doc(db, "invites", invitedEmail), {
    status: "ACCEPTED", acceptedByUid: "wrong-email-user", acceptedAt: serverTimestamp(),
  });
  await rulesTesting.assertFails(batch.commit());
});

integrationTest("profile creation and invite consumption cannot be committed separately", async () => {
  const { doc, serverTimestamp, setDoc, updateDoc } = firestore;
  const email = "atomic@test.local";
  await testEnvironment.withSecurityRulesDisabled(async (context) => {
    await setDoc(doc(context.firestore(), "invites", email), {
      email, displayName: "Atomic", role: "USER", areaIds: [ids.area1],
      status: "PENDING", createdByUid: ids.admin, createdAt: serverTimestamp(),
      acceptedByUid: null, acceptedAt: null,
    });
  });
  const db = verifiedUserDb("atomic-user", email);
  await rulesTesting.assertFails(setDoc(doc(db, "users", "atomic-user"), {
    displayName: "Atomic", email, role: "USER", areaIds: [ids.area1], isActive: true,
  }));
  await rulesTesting.assertFails(updateDoc(doc(db, "invites", email), {
    status: "ACCEPTED", acceptedByUid: "atomic-user", acceptedAt: serverTimestamp(),
  }));
});

integrationTest("inactive accounts cannot access business collections", async () => {
  const { doc, getDoc } = firestore;
  const db = userDb(ids.inactive);
  await rulesTesting.assertSucceeds(getDoc(doc(db, "users", ids.inactive)));
  await rulesTesting.assertFails(getDoc(doc(db, "areas", ids.area1)));
  await rulesTesting.assertFails(getDoc(doc(db, "devices", ids.device1)));
  await rulesTesting.assertFails(getDoc(doc(db, "incidents", ids.incident1)));
});

integrationTest("AREA_ADMIN linked collection access follows device scope", async () => {
  const { addDoc, collection, doc, getDoc, serverTimestamp, setDoc } = firestore;
  const db = userDb(ids.areaAdmin1);
  await rulesTesting.assertFails(getDoc(doc(db, "maintenances", "maintenance-lg2-test")));
  await rulesTesting.assertSucceeds(addDoc(collection(db, "maintenances"), {
    deviceId: ids.device1, title: "Allowed", performedAt: serverTimestamp(), createdAt: serverTimestamp(),
  }));
  await rulesTesting.assertFails(addDoc(collection(db, "maintenances"), {
    deviceId: ids.device2, title: "Denied", performedAt: serverTimestamp(), createdAt: serverTimestamp(),
  }));
  await rulesTesting.assertSucceeds(setDoc(doc(db, "deviceTypes", "area-admin-type"), {
    code: "AA", name: "Scoped", categoryId: "category-1", areaIds: [ids.area1], isActive: true,
  }));
  await rulesTesting.assertFails(setDoc(doc(db, "deviceTypes", "area-admin-global-type"), {
    code: "GLOBAL", name: "Denied", categoryId: "category-1", areaIds: [], isActive: true,
  }));
  await rulesTesting.assertFails(setDoc(doc(db, "deviceTypes", "area-admin-outside-type"), {
    code: "OUTSIDE", name: "Denied", categoryId: "category-1", areaIds: [ids.area2], isActive: true,
  }));
  await rulesTesting.assertSucceeds(setDoc(doc(db, "inspectionTemplates", "area-admin-template"), {
    name: "Scoped template", description: "", areaIds: [ids.area1],
    tasks: [], version: 1, isActive: true,
  }));
});

integrationTest("USER may create maintenance only for devices in assigned areas", async () => {
  const { addDoc, collection, doc, serverTimestamp } = firestore;
  const db = userDb(ids.lg1);
  await rulesTesting.assertSucceeds(addDoc(collection(db, "maintenances"), {
    deviceId: ids.device1, title: "In-scope repair", maintenanceType: "CORRECTIVE",
    status: "COMPLETED", performedAt: serverTimestamp(), createdAt: serverTimestamp(),
  }));
  await rulesTesting.assertFails(addDoc(collection(db, "maintenances"), {
    deviceId: ids.device2, title: "Out-of-scope repair", maintenanceType: "CORRECTIVE",
    status: "COMPLETED", performedAt: serverTimestamp(), createdAt: serverTimestamp(),
  }));
});

integrationTest("AREA_ADMIN manages templates and plans only inside assigned workshops", async () => {
  const { doc, getDoc, setDoc, updateDoc, serverTimestamp } = firestore;
  const areaAdmin1Db = userDb(ids.areaAdmin1);
  const areaAdmin2Db = userDb(ids.areaAdmin2);
  const templateRef = doc(areaAdmin1Db, "inspectionTemplates", "scoped-template-test");

  await rulesTesting.assertSucceeds(setDoc(templateRef, {
    name: "LG1 template", description: "", areaIds: [ids.area1],
    tasks: [], version: 1, isActive: true,
  }));
  await rulesTesting.assertSucceeds(getDoc(templateRef));
  await rulesTesting.assertSucceeds(getDoc(doc(areaAdmin2Db, "inspectionTemplates", "scoped-template-test")));
  await rulesTesting.assertFails(updateDoc(doc(areaAdmin2Db, "inspectionTemplates", "scoped-template-test"), {
    name: "Forbidden update",
  }));
  await rulesTesting.assertFails(updateDoc(templateRef, { areaIds: [ids.area1, ids.area2] }));
  await rulesTesting.assertFails(setDoc(doc(areaAdmin1Db, "inspectionTemplates", "outside-template"), {
    name: "Outside", description: "", areaIds: [ids.area2],
    tasks: [], version: 1, isActive: true,
  }));

  await rulesTesting.assertSucceeds(setDoc(doc(areaAdmin1Db, "devices", "plan-device-lg1"), {
    code: "PLAN-LG1", name: "Plan device", areaId: ids.area1,
    deviceTypeId: "type", isActive: true, status: "ACTIVE",
  }));
  await rulesTesting.assertSucceeds(getDoc(doc(areaAdmin1Db, "deviceInspectionPlans", "plan-device-lg1")));
  await rulesTesting.assertFails(getDoc(doc(areaAdmin2Db, "deviceInspectionPlans", "plan-device-lg1")));
  await rulesTesting.assertFails(getDoc(doc(userDb(ids.lg1), "deviceInspectionPlans", "plan-device-lg1")));
  await rulesTesting.assertSucceeds(setDoc(doc(areaAdmin1Db, "deviceInspectionPlans", "plan-device-lg1"), {
    deviceId: "plan-device-lg1", templateId: "scoped-template-test",
    name: "LG1 plan", tasks: [{ id: "task-1" }], version: 1, isActive: true,
  }));
  const scopedPlanRef = doc(areaAdmin1Db, "deviceInspectionPlans", "plan-device-lg1");
  await rulesTesting.assertSucceeds(updateDoc(scopedPlanRef, {
    name: "LG1 plan updated", tasks: [{ id: "task-1", weekdays: [2] }],
    version: 2, updatedAt: serverTimestamp(),
  }));
  await rulesTesting.assertFails(updateDoc(doc(areaAdmin2Db, "deviceInspectionPlans", "plan-device-lg1"), {
    name: "Out of scope", tasks: [{ id: "task-1", weekdays: [3] }],
    version: 3, updatedAt: serverTimestamp(),
  }));
  await rulesTesting.assertFails(updateDoc(doc(userDb(ids.lg1), "deviceInspectionPlans", "plan-device-lg1"), {
    name: "USER denied", tasks: [{ id: "task-1", weekdays: [3] }],
    version: 3, updatedAt: serverTimestamp(),
  }));
  await rulesTesting.assertFails(updateDoc(scopedPlanRef, {
    isActive: false, version: 3, updatedAt: serverTimestamp(),
  }));
  await rulesTesting.assertSucceeds(updateDoc(doc(userDb(ids.admin), "deviceInspectionPlans", ids.device2), {
    name: "Admin updated LG2", tasks: [{ id: "task-lg2", weekdays: [4] }],
    version: 2, updatedAt: serverTimestamp(),
  }));
  await rulesTesting.assertFails(setDoc(doc(areaAdmin2Db, "deviceInspectionPlans", ids.device2), {
    deviceId: ids.device2, templateId: "scoped-template-test",
    name: "Denied plan", tasks: [], version: 1, isActive: true,
  }));
});

integrationTest("AREA_ADMIN manages only device types fully inside assigned areas", async () => {
  const { doc, setDoc, updateDoc } = firestore;
  const areaAdminDb = userDb(ids.areaAdmin1);
  const userDatabase = userDb(ids.user1);
  const adminDatabase = userDb(ids.admin);
  const typeRef = doc(areaAdminDb, "deviceTypes", "scoped-type-update");

  await rulesTesting.assertSucceeds(setDoc(typeRef, {
    code: "SCOPED", name: "Scoped type", categoryId: "category-1",
    areaIds: [ids.area1], isActive: true,
  }));
  await rulesTesting.assertSucceeds(updateDoc(typeRef, {
    name: "Scoped type updated", isActive: true,
  }));
  await rulesTesting.assertFails(updateDoc(typeRef, {
    areaIds: [ids.area1, ids.area2],
  }));
  await rulesTesting.assertFails(setDoc(doc(userDatabase, "deviceTypes", "user-type"), {
    code: "USER", name: "Denied", categoryId: "category-1",
    areaIds: [ids.area1], isActive: true,
  }));
  await rulesTesting.assertSucceeds(setDoc(doc(adminDatabase, "deviceTypes", "global-type"), {
    code: "GLOBAL", name: "Global", categoryId: "category-1",
    areaIds: [], isActive: true,
  }));
  await rulesTesting.assertFails(setDoc(doc(adminDatabase, "devices", "wrong-type-scope"), {
    code: "WRONG-SCOPE", name: "Denied", areaId: ids.area2,
    deviceTypeId: "scoped-type-update", isActive: true, status: "ACTIVE",
  }));
});

