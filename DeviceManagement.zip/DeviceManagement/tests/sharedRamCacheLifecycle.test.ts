import assert from "node:assert/strict";
import test from "node:test";

import { SharedRamCache } from "../src/services/sharedRamCache.js";
import { SharedRamCacheLifecycle } from "../src/services/sharedRamCacheLifecycle.js";
import type { AppUser } from "../src/types/user.js";

const dataset = { collection: "devices", variant: "list" } as const;
const policy = { freshForMs: 30, staleForMs: 120 } as const;

function profile(overrides: Partial<AppUser> = {}): AppUser {
  return {
    uid: "user-a",
    displayName: "User A",
    email: "user-a@example.invalid",
    role: "USER",
    isActive: true,
    areaIds: ["area-a"],
    ...overrides,
  };
}

function setup() {
  const cache = new SharedRamCache();
  const lifecycle = new SharedRamCacheLifecycle(cache, "project-a");
  return { cache, lifecycle };
}

function activateValidProfile(
  cache: SharedRamCache,
  lifecycle: SharedRamCacheLifecycle,
  user = profile(),
) {
  const verificationEpoch = lifecycle.resolveAuth(user.uid);
  const scope = lifecycle.activateProfile(user, verificationEpoch);
  assert.ok(scope);
  cache.write(scope, dataset, ["device-a"], policy, 0);
  return scope;
}

test("Auth loading keeps the cache inactive", () => {
  const { cache, lifecycle } = setup();
  lifecycle.beginAuthVerification();
  assert.equal(cache.getActiveScope(), null);
  assert.equal(lifecycle.getExpectedUid(), null);
});

test("profile loading keeps the cache inactive after Auth resolves", () => {
  const { cache, lifecycle } = setup();
  lifecycle.resolveAuth("user-a");
  assert.equal(cache.getActiveScope(), null);
  assert.equal(lifecycle.getExpectedUid(), "user-a");
});

test("a valid active profile matching Auth activates its scope", () => {
  const { cache, lifecycle } = setup();
  const verificationEpoch = lifecycle.resolveAuth("user-a");
  const scope = lifecycle.activateProfile(profile(), verificationEpoch);
  assert.ok(scope);
  assert.equal(cache.getActiveScope()?.key, scope.key);
});

test("logout clears the active scope synchronously", () => {
  const { cache, lifecycle } = setup();
  const oldScope = activateValidProfile(cache, lifecycle);
  lifecycle.logout();
  assert.equal(cache.getActiveScope(), null);
  assert.equal(cache.read(oldScope, dataset).state, "missing");
});

for (const [label, changed] of [
  ["UID", profile({ uid: "user-b" })],
  ["role", profile({ role: "ADMIN" })],
  ["areaIds", profile({ areaIds: ["area-b"] })],
] as const) {
  test(`${label} change replaces and clears the old scope`, () => {
    const { cache, lifecycle } = setup();
    const oldScope = activateValidProfile(cache, lifecycle);

    if (label === "UID") {
      lifecycle.resolveAuth(changed.uid);
    }
    const newScope = lifecycle.activateProfile(
      changed,
      lifecycle.getVerificationEpoch(),
    );
    assert.ok(newScope);
    assert.notEqual(newScope.key, oldScope.key);
    assert.equal(cache.read(oldScope, dataset).state, "missing");
  });
}

test("inactive profile invalidates the current scope", () => {
  const { cache, lifecycle } = setup();
  const oldScope = activateValidProfile(cache, lifecycle);
  assert.equal(
    lifecycle.activateProfile(
      profile({ isActive: false }),
      lifecycle.getVerificationEpoch(),
    ),
    null,
  );
  assert.equal(cache.read(oldScope, dataset).state, "missing");
});

test("deleted profile invalidates the current scope", () => {
  const { cache, lifecycle } = setup();
  const oldScope = activateValidProfile(cache, lifecycle);
  lifecycle.invalidateProfile(lifecycle.getVerificationEpoch());
  assert.equal(cache.read(oldScope, dataset).state, "missing");
});

test("profile permission-denied path invalidates the current scope", () => {
  const { cache, lifecycle } = setup();
  const oldScope = activateValidProfile(cache, lifecycle);
  const permissionDenied = Object.assign(new Error("denied"), {
    code: "firestore/permission-denied",
  });

  assert.equal(permissionDenied.code, "firestore/permission-denied");
  lifecycle.invalidateProfile(lifecycle.getVerificationEpoch());
  assert.equal(cache.read(oldScope, dataset).state, "missing");
});

test("a request completing after logout cannot commit", async () => {
  const { cache, lifecycle } = setup();
  const scope = activateValidProfile(cache, lifecycle);
  let resolveRequest!: (value: string[]) => void;
  const pending = new Promise<string[]>((resolve) => {
    resolveRequest = resolve;
  });

  const load = cache.load(scope, dataset, () => pending, policy);
  lifecycle.logout();
  resolveRequest(["late-private-data"]);

  assert.deepEqual(await load, {
    data: ["late-private-data"],
    committed: false,
  });
  assert.equal(cache.getActiveScope(), null);
});

test("replayed profile snapshot with the same normalized scope is a no-op", () => {
  const { cache, lifecycle } = setup();
  const verificationEpoch = lifecycle.resolveAuth("user-a");
  const first = lifecycle.activateProfile(
    profile({ areaIds: ["area-b", " area-a "] }),
    verificationEpoch,
  );
  assert.ok(first);
  const generation = cache.getGeneration();
  cache.write(first, dataset, ["kept"], policy, 0);

  const replay = lifecycle.activateProfile(
    profile({ areaIds: ["area-a", "area-b", "area-a"] }),
    verificationEpoch,
  );
  assert.ok(replay);
  assert.equal(replay.key, first.key);
  assert.equal(cache.getGeneration(), generation);
  assert.deepEqual(cache.read<string[]>(replay, dataset, 1).data, ["kept"]);
});

test("StrictMode cleanup clears scope and remount can activate it again", () => {
  const { cache, lifecycle } = setup();
  lifecycle.beginAuthVerification();
  const first = activateValidProfile(cache, lifecycle);

  lifecycle.dispose();
  assert.equal(cache.getActiveScope(), null);
  assert.equal(cache.read(first, dataset).state, "missing");

  lifecycle.beginAuthVerification();
  const verificationEpoch = lifecycle.resolveAuth("user-a");
  const remounted = lifecycle.activateProfile(profile(), verificationEpoch);
  assert.ok(remounted);
  assert.equal(cache.getActiveScope()?.key, remounted.key);
});

test("a stale same-UID profile callback cannot affect a newer verification", () => {
  const { cache, lifecycle } = setup();
  const oldEpoch = lifecycle.resolveAuth("user-a");
  const newEpoch = lifecycle.resolveAuth("user-a");
  const currentScope = lifecycle.activateProfile(profile(), newEpoch);
  assert.ok(currentScope);

  assert.equal(lifecycle.activateProfile(profile(), oldEpoch), null);
  assert.equal(lifecycle.invalidateProfile(oldEpoch), false);
  assert.equal(cache.getActiveScope()?.key, currentScope.key);
});
