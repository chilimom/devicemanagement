# Firestore Rules tests

`tests/firestore.rules.test.mjs` covers the approved ADMIN/USER scope, current-device history authorization, incident resolution/verification transactions, legacy records, revocation and device transfers.

This workspace intentionally does not install test tooling automatically. To run the suite in an approved environment, install `@firebase/rules-unit-testing` and Firebase CLI, ensure the Firestore Emulator is available, then run:

```powershell
npm run rules:test:emulator
```

`npm run rules:test` is safe to run without those dependencies; it reports the Emulator suite as skipped.
