
/**
 * Vai trò người dùng trong hệ thống.
 */
export type UserRole = "ADMIN" | "AREA_ADMIN" | "USER";

/**
 * Hồ sơ người dùng lưu tại Firestore:
 * users/{uid}
 */
export interface AppUser {
  uid: string;
  displayName: string;
  email: string;
  role: UserRole;
  isActive: boolean;

  // Danh sách Document ID khu vực được phân công.
  // ADMIN không cần areaIds để quản lý toàn hệ thống.
  areaIds: string[];
}

/**
 * Kiểm tra quyền quản trị.
 */
export function isAdmin(user: AppUser | null): boolean {
  return user?.isActive === true && user.role === "ADMIN";
}

/** Quản trị theo một hoặc nhiều xưởng được ghi trong areaIds. */
export function isAreaAdmin(user: AppUser | null): boolean {
  return user?.isActive === true && user.role === "AREA_ADMIN";
}

/** Có quyền thực hiện nghiệp vụ quản trị; phạm vi vẫn do Rules quyết định. */
export function isManager(user: AppUser | null): boolean {
  return isAdmin(user) || isAreaAdmin(user);
}

/**
 * Kiểm tra quyền truy cập một khu vực.
 */
export function canAccessArea(
  user: AppUser | null,
  areaId: string,
): boolean {
  const normalizedAreaId = areaId.trim();

  if (!user || !user.isActive || !normalizedAreaId) {
    return false;
  }

  if (user.role === "ADMIN") {
    return true;
  }

  return (
    (user.role === "AREA_ADMIN" || user.role === "USER") &&
    user.areaIds.some((assignedAreaId) =>
      assignedAreaId.trim() === normalizedAreaId
    )
  );
}
