
/* =========================================================
   TASKLIST TUẦN KIỂM - DATA TYPES V1.0
   ========================================================= */

export type InspectionCategory =
  | "VISUAL"
  | "VIBRATION"
  | "TEMPERATURE"
  | "NOISE"
  | "LEAK"
  | "ELECTRICAL"
  | "LUBRICATION";

export type InspectionInputType =
  | "PASS_FAIL"
  | "NUMBER"
  | "TEXT";

export type InspectionFrequency =
  | "DAILY"
  | "WEEKLY"
  | "MONTHLY"
  | "CUSTOM";

export type InspectionResultStatus =
  | "PASS"
  | "WARNING"
  | "FAIL"
  | "NOT_CHECKED";

export interface InspectionCriterion {
  id: string;

  category: InspectionCategory;

  standard: string;

  inputType: InspectionInputType;

  unit?: string;

  minValue?: number | null;

  maxValue?: number | null;

  isRequired: boolean;
}


export interface InspectionTask {
  id: string;

  name: string;

  description?: string;

  order: number;

  frequency: InspectionFrequency;

  // Lịch riêng của từng công việc:
  // 1 = Thứ Hai, 7 = Chủ nhật
  weekdays: number[];

  criteria: InspectionCriterion[];

  isActive: boolean;
}

/* Mẫu kiểm tra dùng chung */
export interface InspectionTemplate {
  id: string;

  name: string;

  description?: string;

  deviceTypeId?: string;

  categoryId?: string;

  // Xưởng được phép áp dụng/quản lý mẫu. Mẫu legacy thiếu field chỉ ADMIN quản lý.
  areaIds?: string[];

  tasks: InspectionTask[];

  isActive: boolean;

  version: number;
}

/* Tasklist riêng cho từng thiết bị */

export interface DeviceInspectionPlan {
  id: string;

  // Firestore Document ID của thiết bị
  deviceId: string;

  templateId?: string;

  name: string;

  // Mỗi công việc trong tasks có lịch riêng
  tasks: InspectionTask[];

  isActive: boolean;

  version: number;

  createdAt?: unknown;
}


/* Kết quả đánh giá từng tiêu chí */
export interface InspectionCriterionResult {
  criterionId: string;

  status: InspectionResultStatus;

  numericValue?: number | null;

  textValue?: string;

  note?: string;
}

/* Kết quả từng công việc */
export interface InspectionTaskResult {
  taskId: string;

  status: InspectionResultStatus;

  criteriaResults: InspectionCriterionResult[];

  note?: string;
}

/* Một lần kiểm tra thực tế */
export interface InspectionRecord {
  id: string;

  deviceId: string;

  planId: string;

  planVersion: number;

  inspectionDate: string;

  inspectionType: "SCHEDULED" | "EXTRA";

  inspectorName: string;

  recordedByUid: string;

  results: InspectionTaskResult[];

  note?: string;

  /** Links a remediation retest to the failed criterion it follows. */
  remediationSource?: {
    recordId: string;
    taskId: string;
    criterionId: string;
  };

  maintenanceSource?: {
    recordId: string;
    taskId: string;
    criterionId: string;
  };

  createdAt?: unknown;
}
