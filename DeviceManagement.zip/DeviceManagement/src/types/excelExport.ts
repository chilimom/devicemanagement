import type { DocumentData } from "firebase/firestore";

/**
 * A Firestore document at the export read boundary.
 *
 * Values remain unnormalised on purpose. Legacy documents can be missing a
 * field or contain a value with an unexpected type; the row-mapping step must
 * validate each value instead of inventing a replacement here.
 */
export interface ExcelExportDocument<
  TData extends DocumentData = DocumentData,
> {
  id: string;
  data: TData;
}

export interface ExportDeviceData extends DocumentData {
  areaId?: unknown;
  subAreaId?: unknown;
  deviceTypeId?: unknown;
  code?: unknown;
  name?: unknown;
}

export interface ExportIncidentData extends DocumentData {
  managementCode?: unknown;
  createdAt?: unknown;
  reportedAt?: unknown;
  deviceId?: unknown;
  inspectionRecordId?: unknown;
  inspectionTaskId?: unknown;
  inspectionCriterionId?: unknown;
}

export interface ExportIncidentResolutionData extends DocumentData {
  incidentId?: unknown;
  deviceId?: unknown;
  resolution?: unknown;
  attemptNumber?: unknown;
  resolvedByUid?: unknown;
  resolvedByName?: unknown;
  resolvedByEmail?: unknown;
  resolvedAt?: unknown;
  outcome?: unknown;
}

export interface ExportIncidentVerificationData extends DocumentData {
  incidentId?: unknown;
  deviceId?: unknown;
  note?: unknown;
  attemptNumber?: unknown;
  verifiedByUid?: unknown;
  verifiedByName?: unknown;
  verifiedByEmail?: unknown;
  verifiedAt?: unknown;
}

export interface ExportInspectionPlanData extends DocumentData {
  deviceId?: unknown;
  templateId?: unknown;
  name?: unknown;
  tasks?: unknown;
  isActive?: unknown;
  version?: unknown;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface ExportInspectionResultData extends DocumentData {
  managementCode?: unknown;
  deviceId?: unknown;
  planId?: unknown;
  planVersion?: unknown;
  inspectionDate?: unknown;
  inspectionType?: unknown;
  inspectorName?: unknown;
  recordedByUid?: unknown;
  results?: unknown;
  note?: unknown;
  planSnapshot?: unknown;
  createdAt?: unknown;
}

export interface ExportUserData extends DocumentData {
  displayName?: unknown;
}

export type ExportAreaData = DocumentData;
export type ExportDeviceCategoryData = DocumentData;
export type ExportDeviceTypeData = DocumentData;

export interface ExcelExportDataSet {
  devices: ExcelExportDocument<ExportDeviceData>[];
  incidents: ExcelExportDocument<ExportIncidentData>[];
  incidentResolutions: ExcelExportDocument<ExportIncidentResolutionData>[];
  incidentVerifications: ExcelExportDocument<ExportIncidentVerificationData>[];
  deviceInspectionPlans: ExcelExportDocument<ExportInspectionPlanData>[];
  inspectionResults: ExcelExportDocument<ExportInspectionResultData>[];
  areas: ExcelExportDocument<ExportAreaData>[];
  subAreas: ExcelExportDocument<ExportAreaData>[];
  deviceCategories: ExcelExportDocument<ExportDeviceCategoryData>[];
  deviceTypes: ExcelExportDocument<ExportDeviceTypeData>[];
  /** ADMIN-only directory fallback. USER exports intentionally keep this empty. */
  users: ExcelExportDocument<ExportUserData>[];
}

export function createEmptyExcelExportDataSet(): ExcelExportDataSet {
  return {
    devices: [],
    incidents: [],
    incidentResolutions: [],
    incidentVerifications: [],
    deviceInspectionPlans: [],
    inspectionResults: [],
    areas: [],
    subAreas: [],
    deviceCategories: [],
    deviceTypes: [],
    users: [],
  };
}
