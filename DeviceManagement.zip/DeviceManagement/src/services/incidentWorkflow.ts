export type IncidentStatus = "OPEN" | "RESOLVED" | "CLOSED";
export type ResolutionOutcome = "OPEN" | "RESOLVED";

export interface VerificationUserProfile {
  isActive?: unknown;
  role?: unknown;
  areaIds?: unknown;
}

export interface VerificationDeviceAccess {
  areaId?: unknown;
}

export function isResolvableIncident(status?: string): boolean {
  return status === "OPEN";
}

export function isVerifiableIncident(status?: string): boolean {
  return status === "RESOLVED";
}

export function nextStatusAfterResolution(
  outcome: ResolutionOutcome,
): ResolutionOutcome {
  return outcome;
}

/**
 * Pure client-side precondition for a verification transaction. Firestore
 * Rules remain the authoritative server-side control once deployed.
 */
export function hasCurrentAreaAccessForVerification(
  profile: VerificationUserProfile,
  device: VerificationDeviceAccess,
): boolean {
  if (profile.isActive !== true) {
    return false;
  }

  if (profile.role === "ADMIN") {
    return true;
  }

  if (
    (profile.role !== "USER" && profile.role !== "AREA_ADMIN") ||
    typeof device.areaId !== "string"
  ) {
    return false;
  }

  const deviceAreaId = device.areaId.trim();
  if (!deviceAreaId || !Array.isArray(profile.areaIds)) {
    return false;
  }

  return profile.areaIds.some(
    (areaId) => typeof areaId === "string" && areaId.trim() === deviceAreaId,
  );
}
