import type { AppUser, UserRole } from "../types/user.js";

const DEFAULT_DATABASE_ID = "(default)";
const AREA_ID_SEPARATOR = "\u001f";

export const CACHE_POLICIES = {
  devices: { freshForMs: 30_000, staleForMs: 120_000 },
  areas: { freshForMs: 5 * 60_000, staleForMs: 15 * 60_000 },
  subAreas: { freshForMs: 5 * 60_000, staleForMs: 15 * 60_000 },
  deviceCategories: {
    freshForMs: 10 * 60_000,
    staleForMs: 30 * 60_000,
  },
  deviceTypes: { freshForMs: 5 * 60_000, staleForMs: 15 * 60_000 },
} as const satisfies Record<string, CachePolicy>;

export type CacheValueState =
  | "missing"
  | "loading"
  | "fresh"
  | "refreshing"
  | "stale"
  | "expired";

export interface CachePolicy {
  /** Time after a successful read during which the value is fresh. */
  freshForMs: number;
  /** Maximum age of a value before it expires and must not be returned. */
  staleForMs: number;
}

export interface CacheScopeInput {
  projectId: string;
  databaseId?: string;
  uid: string;
  role: UserRole;
  areaIds: readonly string[];
  isActive: boolean;
}

export interface CacheScope {
  projectId: string;
  databaseId: string;
  uid: string;
  role: UserRole;
  areaIds: readonly string[];
  areaSignature: string;
  key: string;
}

export interface CacheDatasetKey {
  collection: string;
  variant?: string;
}

export interface CacheSnapshot<T> {
  state: CacheValueState;
  data?: T;
  fetchedAt?: number;
  staleAt?: number;
  expiresAt?: number;
}

export interface CacheLoadResult<T> {
  data: T;
  /** False when the request completed after its scope was invalidated. */
  committed: boolean;
}

interface CacheEntry<T = unknown> {
  data: T;
  fetchedAt: number;
  staleAt: number;
  expiresAt: number;
}

interface InFlightRequest<T = unknown> {
  promise: Promise<CacheLoadResult<T>>;
  requestId: number;
}

export function normalizeAreaIds(areaIds: readonly string[]): string[] {
  return [...new Set(areaIds.map((areaId) => areaId.trim()).filter(Boolean))]
    .sort((left, right) => left.localeCompare(right));
}

/**
 * Creates a cache scope only after Auth and the Firestore profile are active.
 * Returning null is the cache barrier for logout and inactive profiles.
 */
export function createCacheScope(input: CacheScopeInput): CacheScope | null {
  if (!input.isActive) {
    return null;
  }

  const projectId = requireKeyPart(input.projectId, "projectId");
  const databaseId = input.databaseId?.trim() || DEFAULT_DATABASE_ID;
  const uid = requireKeyPart(input.uid, "uid");
  const areaIds = normalizeAreaIds(input.areaIds);
  const areaSignature = areaIds.join(AREA_ID_SEPARATOR);

  return Object.freeze({
    projectId,
    databaseId,
    uid,
    role: input.role,
    areaIds: Object.freeze(areaIds),
    areaSignature,
    key: JSON.stringify([
      projectId,
      databaseId,
      uid,
      input.role,
      areaSignature,
    ]),
  });
}

export function createCacheScopeFromUser(
  projectId: string,
  user: Pick<AppUser, "uid" | "role" | "areaIds" | "isActive">,
  databaseId = DEFAULT_DATABASE_ID,
): CacheScope | null {
  return createCacheScope({
    projectId,
    databaseId,
    uid: user.uid,
    role: user.role,
    areaIds: user.areaIds,
    isActive: user.isActive,
  });
}

export function isPermissionDenied(error: unknown): boolean {
  if (!error || typeof error !== "object" || !("code" in error)) {
    return false;
  }

  const code = String(error.code).toLowerCase();
  return code === "permission-denied" || code.endsWith("/permission-denied");
}

/**
 * Framework-independent, active-scope-only RAM cache. It never persists data
 * and must not be used as an authorization decision source.
 */
export class SharedRamCache {
  private activeScope: CacheScope | null = null;
  private generation = 0;
  private requestSequence = 0;
  private readonly entries = new Map<string, CacheEntry>();
  private readonly inFlight = new Map<string, InFlightRequest>();

  getActiveScope(): CacheScope | null {
    return this.activeScope;
  }

  getGeneration(): number {
    return this.generation;
  }

  /**
   * Activates a verified scope. Any UID, role, areaIds or active-state change
   * advances the generation and synchronously drops the previous scope.
   */
  activateScope(scope: CacheScope | null): boolean {
    if (scope?.key === this.activeScope?.key) {
      return false;
    }

    this.generation += 1;
    this.entries.clear();
    this.inFlight.clear();
    this.activeScope = scope;
    return true;
  }

  read<T>(
    scope: CacheScope,
    dataset: CacheDatasetKey,
    now = Date.now(),
  ): CacheSnapshot<T> {
    if (!this.isActiveScope(scope)) {
      return { state: "missing" };
    }

    const datasetId = serializeDatasetKey(dataset);
    const entry = this.entries.get(datasetId) as CacheEntry<T> | undefined;
    const requestRunning = this.inFlight.has(datasetId);

    if (!entry) {
      return { state: requestRunning ? "loading" : "missing" };
    }

    const timing = {
      fetchedAt: entry.fetchedAt,
      staleAt: entry.staleAt,
      expiresAt: entry.expiresAt,
    };

    if (now >= entry.expiresAt) {
      return {
        state: requestRunning ? "loading" : "expired",
        ...timing,
      };
    }

    if (requestRunning) {
      return { state: "refreshing", data: entry.data, ...timing };
    }

    return {
      state: now < entry.staleAt ? "fresh" : "stale",
      data: entry.data,
      ...timing,
    };
  }

  write<T>(
    scope: CacheScope,
    dataset: CacheDatasetKey,
    data: T,
    policy: CachePolicy,
    now = Date.now(),
  ): boolean {
    validatePolicy(policy);
    if (!this.isActiveScope(scope)) {
      return false;
    }

    this.entries.set(serializeDatasetKey(dataset), {
      data,
      fetchedAt: now,
      staleAt: now + policy.freshForMs,
      expiresAt: now + policy.staleForMs,
    });
    return true;
  }

  /** Invalidates every variant belonging to a collection in the active scope. */
  invalidateCollection(scope: CacheScope, collection: string): number {
    if (!this.isActiveScope(scope)) {
      return 0;
    }

    const normalizedCollection = requireKeyPart(collection, "collection");
    let removed = 0;

    for (const [datasetId] of this.entries) {
      if (parseDatasetCollection(datasetId) === normalizedCollection) {
        this.entries.delete(datasetId);
        this.inFlight.delete(datasetId);
        removed += 1;
      }
    }

    for (const [datasetId] of this.inFlight) {
      if (parseDatasetCollection(datasetId) === normalizedCollection) {
        this.inFlight.delete(datasetId);
      }
    }

    return removed;
  }

  invalidate(scope: CacheScope, dataset: CacheDatasetKey): boolean {
    if (!this.isActiveScope(scope)) {
      return false;
    }

    const datasetId = serializeDatasetKey(dataset);
    this.inFlight.delete(datasetId);
    return this.entries.delete(datasetId);
  }

  clearScope(scope: CacheScope): boolean {
    if (!this.isActiveScope(scope)) {
      return false;
    }

    this.generation += 1;
    this.entries.clear();
    this.inFlight.clear();
    this.activeScope = null;
    return true;
  }

  clearAll(): void {
    this.generation += 1;
    this.entries.clear();
    this.inFlight.clear();
    this.activeScope = null;
  }

  /**
   * Runs at most one loader per active scope/dataset. A loader from an old
   * generation may resolve for its caller, but cannot commit to this cache.
   */
  load<T>(
    scope: CacheScope,
    dataset: CacheDatasetKey,
    loader: () => Promise<T>,
    policy: CachePolicy,
    now: () => number = Date.now,
  ): Promise<CacheLoadResult<T>> {
    validatePolicy(policy);
    if (!this.isActiveScope(scope)) {
      return Promise.reject(new Error("Cache scope is not active."));
    }

    const datasetId = serializeDatasetKey(dataset);
    const existing = this.inFlight.get(datasetId) as
      | InFlightRequest<T>
      | undefined;
    if (existing) {
      return existing.promise;
    }

    const requestGeneration = this.generation;
    const requestId = ++this.requestSequence;

    const promise = loader().then(
      (data): CacheLoadResult<T> => {
        const canCommit =
          this.generation === requestGeneration &&
          this.isActiveScope(scope) &&
          this.isCurrentRequest(datasetId, requestId);

        if (canCommit) {
          this.write(scope, dataset, data, policy, now());
        }

        return { data, committed: canCommit };
      },
      (error: unknown) => {
        if (
          isPermissionDenied(error) &&
          this.generation === requestGeneration &&
          this.isActiveScope(scope) &&
          this.isCurrentRequest(datasetId, requestId)
        ) {
          this.entries.delete(datasetId);
        }
        throw error;
      },
    ).finally(() => {
      if (this.isCurrentRequest(datasetId, requestId)) {
        this.inFlight.delete(datasetId);
      }
    });

    this.inFlight.set(datasetId, { promise, requestId });
    return promise;
  }

  private isActiveScope(scope: CacheScope): boolean {
    return this.activeScope?.key === scope.key;
  }

  private isCurrentRequest(datasetId: string, requestId: number): boolean {
    const request = this.inFlight.get(datasetId);
    return request?.requestId === requestId;
  }
}

function validatePolicy(policy: CachePolicy): void {
  if (
    !Number.isFinite(policy.freshForMs) ||
    !Number.isFinite(policy.staleForMs) ||
    policy.freshForMs < 0 ||
    policy.staleForMs < policy.freshForMs
  ) {
    throw new Error(
      "Cache policy requires 0 <= freshForMs <= staleForMs.",
    );
  }
}

function requireKeyPart(value: string, label: string): string {
  const normalized = value.trim();
  if (!normalized) {
    throw new Error(`${label} must not be empty.`);
  }
  return normalized;
}

function serializeDatasetKey(dataset: CacheDatasetKey): string {
  const collection = requireKeyPart(dataset.collection, "collection");
  const variant = dataset.variant?.trim() || "default";
  return JSON.stringify([collection, variant]);
}

function parseDatasetCollection(datasetId: string): string {
  const parsed = JSON.parse(datasetId) as [string, string];
  return parsed[0];
}
