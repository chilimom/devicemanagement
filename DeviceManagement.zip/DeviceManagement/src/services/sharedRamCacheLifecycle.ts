import type { AppUser } from "../types/user.js";
import {
  SharedRamCache,
  createCacheScopeFromUser,
  type CacheScope,
} from "./sharedRamCache.js";

/**
 * Owns the security lifecycle of a SharedRamCache. UI/pages must not activate
 * scopes themselves; the Auth/profile barrier is the only caller.
 */
export class SharedRamCacheLifecycle {
  private expectedUid: string | null = null;
  private verificationEpoch = 0;
  private readonly cache: SharedRamCache;
  private readonly projectId: string;
  private readonly databaseId: string;

  constructor(
    cache: SharedRamCache,
    projectId: string,
    databaseId = "(default)",
  ) {
    if (!projectId.trim()) {
      throw new Error("Firebase projectId is required for cache lifecycle.");
    }

    this.cache = cache;
    this.projectId = projectId;
    this.databaseId = databaseId;
  }

  /** Called while Firebase Auth has not resolved its initial state. */
  beginAuthVerification(): number {
    this.verificationEpoch += 1;
    this.expectedUid = null;
    this.cache.activateScope(null);
    return this.verificationEpoch;
  }

  /**
   * Called when Auth resolves. A non-null UID starts profile verification, so
   * no business cache scope remains active until a valid profile is accepted.
   */
  resolveAuth(uid: string | null): number {
    this.verificationEpoch += 1;
    this.expectedUid = normalizeUid(uid);
    this.cache.activateScope(null);
    return this.verificationEpoch;
  }

  /** Activates only an active profile matching the currently authenticated UID. */
  activateProfile(
    user: Pick<AppUser, "uid" | "role" | "areaIds" | "isActive">,
    verificationEpoch: number,
  ): CacheScope | null {
    if (
      verificationEpoch !== this.verificationEpoch ||
      !this.expectedUid ||
      user.uid.trim() !== this.expectedUid
    ) {
      return null;
    }

    if (!user.isActive) {
      this.cache.activateScope(null);
      return null;
    }

    const scope = createCacheScopeFromUser(
      this.projectId,
      user,
      this.databaseId,
    );
    this.cache.activateScope(scope);
    return scope;
  }

  /** Profile missing, inactive, unreadable or authorization-denied. */
  invalidateProfile(verificationEpoch: number): boolean {
    if (verificationEpoch !== this.verificationEpoch) {
      return false;
    }

    this.cache.activateScope(null);
    return true;
  }

  /** Clears the cache synchronously before Firebase signOut is awaited. */
  logout(): void {
    this.verificationEpoch += 1;
    this.expectedUid = null;
    this.cache.activateScope(null);
  }

  /** Effect cleanup, including the intentional React StrictMode remount. */
  dispose(): void {
    this.verificationEpoch += 1;
    this.expectedUid = null;
    this.cache.activateScope(null);
  }

  getExpectedUid(): string | null {
    return this.expectedUid;
  }

  getVerificationEpoch(): number {
    return this.verificationEpoch;
  }
}

function normalizeUid(uid: string | null): string | null {
  const normalized = uid?.trim() ?? "";
  return normalized || null;
}
