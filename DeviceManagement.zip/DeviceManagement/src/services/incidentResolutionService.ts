
import {
  doc,
  runTransaction,
  serverTimestamp,
} from "firebase/firestore";

import { auth, db } from "../config/firebase";
import {
  nextStatusAfterResolution,
  type ResolutionOutcome,
} from "./incidentWorkflow";

/* =========================================================
   DỮ LIỆU KHẮC PHỤC SỰ CỐ
========================================================= */

export interface CreateIncidentResolutionInput {
  incidentId: string;
  resolution: string;
  outcome: ResolutionOutcome;
}

/* =========================================================
   XÁC NHẬN HOÀN THÀNH SỰ CỐ

   Quy trình: OPEN -> CLOSED

   - Bắt buộc đăng nhập.
   - Chỉ xử lý sự cố OPEN.
   - Lưu lịch sử khắc phục riêng biệt.
   - Tự động ghi nhận người xử lý.
   - Sử dụng Transaction.
========================================================= */

export async function createIncidentResolution(
  input: CreateIncidentResolutionInput
): Promise<string> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error("Bạn cần đăng nhập để xử lý sự cố.");
  }

  const incidentId = input.incidentId.trim();
  const resolution = input.resolution.trim();
  const outcome = input.outcome;

  if (!incidentId) {
    throw new Error("Thiếu ID sự cố.");
  }

  if (!resolution) {
    throw new Error("Vui lòng nhập nội dung khắc phục.");
  }

  if (outcome !== "OPEN" && outcome !== "RESOLVED") {
    throw new Error("Kết quả khắc phục không hợp lệ.");
  }

  const incidentRef = doc(db, "incidents", incidentId);

  let savedResolutionId = "";

  // await runTransaction(db, async (transaction) => {
  try {
  await runTransaction(db, async (transaction) => {
    const snapshot = await transaction.get(incidentRef);

    if (!snapshot.exists()) {
      throw new Error("Không tìm thấy sự cố.");
    }

    const incident = snapshot.data();

    if (incident.status !== "OPEN") {
      throw new Error(
        "Sự cố không còn ở trạng thái cho phép xử lý."
      );
    }

    if (
      typeof incident.deviceId !== "string" ||
      !incident.deviceId.trim()
    ) {
      throw new Error("Sự cố chưa có thông tin thiết bị.");
    }

    const previousCount =
      incident.resolutionAttemptCount ?? incident.resolutionCount;

    if (
      previousCount !== undefined &&
      (!Number.isSafeInteger(previousCount) ||
        previousCount < 0)
    ) {
      throw new Error("Số lần khắc phục không hợp lệ.");
    }

    const attemptNumber = (previousCount ?? 0) + 1;

    if (!Number.isSafeInteger(attemptNumber)) {
      throw new Error("Số lần khắc phục vượt giới hạn.");
    }

    /* ID lịch sử xác định theo sự cố và số lần xử lý */
    const resolutionId = `${incidentId}_${attemptNumber}`;

    const resolutionRef = doc(
      db,
      "incidentResolutions",
      resolutionId
    );
    const resolvedByName =
      user.displayName?.trim() ||
      user.email ||
      user.uid;

    /* Lưu lịch sử khắc phục */
    transaction.set(resolutionRef, {
      incidentId,
      deviceId: incident.deviceId,

      resolution,
      attemptNumber,

      resolvedByUid: user.uid,
      resolvedByName,
      resolvedByEmail: user.email || "",

      resolvedAt: serverTimestamp(),
      outcome,
    });

    const nextStatus = nextStatusAfterResolution(outcome);
    const incidentUpdate = {
      resolutionAttemptCount: attemptNumber,
      lastResolutionAttemptAt: serverTimestamp(),
      lastResolutionAttemptByUid: user.uid,
      ...(nextStatus === "RESOLVED"
        ? {
            status: "RESOLVED",
            resolution,
            resolvedAt: serverTimestamp(),
            resolvedByUid: user.uid,
            resolutionCount: attemptNumber,
          }
        : {}),
    };

    transaction.update(incidentRef, incidentUpdate);

      savedResolutionId = resolutionId;
  });
} catch (error) {
  console.error("[INCIDENT RESOLUTION ERROR]", error);

  if (error && typeof error === "object") {
    console.error(
      "[ERROR CODE]",
      "code" in error ? error.code : "unknown"
    );
  }

  throw error;
}

return savedResolutionId;
}
