
import {
  addDoc,
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  runTransaction,
  serverTimestamp,
  updateDoc,
  where,
} from "firebase/firestore";

import { db } from "../config/firebase";

import type {
  InspectionTemplate,
} from "../types/inspection";
import { isAdmin, type AppUser } from "../types/user";

const COLLECTION_NAME = "inspectionTemplates";

/* =====================================================
   LẤY DANH SÁCH MẪU KIỂM TRA
===================================================== */

export async function getInspectionTemplates(appUser: AppUser):
  Promise<InspectionTemplate[]> {
  const documents = isAdmin(appUser)
    ? await getDocs(collection(db, COLLECTION_NAME)).then((snapshot) => snapshot.docs)
    : (await Promise.all(
        Array.from({ length: Math.ceil(appUser.areaIds.length / 30) }, (_, index) =>
          appUser.areaIds.slice(index * 30, index * 30 + 30)
        ).filter((ids) => ids.length > 0).map((ids) =>
          getDocs(query(
            collection(db, COLLECTION_NAME),
            where("areaIds", "array-contains-any", ids),
          )),
        ),
      )).flatMap((snapshot) => snapshot.docs);

  const templates = documents.map((item) => ({
    ...(item.data() as Omit<InspectionTemplate, "id">),
    id: item.id,
  }));

  return [...new Map(templates.map((item) => [item.id, item])).values()]
    .sort((a, b) => a.name.localeCompare(b.name, "vi"));
}

/* =====================================================
   TẠO MẪU KIỂM TRA
===================================================== */

export type CreateInspectionTemplateInput =
  Omit<InspectionTemplate, "id">;

export async function getInspectionTemplate(id: string): Promise<InspectionTemplate | null> {
  if (!id.trim()) throw new Error("Không xác định được mẫu tuần kiểm.");
  const snapshot = await getDoc(doc(db, COLLECTION_NAME, id));
  return snapshot.exists()
    ? { ...(snapshot.data() as Omit<InspectionTemplate, "id">), id: snapshot.id }
    : null;
}

export async function createInspectionTemplate(
  data: CreateInspectionTemplateInput
): Promise<string> {

  const name = data.name.trim();

  if (!name) {
    throw new Error("Tên mẫu kiểm tra không được để trống.");
  }

  const newDocument = await addDoc(
    collection(db, COLLECTION_NAME),
    {
      ...data,
      name,
      version: 1,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    }
  );

  return newDocument.id;
}

/* =====================================================
   CẬP NHẬT MẪU KIỂM TRA

   Giữ nguyên Document ID.
   Không ghi đè dữ liệu của collection khác.
===================================================== */

export async function updateInspectionTemplate(
  id: string,
  data: Partial<Omit<InspectionTemplate, "id">>,
  options: { expectedVersion?: number } = {},
): Promise<void> {

  if (!id.trim()) {
    throw new Error("Không xác định được mẫu kiểm tra.");
  }

  if (data.name !== undefined && !data.name.trim()) {
    throw new Error("Tên mẫu kiểm tra không được để trống.");
  }

  const { version: _version, ...fields } = data;
  void _version;
  const ref = doc(db, COLLECTION_NAME, id);
  const contentChanged = ["name", "description", "tasks", "areaIds"]
    .some((field) => Object.hasOwn(fields, field));
  const updateFields = {
    ...fields,
    ...(fields.name !== undefined ? { name: fields.name.trim() } : {}),
    updatedAt: serverTimestamp(),
  };

  if (!contentChanged) {
    await updateDoc(ref, updateFields);
    return;
  }

  await runTransaction(db, async (transaction) => {
    const snapshot = await transaction.get(ref);
    if (!snapshot.exists()) throw new Error("Không tìm thấy mẫu tuần kiểm.");
    const currentVersion = Number(snapshot.data().version) || 1;
    if (options.expectedVersion !== undefined && currentVersion !== options.expectedVersion) {
      throw new Error("Mẫu đã được người khác cập nhật. Tải lại mẫu trước khi lưu.");
    }
    transaction.update(ref, { ...updateFields, version: currentVersion + 1 });
  });
}
