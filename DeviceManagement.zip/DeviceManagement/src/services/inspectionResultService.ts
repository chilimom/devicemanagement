
import {
  addDoc,
  collection,
  doc,
  getDoc,
  serverTimestamp,
  getDocs,
  query,
  where,
  orderBy,
} from "firebase/firestore";

import { auth, db } from "../config/firebase";

import type {
  InspectionRecord,
  InspectionTask,
  InspectionTaskResult,
} from "../types/inspection";

type CreateInspectionInput = {
  deviceId: string;
  planId: string;
  planVersion: number;
  inspectionDate: string;
  inspectionType: "SCHEDULED" | "EXTRA";
  inspectorName: string;
  results: InspectionTaskResult[];
  note?: string;
  remediationSource?: {
    recordId: string;
    taskId: string;
    criterionId: string;
  };
};

const COLLECTION_NAME = "inspectionResults";

function validateResults(
  tasks: InspectionTask[],
  results: InspectionTaskResult[]
): void {
  if (results.length === 0) {
    throw new Error("Chưa có kết quả tuần kiểm.");
  }

  const taskIds = new Set<string>();

  for (const result of results) {
    if (taskIds.has(result.taskId)) {
      throw new Error("Có công việc bị ghi kết quả trùng.");
    }

    taskIds.add(result.taskId);

    const task = tasks.find(
      (item) => item.id === result.taskId
    );

    if (!task) {
      throw new Error("Có công việc không thuộc kế hoạch.");
    }

    if (
      !["PASS", "WARNING", "FAIL", "NOT_CHECKED"].includes(
        result.status
      )
    ) {
      throw new Error("Trạng thái công việc không hợp lệ.");
    }

    const criterionIds = new Set<string>();

    for (const criterionResult of result.criteriaResults) {
      if (criterionIds.has(criterionResult.criterionId)) {
        throw new Error("Có tiêu chuẩn bị ghi kết quả trùng.");
      }

      criterionIds.add(criterionResult.criterionId);

      const criterion = task.criteria.find(
        (item) => item.id === criterionResult.criterionId
      );

      if (!criterion) {
        throw new Error(
          "Có tiêu chuẩn không thuộc công việc tuần kiểm."
        );
      }

      if (
        !["PASS", "WARNING", "FAIL", "NOT_CHECKED"].includes(
          criterionResult.status
        )
      ) {
        throw new Error("Trạng thái tiêu chuẩn không hợp lệ.");
      }

      if (
        criterion.inputType === "NUMBER" &&
        criterionResult.status !== "NOT_CHECKED"
      ) {
        if (
          typeof criterionResult.numericValue !== "number" ||
          !Number.isFinite(criterionResult.numericValue)
        ) {
          throw new Error(
            `Chưa nhập giá trị đo cho: ${criterion.standard}`
          );
        }
      }

      if (
        criterion.inputType === "TEXT" &&
        criterion.isRequired &&
        criterionResult.status !== "NOT_CHECKED" &&
        !criterionResult.textValue?.trim()
      ) {
        throw new Error(
          `Chưa nhập nội dung cho: ${criterion.standard}`
        );
      }

      if (
        criterion.isRequired &&
        criterionResult.status === "NOT_CHECKED"
      ) {
        throw new Error(
          `Chưa hoàn thành tiêu chuẩn: ${criterion.standard}`
        );
      }
    }

    for (const criterion of task.criteria) {
      if (
        criterion.isRequired &&
        !criterionIds.has(criterion.id)
      ) {
        throw new Error(
          `Thiếu kết quả tiêu chuẩn: ${criterion.standard}`
        );
      }
    }
  } 
}

export async function createInspectionResult(
  input: CreateInspectionInput
): Promise<string> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error("Bạn cần đăng nhập để thực hiện tuần kiểm.");
  }

  if (!input.deviceId.trim()) {
    throw new Error("Thiếu ID thiết bị.");
  }

  if (!input.inspectorName.trim()) {
    throw new Error("Vui lòng nhập họ tên người kiểm tra.");
  }

  if (input.remediationSource && input.inspectionType !== "EXTRA") {
    throw new Error("Kiểm tra khắc phục phải là lượt kiểm tra bổ sung.");
  }

  if (
    !/^\d{4}-\d{2}-\d{2}$/.test(input.inspectionDate)
  ) {
    throw new Error("Ngày kiểm tra không hợp lệ.");
  }

  const deviceSnapshot = await getDoc(
    doc(db, "devices", input.deviceId)
  );

  if (!deviceSnapshot.exists()) {
    throw new Error("Thiết bị không tồn tại.");
  }

  if (deviceSnapshot.data().isActive === false) {
    throw new Error(
      "Thiết bị ngừng hoạt động, không thể thực hiện tuần kiểm."
    );
  }

  const planSnapshot = await getDoc(
    doc(db, "deviceInspectionPlans", input.planId)
  );

  if (!planSnapshot.exists()) {
    throw new Error("Không tìm thấy kế hoạch tuần kiểm.");
  }

  const plan = planSnapshot.data();

  if (plan.deviceId !== input.deviceId) {
    throw new Error("Kế hoạch không thuộc thiết bị này.");
  }

  if (plan.isActive !== true) {
    throw new Error("Kế hoạch tuần kiểm đã ngừng hoạt động.");
  }

  if (plan.version !== input.planVersion) {
    throw new Error(
      "Kế hoạch đã thay đổi. Vui lòng tải lại trước khi lưu."
    );
  }

  const tasks = plan.tasks as InspectionTask[];

  if (input.remediationSource) {
    const sourceSnapshot = await getDoc(
      doc(db, COLLECTION_NAME, input.remediationSource.recordId),
    );
    if (!sourceSnapshot.exists() || sourceSnapshot.data().deviceId !== input.deviceId) {
      throw new Error("Phiếu tuần kiểm nguồn không thuộc thiết bị này.");
    }
    const sourceRecord = sourceSnapshot.data() as InspectionRecord;
    const sourceCriterion = sourceRecord.results
      ?.find((task) => task.taskId === input.remediationSource!.taskId)
      ?.criteriaResults.find((criterion) => criterion.criterionId === input.remediationSource!.criterionId);
    const planTask = tasks.find((task) => task.id === input.remediationSource!.taskId);
    if (!sourceCriterion || !planTask?.criteria.some((criterion) => criterion.id === input.remediationSource!.criterionId)) {
      throw new Error("Không tìm thấy tiêu chí tuần kiểm nguồn hợp lệ.");
    }
    if (sourceCriterion.status !== "WARNING" && sourceCriterion.status !== "FAIL") {
      throw new Error("Tiêu chí tuần kiểm nguồn không cần kiểm tra lại.");
    }
    const submittedCriterion = input.results
      .find((task) => task.taskId === input.remediationSource!.taskId)
      ?.criteriaResults.find((criterion) => criterion.criterionId === input.remediationSource!.criterionId);
    if (!submittedCriterion || input.results.some((task) => task.taskId !== input.remediationSource!.taskId || task.criteriaResults.some((criterion) => criterion.criterionId !== input.remediationSource!.criterionId))) {
      throw new Error("Lượt kiểm tra lại chỉ được chứa tiêu chí nguồn.");
    }
  }

  validateResults(tasks, input.results);

  const payload = {
    deviceId: input.deviceId,
    planId: input.planId,
    planVersion: plan.version,
    inspectionDate: input.inspectionDate,
    inspectionType: input.inspectionType,
    inspectorName: input.inspectorName.trim(),
    recordedByUid: user.uid,
    results: input.results,
    note: input.note?.trim() ?? "",
    ...(input.remediationSource ? { remediationSource: input.remediationSource } : {}),

    // Lưu bản sao kế hoạch tại thời điểm kiểm tra.
    planSnapshot: {
      name: plan.name,
      version: plan.version,
      tasks,
    },

    createdAt: serverTimestamp(),
  };

  const reference = await addDoc(
    collection(db, COLLECTION_NAME),
    payload
  );

  return reference.id;
}

export async function getInspectionResult(
  resultId: string
): Promise<InspectionRecord | null> {
  const snapshot = await getDoc(
    doc(db, COLLECTION_NAME, resultId)
  );

  if (!snapshot.exists()) {
    return null;
  }

  return {
    ...(snapshot.data() as Omit<InspectionRecord, "id">),
    id: snapshot.id,
  };
}

/**
 * Lấy lịch sử tuần kiểm của một thiết bị.
 *
 * - Chỉ lấy phiếu thuộc thiết bị được chọn.
 * - Sắp xếp mới nhất trước.
 * - Không sửa dữ liệu lịch sử.
 */
export async function getDeviceInspectionHistory(
  deviceId: string
): Promise<InspectionRecord[]> {
  if (!deviceId.trim()) {
    throw new Error("Thiếu ID thiết bị.");
  }

  const historyQuery = query(
    collection(db, COLLECTION_NAME),
    where("deviceId", "==", deviceId),
    orderBy("createdAt", "desc")
  );

  const snapshot = await getDocs(historyQuery);

  return snapshot.docs
    .map((document) => ({
      ...(document.data() as Omit<InspectionRecord, "id">),
      id: document.id,
    }))
    .filter((record) => record.deviceId === deviceId);
}
