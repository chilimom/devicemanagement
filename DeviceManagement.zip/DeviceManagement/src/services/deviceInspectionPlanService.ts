
import {
  doc,
  getDoc,
  runTransaction,
  serverTimestamp,
} from "firebase/firestore";

import { db } from "../config/firebase";

import type {
  DeviceInspectionPlan,
  InspectionTask,
} from "../types/inspection";

const COLLECTION_NAME = "deviceInspectionPlans";

export type CreateDeviceInspectionPlanInput =
  Omit<DeviceInspectionPlan, "id" | "version">;

export interface UpdateDeviceInspectionPlanInput {
  deviceId: string;
  expectedVersion: number;
  name: string;
  tasks: InspectionTask[];
}

function normalizeTasks(tasks: InspectionTask[]): InspectionTask[] {
  return tasks.map((task, index) => ({
    id: task.id,
    name: task.name.trim(),
    description: (task.description ?? "").trim(),
    order: index + 1,
    frequency: task.frequency,
    weekdays: [...task.weekdays].sort((a, b) => a - b),
    isActive: task.isActive,
    criteria: task.criteria.map((criterion) => ({
      id: criterion.id,
      category: criterion.category,
      standard: criterion.standard.trim(),
      inputType: criterion.inputType,
      isRequired: criterion.isRequired,
      ...(criterion.inputType === "NUMBER"
        ? {
            unit: (criterion.unit ?? "").trim(),
            minValue: criterion.minValue ?? null,
            maxValue: criterion.maxValue ?? null,
          }
        : {}),
    })),
  }));
}

function validateTasks(tasks: InspectionTask[]): void {
  if (tasks.length === 0) {
    throw new Error("Kế hoạch phải có ít nhất một công việc.");
  }

  for (const [index, task] of tasks.entries()) {
    if (!task.name.trim()) {
      throw new Error(`Công việc ${index + 1} chưa có tên.`);
    }

    if (task.frequency !== "WEEKLY") {
      throw new Error(
        `Công việc ${index + 1} chưa sử dụng lịch tuần hợp lệ.`
      );
    }

    if (
      task.weekdays.length === 0 ||
      task.weekdays.some(
        (day) => !Number.isInteger(day) || day < 1 || day > 7
      )
    ) {
      throw new Error(
        `Công việc ${index + 1} có lịch kiểm tra không hợp lệ.`
      );
    }

    if (task.criteria.length === 0) {
      throw new Error(
        `Công việc ${index + 1} chưa có tiêu chuẩn đánh giá.`
      );
    }

    for (const criterion of task.criteria) {
      if (!criterion.standard.trim()) {
        throw new Error(
          `Công việc ${index + 1} có tiêu chuẩn chưa nhập nội dung.`
        );
      }

      if (
        criterion.inputType === "NUMBER" &&
        criterion.minValue != null &&
        criterion.maxValue != null &&
        criterion.minValue > criterion.maxValue
      ) {
        throw new Error(
          `Công việc ${index + 1}: ngưỡng tối thiểu lớn hơn tối đa.`
        );
      }
    }
  }
}

/**
 * Lấy kế hoạch tuần kiểm của một thiết bị.
 * Trả về null nếu thiết bị chưa được gán kế hoạch.
 */
export async function getDeviceInspectionPlan(
  deviceId: string
): Promise<DeviceInspectionPlan | null> {
  if (!deviceId.trim()) {
    throw new Error("Thiếu ID thiết bị.");
  }

  const snapshot = await getDoc(
    doc(db, COLLECTION_NAME, deviceId)
  );

  if (!snapshot.exists()) {
    return null;
  }

  return {
    ...(snapshot.data() as Omit<DeviceInspectionPlan, "id">),
    id: snapshot.id,
  };
}

/**
 * Tạo kế hoạch lần đầu.
 *
 * - Không thay đổi mẫu gốc.
 * - Không thay đổi document thiết bị.
 * - Không ghi đè kế hoạch đã tồn tại.
 */
export async function createDeviceInspectionPlan(
  data: CreateDeviceInspectionPlanInput
): Promise<string> {
  const deviceId = data.deviceId.trim();

  if (!deviceId) {
    throw new Error("Chưa xác định thiết bị.");
  }

  if (!data.name.trim()) {
    throw new Error("Vui lòng nhập tên kế hoạch.");
  }

  validateTasks(data.tasks);

  const normalizedTasks = normalizeTasks(data.tasks);

  const planRef = doc(db, COLLECTION_NAME, deviceId);
  const deviceRef = doc(db, "devices", deviceId);

  await runTransaction(db, async (transaction) => {
    const deviceSnapshot = await transaction.get(deviceRef);
    const planSnapshot = await transaction.get(planRef);

    if (!deviceSnapshot.exists()) {
      throw new Error("Thiết bị không tồn tại.");
    }

    if (deviceSnapshot.data().isActive === false) {
      throw new Error(
        "Không thể tạo kế hoạch cho thiết bị ngừng hoạt động."
      );
    }

    if (planSnapshot.exists()) {
      throw new Error(
        "Thiết bị đã có kế hoạch tuần kiểm. Không tạo trùng."
      );
    }

    transaction.set(planRef, {
      deviceId,
      ...(data.templateId
        ? { templateId: data.templateId }
        : {}),
      name: data.name.trim(),
      tasks: normalizedTasks,
      isActive: data.isActive,
      version: 1,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  });

  return deviceId;
}

/** Cập nhật lịch của plan hiện có và tăng version một cách nguyên tử. */
export async function updateDeviceInspectionPlan(
  data: UpdateDeviceInspectionPlanInput,
): Promise<number> {
  const deviceId = data.deviceId.trim();
  const name = data.name.trim();
  if (!deviceId) throw new Error("Chưa xác định thiết bị.");
  if (!name) throw new Error("Vui lòng nhập tên kế hoạch.");
  if (!Number.isInteger(data.expectedVersion) || data.expectedVersion < 1) {
    throw new Error("Phiên bản kế hoạch không hợp lệ. Tải lại kế hoạch trước khi lưu.");
  }
  validateTasks(data.tasks);
  const tasks = normalizeTasks(data.tasks);
  const planRef = doc(db, COLLECTION_NAME, deviceId);
  const deviceRef = doc(db, "devices", deviceId);

  return runTransaction(db, async (transaction) => {
    const [deviceSnapshot, planSnapshot] = await Promise.all([
      transaction.get(deviceRef),
      transaction.get(planRef),
    ]);
    if (!deviceSnapshot.exists()) throw new Error("Thiết bị không tồn tại.");
    if (!planSnapshot.exists()) throw new Error("Không tìm thấy kế hoạch tuần kiểm.");
    const currentPlan = planSnapshot.data();
    if (currentPlan.deviceId !== deviceId) throw new Error("Kế hoạch không thuộc thiết bị này.");
    if (currentPlan.version !== data.expectedVersion) {
      throw new Error("Kế hoạch đã được thay đổi. Tải lại trước khi lưu.");
    }

    const nextVersion = data.expectedVersion + 1;
    transaction.update(planRef, {
      name,
      tasks,
      version: nextVersion,
      updatedAt: serverTimestamp(),
    });
    return nextVersion;
  });
}
