import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from "firebase/firestore";
import type { User } from "firebase/auth";
import { db } from "../config/firebase";
import type { AppUser, UserRole } from "../types/user";
import { isAdmin } from "../types/user";
import { getAllUsers, parseAppUser } from "./userService";

export interface UserInvite {
  email: string;
  displayName: string;
  role: UserRole;
  areaIds: string[];
  status: "PENDING" | "ACCEPTED";
  createdByUid: string;
  acceptedByUid: string | null;
}

export function normalizeInviteEmail(email: string): string {
  return email.trim().toLowerCase();
}

export async function createUserInvite(
  actor: AppUser,
  input: Pick<UserInvite, "email" | "displayName" | "role" | "areaIds">,
): Promise<void> {
  const email = normalizeInviteEmail(input.email);
  const areaIds = [...new Set(input.areaIds.map((id) => id.trim()).filter(Boolean))];
  if (!email || (input.role === "ADMIN" && !isAdmin(actor))) {
    throw new Error("Lời mời không hợp lệ.");
  }

  await setDoc(doc(db, "invites", email), {
    email,
    displayName: input.displayName.trim(),
    role: input.role,
    areaIds,
    status: "PENDING",
    createdByUid: actor.uid,
    createdAt: serverTimestamp(),
    acceptedByUid: null,
    acceptedAt: null,
  });
}

export async function loadManageableUsers(actor: AppUser): Promise<{
  users: AppUser[];
  invites: UserInvite[];
}> {
  const inviteQuery = isAdmin(actor)
    ? collection(db, "invites")
    : query(collection(db, "invites"), where("createdByUid", "==", actor.uid));
  const inviteSnapshot = await getDocs(inviteQuery);
  const invites = inviteSnapshot.docs.map((item) => item.data() as UserInvite);

  if (isAdmin(actor)) return { users: await getAllUsers(), invites };

  const acceptedUids = [...new Set(
    invites.map((invite) => invite.acceptedByUid).filter((uid): uid is string => Boolean(uid)),
  )];
  const users: AppUser[] = [];
  for (const uid of acceptedUids) {
    const snapshot = await getDoc(doc(db, "users", uid));
    if (snapshot.exists()) users.push(parseAppUser(snapshot.id, snapshot.data()));
  }
  return { users, invites };
}

export async function updateManagedUser(
  uid: string,
  changes: Pick<AppUser, "displayName" | "role" | "areaIds" | "isActive">,
): Promise<void> {
  await updateDoc(doc(db, "users", uid), {
    displayName: changes.displayName.trim(),
    role: changes.role,
    areaIds: [...new Set(changes.areaIds.map((id) => id.trim()).filter(Boolean))],
    isActive: changes.isActive,
  });
}

export async function acceptCurrentUserInvite(user: User): Promise<void> {
  await user.reload();
  await user.getIdToken(true);
  if (!user.email || !user.emailVerified) throw new Error("EMAIL_NOT_VERIFIED");
  const email = normalizeInviteEmail(user.email);
  if (email !== user.email) throw new Error("EMAIL_NOT_CANONICAL");

  await runTransaction(db, async (transaction) => {
    const inviteRef = doc(db, "invites", email);
    const userRef = doc(db, "users", user.uid);
    const [inviteSnapshot, profileSnapshot] = await Promise.all([
      transaction.get(inviteRef),
      transaction.get(userRef),
    ]);
    if (!inviteSnapshot.exists() || profileSnapshot.exists()) {
      throw new Error("INVITE_NOT_AVAILABLE");
    }
    const invite = inviteSnapshot.data() as UserInvite;
    if (invite.status !== "PENDING" || invite.email !== email) {
      throw new Error("INVITE_NOT_AVAILABLE");
    }
    transaction.set(userRef, {
      displayName: invite.displayName,
      email,
      role: invite.role,
      areaIds: invite.areaIds,
      isActive: true,
    });
    transaction.update(inviteRef, {
      status: "ACCEPTED",
      acceptedByUid: user.uid,
      acceptedAt: serverTimestamp(),
    });
  });
}

export async function hasCurrentUserInvite(user: User): Promise<boolean> {
  if (!user.email || !user.emailVerified) return false;
  await user.getIdToken(true);
  const email = normalizeInviteEmail(user.email);
  if (email !== user.email) return false;
  const snapshot = await getDoc(doc(db, "invites", email));
  return snapshot.exists() && snapshot.data().status === "PENDING";
}
