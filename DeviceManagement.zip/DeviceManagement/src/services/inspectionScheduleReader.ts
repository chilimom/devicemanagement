import { collection, getDocs, query, where } from "firebase/firestore";

import { db } from "../config/firebase";
import type { DeviceInspectionPlan, InspectionRecord } from "../types/inspection";
import {
  evaluateInspectionScheduleStatus,
  getVietnamToday,
  type InspectionScheduleStatus,
} from "./inspectionScheduleStatus";

function timestampToDate(value: unknown): string | undefined {
  if (!value || typeof value !== "object" || !("toDate" in value)) return undefined;
  const toDate = (value as { toDate?: unknown }).toDate;
  if (typeof toDate !== "function") return undefined;
  return getVietnamToday(toDate.call(value) as Date);
}

async function loadDeviceScheduleStatus(
  deviceId: string,
  today: string,
): Promise<InspectionScheduleStatus> {
  const [planSnapshot, resultSnapshot, maintenanceSnapshot] = await Promise.all([
    getDocs(query(collection(db, "deviceInspectionPlans"), where("deviceId", "==", deviceId))),
    getDocs(query(collection(db, "inspectionResults"), where("deviceId", "==", deviceId))),
    getDocs(query(collection(db, "maintenances"), where("deviceId", "==", deviceId))),
  ]);
  const planDocument = planSnapshot.docs[0];
  const plan = planDocument
    ? ({
        ...(planDocument.data() as Omit<DeviceInspectionPlan, "id">),
        id: planDocument.id,
      } satisfies DeviceInspectionPlan)
    : null;
  const records = resultSnapshot.docs.map((document) => ({
    ...(document.data() as Omit<InspectionRecord, "id">),
    id: document.id,
  }));
  const approvedMaintenanceSources = maintenanceSnapshot.docs.flatMap((document) => {
    const data = document.data();
    const source = data.inspectionSource as { recordId?: string; taskId?: string; criterionId?: string } | undefined;
    return data.status === "COMPLETED" && source?.recordId && source.taskId && source.criterionId
      ? [{ recordId: source.recordId, taskId: source.taskId, criterionId: source.criterionId }]
      : [];
  });

  return evaluateInspectionScheduleStatus({
    plan,
    records,
    approvedMaintenanceSources,
    today,
    planCreatedDate: timestampToDate(plan?.createdAt),
  });
}

export async function loadInspectionScheduleStatuses(
  deviceIds: string[],
): Promise<Map<string, InspectionScheduleStatus>> {
  const statuses = new Map<string, InspectionScheduleStatus>();
  const today = getVietnamToday();

  // Giới hạn số query đồng thời để tránh tạo tải đột biến trên Spark plan.
  for (let index = 0; index < deviceIds.length; index += 6) {
    const batch = deviceIds.slice(index, index + 6);
    const batchStatuses = await Promise.all(
      batch.map(async (deviceId) => [
        deviceId,
        await loadDeviceScheduleStatus(deviceId, today),
      ] as const),
    );
    for (const [deviceId, status] of batchStatuses) statuses.set(deviceId, status);
  }

  return statuses;
}
