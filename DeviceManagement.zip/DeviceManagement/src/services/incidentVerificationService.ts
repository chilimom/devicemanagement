import {
  doc,
  runTransaction,
  serverTimestamp,
} from "firebase/firestore";

import { auth, db } from "../config/firebase";
import {
  hasCurrentAreaAccessForVerification,
  type VerificationDeviceAccess,
  type VerificationUserProfile,
} from "./incidentWorkflow";

export interface CreateIncidentVerificationInput {
  incidentId: string;
  note: string;
}

/**
 * Atomically records the only verification for an incident and closes it.
 *
 * The verification document ID is the incident ID so future Firestore Rules
 * can use getAfter() to prove that both writes belong to the same incident.
 */
export async function createIncidentVerification(
  input: CreateIncidentVerificationInput,
): Promise<string> {
  const user = auth.currentUser;

  if (!user) {
    throw new Error("Bạn cần đăng nhập để xác minh sự cố.");
  }

  const incidentId = input.incidentId.trim();
  const note = input.note.trim();

  if (!incidentId) {
    throw new Error("Thiếu ID sự cố.");
  }

  if (!note) {
    throw new Error("Vui lòng nhập nội dung xác minh.");
  }

  const incidentRef = doc(db, "incidents", incidentId);
  const verificationRef = doc(db, "incidentVerifications", incidentId);
  const profileRef = doc(db, "users", user.uid);

  await runTransaction(db, async (transaction) => {
    const incidentSnapshot = await transaction.get(incidentRef);

    if (!incidentSnapshot.exists()) {
      throw new Error("Không tìm thấy sự cố.");
    }

    const incident = incidentSnapshot.data();
    if (incident.status !== "RESOLVED") {
      throw new Error("Sự cố không còn ở trạng thái chờ xác minh.");
    }

    if (typeof incident.deviceId !== "string" || !incident.deviceId.trim()) {
      throw new Error("Sự cố chưa có thông tin thiết bị.");
    }

    const deviceId = incident.deviceId.trim();
    const deviceRef = doc(db, "devices", deviceId);

    // Keep every read before every write in this transaction.
    const [deviceSnapshot, profileSnapshot, fixedVerificationSnapshot] =
      await Promise.all([
        transaction.get(deviceRef),
        transaction.get(profileRef),
        transaction.get(verificationRef),
      ]);

    if (!deviceSnapshot.exists()) {
      throw new Error("Không tìm thấy thiết bị của sự cố.");
    }

    if (!profileSnapshot.exists()) {
      throw new Error("Không tìm thấy hồ sơ tài khoản.");
    }

    if (
      !hasCurrentAreaAccessForVerification(
        profileSnapshot.data() as VerificationUserProfile,
        deviceSnapshot.data() as VerificationDeviceAccess,
      )
    ) {
      throw new Error("Bạn không có quyền xác minh sự cố này.");
    }

    if (fixedVerificationSnapshot.exists()) {
      throw new Error("Sự cố đã có bản ghi xác minh.");
    }

    const previousCount = incident.verificationCount;
    if (
      previousCount !== undefined &&
      (!Number.isSafeInteger(previousCount) || previousCount < 0)
    ) {
      throw new Error("Số lần xác minh hiện tại không hợp lệ.");
    }

    if (previousCount !== undefined && previousCount !== 0) {
      throw new Error(
        "Sự cố đã có dấu vết xác minh. Cần đối soát dữ liệu cũ trước khi tiếp tục.",
      );
    }

    const verifiedByName = user.displayName?.trim() || user.email || user.uid;

    transaction.set(verificationRef, {
      incidentId,
      deviceId,
      note,
      attemptNumber: 1,
      verifiedByUid: user.uid,
      verifiedByName,
      verifiedByEmail: user.email || "",
      verifiedAt: serverTimestamp(),
    });

    transaction.update(incidentRef, {
      status: "CLOSED",
      verificationCount: 1,
      lastVerifiedByUid: user.uid,
      lastVerifiedByName: verifiedByName,
      lastVerifiedAt: serverTimestamp(),
      closedAt: serverTimestamp(),
    });
  });

  return verificationRef.id;
}
