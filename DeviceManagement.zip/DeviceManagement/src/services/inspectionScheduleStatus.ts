import type {
  DeviceInspectionPlan,
  InspectionRecord,
  InspectionResultStatus,
  InspectionTask,
} from "../types/inspection";

export type InspectionScheduleState =
  | "OVERDUE"
  | "DUE_TODAY"
  | "COMPLETED_TODAY"
  | "NO_SCHEDULE_TODAY"
  | "NO_PLAN"
  | "INACTIVE_PLAN";

export interface InspectionScheduleStatus {
  state: InspectionScheduleState;
  overdueTaskCount: number;
  dueTaskCount: number;
  completedTodayCount: number;
  todayResultStatus: InspectionResultStatus | null;
}

interface ScheduleStatusInput {
  plan: DeviceInspectionPlan | null;
  records: InspectionRecord[];
  approvedMaintenanceSources?: Array<{ recordId: string; taskId: string; criterionId: string }>;
  today: string;
  planCreatedDate?: string;
}

function parseDate(date: string): Date {
  return new Date(`${date}T00:00:00.000Z`);
}

function addDays(date: string, days: number): string {
  const value = parseDate(date);
  value.setUTCDate(value.getUTCDate() + days);
  return value.toISOString().slice(0, 10);
}

function weekday(date: string): number {
  const day = parseDate(date).getUTCDay();
  return day === 0 ? 7 : day;
}

function latestPreviousOccurrence(task: InspectionTask, today: string): string {
  for (let offset = 1; offset <= 7; offset += 1) {
    const candidate = addDays(today, -offset);
    if (task.weekdays.includes(weekday(candidate))) return candidate;
  }
  return "";
}

function completedTaskDates(records: InspectionRecord[]): Map<string, Set<string>> {
  const datesByTask = new Map<string, Set<string>>();

  for (const record of records) {
    for (const result of record.results) {
      const dates = datesByTask.get(result.taskId) ?? new Set<string>();
      dates.add(record.inspectionDate);
      datesByTask.set(result.taskId, dates);
    }
  }

  return datesByTask;
}

function timestampMillis(value: unknown): number {
  if (!value || typeof value !== "object" || !("toMillis" in value)) return 0;
  const toMillis = (value as { toMillis?: unknown }).toMillis;
  return typeof toMillis === "function" ? Number(toMillis.call(value)) || 0 : 0;
}

function latestTodayResults(
  records: InspectionRecord[],
  today: string,
  approvedMaintenanceSources: Array<{ recordId: string; taskId: string; criterionId: string }>,
) {
  const latest = new Map<string, { status: InspectionResultStatus; createdAt: number; id: string }>();
  const approvedKeys = new Set(approvedMaintenanceSources.map((source) => `${source.recordId}\u0000${source.taskId}\u0000${source.criterionId}`));

  for (const record of records) {
    if (record.inspectionDate !== today) continue;
    const createdAt = timestampMillis(record.createdAt);
    for (const result of record.results) {
      const criterionStatuses = result.criteriaResults?.map((criterion) =>
        (criterion.status === "FAIL" || criterion.status === "WARNING")
          && approvedKeys.has(`${record.id}\u0000${result.taskId}\u0000${criterion.criterionId}`)
          ? "PASS" as const
          : criterion.status,
      ) ?? [];
      const effectiveStatus = criterionStatuses.length > 0
        ? aggregateTodayResultStatus(criterionStatuses) ?? result.status
        : result.status;
      const current = latest.get(result.taskId);
      if (!current || createdAt > current.createdAt || (createdAt === current.createdAt && record.id > current.id)) {
        latest.set(result.taskId, { status: effectiveStatus, createdAt, id: record.id });
      }
    }
  }

  return latest;
}

function aggregateTodayResultStatus(statuses: InspectionResultStatus[]): InspectionResultStatus | null {
  if (statuses.includes("FAIL")) return "FAIL";
  if (statuses.includes("WARNING")) return "WARNING";
  if (statuses.includes("NOT_CHECKED")) return "NOT_CHECKED";
  return statuses.length > 0 ? "PASS" : null;
}

function hasCompletionBetween(
  dates: Set<string> | undefined,
  from: string,
  to: string,
): boolean {
  if (!dates) return false;
  return [...dates].some((date) => date >= from && date <= to);
}

export function getVietnamToday(now = new Date()): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Ho_Chi_Minh",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(now);
  const values = new Map(parts.map((part) => [part.type, part.value]));
  return `${values.get("year")}-${values.get("month")}-${values.get("day")}`;
}

export function evaluateInspectionScheduleStatus({
  plan,
  records,
  approvedMaintenanceSources = [],
  today,
  planCreatedDate,
}: ScheduleStatusInput): InspectionScheduleStatus {
  if (!plan) {
    return { state: "NO_PLAN", overdueTaskCount: 0, dueTaskCount: 0, completedTodayCount: 0, todayResultStatus: null };
  }
  if (!plan.isActive) {
    return { state: "INACTIVE_PLAN", overdueTaskCount: 0, dueTaskCount: 0, completedTodayCount: 0, todayResultStatus: null };
  }

  const tasks = plan.tasks.filter((task) => task.isActive);
  const datesByTask = completedTaskDates(records);
  const todayWeekday = weekday(today);
  const dueToday = tasks.filter((task) => task.weekdays.includes(todayWeekday));
  const completedToday = dueToday.filter((task) =>
    datesByTask.get(task.id)?.has(today),
  );
  const todayResults = latestTodayResults(records, today, approvedMaintenanceSources);
  const todayResultStatus = aggregateTodayResultStatus(
    tasks.flatMap((task) => {
      const result = todayResults.get(task.id);
      return result ? [result.status] : [];
    }),
  );
  const overdue = tasks.filter((task) => {
    const occurrence = latestPreviousOccurrence(task, today);
    if (!occurrence || (planCreatedDate && occurrence < planCreatedDate)) return false;
    return !hasCompletionBetween(datesByTask.get(task.id), occurrence, today);
  });

  if (overdue.length > 0) {
    return {
      state: "OVERDUE",
      overdueTaskCount: overdue.length,
      dueTaskCount: dueToday.length,
      completedTodayCount: completedToday.length,
      todayResultStatus,
    };
  }
  if (dueToday.length > completedToday.length) {
    return {
      state: "DUE_TODAY",
      overdueTaskCount: 0,
      dueTaskCount: dueToday.length,
      completedTodayCount: completedToday.length,
      todayResultStatus,
    };
  }
  if (dueToday.length > 0) {
    return {
      state: "COMPLETED_TODAY",
      overdueTaskCount: 0,
      dueTaskCount: dueToday.length,
      completedTodayCount: completedToday.length,
      todayResultStatus,
    };
  }
  return {
    state: "NO_SCHEDULE_TODAY",
    overdueTaskCount: 0,
    dueTaskCount: 0,
    completedTodayCount: 0,
    todayResultStatus,
  };
}
