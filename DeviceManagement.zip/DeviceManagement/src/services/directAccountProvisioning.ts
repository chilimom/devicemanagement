import { deleteApp, initializeApp } from "firebase/app";
import {
  createUserWithEmailAndPassword,
  inMemoryPersistence,
  initializeAuth,
  signOut,
} from "firebase/auth";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from "firebase/firestore";
import { auth, db, firebaseConfig } from "../config/firebase";
import type { AppUser, UserRole } from "../types/user";
import { isAdmin } from "../types/user";
import { getAllUsers, parseAppUser } from "./userService";
import { isPermissionDenied } from "./sharedRamCache";

export type ProvisioningStatus =
  | "PENDING_AUTH"
  | "AUTH_CREATED_PROFILE_PENDING"
  | "ACTIVE";

export interface ProvisioningAttempt {
  email: string;
  displayName: string;
  role: Exclude<UserRole, "ADMIN">;
  areaIds: string[];
  status: ProvisioningStatus;
  createdByUid: string;
  targetUid: string | null;
  errorCode: string;
}

export interface ProvisionAccountInput {
  email: string;
  displayName: string;
  role: Exclude<UserRole, "ADMIN">;
  areaIds: string[];
  password?: string;
}

export interface ProvisionAccountResult {
  uid: string;
  email: string;
  resumedProfile: boolean;
}

export type ProvisioningStep =
  | "CHECK_ATTEMPT"
  | "CREATE_ATTEMPT"
  | "CREATE_AUTH"
  | "ACTIVATE_PROFILE";

export class ProvisioningStepError extends Error {
  readonly step: ProvisioningStep;
  readonly code: string;

  constructor(step: ProvisioningStep, cause: unknown) {
    const code = typeof cause === "object" && cause && "code" in cause
      ? String(cause.code)
      : cause instanceof Error
        ? cause.message
        : "UNKNOWN";
    super(code);
    this.step = step;
    this.code = code;
  }
}

export class ProvisioningIncompleteError extends Error {
  readonly uid: string;
  readonly email: string;
  readonly code: string;

  constructor(
    uid: string,
    email: string,
    cause: unknown,
  ) {
    super("AUTH_CREATED_PROFILE_PENDING");
    this.uid = uid;
    this.email = email;
    this.code = typeof cause === "object" && cause && "code" in cause
      ? String(cause.code)
      : "PROFILE_WRITE_FAILED";
  }
}

export function normalizeProvisioningEmail(value: string): string {
  return value.trim().toLowerCase();
}

function normalizeInput(actor: AppUser, input: ProvisionAccountInput): ProvisionAccountInput {
  const email = normalizeProvisioningEmail(input.email);
  const displayName = input.displayName.trim();
  const areaIds = [...new Set(input.areaIds.map((id) => id.trim()).filter(Boolean))];
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !displayName || areaIds.length === 0) {
    throw new Error("INVALID_ACCOUNT_DATA");
  }
  if (!isAdmin(actor) && (input.role !== "USER" || areaIds.some((id) => !actor.areaIds.includes(id)))) {
    throw new Error("OUTSIDE_MANAGEMENT_SCOPE");
  }
  if (input.role !== "USER" && input.role !== "AREA_ADMIN") {
    throw new Error("INVALID_ACCOUNT_ROLE");
  }
  return { email, displayName, role: input.role, areaIds, password: input.password };
}

async function commitProfile(attempt: ProvisioningAttempt, uid: string): Promise<void> {
  const batch = writeBatch(db);
  batch.set(doc(db, "users", uid), {
    displayName: attempt.displayName,
    email: attempt.email,
    role: attempt.role,
    areaIds: attempt.areaIds,
    isActive: true,
  });
  batch.update(doc(db, "accountProvisioningAttempts", attempt.email), {
    status: "ACTIVE",
    targetUid: uid,
    errorCode: "",
    updatedAt: serverTimestamp(),
  });
  await batch.commit();
}

export async function provisionAccount(
  actor: AppUser,
  rawInput: ProvisionAccountInput,
): Promise<ProvisionAccountResult> {
  const input = normalizeInput(actor, rawInput);
  const attemptRef = doc(db, "accountProvisioningAttempts", input.email);
  let existing;
  try {
    existing = await getDoc(attemptRef);
  } catch (error) {
    throw new ProvisioningStepError("CHECK_ATTEMPT", error);
  }

  if (existing.exists()) {
    const attempt = existing.data() as ProvisioningAttempt;
    if (attempt.status === "AUTH_CREATED_PROFILE_PENDING" && attempt.targetUid) {
      await commitProfile(attempt, attempt.targetUid);
      return { uid: attempt.targetUid, email: attempt.email, resumedProfile: true };
    }
    throw new Error(attempt.status === "ACTIVE" ? "ACCOUNT_ALREADY_PROVISIONED" : "PROVISIONING_REQUIRES_CONSOLE_REVIEW");
  }

  if (!input.password || input.password.length < 6) {
    throw new Error("INVALID_PASSWORD");
  }

  const attempt: ProvisioningAttempt = {
    email: input.email,
    displayName: input.displayName,
    role: input.role,
    areaIds: input.areaIds,
    status: "PENDING_AUTH",
    createdByUid: actor.uid,
    targetUid: null,
    errorCode: "",
  };
  try {
    await setDoc(attemptRef, {
      ...attempt,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    throw new ProvisioningStepError("CREATE_ATTEMPT", error);
  }

  const defaultUid = auth.currentUser?.uid;
  const secondaryApp = initializeApp(firebaseConfig, `provision-${crypto.randomUUID()}`);
  const secondaryAuth = initializeAuth(secondaryApp, { persistence: inMemoryPersistence });
  let createdUid = "";

  try {
    let credential;
    try {
      credential = await createUserWithEmailAndPassword(
        secondaryAuth,
        input.email,
        input.password,
      );
    } catch (error) {
      throw new ProvisioningStepError("CREATE_AUTH", error);
    }
    createdUid = credential.user.uid;
    try {
      await commitProfile(attempt, createdUid);
    } catch (profileError) {
      try {
        await updateDoc(attemptRef, {
          status: "AUTH_CREATED_PROFILE_PENDING",
          targetUid: createdUid,
          errorCode: "PROFILE_WRITE_FAILED",
          updatedAt: serverTimestamp(),
        });
      } catch {
        // The UID is still returned in the explicit incomplete error for manual recovery.
      }
      throw new ProvisioningIncompleteError(createdUid, input.email, profileError);
    }

    if (auth.currentUser?.uid !== defaultUid) throw new Error("DEFAULT_AUTH_SESSION_CHANGED");
    return { uid: createdUid, email: input.email, resumedProfile: false };
  } catch (error) {
    if (!createdUid && !(error instanceof ProvisioningIncompleteError)) {
      const code = typeof error === "object" && error && "code" in error ? String(error.code) : "AUTH_CREATE_FAILED";
      try {
        await updateDoc(attemptRef, { errorCode: code, updatedAt: serverTimestamp() });
      } catch {
        // Preserve the original Auth error.
      }
    }
    throw error;
  } finally {
    await signOut(secondaryAuth).catch(() => undefined);
    await deleteApp(secondaryApp).catch(() => undefined);
  }
}

export async function loadDirectManageableUsers(actor: AppUser): Promise<{
  users: AppUser[];
  attempts: ProvisioningAttempt[];
}> {
  const attemptsQuery = isAdmin(actor)
    ? collection(db, "accountProvisioningAttempts")
    : query(collection(db, "accountProvisioningAttempts"), where("createdByUid", "==", actor.uid));
  const snapshot = await getDocs(attemptsQuery);
  const attempts = snapshot.docs.map((item) => item.data() as ProvisioningAttempt);
  if (isAdmin(actor)) return { users: await getAllUsers(), attempts };

  const users: AppUser[] = [];
  for (const attempt of attempts) {
    if (attempt.status !== "ACTIVE" || !attempt.targetUid) continue;
    try {
      const profile = await getDoc(doc(db, "users", attempt.targetUid));
      if (profile.exists()) users.push(parseAppUser(profile.id, profile.data()));
    } catch (error) {
      if (!isPermissionDenied(error)) throw error;
    }
  }
  return { users, attempts };
}
