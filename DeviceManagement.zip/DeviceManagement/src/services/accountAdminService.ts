import { auth } from "../config/firebase";

// Local-only admin API is reached through Vite's same-origin dev proxy.
const ACCOUNT_API_URL = import.meta.env.DEV ? "/__account-admin" : null;

export class AccountServiceError extends Error {
  readonly status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function callAccountService<T>(
  path: string,
  body?: Record<string, unknown>,
): Promise<T> {
  if (!ACCOUNT_API_URL) {
    throw new AccountServiceError(0, "LOCAL_SERVICE_REQUIRES_LOCAL_UI");
  }

  const user = auth.currentUser;
  if (!user) throw new AccountServiceError(401, "NOT_SIGNED_IN");

  // getIdToken() tự làm mới token khi sắp hết hạn
  const token = await user.getIdToken();

  let response: Response;
  try {
    response = await fetch(`${ACCOUNT_API_URL}${path}`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        ...(body ? { "Content-Type": "application/json" } : {}),
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
  } catch {
    // Service chưa chạy, hoặc trình duyệt chặn (CORS / quyền truy cập mạng nội bộ)
    throw new AccountServiceError(0, "SERVICE_UNREACHABLE");
  }

  const data: unknown = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message =
      typeof data === "object" && data !== null && "error" in data
        ? String((data as { error: unknown }).error)
        : "UNKNOWN_ERROR";
    throw new AccountServiceError(response.status, message);
  }
  return data as T;
}

export function setPasswordViaService(uid: string, password: string) {
  return callAccountService<{ uid: string; passwordChanged: true }>(
    `/users/${encodeURIComponent(uid)}/reset-password`,
    { password },
  );
}

export function setActiveViaService(uid: string, active: boolean) {
  return callAccountService<{ uid: string; isActive: boolean }>(
    `/users/${encodeURIComponent(uid)}/${active ? "enable" : "disable"}`,
  );
}
