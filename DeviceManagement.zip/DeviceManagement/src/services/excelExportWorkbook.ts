import ExcelJS from "exceljs";

import {
  EXCEL_SHEET_ORDER,
  type ExcelCellValue,
  type ExcelExportTables,
  type ExcelSheetName,
  type ExcelSheetTable,
} from "./excelExportTransform.js";

export const EXCEL_MAX_ROWS_PER_SHEET = 1_048_576;
const HEADER_ROW_NUMBER = 1;
const DATE_ONLY_COLUMNS = new Set(["Ngày kiểm tra"]);
const DANGEROUS_TEXT_PATTERN = /^[=+\-@]/;

export interface ExcelExportFile {
  fileName: string;
  data: Uint8Array;
}

export class ExcelExportWorkbookError extends Error {
  constructor(message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = "ExcelExportWorkbookError";
  }
}

function validateTables(tables: ExcelExportTables): void {
  if (tables.sheets.length !== EXCEL_SHEET_ORDER.length) {
    throw new ExcelExportWorkbookError(
      `Dữ liệu xuất phải có đúng ${EXCEL_SHEET_ORDER.length} sheet.`,
    );
  }

  for (let index = 0; index < EXCEL_SHEET_ORDER.length; index += 1) {
    const expectedName = EXCEL_SHEET_ORDER[index];
    const sheet = tables.sheets[index];

    if (sheet.name !== expectedName) {
      throw new ExcelExportWorkbookError(
        `Sai thứ tự sheet tại vị trí ${index + 1}: cần ${expectedName}, nhận ${sheet.name}.`,
      );
    }

    if (sheet.columns.length === 0) {
      throw new ExcelExportWorkbookError(`Sheet ${sheet.name} không có cột.`);
    }

    if (new Set(sheet.columns).size !== sheet.columns.length) {
      throw new ExcelExportWorkbookError(
        `Sheet ${sheet.name} có tên cột bị trùng.`,
      );
    }

    const totalRows = sheet.rows.length + HEADER_ROW_NUMBER;
    if (totalRows > EXCEL_MAX_ROWS_PER_SHEET) {
      throw new ExcelExportWorkbookError(
        `Sheet ${sheet.name} có ${totalRows.toLocaleString("vi-VN")} dòng, vượt giới hạn ${EXCEL_MAX_ROWS_PER_SHEET.toLocaleString("vi-VN")} dòng của Excel (đã tính hàng tiêu đề).`,
      );
    }
  }
}

function isTextColumn(header: string): boolean {
  return (
    /^(ID|UID)\b/i.test(header) ||
    /\bID\b/i.test(header) ||
    /Mã/i.test(header) ||
    /IP|MAC|serial/i.test(header)
  );
}

function columnWidth(header: string): number {
  if (header === "STT") return 7;
  if (/Mô tả|Nội dung|Tiêu chí|Ghi chú|Kết quả ghi nhận/i.test(header)) return 36;
  if (/Thời điểm|Thời gian|Ngày /i.test(header)) return 21;
  if (isTextColumn(header)) return 24;
  if (/Tên /i.test(header)) return 26;
  if (/Trạng thái|Kết quả|Phiên bản|Bắt buộc|hoạt động/i.test(header)) return 18;
  return Math.min(28, Math.max(12, header.length + 3));
}

function columnNumberFormat(header: string): string | undefined {
  if (isTextColumn(header)) return "@";
  if (DATE_ONLY_COLUMNS.has(header)) return "dd/mm/yyyy";
  if (/Thời điểm|Thời gian|^Ngày /i.test(header)) return "dd/mm/yyyy hh:mm";
  return undefined;
}

function shouldWrapText(header: string): boolean {
  return /Mô tả|Nội dung|Tiêu chí|Ghi chú|Kết quả ghi nhận|Trạng thái xác minh/i
    .test(header);
}

function assertCellValue(
  sheetName: ExcelSheetName,
  rowNumber: number,
  header: string,
  value: unknown,
): asserts value is ExcelCellValue {
  if (typeof value === "string") {
    if (DANGEROUS_TEXT_PATTERN.test(value)) {
      throw new ExcelExportWorkbookError(
        `Chuỗi chưa được bảo vệ tại sheet ${sheetName}, dòng ${rowNumber}, cột ${header}.`,
      );
    }
    return;
  }

  if (typeof value === "number") {
    if (!Number.isFinite(value)) {
      throw new ExcelExportWorkbookError(
        `Số không hợp lệ tại sheet ${sheetName}, dòng ${rowNumber}, cột ${header}.`,
      );
    }
    return;
  }

  if (value instanceof Date && !Number.isNaN(value.getTime())) return;

  throw new ExcelExportWorkbookError(
    `Kiểu dữ liệu không hợp lệ tại sheet ${sheetName}, dòng ${rowNumber}, cột ${header}.`,
  );
}

function configureWorksheet(
  worksheet: ExcelJS.Worksheet,
  sheet: ExcelSheetTable,
): void {
  worksheet.views = [{ state: "frozen", ySplit: 1 }];
  worksheet.autoFilter = {
    from: { row: HEADER_ROW_NUMBER, column: 1 },
    to: { row: HEADER_ROW_NUMBER, column: sheet.columns.length },
  };

  worksheet.columns = sheet.columns.map((header) => ({
    header,
    width: columnWidth(header),
    style: {
      numFmt: columnNumberFormat(header),
      alignment: {
        vertical: "top",
        horizontal: header === "STT" ? "center" : undefined,
        wrapText: shouldWrapText(header),
      },
    },
  }));

  const headerRow = worksheet.getRow(HEADER_ROW_NUMBER);
  headerRow.height = 24;
  headerRow.font = { bold: true, color: { argb: "FFFFFFFF" } };
  headerRow.fill = {
    type: "pattern",
    pattern: "solid",
    fgColor: { argb: "FF1F4E78" },
  };
  headerRow.alignment = {
    vertical: "middle",
    horizontal: "center",
    wrapText: true,
  };
  headerRow.eachCell((cell) => {
    cell.border = {
      bottom: { style: "thin", color: { argb: "FFD9E2F3" } },
    };
  });
}

function appendRows(
  worksheet: ExcelJS.Worksheet,
  sheet: ExcelSheetTable,
): void {
  for (let index = 0; index < sheet.rows.length; index += 1) {
    const sourceRow = sheet.rows[index];
    const excelRowNumber = index + 2;
    const values = sheet.columns.map((header) => {
      const value = sourceRow[header];
      assertCellValue(sheet.name, excelRowNumber, header, value);
      return value;
    });

    worksheet.addRow(values);
  }
}

/** Creates a complete in-memory workbook without reading Firestore. */
export function createExcelExportWorkbook(
  tables: ExcelExportTables,
): ExcelJS.Workbook {
  validateTables(tables);

  const workbook = new ExcelJS.Workbook();
  workbook.creator = "DeviceManagement";
  workbook.company = "DeviceManagement";
  workbook.calcProperties.fullCalcOnLoad = false;

  for (const sheet of tables.sheets) {
    const worksheet = workbook.addWorksheet(sheet.name, {
      properties: { defaultRowHeight: 18 },
    });
    configureWorksheet(worksheet, sheet);
    appendRows(worksheet, sheet);
  }

  return workbook;
}

function pad(value: number): string {
  return String(value).padStart(2, "0");
}

export function createExcelExportFileName(now: Date = new Date()): string {
  if (Number.isNaN(now.getTime())) {
    throw new ExcelExportWorkbookError("Không thể tạo tên file từ ngày không hợp lệ.");
  }

  return (
    `QuanLyThietBi_${now.getFullYear()}` +
    `${pad(now.getMonth() + 1)}${pad(now.getDate())}_` +
    `${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}.xlsx`
  );
}

/** Serializes all six sheets. No file is exposed if serialization fails. */
export async function createExcelExportFile(
  tables: ExcelExportTables,
  now: Date = new Date(),
): Promise<ExcelExportFile> {
  try {
    const workbook = createExcelExportWorkbook(tables);
    const buffer = await workbook.xlsx.writeBuffer();
    return {
      fileName: createExcelExportFileName(now),
      data: new Uint8Array(buffer),
    };
  } catch (error) {
    if (error instanceof ExcelExportWorkbookError) throw error;
    throw new ExcelExportWorkbookError("Không thể tạo file Excel hoàn chỉnh.", {
      cause: error,
    });
  }
}

/** Browser-only download helper; call only after createExcelExportFile succeeds. */
export async function downloadExcelExportFile(
  tables: ExcelExportTables,
  now: Date = new Date(),
): Promise<string> {
  const file = await createExcelExportFile(tables, now);
  const arrayBuffer = new ArrayBuffer(file.data.byteLength);
  new Uint8Array(arrayBuffer).set(file.data);
  const blob = new Blob([arrayBuffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const url = URL.createObjectURL(blob);

  try {
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = file.fileName;
    anchor.style.display = "none";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
  } finally {
    URL.revokeObjectURL(url);
  }

  return file.fileName;
}
