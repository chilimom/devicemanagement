import type {
  ExcelExportDataSet,
  ExcelExportDocument,
} from "../types/excelExport.js";

export const EXCEL_SHEET_ORDER = [
  "DM_ThietBi",
  "DM_SuCo",
  "LS_KhacPhuc",
  "LS_XacMinh",
  "DM_TuanKiem",
  "KQ_TuanKiem",
] as const;

export type ExcelSheetName = (typeof EXCEL_SHEET_ORDER)[number];
export type ExcelCellValue = string | number | Date;
export type ExcelExportRow = Record<string, ExcelCellValue>;

export interface ExcelSheetTable {
  name: ExcelSheetName;
  columns: readonly string[];
  rows: ExcelExportRow[];
}

export interface ExcelExportTables {
  sheets: readonly [
    ExcelSheetTable,
    ExcelSheetTable,
    ExcelSheetTable,
    ExcelSheetTable,
    ExcelSheetTable,
    ExcelSheetTable,
  ];
  byName: Record<ExcelSheetName, ExcelSheetTable>;
}

export const EXCEL_APPROVED_COLUMNS = {
  DM_ThietBi: [
    "STT", "Mã thiết bị", "Tên thiết bị", "Lĩnh vực", "Loại thiết bị",
    "Khu vực", "Hãng / Model", "Địa chỉ IP", "Trạng thái", "Ngày tạo",
  ],
  DM_SuCo: [
    "STT", "Mã thiết bị", "Tên thiết bị", "Tên khu vực", "Loại thiết bị",
    "Tiêu đề sự cố", "Mô tả sự cố", "Nội dung khắc phục",
    "Thời gian sự cố", "Thời gian khắc phục", "Người khắc phục",
    "Trạng thái xác minh đóng sự cố",
  ],
  LS_KhacPhuc: [
    "STT", "Mã thiết bị", "Tên thiết bị", "Khu vực", "Tiêu đề sự cố",
    "Lần khắc phục", "Nội dung khắc phục", "Người khắc phục",
    "Thời gian khắc phục", "Kết quả khắc phục",
  ],
  LS_XacMinh: [
    "STT", "Mã thiết bị", "Tên thiết bị", "Khu vực", "Tiêu đề sự cố",
    "Người xác minh", "Thời gian xác minh", "Kết quả xác minh",
    "Trạng thái đóng sự cố",
  ],
  DM_TuanKiem: [
    "STT", "Mã thiết bị", "Tên thiết bị", "Khu vực", "Loại thiết bị",
    "Tên kế hoạch", "Hạng mục kiểm tra", "Tiêu chí kiểm tra",
    "Trạng thái kế hoạch", "Ngày tạo",
  ],
  KQ_TuanKiem: [
    "STT", "Mã thiết bị", "Tên thiết bị", "Khu vực", "Tên kế hoạch",
    "Ngày kiểm tra", "Người kiểm tra", "Hạng mục kiểm tra",
    "Tiêu chí kiểm tra", "Giá trị/Kết quả ghi nhận", "Đánh giá", "Ghi chú",
  ],
} as const satisfies Record<ExcelSheetName, readonly string[]>;

type UnknownRecord = Record<string, unknown>;

function isRecord(value: unknown): value is UnknownRecord {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function protectExcelText(value: string): string {
  return /^[=+\-@]/.test(value) ? `'${value}` : value;
}

function text(value: unknown): string {
  return typeof value === "string" ? protectExcelText(value) : "";
}

function finiteNumber(value: unknown): number | "" {
  return typeof value === "number" && Number.isFinite(value) ? value : "";
}

function timestampDate(value: unknown): Date | "" {
  if (value instanceof Date) {
    return Number.isNaN(value.getTime()) ? "" : new Date(value.getTime());
  }
  if (!isRecord(value) || typeof value.toDate !== "function") return "";
  try {
    const converted = value.toDate();
    return converted instanceof Date && !Number.isNaN(converted.getTime())
      ? new Date(converted.getTime())
      : "";
  } catch {
    return "";
  }
}

export function localDateOnly(value: unknown): Date | "" {
  if (typeof value !== "string") return "";
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return "";
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const result = new Date(year, month - 1, day);
  return result.getFullYear() === year &&
    result.getMonth() === month - 1 &&
    result.getDate() === day
    ? result
    : "";
}

function mapById<T extends ExcelExportDocument>(items: T[]): Map<string, T> {
  return new Map(items.map((item) => [item.id, item]));
}

function linkedDocument<T extends ExcelExportDocument>(
  source: UnknownRecord,
  field: string,
  lookup: Map<string, T>,
): T | undefined {
  const id = source[field];
  return typeof id === "string" ? lookup.get(id) : undefined;
}

function dataOf(document: ExcelExportDocument | undefined): UnknownRecord {
  return document?.data ?? {};
}

function combinedText(left: unknown, right: unknown, separator: string): string {
  const leftText = text(left);
  const rightText = text(right);
  if (leftText && rightText) return `${leftText}${separator}${rightText}`;
  return leftText || rightText;
}

function areaDisplay(area: UnknownRecord): string {
  return combinedText(area.code, area.name, " - ");
}

function isEmailLike(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

function userDisplayNameMap(dataSet: ExcelExportDataSet): Map<string, string> {
  const result = new Map<string, string>();
  for (const user of dataSet.users) {
    if (
      typeof user.data.displayName === "string" &&
      user.data.displayName.trim().length > 0 &&
      !isEmailLike(user.data.displayName)
    ) {
      result.set(user.id, user.data.displayName);
    }
  }
  return result;
}

function actorDisplayName(
  snapshotName: unknown,
  uid: unknown,
  userNames: Map<string, string>,
): string {
  if (
    typeof snapshotName === "string" &&
    snapshotName.trim().length > 0 &&
    snapshotName !== uid &&
    !isEmailLike(snapshotName)
  ) {
    return text(snapshotName);
  }
  if (typeof uid !== "string" || uid.length === 0) return "";
  return text(userNames.get(uid));
}

function incidentAttemptKey(incidentId: string, attemptNumber: number): string {
  return `${incidentId}\u0000${attemptNumber}`;
}

function resolutionByAttemptMap(
  dataSet: ExcelExportDataSet,
): Map<string, UnknownRecord> {
  const result = new Map<string, UnknownRecord>();
  for (const resolution of dataSet.incidentResolutions) {
    const { incidentId, attemptNumber } = resolution.data;
    if (
      typeof incidentId === "string" &&
      typeof attemptNumber === "number" &&
      Number.isSafeInteger(attemptNumber)
    ) {
      result.set(incidentAttemptKey(incidentId, attemptNumber), resolution.data);
    }
  }
  return result;
}

function verificationByIncidentMap(
  dataSet: ExcelExportDataSet,
): Map<string, UnknownRecord> {
  const result = new Map<string, UnknownRecord>();
  for (const verification of dataSet.incidentVerifications) {
    if (typeof verification.data.incidentId === "string") {
      result.set(verification.data.incidentId, verification.data);
    }
  }
  return result;
}

function validVerification(
  verification: UnknownRecord | undefined,
  incidentId: string,
  deviceId: unknown,
): boolean {
  return verification?.incidentId === incidentId &&
    verification.deviceId === deviceId &&
    verification.attemptNumber === 1 &&
    typeof verification.note === "string" &&
    verification.note.trim().length > 0 &&
    typeof verification.verifiedByUid === "string" &&
    verification.verifiedByUid.length > 0 &&
    typeof verification.verifiedByName === "string" &&
    verification.verifiedByName.length > 0 &&
    timestampDate(verification.verifiedAt) instanceof Date;
}

function deviceStatusLabel(value: unknown): string {
  switch (value) {
    case "ACTIVE": return "Hoạt động";
    case "WARNING": return "Cảnh báo";
    case "OFFLINE": return "Mất kết nối";
    case "MAINTENANCE": return "Bảo trì";
    default: return "";
  }
}

function resolutionOutcomeLabel(value: unknown): string {
  switch (value) {
    case "OPEN": return "Chưa đạt — sự cố tiếp tục mở";
    case "RESOLVED": return "Đạt — chờ xác minh";
    default: return "";
  }
}

function inspectionStatusLabel(value: unknown): string {
  switch (value) {
    case "PASS": return "Đạt";
    case "WARNING": return "Cảnh báo";
    case "FAIL": return "Không đạt";
    case "NOT_CHECKED": return "Chưa kiểm tra";
    default: return "";
  }
}

function planStatusLabel(value: unknown): string {
  if (value === true) return "Đang hoạt động";
  if (value === false) return "Ngừng hoạt động";
  return "";
}

function closureVerificationStatus(
  incidentId: string,
  incident: UnknownRecord,
  verification: UnknownRecord | undefined,
): string {
  if (incident.status === "CLOSED") {
    return validVerification(verification, incidentId, incident.deviceId)
      ? "Đã xác minh, đã đóng"
      : "";
  }
  if (incident.status === "RESOLVED") return "Chờ xác minh";
  if (incident.status === "OPEN") return "Chưa xác minh";
  return "";
}

function deviceContext(
  source: UnknownRecord,
  deviceMap: Map<string, ExcelExportDocument>,
  areaMap: Map<string, ExcelExportDocument>,
  typeMap: Map<string, ExcelExportDocument>,
): { device: UnknownRecord; area: UnknownRecord; deviceType: UnknownRecord } {
  const device = dataOf(linkedDocument(source, "deviceId", deviceMap));
  const area = dataOf(linkedDocument(device, "areaId", areaMap));
  const deviceType = dataOf(linkedDocument(device, "deviceTypeId", typeMap));
  return { device, area, deviceType };
}

function deviceRows(dataSet: ExcelExportDataSet): ExcelExportRow[] {
  const areaMap = mapById(dataSet.areas);
  const subAreaMap = mapById(dataSet.subAreas);
  const typeMap = mapById(dataSet.deviceTypes);
  const categoryMap = mapById(dataSet.deviceCategories);
  return dataSet.devices.map(({ data }) => {
    const area = dataOf(linkedDocument(data, "areaId", areaMap));
    const deviceType = dataOf(linkedDocument(data, "deviceTypeId", typeMap));
    const category = dataOf(linkedDocument(deviceType, "categoryId", categoryMap));
    return {
      "Mã thiết bị": text(data.code),
      "Tên thiết bị": text(data.name),
      "Lĩnh vực": text(category.name),
      "Loại thiết bị": text(deviceType.name),
      "Khu vực": combinedText(areaDisplay(area), areaDisplay(dataOf(linkedDocument(data, "subAreaId", subAreaMap))), " / "),
      "Hãng / Model": combinedText(data.manufacturer, data.model, " / "),
      "Địa chỉ IP": text(data.ipAddress),
      "Trạng thái": deviceStatusLabel(data.status),
      "Ngày tạo": timestampDate(data.createdAt),
    };
  });
}

function incidentRows(dataSet: ExcelExportDataSet): ExcelExportRow[] {
  const deviceMap = mapById(dataSet.devices);
  const areaMap = mapById(dataSet.areas);
  const typeMap = mapById(dataSet.deviceTypes);
  const resolutions = resolutionByAttemptMap(dataSet);
  const verifications = verificationByIncidentMap(dataSet);
  const userNames = userDisplayNameMap(dataSet);
  return dataSet.incidents.map(({ id, data }) => {
    const { device, area, deviceType } = deviceContext(
      data, deviceMap, areaMap, typeMap,
    );
    const finalAttempt = typeof data.resolutionCount === "number" &&
      Number.isSafeInteger(data.resolutionCount)
      ? resolutions.get(incidentAttemptKey(id, data.resolutionCount))
      : undefined;
    const resolvedByUid = data.resolvedByUid ?? finalAttempt?.resolvedByUid;
    const resolverName = actorDisplayName(
      finalAttempt && finalAttempt.resolvedByUid === resolvedByUid
        ? finalAttempt.resolvedByName
        : undefined,
      resolvedByUid,
      userNames,
    );
    const verification = verifications.get(id);
    return {
      "Mã thiết bị": text(data.deviceCode) || text(device.code),
      "Tên thiết bị": text(data.deviceName) || text(device.name),
      "Tên khu vực": text(area.name),
      "Loại thiết bị": text(deviceType.name),
      "Tiêu đề sự cố": text(data.title),
      "Mô tả sự cố": text(data.description),
      "Nội dung khắc phục": text(data.resolution) || text(finalAttempt?.resolution),
      "Thời gian sự cố": timestampDate(data.reportedAt),
      "Thời gian khắc phục": timestampDate(data.resolvedAt) ||
        timestampDate(finalAttempt?.resolvedAt),
      "Người khắc phục": resolverName,
      "Trạng thái xác minh đóng sự cố": closureVerificationStatus(
        id, data, verification,
      ),
    };
  });
}

function resolutionRows(dataSet: ExcelExportDataSet): ExcelExportRow[] {
  const deviceMap = mapById(dataSet.devices);
  const areaMap = mapById(dataSet.areas);
  const typeMap = mapById(dataSet.deviceTypes);
  const incidentMap = mapById(dataSet.incidents);
  const userNames = userDisplayNameMap(dataSet);
  return dataSet.incidentResolutions.map(({ data }) => {
    const { device, area } = deviceContext(data, deviceMap, areaMap, typeMap);
    const incident = dataOf(linkedDocument(data, "incidentId", incidentMap));
    return {
      "Mã thiết bị": text(device.code) || text(incident.deviceCode),
      "Tên thiết bị": text(device.name) || text(incident.deviceName),
      "Khu vực": areaDisplay(area),
      "Tiêu đề sự cố": text(incident.title),
      "Lần khắc phục": finiteNumber(data.attemptNumber),
      "Nội dung khắc phục": text(data.resolution),
      "Người khắc phục": actorDisplayName(
        data.resolvedByName, data.resolvedByUid, userNames,
      ),
      "Thời gian khắc phục": timestampDate(data.resolvedAt),
      "Kết quả khắc phục": resolutionOutcomeLabel(data.outcome),
    };
  });
}

function verificationRows(dataSet: ExcelExportDataSet): ExcelExportRow[] {
  const deviceMap = mapById(dataSet.devices);
  const areaMap = mapById(dataSet.areas);
  const typeMap = mapById(dataSet.deviceTypes);
  const incidentMap = mapById(dataSet.incidents);
  const userNames = userDisplayNameMap(dataSet);
  return dataSet.incidentVerifications.map(({ data }) => {
    const { device, area } = deviceContext(data, deviceMap, areaMap, typeMap);
    const incident = dataOf(linkedDocument(data, "incidentId", incidentMap));
    const incidentId = typeof data.incidentId === "string" ? data.incidentId : "";
    return {
      "Mã thiết bị": text(device.code) || text(incident.deviceCode),
      "Tên thiết bị": text(device.name) || text(incident.deviceName),
      "Khu vực": areaDisplay(area),
      "Tiêu đề sự cố": text(incident.title),
      "Người xác minh": actorDisplayName(
        data.verifiedByName, data.verifiedByUid, userNames,
      ),
      "Thời gian xác minh": timestampDate(data.verifiedAt),
      "Kết quả xác minh": text(data.note),
      "Trạng thái đóng sự cố": incident.status === "CLOSED" &&
        validVerification(data, incidentId, incident.deviceId)
        ? "Đã đóng"
        : "",
    };
  });
}

function planRows(dataSet: ExcelExportDataSet): ExcelExportRow[] {
  const deviceMap = mapById(dataSet.devices);
  const areaMap = mapById(dataSet.areas);
  const typeMap = mapById(dataSet.deviceTypes);
  const rows: ExcelExportRow[] = [];
  for (const { data } of dataSet.deviceInspectionPlans) {
    const { device, area, deviceType } = deviceContext(
      data, deviceMap, areaMap, typeMap,
    );
    const tasks = Array.isArray(data.tasks) && data.tasks.length > 0
      ? data.tasks : [undefined];
    for (const taskValue of tasks) {
      const task = isRecord(taskValue) ? taskValue : {};
      const criteria = Array.isArray(task.criteria) && task.criteria.length > 0
        ? task.criteria : [undefined];
      for (const criterionValue of criteria) {
        const criterion = isRecord(criterionValue) ? criterionValue : {};
        rows.push({
          "Mã thiết bị": text(device.code),
          "Tên thiết bị": text(device.name),
          "Khu vực": areaDisplay(area),
          "Loại thiết bị": text(deviceType.name),
          "Tên kế hoạch": text(data.name),
          "Hạng mục kiểm tra": text(task.name),
          "Tiêu chí kiểm tra": text(criterion.standard),
          "Trạng thái kế hoạch": planStatusLabel(data.isActive),
          "Ngày tạo": timestampDate(data.createdAt),
        });
      }
    }
  }
  return rows;
}

function snapshotTaskMap(planSnapshot: unknown): Map<string, UnknownRecord> {
  if (!isRecord(planSnapshot) || !Array.isArray(planSnapshot.tasks)) {
    return new Map();
  }
  const entries: [string, UnknownRecord][] = [];
  for (const value of planSnapshot.tasks) {
    if (isRecord(value) && typeof value.id === "string") {
      entries.push([value.id, value]);
    }
  }
  return new Map(entries);
}

function snapshotCriterion(
  task: UnknownRecord,
  criterionId: unknown,
): UnknownRecord {
  if (typeof criterionId !== "string" || !Array.isArray(task.criteria)) return {};
  const found = task.criteria.find(
    (value) => isRecord(value) && value.id === criterionId,
  );
  return isRecord(found) ? found : {};
}

function recordedValue(
  criterionResult: UnknownRecord,
  criterion: UnknownRecord,
): ExcelCellValue {
  const number = finiteNumber(criterionResult.numericValue);
  if (number !== "") {
    const unit = text(criterion.unit);
    return unit ? `${number} ${unit}` : number;
  }
  return text(criterionResult.textValue);
}

function combinedNotes(
  criterionResult: UnknownRecord,
  taskResult: UnknownRecord,
  inspectionResult: UnknownRecord,
): string {
  const parts: string[] = [];
  const criterionNote = text(criterionResult.note);
  const taskNote = text(taskResult.note);
  const inspectionNote = text(inspectionResult.note);
  if (criterionNote) parts.push(`Tiêu chí: ${criterionNote}`);
  if (taskNote) parts.push(`Hạng mục: ${taskNote}`);
  if (inspectionNote) parts.push(`Phiếu: ${inspectionNote}`);
  return parts.join(" | ");
}

function inspectionResultRows(dataSet: ExcelExportDataSet): ExcelExportRow[] {
  const deviceMap = mapById(dataSet.devices);
  const areaMap = mapById(dataSet.areas);
  const typeMap = mapById(dataSet.deviceTypes);
  const rows: ExcelExportRow[] = [];
  for (const { data } of dataSet.inspectionResults) {
    const { device, area } = deviceContext(data, deviceMap, areaMap, typeMap);
    const snapshot = isRecord(data.planSnapshot) ? data.planSnapshot : {};
    const taskMap = snapshotTaskMap(data.planSnapshot);
    const results = Array.isArray(data.results) && data.results.length > 0
      ? data.results : [undefined];
    for (const resultValue of results) {
      const result = isRecord(resultValue) ? resultValue : {};
      const snapshotTask = typeof result.taskId === "string"
        ? taskMap.get(result.taskId) ?? {} : {};
      const criteriaResults = Array.isArray(result.criteriaResults) &&
        result.criteriaResults.length > 0
        ? result.criteriaResults : [undefined];
      for (const criterionResultValue of criteriaResults) {
        const criterionResult = isRecord(criterionResultValue)
          ? criterionResultValue : {};
        const criterion = snapshotCriterion(
          snapshotTask, criterionResult.criterionId,
        );
        const hasCriterion = Object.keys(criterionResult).length > 0;
        rows.push({
          "Mã thiết bị": text(device.code),
          "Tên thiết bị": text(device.name),
          "Khu vực": areaDisplay(area),
          "Tên kế hoạch": text(snapshot.name),
          "Ngày kiểm tra": localDateOnly(data.inspectionDate),
          "Người kiểm tra": text(data.inspectorName),
          "Hạng mục kiểm tra": text(snapshotTask.name),
          "Tiêu chí kiểm tra": text(criterion.standard),
          "Giá trị/Kết quả ghi nhận": recordedValue(criterionResult, criterion),
          "Đánh giá": inspectionStatusLabel(
            hasCriterion ? criterionResult.status : result.status,
          ),
          "Ghi chú": combinedNotes(criterionResult, result, data),
        });
      }
    }
  }
  return rows;
}

const DEVICE_CODE_COLUMN = "Mã thiết bị";
const sequenceCollator = new Intl.Collator("vi", {
  numeric: true,
  sensitivity: "base",
});

function compareCellValues(left: ExcelCellValue, right: ExcelCellValue): number {
  if (left instanceof Date && right instanceof Date) {
    return left.getTime() - right.getTime();
  }
  if (typeof left === "number" && typeof right === "number") {
    return left - right;
  }
  return sequenceCollator.compare(String(left), String(right));
}

function compareRows(left: ExcelExportRow, right: ExcelExportRow): number {
  const columns = Object.keys(left).filter(
    (column) => column !== "STT" && column !== DEVICE_CODE_COLUMN,
  );
  for (const column of columns) {
    const compared = compareCellValues(left[column], right[column]);
    if (compared !== 0) return compared;
  }
  return 0;
}

function groupAndNumberRows(rows: ExcelExportRow[]): ExcelExportRow[] {
  const codedGroups = new Map<string, Array<{ row: ExcelExportRow; index: number }>>();
  const missingCodeRows: Array<{ row: ExcelExportRow; index: number }> = [];

  rows.forEach((row, index) => {
    const rawCode = row[DEVICE_CODE_COLUMN];
    const code = typeof rawCode === "string" ? rawCode.trim() : "";
    if (!code) {
      missingCodeRows.push({ row, index });
      return;
    }
    const group = codedGroups.get(code) ?? [];
    group.push({ row, index });
    codedGroups.set(code, group);
  });

  const groups = [...codedGroups.entries()]
    .sort(([left], [right]) => sequenceCollator.compare(left, right))
    .map(([, entries]) => entries);
  missingCodeRows
    .sort((left, right) => compareRows(left.row, right.row) || left.index - right.index)
    .forEach((entry) => groups.push([entry]));

  let sequence = 0;
  return groups.flatMap((entries) => {
    sequence += 1;
    return entries
      .sort((left, right) => compareRows(left.row, right.row) || left.index - right.index)
      .map(({ row }, index) => ({ STT: index === 0 ? sequence : "", ...row }));
  });
}

function table(name: ExcelSheetName, rows: ExcelExportRow[]): ExcelSheetTable {
  return {
    name,
    columns: EXCEL_APPROVED_COLUMNS[name],
    rows: groupAndNumberRows(rows),
  };
}

export function transformExcelExportData(
  dataSet: ExcelExportDataSet,
): ExcelExportTables {
  const sheets: ExcelExportTables["sheets"] = [
    table("DM_ThietBi", deviceRows(dataSet)),
    table("DM_SuCo", incidentRows(dataSet)),
    table("LS_KhacPhuc", resolutionRows(dataSet)),
    table("LS_XacMinh", verificationRows(dataSet)),
    table("DM_TuanKiem", planRows(dataSet)),
    table("KQ_TuanKiem", inspectionResultRows(dataSet)),
  ];
  return {
    sheets,
    byName: Object.fromEntries(sheets.map((item) => [item.name, item])) as
      Record<ExcelSheetName, ExcelSheetTable>,
  };
}
