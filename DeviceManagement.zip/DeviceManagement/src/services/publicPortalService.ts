import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  serverTimestamp,
  setDoc,
  where,
  writeBatch,
} from "firebase/firestore";

import { db } from "../config/firebase";

export type PublicInspectionState =
  | "OVERDUE" | "DUE_TODAY" | "COMPLETED_TODAY"
  | "NO_SCHEDULE_TODAY" | "NO_PLAN" | "INACTIVE_PLAN";

export interface PublicAreaSummary { id: string; code: string; name: string; status: string; totalDevices: number; }
export interface PublicDeviceSummary { id: string; code: string; name: string; areaId: string; areaName: string; categoryName: string; deviceTypeName: string; status: string; isActive: boolean; inspectionState: PublicInspectionState; inspectionCount: number; }
export interface PublicIncidentSummary { id: string; deviceCode: string; deviceName: string; severity: string; status: string; reportedAt?: unknown; }
export interface PublicMaintenanceSummary { id: string; deviceCode: string; deviceName: string; maintenanceType: string; status: string; performedAt?: unknown; }

export interface PublicPortalData {
  areas: PublicAreaSummary[];
  devices: PublicDeviceSummary[];
  incidents: PublicIncidentSummary[];
  maintenances: PublicMaintenanceSummary[];
}

const COLLECTIONS = ["publicAreas", "publicDevices", "publicIncidents", "publicMaintenances"] as const;

export async function loadPublicPortalData(): Promise<PublicPortalData> {
  const config = await getDoc(doc(db, "publicPortal", "current"));
  if (!config.exists() || typeof config.data().generation !== "string") {
    return { areas: [], devices: [], incidents: [], maintenances: [] };
  }
  const generation = config.data().generation as string;
  const snapshots = await Promise.all(COLLECTIONS.map((name) =>
    getDocs(query(collection(db, name), where("generation", "==", generation))),
  ));
  return {
    areas: snapshots[0].docs.map((item) => ({ id: item.id, ...item.data() } as PublicAreaSummary)),
    devices: snapshots[1].docs.map((item) => ({ id: item.id, ...item.data() } as PublicDeviceSummary)),
    incidents: snapshots[2].docs.map((item) => ({ id: item.id, ...item.data() } as PublicIncidentSummary)),
    maintenances: snapshots[3].docs.map((item) => ({ id: item.id, ...item.data() } as PublicMaintenanceSummary)),
  };
}

export async function publishPublicPortal(data: PublicPortalData): Promise<void> {
  const generation = `${Date.now()}`;
  const writes = [
    ...data.areas.map((item) => ["publicAreas", item] as const),
    ...data.devices.map((item) => ["publicDevices", item] as const),
    ...data.incidents.map((item) => ["publicIncidents", item] as const),
    ...data.maintenances.map((item) => ["publicMaintenances", item] as const),
  ];

  for (let index = 0; index < writes.length; index += 450) {
    const batch = writeBatch(db);
    for (const [collectionName, item] of writes.slice(index, index + 450)) {
      const { id, ...summary } = item;
      batch.set(doc(db, collectionName, id), { ...summary, generation });
    }
    await batch.commit();
  }

  await setDoc(doc(db, "publicPortal", "current"), {
    generation,
    publishedAt: serverTimestamp(),
  });
}
