
import {
  collection,
  doc,
  getDoc,
  getDocs,
} from "firebase/firestore";
import { db } from "../config/firebase";
import type { AppUser, UserRole } from "../types/user";

/**
 * Validate and normalize a Firestore user profile. Shared by one-time reads
 * and the realtime profile listener.
 */
export function parseAppUser(
  uid: string,
  data: Record<string, unknown>,
): AppUser {
  if (!uid.trim()) {
    throw new Error("Invalid user identifier.");
  }

  if (
    data.role !== "ADMIN" &&
    data.role !== "AREA_ADMIN" &&
    data.role !== "USER"
  ) {
    throw new Error("Invalid user role.");
  }

  if (data.isActive !== true && data.isActive !== false) {
    throw new Error("Invalid user status.");
  }

  if (
    data.areaIds !== undefined &&
    (!Array.isArray(data.areaIds) ||
      !data.areaIds.every(
        (areaId: unknown) =>
          typeof areaId === "string" && areaId.trim().length > 0
      ))
  ) {
    throw new Error("Invalid assigned areas.");
  }

  return {
    uid,
    displayName:
      typeof data.displayName === "string"
        ? data.displayName
        : "",
    email:
      typeof data.email === "string" ? data.email : "",
    role: data.role as UserRole,
    isActive: data.isActive,
    areaIds: Array.isArray(data.areaIds)
      ? [...new Set(data.areaIds.map((areaId: string) => areaId.trim()))]
      : [],
  };
}

/**
 * Đọc hồ sơ người dùng từ Firestore.
 *
 * Collection: users
 * Document ID: Firebase Authentication UID
 */
export async function getAppUser(
  uid: string,
): Promise<AppUser | null> {
  if (!uid.trim()) {
    return null;
  }

  const userRef = doc(db, "users", uid);
  const userSnap = await getDoc(userRef);

  if (!userSnap.exists()) {
    return null;
  }

  const data = userSnap.data();

  // Không tự cấp quyền cho dữ liệu sai hoặc thiếu.
  if (
    data.role !== "ADMIN" &&
    data.role !== "AREA_ADMIN" &&
    data.role !== "USER"
  ) {
    throw new Error("Vai trò người dùng không hợp lệ.");
  }

  if (data.isActive !== true && data.isActive !== false) {
    throw new Error("Trạng thái tài khoản không hợp lệ.");
  }

  if (
    data.areaIds !== undefined &&
    (!Array.isArray(data.areaIds) ||
      !data.areaIds.every(
        (areaId: unknown) =>
          typeof areaId === "string" &&
          areaId.trim().length > 0
      ))
  ) {
    throw new Error("Danh sách khu vực không hợp lệ.");
  }

  const areaIds = Array.isArray(data.areaIds)
    ? [...new Set(data.areaIds.map((areaId: string) => areaId.trim()))]
    : [];

  return {
    uid: userSnap.id,
    displayName:
      typeof data.displayName === "string"
        ? data.displayName
        : "",
    email:
      typeof data.email === "string"
        ? data.email
        : "",
    role: data.role as UserRole,
    isActive: data.isActive,
    // Document ID khong duoc co khoang trang o dau/cuoi. Chuan hoa
    // gia tri cu de viec so sanh quyen theo areaId on dinh hon.
    areaIds,
  };
}

/**
 * Lấy danh sách hồ sơ tài khoản từ Firestore.
 *
 * Collection: users
 *
 * Chỉ được gọi từ giao diện ADMIN.
 * Firestore Security Rules vẫn phải kiểm soát
 * quyền đọc dữ liệu ở phía máy chủ.
 */
export async function getAllUsers(): Promise<AppUser[]> {
  const usersRef = collection(db, "users");
  const snapshot = await getDocs(usersRef);

  return snapshot.docs.map((userDoc) => {
    const data = userDoc.data();

    const role: UserRole =
      data.role === "ADMIN" || data.role === "AREA_ADMIN"
        ? data.role
        : "USER";

    return {
      uid: userDoc.id,
      displayName:
        typeof data.displayName === "string"
          ? data.displayName
          : "",
      email:
        typeof data.email === "string"
          ? data.email
          : "",
      role,
      isActive: data.isActive === true,
      areaIds: Array.isArray(data.areaIds)
        ? [
            ...new Set(
              data.areaIds
                .filter(
                  (id: unknown): id is string =>
                    typeof id === "string" && id.trim().length > 0
                )
                .map((id) => id.trim())
            ),
          ]
        : [],
    };
  });
}
