import type { AppUser } from "../types/user.js";
import {
  appSharedRamCache,
  getAppCacheScopeForUser,
} from "./appSharedRamCache.js";
import {
  CACHE_POLICIES,
  type CacheDatasetKey,
  type CacheLoadResult,
  type CachePolicy,
  type CacheScope,
  type CacheSnapshot,
  type SharedRamCache,
} from "./sharedRamCache.js";

export type SharedCollectionName =
  | "devices"
  | "areas"
  | "subAreas"
  | "deviceCategories"
  | "deviceTypes";

export interface SharedCacheRead<T> {
  snapshot: CacheSnapshot<T>;
  request: Promise<CacheLoadResult<T>> | null;
}

const DATASET_KEYS = {
  devices: { collection: "devices", variant: "list" },
  areas: { collection: "areas", variant: "list" },
  subAreas: { collection: "subAreas", variant: "list" },
  deviceCategories: {
    collection: "deviceCategories",
    variant: "list",
  },
  deviceTypes: { collection: "deviceTypes", variant: "list" },
} as const satisfies Record<SharedCollectionName, CacheDatasetKey>;

/**
 * Reads synchronously from RAM and starts one deduplicated request when the
 * value is missing, stale or expired. Consumers decide how to render states.
 */
export function beginScopedCacheRead<T>(
  cache: SharedRamCache,
  scope: CacheScope,
  dataset: CacheDatasetKey,
  policy: CachePolicy,
  loader: () => Promise<T>,
  now = Date.now(),
): SharedCacheRead<T> {
  const snapshot = cache.read<T>(scope, dataset, now);
  const request = snapshot.state === "fresh"
    ? null
    : cache.load(scope, dataset, loader, policy);
  return { snapshot, request };
}

export function beginAppCollectionRead<T>(
  user: Pick<AppUser, "uid" | "role" | "areaIds" | "isActive">,
  collection: SharedCollectionName,
  loader: () => Promise<T>,
): SharedCacheRead<T> | null {
  const scope = getAppCacheScopeForUser(user);
  if (!scope) {
    return null;
  }

  return beginScopedCacheRead(
    appSharedRamCache,
    scope,
    DATASET_KEYS[collection],
    CACHE_POLICIES[collection],
    loader,
  );
}

export function readAppCollectionCache<T>(
  user: Pick<AppUser, "uid" | "role" | "areaIds" | "isActive">,
  collection: SharedCollectionName,
): CacheSnapshot<T> {
  const scope = getAppCacheScopeForUser(user);
  return scope
    ? appSharedRamCache.read<T>(scope, DATASET_KEYS[collection])
    : { state: "missing" };
}

/** Call only after a Firestore write/transaction has resolved successfully. */
export function invalidateAppCollection(
  collection: SharedCollectionName,
): number {
  const scope = appSharedRamCache.getActiveScope();
  return scope
    ? appSharedRamCache.invalidateCollection(scope, collection)
    : 0;
}
