import {
  collection,
  deleteDoc,
  doc,
  getCountFromServer,
  getDoc,
  query,
  where,
} from "firebase/firestore";

import { db } from "../config/firebase";

export interface DeletionDependency {
  label: string;
  count: number;
}

export class PermanentDeletionBlockedError extends Error {
  readonly dependencies: DeletionDependency[];

  constructor(dependencies: DeletionDependency[]) {
    super(`Dữ liệu vẫn đang được tham chiếu: ${dependencies.map((item) => `${item.label} (${item.count})`).join(", ")}.`);
    this.name = "PermanentDeletionBlockedError";
    this.dependencies = dependencies;
  }
}

async function count(collectionName: string, field: string, operator: "==" | "array-contains", value: string) {
  const snapshot = await getCountFromServer(query(collection(db, collectionName), where(field, operator, value)));
  return snapshot.data().count;
}

function activeDependencies(values: Array<[string, number]>): DeletionDependency[] {
  return values.filter(([, dependencyCount]) => dependencyCount > 0)
    .map(([label, dependencyCount]) => ({ label, count: dependencyCount }));
}

export async function permanentlyDeleteInactiveArea(areaId: string): Promise<void> {
  const areaRef = doc(db, "areas", areaId);
  const [areaSnapshot, devices, users, types, templates, attempts, invites, subAreas] = await Promise.all([
    getDoc(areaRef),
    count("devices", "areaId", "==", areaId),
    count("users", "areaIds", "array-contains", areaId),
    count("deviceTypes", "areaIds", "array-contains", areaId),
    count("inspectionTemplates", "areaIds", "array-contains", areaId),
    count("accountProvisioningAttempts", "areaIds", "array-contains", areaId),
    count("invites", "areaIds", "array-contains", areaId),
    count("subAreas", "factoryId", "==", areaId),
  ]);
  if (!areaSnapshot.exists()) throw new Error("Khu vực không còn tồn tại.");
  if (areaSnapshot.data().status !== "INACTIVE") throw new Error("Chỉ có thể xóa khu vực đã ngừng sử dụng.");
  const dependencies = activeDependencies([
    ["thiết bị", devices], ["tài khoản", users], ["loại thiết bị", types],
    ["mẫu tuần kiểm", templates], ["lần tạo tài khoản", attempts], ["lời mời cũ", invites],
    ["khu vực con", subAreas],
  ]);
  if (dependencies.length) throw new PermanentDeletionBlockedError(dependencies);
  await deleteDoc(areaRef);
}

export async function permanentlyDeleteInactiveDeviceType(typeId: string): Promise<void> {
  const typeRef = doc(db, "deviceTypes", typeId);
  const [typeSnapshot, devices, templates] = await Promise.all([
    getDoc(typeRef),
    count("devices", "deviceTypeId", "==", typeId),
    count("inspectionTemplates", "deviceTypeId", "==", typeId),
  ]);
  if (!typeSnapshot.exists()) throw new Error("Loại thiết bị không còn tồn tại.");
  if (typeSnapshot.data().isActive !== false) throw new Error("Chỉ có thể xóa loại thiết bị đã ngừng sử dụng.");
  const dependencies = activeDependencies([["thiết bị", devices], ["mẫu tuần kiểm", templates]]);
  if (dependencies.length) throw new PermanentDeletionBlockedError(dependencies);
  await deleteDoc(typeRef);
}

export async function permanentlyDeleteInactiveInspectionTemplate(templateId: string): Promise<void> {
  const templateRef = doc(db, "inspectionTemplates", templateId);
  const [templateSnapshot, plans] = await Promise.all([
    getDoc(templateRef),
    count("deviceInspectionPlans", "templateId", "==", templateId),
  ]);
  if (!templateSnapshot.exists()) throw new Error("Mẫu tuần kiểm không còn tồn tại.");
  if (templateSnapshot.data().isActive !== false) throw new Error("Chỉ có thể xóa mẫu tuần kiểm đã ngừng sử dụng.");
  const dependencies = activeDependencies([["kế hoạch tuần kiểm", plans]]);
  if (dependencies.length) throw new PermanentDeletionBlockedError(dependencies);
  await deleteDoc(templateRef);
}
