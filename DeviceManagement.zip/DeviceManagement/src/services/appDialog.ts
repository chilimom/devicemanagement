export interface AppDialogRequest {
  kind: "alert" | "confirm";
  title?: string;
  message: string;
  tone?: "info" | "success" | "warning" | "error";
  confirmLabel?: string;
  cancelLabel?: string;
  verificationText?: string;
  verificationLabel?: string;
  resolve: (accepted: boolean) => void;
}

function requestDialog(request: Omit<AppDialogRequest, "resolve">): Promise<boolean> {
  return new Promise((resolve) => {
    window.dispatchEvent(new CustomEvent<AppDialogRequest>("app:dialog", {
      detail: { ...request, resolve },
    }));
  });
}

export async function showAppAlert(
  message: string,
  options: Omit<AppDialogRequest, "kind" | "message" | "resolve" | "cancelLabel"> = {},
): Promise<void> {
  await requestDialog({ kind: "alert", message, ...options });
}

export function showAppConfirm(
  message: string,
  options: Omit<AppDialogRequest, "kind" | "message" | "resolve"> = {},
): Promise<boolean> {
  return requestDialog({ kind: "confirm", message, ...options });
}
