import app from "../config/firebase.js";
import type { AppUser } from "../types/user.js";
import {
  SharedRamCache,
  createCacheScopeFromUser,
  type CacheScope,
} from "./sharedRamCache.js";
import { SharedRamCacheLifecycle } from "./sharedRamCacheLifecycle.js";

const projectId = app.options.projectId;

if (!projectId) {
  throw new Error("Firebase projectId is required for shared RAM cache.");
}

const configuredProjectId: string = projectId;

/** Single RAM-only cache instance for the lifetime of this application tab. */
export const appSharedRamCache = new SharedRamCache();

/** The Auth/profile layer is the sole owner of scope activation. */
export const appSharedRamCacheLifecycle = new SharedRamCacheLifecycle(
  appSharedRamCache,
  configuredProjectId,
);

/** Returns a scope only when the verified App profile matches the active cache. */
export function getAppCacheScopeForUser(
  user: Pick<AppUser, "uid" | "role" | "areaIds" | "isActive">,
): CacheScope | null {
  const expected = createCacheScopeFromUser(configuredProjectId, user);
  const active = appSharedRamCache.getActiveScope();
  return expected?.key === active?.key ? active : null;
}
