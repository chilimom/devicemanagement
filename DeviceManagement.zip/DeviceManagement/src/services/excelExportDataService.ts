import {
  collection,
  documentId,
  getDocs,
  query,
  where,
  type DocumentData,
  type Firestore,
  type QueryDocumentSnapshot,
} from "firebase/firestore";

import { db } from "../config/firebase";
import type {
  ExcelExportDataSet,
  ExcelExportDocument,
  ExportAreaData,
  ExportDeviceCategoryData,
  ExportDeviceData,
  ExportDeviceTypeData,
  ExportIncidentData,
  ExportIncidentResolutionData,
  ExportIncidentVerificationData,
  ExportInspectionPlanData,
  ExportInspectionResultData,
  ExportUserData,
} from "../types/excelExport";
import { createEmptyExcelExportDataSet } from "../types/excelExport";
import { isAdmin, type AppUser } from "../types/user";

const FIRESTORE_IN_LIMIT = 30;
const DEFAULT_MAX_CONCURRENT_READS = 6;

type ExportCollectionName =
  | "devices"
  | "areas"
  | "subAreas"
  | "deviceCategories"
  | "deviceTypes"
  | "incidents"
  | "incidentResolutions"
  | "incidentVerifications"
  | "deviceInspectionPlans"
  | "inspectionResults";

export interface ExcelExportReaderOptions {
  maxConcurrentReads?: number;
}

export class ExcelExportReadError extends Error {
  readonly operation: string;
  readonly firestoreCode?: string;

  constructor(operation: string, cause: unknown) {
    const firestoreCode = getFirestoreErrorCode(cause);
    const suffix = firestoreCode ? ` (${firestoreCode})` : "";
    super(`Không thể đọc dữ liệu xuất Excel: ${operation}${suffix}.`, {
      cause,
    });
    this.name = "ExcelExportReadError";
    this.operation = operation;
    this.firestoreCode = firestoreCode;
  }
}

function getFirestoreErrorCode(error: unknown): string | undefined {
  if (
    error &&
    typeof error === "object" &&
    "code" in error &&
    typeof error.code === "string"
  ) {
    return error.code;
  }

  return undefined;
}

function normalizeConcurrency(value?: number): number {
  if (value === undefined) {
    return DEFAULT_MAX_CONCURRENT_READS;
  }

  if (!Number.isSafeInteger(value) || value < 1 || value > 20) {
    throw new Error("maxConcurrentReads phải là số nguyên từ 1 đến 20.");
  }

  return value;
}

function normalizeIds(values: string[]): string[] {
  return [...new Set(values.map((value) => value.trim()).filter(Boolean))];
}

function chunkIds(values: string[]): string[][] {
  const chunks: string[][] = [];

  for (let index = 0; index < values.length; index += FIRESTORE_IN_LIMIT) {
    chunks.push(values.slice(index, index + FIRESTORE_IN_LIMIT));
  }

  return chunks;
}

function toExportDocument<TData extends DocumentData>(
  snapshot: QueryDocumentSnapshot<DocumentData>,
): ExcelExportDocument<TData> {
  return {
    id: snapshot.id,
    data: snapshot.data() as TData,
  };
}

function deduplicateDocuments<TData extends DocumentData>(
  documents: ExcelExportDocument<TData>[],
): ExcelExportDocument<TData>[] {
  const documentsById = new Map<string, ExcelExportDocument<TData>>();

  for (const document of documents) {
    documentsById.set(document.id, document);
  }

  return [...documentsById.values()];
}

async function mapWithConcurrency<TItem, TResult>(
  items: readonly TItem[],
  concurrency: number,
  worker: (item: TItem) => Promise<TResult>,
): Promise<TResult[]> {
  const results = new Array<TResult>(items.length);
  let nextIndex = 0;
  let stopped = false;

  async function runWorker(): Promise<void> {
    while (!stopped) {
      const currentIndex = nextIndex;
      nextIndex += 1;

      if (currentIndex >= items.length) {
        return;
      }

      try {
        results[currentIndex] = await worker(items[currentIndex]);
      } catch (error) {
        stopped = true;
        throw error;
      }
    }
  }

  const workers = Array.from(
    { length: Math.min(concurrency, items.length) },
    () => runWorker(),
  );

  await Promise.all(workers);
  return results;
}

async function runRead<TResult>(
  operation: string,
  read: () => Promise<TResult>,
): Promise<TResult> {
  try {
    return await read();
  } catch (error) {
    if (error instanceof ExcelExportReadError) {
      throw error;
    }

    throw new ExcelExportReadError(operation, error);
  }
}

async function readWholeCollection<TData extends DocumentData>(
  firestore: Firestore,
  collectionName: ExportCollectionName,
): Promise<ExcelExportDocument<TData>[]> {
  return runRead(`collection ${collectionName}`, async () => {
    const snapshot = await getDocs(collection(firestore, collectionName));
    return snapshot.docs.map((item) => toExportDocument<TData>(item));
  });
}

async function readAdminUserDisplayNames(
  firestore: Firestore,
  userIds: string[],
  concurrency: number,
): Promise<ExcelExportDocument<ExportUserData>[]> {
  const chunks = chunkIds(normalizeIds(userIds));
  const groups = await mapWithConcurrency(
    chunks,
    concurrency,
    (userIdsChunk) => runRead(
      `displayName users [${userIdsChunk.join(", ")}]`,
      async () => {
        const snapshot = await getDocs(query(
          collection(firestore, "users"),
          where(documentId(), "in", userIdsChunk),
        ));
        return snapshot.docs.map((item) => {
          const data = item.data();
          return {
            id: item.id,
            data: {
              displayName:
                typeof data.displayName === "string"
                  ? data.displayName
                  : undefined,
            },
          };
        });
      },
    ),
  );
  return deduplicateDocuments(groups.flat());
}

async function readDocumentsByDevice<TData extends DocumentData>(
  firestore: Firestore,
  collectionName: ExportCollectionName,
  deviceId: string,
): Promise<ExcelExportDocument<TData>[]> {
  return runRead(
    `${collectionName} của thiết bị ${deviceId}`,
    async () => {
      const snapshot = await getDocs(
        query(
          collection(firestore, collectionName),
          where("deviceId", "==", deviceId),
        ),
      );

      return snapshot.docs.map((item) => toExportDocument<TData>(item));
    },
  );
}

async function readDevicesForAreas(
  firestore: Firestore,
  areaIds: string[],
  concurrency: number,
): Promise<ExcelExportDocument<ExportDeviceData>[]> {
  const chunks = chunkIds(areaIds);
  const groups = await mapWithConcurrency(
    chunks,
    concurrency,
    (areaIdsChunk) =>
      runRead(
        `devices thuộc khu vực [${areaIdsChunk.join(", ")}]`,
        async () => {
          const snapshot = await getDocs(
            query(
              collection(firestore, "devices"),
              where("areaId", "in", areaIdsChunk),
            ),
          );

          return snapshot.docs.map((item) =>
            toExportDocument<ExportDeviceData>(item),
          );
        },
      ),
  );

  return deduplicateDocuments(groups.flat());
}

async function readAreasById(
  firestore: Firestore,
  areaIds: string[],
  concurrency: number,
): Promise<ExcelExportDocument<ExportAreaData>[]> {
  const chunks = chunkIds(areaIds);
  const groups = await mapWithConcurrency(
    chunks,
    concurrency,
    (areaIdsChunk) =>
      runRead(
        `areas [${areaIdsChunk.join(", ")}]`,
        async () => {
          const snapshot = await getDocs(
            query(
              collection(firestore, "areas"),
              where(documentId(), "in", areaIdsChunk),
            ),
          );

          return snapshot.docs.map((item) =>
            toExportDocument<ExportAreaData>(item),
          );
        },
      ),
  );

  return deduplicateDocuments(groups.flat());
}

async function readPlanForDevice(
  firestore: Firestore,
  deviceId: string,
): Promise<ExcelExportDocument<ExportInspectionPlanData> | null> {
  return runRead(
    `deviceInspectionPlans của thiết bị ${deviceId}`,
    async () => {
      const snapshot = await getDocs(
        query(
          collection(firestore, "deviceInspectionPlans"),
          where("deviceId", "==", deviceId),
        ),
      );

      const planSnapshot = snapshot.docs[0];
      if (!planSnapshot) {
        return null;
      }

      return {
        id: planSnapshot.id,
        data: planSnapshot.data() as ExportInspectionPlanData,
      };
    },
  );
}

async function readAdminData(
  firestore: Firestore,
  concurrency: number,
): Promise<ExcelExportDataSet> {
  const reads = [
    () => readWholeCollection<ExportDeviceData>(firestore, "devices"),
    () => readWholeCollection<ExportIncidentData>(firestore, "incidents"),
    () =>
      readWholeCollection<ExportIncidentResolutionData>(
        firestore,
        "incidentResolutions",
      ),
    () =>
      readWholeCollection<ExportIncidentVerificationData>(
        firestore,
        "incidentVerifications",
      ),
    () =>
      readWholeCollection<ExportInspectionPlanData>(
        firestore,
        "deviceInspectionPlans",
      ),
    () =>
      readWholeCollection<ExportInspectionResultData>(
        firestore,
        "inspectionResults",
      ),
    () => readWholeCollection<ExportAreaData>(firestore, "areas"),
    () => readWholeCollection<ExportAreaData>(firestore, "subAreas"),
    () =>
      readWholeCollection<ExportDeviceCategoryData>(
        firestore,
        "deviceCategories",
      ),
    () => readWholeCollection<ExportDeviceTypeData>(firestore, "deviceTypes"),
  ] as const;

  const results = await mapWithConcurrency(
    reads,
    concurrency,
    (read) => read(),
  );

  const dataSet: ExcelExportDataSet = {
    devices: results[0] as ExcelExportDataSet["devices"],
    incidents: results[1] as ExcelExportDataSet["incidents"],
    incidentResolutions:
      results[2] as ExcelExportDataSet["incidentResolutions"],
    incidentVerifications:
      results[3] as ExcelExportDataSet["incidentVerifications"],
    deviceInspectionPlans:
      results[4] as ExcelExportDataSet["deviceInspectionPlans"],
    inspectionResults: results[5] as ExcelExportDataSet["inspectionResults"],
    areas: results[6] as ExcelExportDataSet["areas"],
    subAreas: results[7] as ExcelExportDataSet["subAreas"],
    deviceCategories: results[8] as ExcelExportDataSet["deviceCategories"],
    deviceTypes: results[9] as ExcelExportDataSet["deviceTypes"],
    users: [],
  };

  const actorUids = [
    ...dataSet.incidents.flatMap((item) => [
      item.data.resolvedByUid,
      item.data.lastResolutionAttemptByUid,
      item.data.lastVerifiedByUid,
    ]),
    ...dataSet.incidentResolutions.map((item) => item.data.resolvedByUid),
    ...dataSet.incidentVerifications.map((item) => item.data.verifiedByUid),
    ...dataSet.inspectionResults.map((item) => item.data.recordedByUid),
  ].filter((value): value is string => typeof value === "string");

  // Rules allow these document-ID queries only for ADMIN. Read only profiles
  // referenced by exported records and retain only displayName in memory.
  dataSet.users = await readAdminUserDisplayNames(
    firestore,
    actorUids,
    concurrency,
  );
  return dataSet;
}

type DeviceScopedRead =
  | { kind: "incidents"; deviceId: string }
  | { kind: "incidentResolutions"; deviceId: string }
  | { kind: "incidentVerifications"; deviceId: string }
  | { kind: "deviceInspectionPlans"; deviceId: string }
  | { kind: "inspectionResults"; deviceId: string };

type DeviceScopedReadResult =
  | { kind: "incidents"; documents: ExcelExportDataSet["incidents"] }
  | {
      kind: "incidentResolutions";
      documents: ExcelExportDataSet["incidentResolutions"];
    }
  | {
      kind: "incidentVerifications";
      documents: ExcelExportDataSet["incidentVerifications"];
    }
  | {
      kind: "deviceInspectionPlans";
      documents: ExcelExportDataSet["deviceInspectionPlans"];
    }
  | {
      kind: "inspectionResults";
      documents: ExcelExportDataSet["inspectionResults"];
    };

async function runDeviceScopedRead(
  firestore: Firestore,
  item: DeviceScopedRead,
): Promise<DeviceScopedReadResult> {
  switch (item.kind) {
    case "incidents":
      return {
        kind: item.kind,
        documents: await readDocumentsByDevice<ExportIncidentData>(
          firestore,
          item.kind,
          item.deviceId,
        ),
      };
    case "incidentResolutions":
      return {
        kind: item.kind,
        documents:
          await readDocumentsByDevice<ExportIncidentResolutionData>(
            firestore,
            item.kind,
            item.deviceId,
          ),
      };
    case "incidentVerifications":
      return {
        kind: item.kind,
        documents:
          await readDocumentsByDevice<ExportIncidentVerificationData>(
            firestore,
            item.kind,
            item.deviceId,
          ),
      };
    case "deviceInspectionPlans": {
      const plan = await readPlanForDevice(firestore, item.deviceId);
      return {
        kind: item.kind,
        documents: plan ? [plan] : [],
      };
    }
    case "inspectionResults":
      return {
        kind: item.kind,
        documents: await readDocumentsByDevice<ExportInspectionResultData>(
          firestore,
          item.kind,
          item.deviceId,
        ),
      };
  }
}

async function readUserData(
  firestore: Firestore,
  appUser: AppUser,
  concurrency: number,
): Promise<ExcelExportDataSet> {
  const areaIds = normalizeIds(appUser.areaIds);
  if (areaIds.length === 0) {
    return createEmptyExcelExportDataSet();
  }

  const devices = await readDevicesForAreas(firestore, areaIds, concurrency);
  if (devices.length === 0) {
    return createEmptyExcelExportDataSet();
  }

  const deviceIds = devices.map((device) => device.id);
  const scopedReads: DeviceScopedRead[] = deviceIds.flatMap((deviceId) => [
    { kind: "incidents", deviceId },
    { kind: "incidentResolutions", deviceId },
    { kind: "incidentVerifications", deviceId },
    { kind: "deviceInspectionPlans", deviceId },
    { kind: "inspectionResults", deviceId },
  ]);

  const catalogReads = [
    () =>
      readWholeCollection<ExportDeviceCategoryData>(
        firestore,
        "deviceCategories",
      ),
    () => readWholeCollection<ExportDeviceTypeData>(firestore, "deviceTypes"),
  ] as const;

  // Run bounded phases in sequence so maxConcurrentReads remains a global
  // upper bound, including users assigned to more than 30 areas.
  const areas = await readAreasById(firestore, areaIds, concurrency);
  const referencedSubAreaIds = normalizeIds(devices.map((device) => device.data.subAreaId).filter((value): value is string => typeof value === "string"));
  const subAreas = referencedSubAreaIds.length
    ? await mapWithConcurrency(chunkIds(referencedSubAreaIds), concurrency, async (ids) => {
        const snapshot = await getDocs(query(collection(firestore, "subAreas"), where(documentId(), "in", ids)));
        return snapshot.docs.map((item) => toExportDocument<ExportAreaData>(item));
      }).then((groups) => groups.flat())
    : [];
  const catalogResults = await mapWithConcurrency(
    catalogReads,
    Math.min(concurrency, catalogReads.length),
    (read) => read(),
  );
  const scopedResults = await mapWithConcurrency(
    scopedReads,
    concurrency,
    (item) => runDeviceScopedRead(firestore, item),
  );

  const result = createEmptyExcelExportDataSet();
  result.devices = devices;
  result.areas = areas;
  result.subAreas = subAreas;
  result.deviceCategories =
    catalogResults[0] as ExcelExportDataSet["deviceCategories"];
  result.deviceTypes = catalogResults[1] as ExcelExportDataSet["deviceTypes"];
  // Scoped USER/AREA_ADMIN accounts cannot list /users under the current
  // Rules. Do not attempt per-UID reads that would fail or reveal profiles
  // outside the caller's scope.
  result.users = [];

  for (const scopedResult of scopedResults) {
    switch (scopedResult.kind) {
      case "incidents":
        result.incidents.push(...scopedResult.documents);
        break;
      case "incidentResolutions":
        result.incidentResolutions.push(...scopedResult.documents);
        break;
      case "incidentVerifications":
        result.incidentVerifications.push(...scopedResult.documents);
        break;
      case "deviceInspectionPlans":
        result.deviceInspectionPlans.push(...scopedResult.documents);
        break;
      case "inspectionResults":
        result.inspectionResults.push(...scopedResult.documents);
        break;
    }
  }

  result.incidents = deduplicateDocuments(result.incidents);
  result.incidentResolutions = deduplicateDocuments(result.incidentResolutions);
  result.incidentVerifications = deduplicateDocuments(
    result.incidentVerifications,
  );
  result.deviceInspectionPlans = deduplicateDocuments(
    result.deviceInspectionPlans,
  );
  result.inspectionResults = deduplicateDocuments(result.inspectionResults);

  return result;
}

/**
 * Reads every document needed by the six-sheet export within the caller's
 * existing Firestore scope. This module performs reads only.
 */
export async function loadExcelExportData(
  appUser: AppUser,
  options: ExcelExportReaderOptions = {},
  firestore: Firestore = db,
): Promise<ExcelExportDataSet> {
  if (!appUser.isActive) {
    throw new Error("Không thể xuất Excel cho tài khoản đã bị vô hiệu hóa.");
  }

  const concurrency = normalizeConcurrency(options.maxConcurrentReads);

  if (isAdmin(appUser)) {
    return readAdminData(firestore, concurrency);
  }

  if (appUser.role !== "USER" && appUser.role !== "AREA_ADMIN") {
    throw new Error("Vai trò tài khoản không hợp lệ để xuất Excel.");
  }

  return readUserData(firestore, appUser, concurrency);
}
