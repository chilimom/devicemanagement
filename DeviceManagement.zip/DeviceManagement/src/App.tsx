import { lazy, Suspense, useEffect, useState } from "react";
import { onAuthStateChanged, type User } from "firebase/auth";
import { doc, onSnapshot } from "firebase/firestore";
import { Navigate, Route, Routes, useLocation } from "react-router-dom";

import { auth, db } from "./config/firebase";
import { appSharedRamCacheLifecycle } from "./services/appSharedRamCache";
import { parseAppUser } from "./services/userService";
import type { AppUser } from "./types/user";
import Login from "./pages/Login";
import AppLayout from "./components/AppLayout";
import AdminRoute from "./components/AdminRoute";

const Dashboard = lazy(() => import("./pages/Dashboard"));
const Devices = lazy(() => import("./pages/Devices"));
const AddDevice = lazy(() => import("./pages/AddDevice"));
const DeviceDetail = lazy(() => import("./pages/DeviceDetail"));
const DeviceEdit = lazy(() => import("./pages/DeviceEdit"));
const DeviceQrPrint = lazy(() => import("./pages/DeviceQrPrint"));
const QrScanner = lazy(() => import("./pages/QrScanner"));
const QrDeviceRedirect = lazy(() => import("./pages/QrDeviceRedirect"));
const Areas = lazy(() => import("./pages/Areas"));
const SubAreas = lazy(() => import("./pages/SubAreas"));
const AreaCreate = lazy(() => import("./pages/AreaCreate"));
const AreaEdit = lazy(() => import("./pages/AreaEdit"));
const Incidents = lazy(() => import("./pages/Incidents"));
const IncidentCreate = lazy(() => import("./pages/IncidentCreate"));
const IncidentResolve = lazy(() => import("./pages/IncidentResolve"));
const IncidentVerify = lazy(() => import("./pages/IncidentVerify"));
const Maintenances = lazy(() => import("./pages/Maintenances"));
const MaintenanceCreate = lazy(() => import("./pages/MaintenanceCreate"));
const DeviceTypes = lazy(() => import("./pages/DeviceTypes"));
const UserManagement = lazy(() => import("./pages/UserManagement"));
const InspectionTemplates = lazy(() => import("./pages/InspectionTemplates"));
const MaintenanceTypeCreate = lazy(() =>import("./pages/MaintenanceTypeCreate"));
const InspectionTemplateForm = lazy(
  () => import("./pages/InspectionTemplateForm"),
);
const InspectionHub = lazy(() => import("./pages/InspectionHub"));
const DeviceInspectionPlan = lazy(
  () => import("./pages/DeviceInspectionPlan"),
);
const DeviceInspectionExecute = lazy(
  () => import("./pages/DeviceInspectionExecute"),
);
const DeviceInspectionHistory = lazy(
  () => import("./pages/DeviceInspectionHistory"),
);
const GuestPortal = lazy(() => import("./pages/GuestPortal"));

function App() {
const location = useLocation();
  
const [user, setUser] = useState<User | null>(null);
const [appUser, setAppUser] = useState<AppUser | null>(null);
const [checkingAuth, setCheckingAuth] = useState(true);
const [authError, setAuthError] = useState("");
const [profileMissing, setProfileMissing] = useState(false);

useEffect(() => {
  let active = true;
  let unsubscribeProfile: (() => void) | null = null;

  appSharedRamCacheLifecycle.beginAuthVerification();

  const unsubscribe = onAuthStateChanged(
    auth,
    (currentUser) => {
      if (!active) return;

      unsubscribeProfile?.();
      unsubscribeProfile = null;
      const profileVerificationEpoch =
        appSharedRamCacheLifecycle.resolveAuth(currentUser?.uid ?? null);

      setCheckingAuth(true);
      setUser(null);
      setAppUser(null);
      setAuthError("");
      setProfileMissing(false);

      if (!currentUser) {
        setCheckingAuth(false);
        return;
      }

      const uid = currentUser.uid;

      unsubscribeProfile = onSnapshot(
        doc(db, "users", uid),
        (profileSnapshot) => {
          if (!active || auth.currentUser?.uid !== uid) {
            return;
          }

          if (!profileSnapshot.exists()) {
            appSharedRamCacheLifecycle.invalidateProfile(
              profileVerificationEpoch,
            );
            setUser(currentUser);
            setAppUser(null);
            setProfileMissing(true);
            setCheckingAuth(false);
            return;
          }

          try {
            const profile = parseAppUser(
              profileSnapshot.id,
              profileSnapshot.data(),
            );

            if (!profile.isActive) {
              appSharedRamCacheLifecycle.invalidateProfile(
                profileVerificationEpoch,
              );
              setUser(null);
              setAppUser(null);
              setAuthError("Tài khoản đã bị vô hiệu hóa.");
            setProfileMissing(false);
              setCheckingAuth(false);
              return;
            }

            if (!appSharedRamCacheLifecycle.activateProfile(
              profile,
              profileVerificationEpoch,
            )) {
              throw new Error("Cache scope does not match authenticated user.");
            }

            setAppUser(profile);
            setUser(currentUser);
            setAuthError("");
            setProfileMissing(false);
          } catch {
            appSharedRamCacheLifecycle.invalidateProfile(
              profileVerificationEpoch,
            );
            setUser(null);
            setAppUser(null);
            setAuthError("Không thể xác minh quyền truy cập tài khoản.");
          } finally {
            if (active && auth.currentUser?.uid === uid) {
              setCheckingAuth(false);
            }
          }
        },
        () => {
          if (!active || auth.currentUser?.uid !== uid) {
            return;
          }

          appSharedRamCacheLifecycle.invalidateProfile(
            profileVerificationEpoch,
          );
          setUser(null);
          setAppUser(null);
          setAuthError("Không thể xác minh quyền truy cập tài khoản.");
          setProfileMissing(false);
          setCheckingAuth(false);
        },
      );
    }
  );

  return () => {
    active = false;
    appSharedRamCacheLifecycle.dispose();
    unsubscribeProfile?.();
    unsubscribe();
  };
}, []);


 
if (checkingAuth) {
  return <div style={{ padding: 30 }}>Đang xác minh tài khoản...</div>;
}

if (profileMissing && user) {
  return <div style={{ padding: 30 }}>
    <h3>Tài khoản chưa được cấp quyền</h3>
    <p>Auth account này chưa có hồ sơ người dùng hợp lệ. Vui lòng liên hệ quản trị viên.</p>
    <button onClick={() => {
      appSharedRamCacheLifecycle.logout();
      void auth.signOut();
    }}>Đăng xuất</button>
  </div>;
}

if (authError) {
  return (
    <div style={{ padding: 30 }}>
      <h3>Không thể truy cập hệ thống</h3>
      <p>{authError}</p>
      <button
        onClick={() => {
          appSharedRamCacheLifecycle.logout();
          void auth.signOut();
        }}
      >
        Đăng xuất
      </button>
    </div>
  );
}

if (!user || !appUser) {
  if (location.pathname === "/login") {
    return <Login onLogin={() => {}} />;
  }

  return (
    <AppLayout userDisplayName="Khách" appUser={null} guestMode>
      <Suspense fallback={<p>Đang tải trang...</p>}>
        <Routes>
          <Route path="/" element={<GuestPortal page="dashboard" />} />
          <Route path="/devices" element={<GuestPortal page="devices" />} />
          <Route path="/areas" element={<GuestPortal page="areas" />} />
          <Route path="/incidents" element={<GuestPortal page="incidents" />} />
          <Route path="/maintenances" element={<GuestPortal page="maintenances" />} />
          <Route path="/inspections" element={<GuestPortal page="inspections" />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </Suspense>
    </AppLayout>
  );
}


  return (
    <AppLayout
          userDisplayName={
            appUser.displayName.trim() ||
            user.displayName?.trim() ||
            user.email ||
            "Tài khoản"
          }
          appUser={appUser}
        >
      <Suspense fallback={<p>Đang tải trang...</p>}>
      <Routes>
        <Route path="/" element={<Dashboard appUser={appUser} />} />

        <Route
          path= "/devices" 
          element={<Devices appUser={appUser} />}
        />
        <Route
          path="/devices/new"
          element={
        <AdminRoute user={appUser} allowAreaAdmin>
          <AddDevice appUser={appUser} />
        </AdminRoute>
         }
        />
        <Route
          path="/devices/:id/history"
          element={<DeviceDetail appUser={appUser} />}
        />
        <Route
          path="/devices/:id"
          element={<DeviceDetail appUser={appUser} />}
          />
        <Route
          path="/devices/:id/inspection-plan"
          element={
            <AdminRoute user={appUser} allowAreaAdmin>
              <DeviceInspectionPlan appUser={appUser} />
            </AdminRoute>
          }
        />
        <Route
          path="/devices/:id/edit"
          element={
            <AdminRoute user={appUser} allowAreaAdmin>
              <DeviceEdit appUser={appUser} />
            </AdminRoute>
          }
        />
        <Route
          path="/devices/:id/qr"
          element={<DeviceQrPrint appUser={appUser} />}
        />
        <Route
          path="/scan"
          element={<QrScanner />}
        />
        <Route
          path="/areas/new"
          element={
            <AdminRoute user={appUser}>
              <AreaCreate />
            </AdminRoute>
          }
        />
        <Route
          path="/areas/:areaId/edit"
          element={
            <AdminRoute user={appUser} allowAreaAdmin>
              <AreaEdit appUser={appUser} />
            </AdminRoute>
          }
        />
        <Route path="/areas/:areaId/subareas" element={<AdminRoute user={appUser} allowAreaAdmin><SubAreas appUser={appUser} /></AdminRoute>} />
        <Route
          path="/q/:deviceCode"
          element={<QrDeviceRedirect appUser={appUser} />}
        />
        <Route path="/incidents" element={<Incidents appUser={appUser} />} />
        {/* <Route
          path="/devices/:id/edit"
           element={<EditDevice />}
        /> */}
        <Route
          path="/devices/:id/incidents/new"
          element={<IncidentCreate appUser={appUser} />}
        />
        <Route
          path="/devices/:id/maintenance/new"
          element={<MaintenanceCreate appUser={appUser} />}
        />
        <Route 
            path="/maintenance/types/new" 
            element={<AdminRoute user={appUser} allowAreaAdmin><MaintenanceTypeCreate appUser={appUser} /></AdminRoute>} />
        <Route
          path="/maintenances"
          element={<Maintenances appUser={appUser} />}
        />
        <Route
          path="/incidents/:incidentId/resolve"
          element={<IncidentResolve appUser={appUser} />}
        />
        <Route
          path="/incidents/:incidentId/verify"
          element={<IncidentVerify appUser={appUser} />}
        />
        <Route
          path="/areas"
          element={<Areas appUser={appUser} />}
        />

        {/* Quản lý danh mục loại thiết bị */}
        <Route
          path="/admin/device-types"
          element={
            <AdminRoute user={appUser} allowAreaAdmin>
              <DeviceTypes appUser={appUser} />
            </AdminRoute>
          }
        />
        {/* Quản lý tài khoản người dùng */}
          <Route
            path="/admin/users"
            element={
              <AdminRoute user={appUser} allowAreaAdmin>
                <UserManagement appUser={appUser} />
              </AdminRoute>
            }
          />
        <Route
          path="/admin"
          element={<Navigate to="/admin/device-types" replace />}
        />
        {/* Quản lý mẫu tuần kiểm */}
        <Route
          path="/inspections/templates"
          element={
            <AdminRoute user={appUser} allowAreaAdmin>
              <InspectionTemplates appUser={appUser} />
            </AdminRoute>
          }
          />
        <Route path="/inspections" element={<InspectionHub appUser={appUser} />} />
        <Route
            path="/inspections/templates/new"
            element={
              <AdminRoute user={appUser} allowAreaAdmin>
                <InspectionTemplateForm appUser={appUser} />
              </AdminRoute>
            }
          />
        <Route
          path="/inspections/templates/:templateId"
          element={
            <AdminRoute user={appUser} allowAreaAdmin>
              <InspectionTemplateForm appUser={appUser} />
            </AdminRoute>
          }
        />
        <Route
          path="/devices/:id/inspection"
          element={<DeviceInspectionExecute appUser={appUser} />}
          />
        <Route
          path="/devices/:id/inspection-history"
          element={<DeviceInspectionHistory appUser={appUser} />}
          />
        
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      </Suspense>
    </AppLayout>
  );
}

export default App;
