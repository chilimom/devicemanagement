import { useEffect, useState } from "react";
import { doc, getDoc } from "firebase/firestore";
import { useNavigate, useParams } from "react-router-dom";

import { db } from "../config/firebase";
import { createIncidentVerification } from "../services/incidentVerificationService";
import { isVerifiableIncident } from "../services/incidentWorkflow";
import { canAccessArea, isAdmin, type AppUser } from "../types/user";

interface Incident {
  id: string;
  deviceId?: string;
  deviceCode?: string;
  deviceName?: string;
  title?: string;
  status?: string;
  resolution?: string;
}

interface DeviceAccessRecord {
  areaId?: string;
}

interface IncidentVerifyProps {
  appUser: AppUser;
}

export default function IncidentVerify({ appUser }: IncidentVerifyProps) {
  const { incidentId } = useParams<{ incidentId: string }>();
  const navigate = useNavigate();
  const [incident, setIncident] = useState<Incident | null>(null);
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function loadIncident() {
      if (!incidentId) {
        setError("Không xác định được sự cố.");
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError("");
        setIncident(null);

        const incidentSnapshot = await getDoc(doc(db, "incidents", incidentId));
        if (cancelled) return;

        if (!incidentSnapshot.exists()) {
          setError("Không tìm thấy sự cố.");
          return;
        }

        const incidentData: Incident = {
          id: incidentSnapshot.id,
          ...incidentSnapshot.data(),
        };

        if (!incidentData.deviceId) {
          setError("Sự cố không có thông tin thiết bị hợp lệ.");
          return;
        }

        const deviceSnapshot = await getDoc(
          doc(db, "devices", incidentData.deviceId),
        );
        if (cancelled) return;

        if (!deviceSnapshot.exists()) {
          setError("Không tìm thấy thiết bị của sự cố.");
          return;
        }

        const deviceData = deviceSnapshot.data() as DeviceAccessRecord;
        if (
          !isAdmin(appUser) &&
          !canAccessArea(appUser, deviceData.areaId?.trim() || "")
        ) {
          setError("Bạn không có quyền xác minh sự cố này.");
          return;
        }

        if (!isVerifiableIncident(incidentData.status)) {
          setError("Sự cố chưa ở trạng thái chờ xác minh.");
          return;
        }

        setIncident(incidentData);
      } catch {
        if (!cancelled) {
          setError("Không thể tải thông tin sự cố.");
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    void loadIncident();

    return () => {
      cancelled = true;
    };
  }, [appUser, incidentId]);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!incidentId || !incident || saving) return;
    if (!note.trim()) {
      setError("Vui lòng nhập nội dung xác minh.");
      return;
    }

    try {
      setSaving(true);
      setError("");
      await createIncidentVerification({
        incidentId,
        note: note.trim(),
      });
      navigate(`/devices/${incident.deviceId}`);
    } catch (caughtError) {
      const code =
        caughtError && typeof caughtError === "object" && "code" in caughtError
          ? String(caughtError.code)
          : "";

      setError(
        code === "permission-denied"
          ? "Không thể xác minh vì Firestore Rules hiện tại chưa cấp quyền cho lịch sử xác minh."
          : "Không thể xác minh sự cố. Vui lòng tải lại và thử lại.",
      );
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <p>Đang tải thông tin xác minh sự cố...</p>;

  if (error && !incident) {
    return (
      <section className="panel">
        <h2>Không thể xác minh sự cố</h2>
        <p>{error}</p>
        <button className="table-action" onClick={() => navigate("/incidents")}>
          Quay lại danh sách sự cố
        </button>
      </section>
    );
  }

  if (!incident) return null;

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <button
            type="button"
            className="back-button"
            onClick={() => navigate(`/devices/${incident.deviceId}`)}
          >
            ← Quay lại thiết bị
          </button>
          <h1>Xác minh sự cố</h1>
          <p className="page-subtitle">
            Xác nhận kết quả khắc phục trước khi đóng sự cố.
          </p>
        </div>
      </div>

      <section className="panel detail-card">
        <h2>{incident.title || "Sự cố"}</h2>
        <p>{incident.deviceCode || "-"} {incident.deviceName ? `- ${incident.deviceName}` : ""}</p>
        <p><strong>Kết quả khắc phục:</strong> {incident.resolution || "-"}</p>

        {error && <div className="form-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="verification-note">Nội dung xác minh <span>*</span></label>
            <textarea
              id="verification-note"
              value={note}
              onChange={(event) => setNote(event.target.value)}
              rows={5}
              required
              placeholder="Nhập kết quả kiểm tra sau khắc phục."
            />
          </div>

          <div className="form-actions">
            <button
              type="button"
              className="btn-secondary"
              onClick={() => navigate(`/devices/${incident.deviceId}`)}
            >
              Hủy
            </button>
            <button type="submit" className="primary-button" disabled={saving}>
              {saving ? "Đang xác minh..." : "Xác minh và đóng sự cố"}
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}
