import { useEffect, useMemo, useState } from "react";
import {
  collection,
  documentId,
  getDocs,
  query,
  where,
} from "firebase/firestore";
import { useNavigate, useSearchParams } from "react-router-dom";

import { db } from "../config/firebase";
import PaginationControls, { DEFAULT_PAGE_SIZE } from "../components/PaginationControls";
import { beginAppCollectionRead } from "../services/sharedCollectionCache";
import { loadExcelExportData } from "../services/excelExportDataService";
import ActionIconButton from "../components/ActionIconButton";
import { transformExcelExportData } from "../services/excelExportTransform";
import {
  canAccessArea,
  isAdmin,
  type AppUser,
} from "../types/user";

const FIRESTORE_IN_LIMIT = 30;

function chunkIds(ids: string[]): string[][] {
  const chunks: string[][] = [];
  for (let index = 0; index < ids.length; index += FIRESTORE_IN_LIMIT) {
    chunks.push(ids.slice(index, index + FIRESTORE_IN_LIMIT));
  }
  return chunks;
}

async function getDevicesForAreas(areaIds: string[]) {
  const snapshots = await Promise.all(
    chunkIds(areaIds).map((areaIdsChunk) =>
      getDocs(
        query(
          collection(db, "devices"),
          where("areaId", "in", areaIdsChunk),
        ),
      ),
    ),
  );
  return snapshots.flatMap((snapshot) => snapshot.docs);
}

async function getAreasByIds(areaIds: string[]) {
  const snapshots = await Promise.all(
    chunkIds(areaIds).map((areaIdsChunk) =>
      getDocs(
        query(
          collection(db, "areas"),
          where(documentId(), "in", areaIdsChunk),
        ),
      ),
    ),
  );
  return snapshots.flatMap((snapshot) => snapshot.docs);
}
// ======================================================
// 1. ĐỊNH NGHĨA DỮ LIỆU
// ======================================================

interface Device {
  id: string;
  code?: string;
  name?: string;
  areaId?: string;
  subAreaId?: string;
  deviceTypeId?: string;
  manufacturer?: string;
  model?: string;
  ipAddress?: string;
  status?: string;
  isActive?: boolean;
}

interface Area {
  id: string;
  code?: string;
  name?: string;
  status?: string;
}

interface DeviceCategory {
  id: string;
  code?: string;
  name?: string;
  status?: string;
}

interface DeviceType {
  id: string;
  code?: string;
  name?: string;
  categoryId?: string;
  isActive?: boolean;
}

function getAreaId(value?: string): string {
  return typeof value === "string" ? value.trim() : "";
}

// ======================================================
// 2. HÀM HIỂN THỊ TRẠNG THÁI
// ======================================================

function getStatusLabel(status?: string) {
  switch (status) {
    case "ACTIVE":
      return "Hoạt động";
    case "WARNING":
      return "Cảnh báo";
    case "OFFLINE":
      return "Mất kết nối";
    case "MAINTENANCE":
      return "Bảo trì";
    default:
      return status || "Không xác định";
  }
}

function isPermissionDenied(error: unknown): boolean {
  let current: unknown = error;

  for (let depth = 0; depth < 6; depth += 1) {
    if (!current || typeof current !== "object") {
      return false;
    }

    if (
      "code" in current &&
      typeof current.code === "string" &&
      current.code.includes("permission-denied")
    ) {
      return true;
    }

    current = "cause" in current ? current.cause : undefined;
  }

  return false;
}

// ======================================================
// 3. TRANG QUẢN LÝ THIẾT BỊ
// ======================================================

interface DevicesProps {
  appUser: AppUser | null;
}

export default function Devices({ appUser }: DevicesProps) {

  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  // Giữ tương thích với liên kết từ trang Khu vực:
  // /devices?area=<Firestore Document ID>
  const areaFromUrl = searchParams.get("area") || "";
  // Lĩnh vực được truyền từ Dashboard
  const categoryFromUrl = searchParams.get("category") || "";

  // Dữ liệu Firestore
  const [devices, setDevices] = useState<Device[]>([]);
  const [areas, setAreas] = useState<Area[]>([]);
  const [subAreas, setSubAreas] = useState<Area[]>([]);
  const [categories, setCategories] = useState<DeviceCategory[]>([]);
  const [deviceTypes, setDeviceTypes] = useState<DeviceType[]>([]);

  // Các bộ lọc
  const [search, setSearch] = useState("");
  const [areaFilter, setAreaFilter] = useState(areaFromUrl);
  const [categoryFilter, setCategoryFilter] = useState(categoryFromUrl);
  const [typeFilter, setTypeFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [lifecycleFilter, setLifecycleFilter] = useState("ACTIVE");
  const [currentPage, setCurrentPage] = useState(1);

  // Trạng thái trang
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [refreshError, setRefreshError] = useState("");
  const [error, setError] = useState("");
  const [exporting, setExporting] = useState(false);
  const [exportNotice, setExportNotice] = useState<{
    type: "success" | "error";
    message: string;
  } | null>(null);
  const isAdminUser = isAdmin(appUser);

  // ====================================================
  // 4. ĐỒNG BỘ KHU VỰC VỚI URL
  // ====================================================

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- URL is the source of truth for browser navigation.
    setAreaFilter(areaFromUrl);
  }, [areaFromUrl]);
  // Đồng bộ bộ lọc lĩnh vực khi đi từ Dashboard
// hoặc khi người dùng sử dụng nút Back / Forward.
useEffect(() => {
  // eslint-disable-next-line react-hooks/set-state-in-effect -- URL is the source of truth for browser navigation.
  setCategoryFilter(categoryFromUrl);
  setTypeFilter("");
}, [categoryFromUrl]);

  useEffect(() => {
    if (isAdminUser || !areaFilter || appUser?.areaIds.includes(areaFilter)) {
      return;
    }

    // eslint-disable-next-line react-hooks/set-state-in-effect -- Remove a filter that is no longer authorized.
    setAreaFilter("");
    const params = new URLSearchParams(searchParams);
    params.delete("area");
    setSearchParams(params);
  }, [appUser?.areaIds, areaFilter, isAdminUser, searchParams, setSearchParams]);
  // ====================================================
  // 5. TẢI DỮ LIỆU TỪ FIRESTORE
  // ====================================================

  useEffect(() => {
    let cancelled = false;

    async function loadData() {
      let showedCachedData = false;

      try {
        setLoading(true);
        setRefreshing(false);
        setRefreshError("");
        setError("");

        if (!appUser) {
          setDevices([]);
          setAreas([]);
          setCategories([]);
          setDeviceTypes([]);
          return;
        }

        const verifiedUser = appUser;
        const assignedAreaIds = verifiedUser.areaIds;

        if (!isAdminUser && assignedAreaIds.length === 0) {
          if (!cancelled) {
            setDevices([]);
            setAreas([]);
            setCategories([]);
            setDeviceTypes([]);
          }
          return;
        }

        const loadDevices = async (): Promise<Device[]> => {
          const documents = isAdminUser
            ? await getDocs(collection(db, "devices")).then(
                (snapshot) => snapshot.docs,
              )
            : await getDevicesForAreas(assignedAreaIds);
          return documents.map((item) => ({
            ...(item.data() as Omit<Device, "id">),
            id: item.id,
          }));
        };
        const loadAreas = async (): Promise<Area[]> => {
          const documents = isAdminUser
            ? await getDocs(collection(db, "areas")).then(
                (snapshot) => snapshot.docs,
              )
            : await getAreasByIds(assignedAreaIds);
          return documents
            .map((item) => ({
              ...(item.data() as Omit<Area, "id">),
              id: item.id,
            }))
            .sort((a, b) =>
              (a.code || "").localeCompare(b.code || "")
            );
        };
        const loadSubAreas = async (): Promise<Area[]> => {
          const documents = isAdminUser
            ? (await getDocs(collection(db, "subAreas"))).docs
            : (await Promise.all(chunkIds(assignedAreaIds).map((ids) => getDocs(query(
                collection(db, "subAreas"), where("factoryId", "in", ids),
              ))))).flatMap((snapshot) => snapshot.docs);
          return documents.map((item) => ({ id: item.id, ...(item.data() as Omit<Area, "id">) }));
        };
        const loadCategories = async (): Promise<DeviceCategory[]> => {
          const snapshot = await getDocs(collection(db, "deviceCategories"));
          return snapshot.docs
            .map((item) => ({
              ...(item.data() as Omit<DeviceCategory, "id">),
              id: item.id,
            }))
            .sort((a, b) =>
              (a.name || "").localeCompare(
                b.name || "",
                "vi"
              )
            );
        };
        const loadDeviceTypes = async (): Promise<DeviceType[]> => {
          const snapshot = await getDocs(collection(db, "deviceTypes"));
          return snapshot.docs
            .map((item) => ({
              ...(item.data() as Omit<DeviceType, "id">),
              id: item.id,
            }))
            .sort((a, b) =>
              (a.name || "").localeCompare(
                b.name || "",
                "vi"
              )
            );
        };

        const deviceRead = beginAppCollectionRead(
          verifiedUser,
          "devices",
          loadDevices,
        );
        const areaRead = beginAppCollectionRead(
          verifiedUser,
          "areas",
          loadAreas,
        );
        const categoryRead = beginAppCollectionRead(
          verifiedUser,
          "deviceCategories",
          loadCategories,
        );
        const typeRead = beginAppCollectionRead(
          verifiedUser,
          "deviceTypes",
          loadDeviceTypes,
        );
        const subAreaRead = beginAppCollectionRead(verifiedUser, "subAreas", loadSubAreas);

        if (!deviceRead || !areaRead || !categoryRead || !typeRead || !subAreaRead) {
          throw new Error("Cache scope is not available for verified profile.");
        }

        const hasCachedData =
          deviceRead.snapshot.data !== undefined &&
          areaRead.snapshot.data !== undefined &&
          categoryRead.snapshot.data !== undefined &&
          typeRead.snapshot.data !== undefined;
        showedCachedData = hasCachedData;

        if (!cancelled) {
          if (deviceRead.snapshot.data) setDevices(deviceRead.snapshot.data);
          if (areaRead.snapshot.data) setAreas(areaRead.snapshot.data);
          if (categoryRead.snapshot.data) {
            setCategories(categoryRead.snapshot.data);
          }
          if (typeRead.snapshot.data) setDeviceTypes(typeRead.snapshot.data);
          if (subAreaRead.snapshot.data) setSubAreas(subAreaRead.snapshot.data);
          setLoading(!hasCachedData);
          setRefreshing(hasCachedData && Boolean(
            deviceRead.request || areaRead.request ||
            categoryRead.request || typeRead.request || subAreaRead.request
          ));
        }

        await Promise.all([
          deviceRead.request?.then((result) => {
            if (!cancelled && result.committed) setDevices(result.data);
          }),
          areaRead.request?.then((result) => {
            if (!cancelled && result.committed) setAreas(result.data);
          }),
          categoryRead.request?.then((result) => {
            if (!cancelled && result.committed) setCategories(result.data);
          }),
          typeRead.request?.then((result) => {
            if (!cancelled && result.committed) setDeviceTypes(result.data);
          }),
          subAreaRead.request?.then((result) => { if (!cancelled && result.committed) setSubAreas(result.data); }),
        ]);
      } catch (err) {
        console.error("Unable to load devices:", err);

        if (!cancelled) {
          if (isPermissionDenied(err)) {
            setDevices([]);
            setAreas([]);
            setCategories([]);
            setDeviceTypes([]);
            setError("Bạn không có quyền tải dữ liệu thiết bị.");
          } else if (showedCachedData) {
            setRefreshError("Không thể làm mới dữ liệu. Đang hiển thị dữ liệu gần nhất.");
          } else {
            setError(
              "Không thể tải dữ liệu thiết bị hoặc danh mục từ Firestore."
            );
          }
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
          setRefreshing(false);
        }
      }
    }

    void loadData();

    return () => {
      cancelled = true;
    };
  }, [appUser, isAdminUser]);

  // ====================================================
  // 6. TẠO BẢNG TRA CỨU THEO DOCUMENT ID
  // ====================================================

  const areaMap = useMemo(() => {
    return new Map(areas.map((area) => [area.id, area]));
  }, [areas]);
  const subAreaMap = useMemo(() => new Map(subAreas.map((item) => [item.id, item])), [subAreas]);

  const categoryMap = useMemo(() => {
    return new Map(
      categories.map((category) => [
        category.id,
        category,
      ])
    );
  }, [categories]);

  const typeMap = useMemo(() => {
    return new Map(
      deviceTypes.map((type) => [type.id, type])
    );
  }, [deviceTypes]);

  // ====================================================
  // 7. DANH SÁCH LOẠI THEO LĨNH VỰC
  // ====================================================

  // Không loại bỏ loại thiết bị đã INACTIVE.
  // Danh sách quản lý cần tra cứu được thiết bị cũ.
  const availableTypes = useMemo(() => {
    return deviceTypes.filter(
      (type) =>
        !categoryFilter ||
        type.categoryId === categoryFilter
    );
  }, [deviceTypes, categoryFilter]);

  function handleCategoryChange(value: string) {
  setCategoryFilter(value);
  setTypeFilter("");
  setCurrentPage(1);

  // Đồng bộ lĩnh vực vào URL
  const params = new URLSearchParams(searchParams);

  if (value) {
    params.set("category", value);
  } else {
    params.delete("category");
  }

  setSearchParams(params);
}

  // ====================================================
  // 8. LỌC DANH SÁCH THIẾT BỊ
  // ====================================================

  
const permittedDevices = useMemo(
  () =>
    devices.filter((device) =>
      canAccessArea(appUser, getAreaId(device.areaId))
    ),
  [appUser, devices]
);

const filteredDevices = useMemo(() => {
  const keyword = search.trim().toLocaleLowerCase("vi");

  return permittedDevices.filter((device) => {
    // Chỉ hiển thị thiết bị thuộc khu vực được phân quyền.
    const deviceAreaId = getAreaId(device.areaId);

      const deviceType = device.deviceTypeId
        ? typeMap.get(device.deviceTypeId)
        : undefined;

      const deviceCategoryId = deviceType?.categoryId || "";

      const area = deviceAreaId
        ? areaMap.get(deviceAreaId)
        : undefined;

      const category = deviceCategoryId
        ? categoryMap.get(deviceCategoryId)
        : undefined;

      const searchText = [
        device.code,
        device.name,
        device.ipAddress,
        device.manufacturer,
        device.model,
        area?.name,
        area?.code,
        deviceType?.name,
        deviceType?.code,
        category?.name,
      ]
        .filter(Boolean)
        .join(" ")
        .toLocaleLowerCase("vi");

      const matchesSearch =
        !keyword || searchText.includes(keyword);

      const matchesArea =
        !areaFilter || deviceAreaId === areaFilter;

      const matchesCategory =
        !categoryFilter ||
        deviceCategoryId === categoryFilter;

      const matchesType =
        !typeFilter ||
        device.deviceTypeId === typeFilter;

      const matchesStatus =
        !statusFilter ||
        device.status === statusFilter;

      let matchesLifecycle = true;

      if (lifecycleFilter === "ACTIVE") {
        matchesLifecycle = device.isActive !== false;
      }

      if (lifecycleFilter === "INACTIVE") {
        matchesLifecycle = device.isActive === false;
      }

      return (
        matchesSearch &&
        matchesArea &&
        matchesCategory &&
        matchesType &&
        matchesStatus &&
        matchesLifecycle
      );
    });
  }, [
    areaFilter,
    categoryFilter,
    categoryMap,
    lifecycleFilter,
    permittedDevices,
    search,
    statusFilter,
    typeFilter,
    typeMap,
    areaMap,
  ]);
  const totalDevicePages = Math.max(1, Math.ceil(filteredDevices.length / DEFAULT_PAGE_SIZE));
  const safeDevicePage = Math.min(currentPage, totalDevicePages);
  const paginatedDevices = filteredDevices.slice(
    (safeDevicePage - 1) * DEFAULT_PAGE_SIZE,
    safeDevicePage * DEFAULT_PAGE_SIZE,
  );
  

  // ====================================================
  // 9. ĐỒNG BỘ BỘ LỌC KHU VỰC VỚI URL
  // ====================================================

  function handleAreaChange(value: string) {
    setAreaFilter(value);
    setCurrentPage(1);

    const params = new URLSearchParams(searchParams);

    if (value) {
      params.set("area", value);
    } else {
      params.delete("area");
    }

    setSearchParams(params);
  }

  // ====================================================
  // 10. XÓA TẤT CẢ BỘ LỌC
  // ====================================================

  function clearFilters() {
    setSearch("");
    setAreaFilter("");
    setCategoryFilter("");
    setTypeFilter("");
    setStatusFilter("");
    setLifecycleFilter("ACTIVE");
    setCurrentPage(1);

    const params = new URLSearchParams(searchParams);
    params.delete("area");
    params.delete("category");
    setSearchParams(params);
    
  }

  // ====================================================
  // 11. THỐNG KÊ KẾT QUẢ
  // ====================================================

  const visibleDeviceCount = permittedDevices.length;

  const activeCount = permittedDevices.filter(
    (device) => device.isActive !== false
  ).length;

  const inactiveCount = permittedDevices.filter(
    (device) => device.isActive === false
  ).length;

  async function handleExportExcel() {
    if (!appUser || exporting) {
      return;
    }

    try {
      setExporting(true);
      setExportNotice(null);

      const dataSet = await loadExcelExportData(appUser);
      const tables = transformExcelExportData(dataSet);
      const { downloadExcelExportFile } = await import(
        "../services/excelExportWorkbook"
      );
      const fileName = await downloadExcelExportFile(tables);

      setExportNotice({
        type: "success",
        message: `Đã tải file ${fileName}.`,
      });
    } catch (exportError) {
      console.error("Unable to export Excel:", exportError);
      setExportNotice({
        type: "error",
        message: isPermissionDenied(exportError)
          ? "Không thể xuất Excel vì tài khoản không có quyền đọc một phần dữ liệu. Vui lòng tải lại trang hoặc liên hệ quản trị viên."
          : exportError instanceof Error
            ? exportError.message
            : "Không thể tạo file Excel. Vui lòng thử lại.",
      });
    } finally {
      setExporting(false);
    }
  }

  // ====================================================
  // 12. GIAO DIỆN
  // ====================================================

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Quản lý thiết bị</h1>

          <p className="page-subtitle">
            Tra cứu thiết bị theo lĩnh vực, loại và khu vực
          </p>
        </div>

        
        <div className="device-header-actions">
          <ActionIconButton
            icon="export" label={exporting ? "Đang xuất Excel" : "Xuất Excel"}
            type="button"
            onClick={() => void handleExportExcel()}
            disabled={exporting || appUser?.isActive !== true}
          />

          {appUser?.isActive === true &&
            (appUser.role === "ADMIN" || appUser.role === "AREA_ADMIN") && (
            <ActionIconButton
              icon="add" label="Thêm thiết bị" variant="primary"
              type="button"
              onClick={() => navigate("/devices/new")}
            />
          )}
        </div>

      </div>

      {exportNotice && (
        <div
          className={exportNotice.type === "error" ? "error-message" : undefined}
          role={exportNotice.type === "error" ? "alert" : "status"}
          aria-live="polite"
          style={
            exportNotice.type === "success"
              ? { color: "#166534", marginBottom: 16 }
              : { marginBottom: 16 }
          }
        >
          {exportNotice.message}
        </div>
      )}

      <section className="panel">
        {/* THANH BỘ LỌC */}
        <div className="device-filters">
          {/* TÌM KIẾM */}
          <input
            className="search-input"
            type="text"
            placeholder="Tìm mã, tên, IP, hãng, loại..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
          />

          {/* LĨNH VỰC */}
          <select
            value={categoryFilter}
            onChange={(e) =>
              handleCategoryChange(e.target.value)
            }
          >
            <option value="">Tất cả lĩnh vực</option>

            {categories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.name || category.code || category.id}
                {category.status === "INACTIVE"
                  ? " (Ngừng sử dụng)"
                  : ""}
              </option>
            ))}
          </select>

          {/* LOẠI THIẾT BỊ */}
          <select
            value={typeFilter}
            onChange={(e) => { setTypeFilter(e.target.value); setCurrentPage(1); }}
          >
            <option value="">Tất cả loại thiết bị</option>

            {availableTypes.map((type) => (
              <option key={type.id} value={type.id}>
                {type.name || type.code || type.id}
                {type.isActive === false
                  ? " (Ngừng sử dụng)"
                  : ""}
              </option>
            ))}
          </select>

          {/* KHU VỰC */}
          <select
            value={areaFilter}
            onChange={(e) =>
              handleAreaChange(e.target.value)
            }
          >
            <option value="">Tất cả khu vực</option>

            {areas.map((area) => (
              <option key={area.id} value={area.id}>
                {area.code ? `${area.code} - ` : ""}
                {area.name || area.id}
                {area.status === "INACTIVE"
                  ? " (Ngừng sử dụng)"
                  : ""}
              </option>
            ))}
          </select>

          {/* TRẠNG THÁI VẬN HÀNH */}
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1); }}
          >
            <option value="">Tất cả trạng thái</option>
            <option value="ACTIVE">Hoạt động</option>
            <option value="WARNING">Cảnh báo</option>
            <option value="OFFLINE">Mất kết nối</option>
            <option value="MAINTENANCE">Bảo trì</option>
          </select>

          {/* VÒNG ĐỜI THIẾT BỊ */}
          <select
            value={lifecycleFilter}
            onChange={(e) => { setLifecycleFilter(e.target.value); setCurrentPage(1); }}
          >
            <option value="ACTIVE">Đang sử dụng</option>
            <option value="INACTIVE">Ngừng sử dụng</option>
            <option value="ALL">Tất cả thiết bị</option>
          </select>
        </div>

        {/* THỐNG KÊ VÀ XÓA BỘ LỌC */}
        <div
          className="result-summary"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: 12,
            marginTop: 16,
            marginBottom: 16,
          }}
        >
          <div>
            Hiển thị{" "}
            <strong>{filteredDevices.length}</strong>
            {" / "}
            {visibleDeviceCount} thiết bị

            {!loading && !error && (
              <span style={{ marginLeft: 12 }}>
                Đang sử dụng: <strong>{activeCount}</strong>
                {" | "}
                Ngừng sử dụng: <strong>{inactiveCount}</strong>
              </span>
            )}
          </div>

          <ActionIconButton
            icon="clear" label="Xóa bộ lọc"
            type="button"
            onClick={clearFilters}
          />
        </div>

        {loading && <p>Đang tải dữ liệu...</p>}

        {refreshing && <p role="status">Đang làm mới dữ liệu...</p>}

        {refreshError && <p role="status">{refreshError}</p>}

        {error && (
          <div className="error-message">{error}</div>
        )}

        {/* BẢNG DANH SÁCH */}
        {!loading && !error && (
          <><div className="table-wrapper">
            <table className="device-table table-cards">
              <thead>
                <tr>
                  <th>Mã thiết bị</th>
                  <th>Tên thiết bị</th>
                  <th>Lĩnh vực</th>
                  <th>Loại thiết bị</th>
                  <th>Khu vực</th>
                  <th>Hãng / Model</th>
                  <th>Địa chỉ IP</th>
                  <th>Trạng thái</th>
                  <th>Thao tác</th>
                </tr>
              </thead>

              <tbody>
                {paginatedDevices.map((device) => {
                  const type = device.deviceTypeId
                    ? typeMap.get(device.deviceTypeId)
                    : undefined;

                  const category = type?.categoryId
                    ? categoryMap.get(type.categoryId)
                    : undefined;

                  const area = device.areaId
                    ? areaMap.get(device.areaId)
                    : undefined;
                  const subArea = device.subAreaId ? subAreaMap.get(device.subAreaId) : undefined;

                  return (
                    <tr
                      key={device.id}
                      className={
                        device.isActive === false
                          ? "device-row-inactive"
                          : ""
                      }
                    >
                      {/* MÃ THIẾT BỊ */}
                      <td>
                        <strong>
                          {device.code || device.id}
                        </strong>
                      </td>

                      {/* TÊN THIẾT BỊ */}
                      <td className="cell-name">{device.name || "-"}</td>

                      {/* LĨNH VỰC */}
                      <td data-label="Lĩnh vực" data-mobile="hide">
                        {category
                          ? category.name ||
                            category.code ||
                            category.id
                          : "-"}
                      </td>

                      {/* LOẠI THIẾT BỊ */}
                      <td data-label="Loại">
                        {type
                          ? type.name ||
                            type.code ||
                            type.id
                          : "-"}
                      </td>

                      {/* KHU VỰC */}
                      <td data-label="Khu vực">
                        {area
                          ? area.name ||
                            area.code ||
                            area.id
                          : "-"}
                        {subArea ? ` / ${subArea.name || subArea.code || subArea.id}` : ""}
                      </td>

                      {/* HÃNG / MODEL */}
                      <td data-label="Hãng / Model" data-mobile="hide">
                        {device.manufacturer || "-"}
                        {device.model
                          ? ` / ${device.model}`
                          : ""}
                      </td>

                      {/* ĐỊA CHỈ IP */}
                      <td data-label="IP">{device.ipAddress || "-"}</td>

                      {/* TRẠNG THÁI */}
                      <td data-label="Trạng thái">
                        {device.isActive === false ? (
                          <span className="status status-inactive">
                            Ngừng sử dụng
                          </span>
                        ) : (
                          <span
                            className={`status status-${(
                              device.status || "UNKNOWN"
                            ).toLowerCase()}`}
                          >
                            {getStatusLabel(device.status)}
                          </span>
                        )}
                      </td>

                      {/* THAO TÁC */}
                      <td className="cell-actions">
                        <ActionIconButton
                          icon="view" label={`Xem thiết bị ${device.code || device.id}`}
                          type="button"
                          onClick={() =>
                            navigate(`/devices/${device.id}`)
                          }
                        />
                      </td>
                    </tr>
                  );
                })}

                {filteredDevices.length === 0 && (
                  <tr>
                    <td
                      colSpan={9}
                      className="empty-table"
                    >
                      Không tìm thấy thiết bị phù hợp.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          <PaginationControls currentPage={safeDevicePage} totalItems={filteredDevices.length} onPageChange={setCurrentPage} /></>
        )}
      </section>
    </>
  );
}