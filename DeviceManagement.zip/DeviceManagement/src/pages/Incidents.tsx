import { useEffect, useState } from "react";
import {
  collection,
  getDocs,
  query,
  where,
} from "firebase/firestore";
import { useNavigate } from "react-router-dom";

import { db } from "../config/firebase";
import PaginationControls, { DEFAULT_PAGE_SIZE } from "../components/PaginationControls";
import ActionIconButton from "../components/ActionIconButton";
import { isAdmin, type AppUser } from "../types/user";

const FIRESTORE_IN_LIMIT = 30;

interface FirestoreTimestamp {
  toDate(): Date;
  toMillis(): number;
}

function chunkIds(ids: string[]): string[][] {
  const chunks: string[][] = [];
  for (let index = 0; index < ids.length; index += FIRESTORE_IN_LIMIT) {
    chunks.push(ids.slice(index, index + FIRESTORE_IN_LIMIT));
  }
  return chunks;
}

async function getDocumentsByField(
  collectionName: string,
  fieldName: string,
  values: string[],
) {
  const snapshots = await Promise.all(
    chunkIds(values).map((valuesChunk) =>
      getDocs(
        query(
          collection(db, collectionName),
          where(fieldName, "in", valuesChunk),
        ),
      ),
    ),
  );
  return snapshots.flatMap((snapshot) => snapshot.docs);
}

async function getDocumentsForDevices(
  collectionName: string,
  deviceIds: string[],
) {
  const snapshots = await Promise.all(
    [...new Set(deviceIds)].map((deviceId) =>
      getDocs(
        query(
          collection(db, collectionName),
          where("deviceId", "==", deviceId),
        ),
      ),
    ),
  );

  const documentsById = new Map<string, (typeof snapshots)[number]["docs"][number]>();
  for (const snapshot of snapshots) {
    for (const document of snapshot.docs) {
      documentsById.set(document.id, document);
    }
  }

  return [...documentsById.values()];
}

interface Incident {
  id: string;
  deviceId?: string;
  deviceCode?: string;
  deviceName?: string;
  title?: string;
  description?: string;
  severity?: string;
  status?: string;
  reportedAt?: FirestoreTimestamp;
  resolvedAt?: FirestoreTimestamp;
  resolution?: string;
}

interface IncidentsProps {
  appUser: AppUser;
}

export default function Incidents({ appUser }: IncidentsProps) {
  const navigate = useNavigate();
  const isAdminUser = isAdmin(appUser);

  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [severityFilter, setSeverityFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [currentPage, setCurrentPage] = useState(1);
  useEffect(() => {
    let cancelled = false;

    async function loadIncidents() {
      try {
        setLoading(true);
        setError("");

        if (!isAdminUser && appUser.areaIds.length === 0) {
          if (!cancelled) {
            setIncidents([]);
          }
          return;
        }

        const deviceDocuments = isAdminUser
          ? []
          : await getDocumentsByField(
              "devices",
              "areaId",
              appUser.areaIds,
            );
        if (cancelled) {
          return;
        }

        const deviceIds = deviceDocuments.map((device) => device.id);
        const incidentDocuments = isAdminUser
          ? await getDocs(collection(db, "incidents")).then(
              (snapshot) => snapshot.docs,
            )
          : deviceIds.length === 0
            ? []
            : await getDocumentsForDevices(
                "incidents",
                deviceIds,
              );

        if (cancelled) {
          return;
        }

        const data: Incident[] = incidentDocuments.map((item) => ({
          id: item.id,
          ...item.data(),
        }));

        // Mới nhất lên trên
        data.sort((a, b) => {
          const timeA = a.reportedAt?.toMillis?.() ?? 0;
          const timeB = b.reportedAt?.toMillis?.() ?? 0;

          return timeB - timeA;
        });

        setIncidents(data);
      } catch (err) {
        console.error(err);
        if (!cancelled) {
          setError("Không thể tải danh sách sự cố.");
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    void loadIncidents();

    return () => {
      cancelled = true;
    };
  }, [appUser.areaIds, isAdminUser]);
  const totalIncidents = incidents.length;

const openIncidents = incidents.filter(
  (item) => item.status === "OPEN"
).length;

const resolvedIncidents = incidents.filter(
  (item) => item.status === "RESOLVED"
).length;

const closedIncidents = incidents.filter(
  (item) => item.status === "CLOSED"
).length;

const criticalIncidents = incidents.filter(
  (item) =>
    item.severity === "CRITICAL" &&
    item.status === "OPEN"
).length;

const legacyStatusIncidents = incidents.filter(
  (item) => !["OPEN", "RESOLVED", "CLOSED"].includes(item.status || "")
).length;

const filteredIncidents = incidents.filter((item) => {
  const keyword = search.trim().toLowerCase();

  const matchSearch =
    !keyword ||
    item.deviceCode?.toLowerCase().includes(keyword) ||
    item.deviceName?.toLowerCase().includes(keyword) ||
    item.title?.toLowerCase().includes(keyword) ||
    item.description?.toLowerCase().includes(keyword);

  const matchSeverity =
    severityFilter === "ALL" ||
    item.severity === severityFilter;

  const matchStatus =
    statusFilter === "ALL" ||
    item.status === statusFilter;

  return matchSearch && matchSeverity && matchStatus;
});
  const totalIncidentPages = Math.max(1, Math.ceil(filteredIncidents.length / DEFAULT_PAGE_SIZE));
  const safeIncidentPage = Math.min(currentPage, totalIncidentPages);
  const paginatedIncidents = filteredIncidents.slice(
    (safeIncidentPage - 1) * DEFAULT_PAGE_SIZE,
    safeIncidentPage * DEFAULT_PAGE_SIZE,
  );
  function getSeverityLabel(severity?: string) {
    switch (severity) {
      case "LOW":
        return "Thấp";
      case "MEDIUM":
        return "Trung bình";
      case "HIGH":
        return "Cao";
      case "CRITICAL":
        return "Nghiêm trọng";
      default:
        return severity || "-";
    }
  }

  function getStatusLabel(status?: string) {
    switch (status) {
      case "OPEN":
        return "Đang mở";
      case "RESOLVED":
        return "Đã xử lý";
      case "CLOSED":
        return "Đã đóng";
      default:
        return status || "-";
    }
  }

  function getStatusClass(status?: string) {
    switch (status) {
      case "RESOLVED":
        return "incident-badge resolved";
      case "CLOSED":
        return "incident-badge closed";
      default:
        return "incident-badge open";
    }
  }

  function formatDate(timestamp?: FirestoreTimestamp | null) {
    if (!timestamp?.toDate) {
      return "-";
    }

    return timestamp.toDate().toLocaleString("vi-VN");
  }

  if (loading) {
    return <p>Đang tải danh sách sự cố...</p>;
  }

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Quản lý sự cố</h1>
          <p className="page-subtitle">
            Theo dõi và xử lý sự cố thiết bị trong toàn hệ thống
          </p>
        </div>
      </div>
        <div className="incident-kpi-grid">
  <div className="incident-kpi-card">
    <span>Tổng sự cố</span>
    <strong>{totalIncidents}</strong>
  </div>

  <div className="incident-kpi-card kpi-open">
    <span>Đang mở</span>
    <strong>{openIncidents}</strong>
  </div>

  <div className="incident-kpi-card kpi-resolved">
    <span>Đã xử lý</span>
    <strong>{resolvedIncidents}</strong>
  </div>

  <div className="incident-kpi-card kpi-critical">
    <span>Nghiêm trọng</span>
    <strong>{criticalIncidents}</strong>
  </div>
</div>

<section className="incident-notifications" aria-label="Thông báo trạng thái sự cố">
  {criticalIncidents > 0 && (
    <button
      type="button"
      className="incident-notification is-critical"
      onClick={() => {
        setSeverityFilter("CRITICAL");
        setStatusFilter("OPEN");
        setCurrentPage(1);
      }}
    >
      <strong>{criticalIncidents} sự cố nghiêm trọng đang mở</strong>
      <span>Cần ưu tiên kiểm tra và xử lý.</span>
    </button>
  )}

  {openIncidents > 0 && (
    <button
      type="button"
      className="incident-notification is-open"
      onClick={() => {
        setSeverityFilter("ALL");
        setStatusFilter("OPEN");
        setCurrentPage(1);
      }}
    >
      <strong>{openIncidents} sự cố đang chờ xử lý</strong>
      <span>Bấm để xem danh sách sự cố đang mở.</span>
    </button>
  )}

  {resolvedIncidents > 0 && (
    <button
      type="button"
      className="incident-notification is-verification"
      onClick={() => {
        setSeverityFilter("ALL");
        setStatusFilter("RESOLVED");
        setCurrentPage(1);
      }}
    >
      <strong>{resolvedIncidents} sự cố đang chờ xác minh</strong>
      <span>Đã khắc phục nhưng chưa hoàn tất xác minh đóng sự cố.</span>
    </button>
  )}

  {legacyStatusIncidents > 0 && (
    <div className="incident-notification is-legacy" role="status">
      <strong>{legacyStatusIncidents} bản ghi có trạng thái cũ</strong>
      <span>Cần đối soát vì không thuộc luồng OPEN → RESOLVED → CLOSED.</span>
    </div>
  )}

  {openIncidents === 0 && resolvedIncidents === 0 && legacyStatusIncidents === 0 && (
    <div className="incident-notification is-clear" role="status">
      <strong>Không có sự cố cần xử lý hoặc xác minh</strong>
      <span>{closedIncidents} sự cố đã được đóng.</span>
    </div>
  )}
</section>

<div className="incident-filters">
  <input
    type="text"
    placeholder="Tìm mã thiết bị, tên thiết bị, sự cố..."
    value={search}
    onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
  />

  <select
    value={severityFilter}
    onChange={(e) => { setSeverityFilter(e.target.value); setCurrentPage(1); }}
  >
    <option value="ALL">Tất cả mức độ</option>
    <option value="LOW">Thấp</option>
    <option value="MEDIUM">Trung bình</option>
    <option value="HIGH">Cao</option>
    <option value="CRITICAL">Nghiêm trọng</option>
  </select>

  <select
    value={statusFilter}
    onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1); }}
  >
    <option value="ALL">Tất cả trạng thái</option>
    <option value="OPEN">Đang mở</option>
    <option value="RESOLVED">Đã xử lý</option>
    <option value="CLOSED">Đã đóng</option>
  </select>
</div>
      {error && (
        <div className="form-error">
          {error}
        </div>
      )}

      <section className="panel">
        {incidents.length === 0 ? (
          <div className="empty-history">
            Chưa có sự cố nào được ghi nhận.
          </div>
        ) : (
          <div className="table-wrapper">
            <table className="device-table">
              <thead>
                <tr>
                  <th>Thiết bị</th>
                  <th>Sự cố</th>
                  <th>Mức độ</th>
                  <th>Phát sinh</th>
                  <th>Trạng thái</th>
                  <th>Thao tác</th>
                </tr>
              </thead>

              <tbody>
                {paginatedIncidents.map((incident) => (
                  <tr key={incident.id}>
                    <td>
                      <strong>
                        {incident.deviceCode || "-"}
                      </strong>

                      <div>
                        {incident.deviceName || ""}
                      </div>
                    </td>

                    <td>
                      <strong>
                        {incident.title || "-"}
                      </strong>

                      {incident.description && (
                        <div>
                          {incident.description}
                        </div>
                      )}
                    </td>

                    <td>
                      {getSeverityLabel(incident.severity)}
                    </td>

                    <td>
                      {formatDate(incident.reportedAt)}
                    </td>

                    <td>
                      <span
                        className={getStatusClass(incident.status)}
                      >
                        {getStatusLabel(incident.status)}
                      </span>
                    </td>

                    <td>
                      {incident.status === "OPEN" ? (
                        <ActionIconButton
                          icon="resolve" variant="primary" label={`Khắc phục sự cố ${incident.deviceCode || ""}`}
                          onClick={() =>
                            navigate(
                              `/incidents/${incident.id}/resolve`
                            )
                          }
                        />
                      ) : incident.status === "RESOLVED" ? (
                        <ActionIconButton
                          icon="verify" variant="primary" label={`Xác minh sự cố ${incident.deviceCode || ""}`}
                          onClick={() =>
                            navigate(
                              `/incidents/${incident.id}/verify`
                            )
                          }
                        />
                      ) : (
                        <ActionIconButton
                          icon="view" label={`Xem thiết bị ${incident.deviceCode || ""}`}
                          onClick={() =>
                            navigate(
                              `/devices/${incident.deviceId}`
                            )
                          }
                        />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <PaginationControls currentPage={safeIncidentPage} totalItems={filteredIncidents.length} onPageChange={setCurrentPage} />
          </div>
        )}
      </section>
    </>
  );
}
