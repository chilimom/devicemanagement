
// import { useEffect, useState, type FormEvent } from "react";
// import {
//   addDoc,
//   collection,
//   doc,
//   getDoc,
//   getDocs,
//   runTransaction,
//   serverTimestamp,
//   query,
//   where,
// } from "firebase/firestore";
// import { useNavigate } from "react-router-dom";
// import { db } from "../config/firebase";
// import { invalidateAppCollection } from "../services/sharedCollectionCache";
// import { isAdmin, type AppUser } from "../types/user";

// // ======================================================
// // 1. KIỂU DỮ LIỆU
// // ======================================================

// interface Area {
//   id: string;
//   code: string;
//   name: string;
//   status?: string;
// }

// interface SubArea {
//   id: string;
//   factoryId: string;
//   code: string;
//   name: string;
//   status?: string;
// }

// interface DeviceCategory {
//   id: string;
//   name: string;
//   status: string;
// }

// interface DeviceType {
//   id: string;
//   code: string;
//   name: string;
//   categoryId: string;
//   isActive: boolean;
//   areaIds: string[];
// }

// // ======================================================
// // 2. KIỂM TRA ĐỊA CHỈ IP VÀ MAC
// // ======================================================

// function isValidIPv4(ip: string) {
//   if (!ip) return true;

//   const parts = ip.split(".");
//   if (parts.length !== 4) return false;

//   return parts.every(
//     (part) =>
//       /^\d{1,3}$/.test(part) &&
//       Number(part) >= 0 &&
//       Number(part) <= 255
//   );
// }

// function isValidMac(mac: string) {
//   if (!mac) return true;

//   return /^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/.test(mac);
// }

// // ======================================================
// // 3. COMPONENT
// // ======================================================

// export default function AddDevice({ appUser }: { appUser: AppUser }) {
//   const navigate = useNavigate();

//   // Danh mục
//   const [areas, setAreas] = useState<Area[]>([]);
//   const [subAreas, setSubAreas] = useState<SubArea[]>([]);
//   const [categories, setCategories] = useState<DeviceCategory[]>([]);
//   const [deviceTypes, setDeviceTypes] = useState<DeviceType[]>([]);

//   // Thông tin thiết bị
//   const [code, setCode] = useState("");
//   const [name, setName] = useState("");
//   const [areaId, setAreaId] = useState("");
//   const [subAreaId, setSubAreaId] = useState("");
//   const [categoryId, setCategoryId] = useState("");
//   const [deviceTypeId, setDeviceTypeId] = useState("");

//   const [manufacturer, setManufacturer] = useState("");
//   const [model, setModel] = useState("");
//   const [serialNumber, setSerialNumber] = useState("");
//   const [ipAddress, setIpAddress] = useState("");
//   const [macAddress, setMacAddress] = useState("");
//   const [status, setStatus] = useState("ACTIVE");
//   const [description, setDescription] = useState("");

//   // Thêm loại thiết bị ngay tại biểu mẫu
//   const [showNewType, setShowNewType] = useState(false);
//   const [newTypeName, setNewTypeName] = useState("");
//   const [newTypeDescription, setNewTypeDescription] = useState("");
//   const [addingType, setAddingType] = useState(false);

//   // Trạng thái
//   const [loadingMasterData, setLoadingMasterData] = useState(true);
//   const [saving, setSaving] = useState(false);
//   const [error, setError] = useState("");
//   const [typeMessage, setTypeMessage] = useState("");

//   // ====================================================
//   // 4. TẢI DANH MỤC
//   // ====================================================

//   useEffect(() => {
//     let cancelled = false;

//     async function loadMasterData() {
//       try {
//         setLoadingMasterData(true);
//         setError("");

//         const areaPromise = isAdmin(appUser)
//           ? getDocs(collection(db, "areas")).then((snapshot) => snapshot.docs)
//           : Promise.all(appUser.areaIds.map((id) => getDoc(doc(db, "areas", id))))
//               .then((snapshots) => snapshots.filter((snapshot) => snapshot.exists()));
//         const subAreaPromise = isAdmin(appUser)
//           ? getDocs(collection(db, "subAreas")).then((snapshot) => snapshot.docs)
//           : Promise.all(appUser.areaIds.map((factoryId) => getDocs(query(
//               collection(db, "subAreas"), where("factoryId", "==", factoryId),
//             )))).then((snapshots) => snapshots.flatMap((snapshot) => snapshot.docs));
//         const [areaDocs, categorySnap, typeSnap, subAreaDocs] =
//           await Promise.all([
//             areaPromise,
//             getDocs(collection(db, "deviceCategories")),
//             getDocs(collection(db, "deviceTypes")),
//             subAreaPromise,
//           ]);

//         if (cancelled) return;

//         const areaData: Area[] = areaDocs.map((item) => ({
//           ...(item.data() as Omit<Area, "id">),
//           id: item.id,
//         }));

//         const categoryData: DeviceCategory[] =
//           categorySnap.docs.map((item) => ({
//             id: item.id,
//             name: String(item.data().name || ""),
//             status: String(item.data().status || "ACTIVE"),
//           }));

//         const typeData: DeviceType[] = typeSnap.docs.map(
//           (item) => ({
//             id: item.id,
//             code: String(item.data().code || ""),
//             name: String(item.data().name || ""),
//             categoryId: String(item.data().categoryId || ""),
//             isActive: item.data().isActive !== false,
//             areaIds: Array.isArray(item.data().areaIds)
//               ? item.data().areaIds.filter((value: unknown): value is string => typeof value === "string")
//               : [],
//           })
//         );

//         setAreas(
//           areaData
//             .filter((item) => item.status !== "INACTIVE")
//             .sort((a, b) => a.code.localeCompare(b.code))
//         );
//         setSubAreas(subAreaDocs.map((item) => ({ id: item.id, ...(item.data() as Omit<SubArea, "id">) })));

//         setCategories(
//           categoryData
//             .filter((item) => item.status === "ACTIVE")
//             .sort((a, b) =>
//               a.name.localeCompare(b.name, "vi")
//             )
//         );

//         setDeviceTypes(
//           typeData.sort((a, b) =>
//             a.name.localeCompare(b.name, "vi")
//           )
//         );
//       } catch (err) {
//         console.error("Lỗi tải danh mục:", err);

//         if (!cancelled) {
//           setError(
//             "Không thể tải danh mục khu vực, lĩnh vực hoặc loại thiết bị."
//           );
//         }
//       } finally {
//         if (!cancelled) setLoadingMasterData(false);
//       }
//     }

//     void loadMasterData();

//     return () => {
//       cancelled = true;
//     };
//   }, [appUser]);

//   // ====================================================
//   // 5. LỌC LOẠI THIẾT BỊ THEO LĨNH VỰC
//   // ====================================================

//   const filteredTypes = deviceTypes.filter(
//     (item) =>
//       item.categoryId === categoryId &&
//       item.isActive &&
//       (item.areaIds.length === 0 || item.areaIds.includes(areaId))
//   );

//   function handleCategoryChange(value: string) {
//     setCategoryId(value);

//     // Khi đổi lĩnh vực phải bỏ loại đã chọn trước đó.
//     setDeviceTypeId("");
//     setShowNewType(false);
//     setNewTypeName("");
//     setNewTypeDescription("");
//     setTypeMessage("");
//     setError("");
//   }

//   // ====================================================
//   // 6. THÊM LOẠI THIẾT BỊ MỚI
//   // ====================================================

//   async function handleAddType() {
//     const cleanName = newTypeName.trim();
//     const cleanDescription = newTypeDescription.trim();

//     setError("");
//     setTypeMessage("");

//     if (!categoryId || !cleanName) {
//       setError("Vui lòng chọn lĩnh vực và nhập tên loại thiết bị.");
//       return;
//     }

//     try {
//       setAddingType(true);

//       // Kiểm tra lĩnh vực còn hoạt động.
//       const categorySnap = await getDoc(
//         doc(db, "deviceCategories", categoryId)
//       );

//       if (
//         !categorySnap.exists() ||
//         categorySnap.data().status !== "ACTIVE"
//       ) {
//         setError("Lĩnh vực đã ngừng sử dụng hoặc không tồn tại.");
//         return;
//       }

//       // Đọc danh mục mới nhất trước khi thêm.
//       const latestSnap = await getDocs(
//         collection(db, "deviceTypes")
//       );

//       const duplicate = latestSnap.docs.find((item) => {
//         const data = item.data();

//         return (
//           data.categoryId === categoryId &&
//           String(data.name || "")
//             .trim()
//             .toLocaleLowerCase("vi") ===
//             cleanName.toLocaleLowerCase("vi")
//         );
//       });

//       if (duplicate) {
//         // Nếu đã có loại cùng tên, không tạo bản ghi trùng.
//         if (duplicate.data().isActive === false) {
//           setError(
//             "Loại thiết bị đã tồn tại nhưng đang ngừng sử dụng. " +
//             "Vui lòng kích hoạt lại trong trang Quản trị."
//           );
//           return;
//         }

//         const existingType: DeviceType = {
//           id: duplicate.id,
//           code: String(duplicate.data().code || ""),
//           name: String(duplicate.data().name || ""),
//           categoryId,
//           isActive: true,
//           areaIds: Array.isArray(duplicate.data().areaIds)
//             ? duplicate.data().areaIds.filter((value: unknown): value is string => typeof value === "string")
//             : [],
//         };

//         setDeviceTypes((previous) => [
//           ...previous.filter((item) => item.id !== existingType.id),
//           existingType,
//         ]);

//         setDeviceTypeId(existingType.id);
//         setShowNewType(false);
//         setTypeMessage(
//           "Loại thiết bị đã tồn tại. Hệ thống đã chọn loại này."
//         );
//         return;
//       }

//       // Tạo loại mới với Document ID tự động.
//       const codeValue =
//         "TYPE-" +
//         Date.now().toString(36).toUpperCase() +
//         "-" +
//         Math.random().toString(36).slice(2, 7).toUpperCase();

//       const newRef = await addDoc(
//         collection(db, "deviceTypes"),
//         {
//           code: codeValue,
//           name: cleanName,
//           description: cleanDescription,
//           categoryId,
//           areaIds: [],
//           isActive: true,
//           createdAt: serverTimestamp(),
//           updatedAt: serverTimestamp(),
//         }
//       );

//       invalidateAppCollection("deviceTypes");

//       // Cập nhật dropdown mà không cần tải lại trang.
//       setDeviceTypes((previous) =>
//         [
//           ...previous,
//           {
//             id: newRef.id,
//             code: codeValue,
//             name: cleanName,
//             categoryId,
//             areaIds: [],
//             isActive: true,
//           },
//         ].sort((a, b) =>
//           a.name.localeCompare(b.name, "vi")
//         )
//       );

//       // Tự chọn loại vừa tạo.
//       setDeviceTypeId(newRef.id);
//       setShowNewType(false);
//       setNewTypeName("");
//       setNewTypeDescription("");

//       setTypeMessage(
//         `Đã thêm loại "${cleanName}" và tự động chọn loại này.`
//       );
//     } catch (err) {
//       console.error("Lỗi thêm loại thiết bị:", err);
//       setError("Không thể thêm loại thiết bị. Vui lòng thử lại.");
//     } finally {
//       setAddingType(false);
//     }
//   }

//   // ====================================================
//   // 7. LƯU THIẾT BỊ
//   // ====================================================

//   async function handleSubmit(e: FormEvent<HTMLFormElement>) {
//     e.preventDefault();
//     setError("");

//     const normalizedCode = code.trim().toUpperCase();
//     const normalizedName = name.trim();
//     const normalizedIp = ipAddress.trim();
//     const normalizedMac = macAddress.trim().toUpperCase();

//     if (
//       !normalizedCode ||
//       !normalizedName ||
//       !areaId ||
//       !categoryId ||
//       !deviceTypeId
//     ) {
//       setError("Vui lòng nhập đầy đủ các trường bắt buộc.");
//       return;
//     }

//     if (!isValidIPv4(normalizedIp)) {
//       setError("Địa chỉ IP không hợp lệ.");
//       return;
//     }

//     if (!isValidMac(normalizedMac)) {
//       setError(
//         "MAC Address không hợp lệ. Ví dụ: AA:BB:CC:DD:EE:FF"
//       );
//       return;
//     }

//     try {
//       setSaving(true);

//       // Kiểm tra lại dữ liệu danh mục tại thời điểm lưu.
//       const areaRef = doc(db, "areas", areaId);
//       const subAreaRef = subAreaId ? doc(db, "subAreas", subAreaId) : null;
//       const categoryRef = doc(db, "deviceCategories", categoryId);
//       const typeRef = doc(db, "deviceTypes", deviceTypeId);
//       const deviceRef = doc(db, "devices", normalizedCode);

//       // Transaction kiểm tra dữ liệu và tạo thiết bị.
//       // Không ghi đè thiết bị đã tồn tại.
//       await runTransaction(db, async (transaction) => {
//         const [areaSnap, categorySnap, typeSnap, deviceSnap, subAreaSnap] =
//           await Promise.all([
//             transaction.get(areaRef),
//             transaction.get(categoryRef),
//             transaction.get(typeRef),
//             transaction.get(deviceRef),
//             subAreaRef ? transaction.get(subAreaRef) : Promise.resolve(null),
//           ]);

//         if (!areaSnap.exists()) {
//           throw new Error("Khu vực không tồn tại.");
//         }

//         if (areaSnap.data().status === "INACTIVE") {
//           throw new Error("Khu vực đã ngừng sử dụng.");
//         }
//         if (subAreaId && (!subAreaSnap?.exists() || subAreaSnap.data().factoryId !== areaId || subAreaSnap.data().status === "INACTIVE")) {
//           throw new Error("Khu vực con không hợp lệ hoặc không thuộc nhà máy đã chọn.");
//         }

//         if (
//           !categorySnap.exists() ||
//           categorySnap.data().status !== "ACTIVE"
//         ) {
//           throw new Error("Lĩnh vực không còn hoạt động.");
//         }

//         if (
//           !typeSnap.exists() ||
//           typeSnap.data().isActive === false ||
//           typeSnap.data().categoryId !== categoryId
//         ) {
//           throw new Error(
//             "Loại thiết bị không hợp lệ hoặc đã ngừng sử dụng."
//           );
//         }

//         if (deviceSnap.exists()) {
//           throw new Error(
//             `Mã thiết bị ${normalizedCode} đã tồn tại.`
//           );
//         }

//         transaction.set(deviceRef, {
//           code: normalizedCode,
//           name: normalizedName,

//           areaId,
//           ...(subAreaId ? { subAreaId } : {}),
//           deviceTypeId,

//           manufacturer: manufacturer.trim(),
//           model: model.trim(),
//           serialNumber: serialNumber.trim(),

//           ipAddress: normalizedIp,
//           macAddress: normalizedMac,

//           status,
//           description: description.trim(),

//           isActive: true,
//           createdAt: serverTimestamp(),
//           updatedAt: serverTimestamp(),
//         });
//       });

//       invalidateAppCollection("devices");

//       navigate("/devices");
//     } catch (err) {
//       console.error("Lỗi lưu thiết bị:", err);

//       setError(
//         err instanceof Error
//           ? err.message
//           : "Không thể lưu thiết bị."
//       );
//     } finally {
//       setSaving(false);
//     }
//   }

//   // ====================================================
//   // 8. GIAO DIỆN
//   // ====================================================

//   return (
//     <main className="add-device-page">
//       <div className="page-header">
//         <div>
//           <h1>Thêm thiết bị</h1>
//           <p className="page-subtitle">
//             Thêm thiết bị mới vào hệ thống quản lý
//           </p>
//         </div>
//       </div>

//       <form className="device-form" onSubmit={handleSubmit}>
//         {error && (
//           <div className="error-message">{error}</div>
//         )}

//         {typeMessage && (
//           <div
//             style={{
//               padding: 12,
//               marginBottom: 16,
//               borderRadius: 8,
//               background: "#dcfce7",
//               color: "#166534",
//             }}
//           >
//             {typeMessage}
//           </div>
//         )}

//         <div className="form-grid">
          

//           {/* KHU VỰC */}
//           <label>
//             Nhà máy *
//             <select
//               value={areaId}
//               onChange={(e) => {
//                 setAreaId(e.target.value);
//                 setSubAreaId("");
//                 setDeviceTypeId("");
//               }}
//               disabled={loadingMasterData}
//               required
//             >
//               <option value="">-- Chọn nhà máy --</option>

//               {areas.map((area) => (
//                 <option key={area.id} value={area.id}>
//                   {area.code} - {area.name}
//                 </option>
//               ))}
//             </select>

//             {!loadingMasterData && areas.length === 0 && (
//               <small className="form-warning-text">
//                 Không có nhà máy đang hoạt động.
//               </small>
//             )}
//           </label>

//           <label>
//             Khu vực
//             <select value={subAreaId} onChange={(e) => setSubAreaId(e.target.value)} disabled={!areaId || loadingMasterData}>
//               <option value="">-- Chưa xác định --</option>
//               {subAreas.filter((item) => item.factoryId === areaId && item.status !== "INACTIVE").map((item) => (
//                 <option key={item.id} value={item.id}>{item.code} - {item.name}</option>
//               ))}
//             </select>
//           </label>
//               {/* MÃ THIẾT BỊ */}
//           <label>
//             Mã thiết bị *
//             <input
//               value={code}
//               onChange={(e) =>
//                 setCode(e.target.value.toUpperCase())
//               }
//               placeholder="VD: MT-LC-VH"
//               required
//             />
//           </label>

//           {/* TÊN THIẾT BỊ */}
//           <label>
//             Tên thiết bị *
//             <input
//               value={name}
//               onChange={(e) => setName(e.target.value)}
//               placeholder="Tên thiết bị"
//               required
//             />
//           </label>
//           {/* LĨNH VỰC */}
//           <label>
//             Lĩnh vực *
//             <select
//               value={categoryId}
//               onChange={(e) =>
//                 handleCategoryChange(e.target.value)
//               }
//               disabled={loadingMasterData}
//               required
//             >
//               <option value="">-- Chọn lĩnh vực --</option>

//               {categories.map((category) => (
//                 <option key={category.id} value={category.id}>
//                   {category.name}
//                 </option>
//               ))}
//             </select>
//           </label>

//           {/* LOẠI THIẾT BỊ */}
//           <label>
//             Loại thiết bị *
//             <select
//               value={deviceTypeId}
//               onChange={(e) =>
//                 setDeviceTypeId(e.target.value)
//               }
//               disabled={
//                 loadingMasterData ||
//                 !categoryId ||
//                 showNewType
//               }
//               required
//             >
//               <option value="">
//                 -- Chọn loại thiết bị --
//               </option>

//               {filteredTypes.map((type) => (
//                 <option key={type.id} value={type.id}>
//                   {type.name}
//                 </option>
//               ))}
//             </select>
//           </label>

//           {/* THÊM LOẠI MỚI
//           <div
//             style={{
//               display: "flex",
//               alignItems: "flex-end",
//             }}
//           >
//             {isAdmin(appUser) && <button
//               type="button"
//               className="secondary-button"
//               disabled={
//                 !categoryId ||
//                 loadingMasterData ||
//                 saving ||
//                 addingType
//               }
//               onClick={() => {
//                 setShowNewType((previous) => !previous);
//                 setError("");
//               }}
//             >
//               {showNewType
//                 ? "Hủy thêm loại mới"
//                 : "+ Thêm loại thiết bị mới"}
//             </button>}
//           </div> */}

//           {/* HÃNG SẢN XUẤT */}
//           <label>
//             Hãng sản xuất
//             <input
//               value={manufacturer}
//               onChange={(e) =>
//                 setManufacturer(e.target.value)
//               }
//               placeholder="VD: Dell, Siemens, Hikvision"
//             />
//           </label>

//           {/* MODEL */}
//           <label>
//             Model
//             <input
//               value={model}
//               onChange={(e) => setModel(e.target.value)}
//             />
//           </label>

//           {/* SERIAL */}
//           <label>
//             Serial Number
//             <input
//               value={serialNumber}
//               onChange={(e) =>
//                 setSerialNumber(e.target.value)
//               }
//             />
//           </label>

//           {/* IP */}
//           <label>
//             Địa chỉ IP
//             <input
//               value={ipAddress}
//               onChange={(e) =>
//                 setIpAddress(e.target.value)
//               }
//               placeholder="10.192.x.x"
//             />
//           </label>

//           {/* MAC */}
//           <label>
//             MAC Address
//             <input
//               value={macAddress}
//               onChange={(e) =>
//                 setMacAddress(e.target.value)
//               }
//               placeholder="AA:BB:CC:DD:EE:FF"
//             />
//           </label>

//           {/* TRẠNG THÁI */}
//           <label>
//             Trạng thái
//             <select
//               value={status}
//               onChange={(e) => setStatus(e.target.value)}
//             >
//               <option value="ACTIVE">Hoạt động</option>
//               <option value="WARNING">Cảnh báo</option>
//               <option value="OFFLINE">Mất kết nối</option>
//               <option value="MAINTENANCE">Bảo trì</option>
//             </select>
//           </label>
//         </div>

//         {/* BIỂU MẪU THÊM LOẠI MỚI */}
//         {showNewType && isAdmin(appUser) && (
//           <section
//             style={{
//               marginTop: 20,
//               padding: 20,
//               background: "#eff6ff",
//               border: "1px solid #bfdbfe",
//               borderRadius: 10,
//             }}
//           >
//             <h3>Thêm loại thiết bị mới</h3>

//             <p>
//               Lĩnh vực:{" "}
//               <strong>
//                 {
//                   categories.find(
//                     (item) => item.id === categoryId
//                   )?.name
//                 }
//               </strong>
//             </p>

//             <label>
//               Tên loại thiết bị *
//               <input
//                 value={newTypeName}
//                 onChange={(e) =>
//                   setNewTypeName(e.target.value)
//                 }
//                 placeholder="VD: Động cơ điện"
//                 disabled={addingType}
//               />
//             </label>

//             <label
//               style={{
//                 display: "block",
//                 marginTop: 12,
//               }}
//             >
//               Mô tả
//               <textarea
//                 value={newTypeDescription}
//                 onChange={(e) =>
//                   setNewTypeDescription(e.target.value)
//                 }
//                 rows={2}
//                 disabled={addingType}
//               />
//             </label>

//             <button
//               type="button"
//               className="primary-button"
//               onClick={handleAddType}
//               disabled={addingType || !newTypeName.trim()}
//               style={{ marginTop: 12 }}
//             >
//               {addingType
//                 ? "Đang thêm..."
//                 : "Lưu loại thiết bị"}
//             </button>
//           </section>
//         )}

//         {/* GHI CHÚ */}
//         <label className="full-field">
//           Ghi chú
//           <textarea
//             value={description}
//             onChange={(e) =>
//               setDescription(e.target.value)
//             }
//             rows={4}
//           />
//         </label>

//         {/* NÚT THAO TÁC */}
//         <div className="form-actions">
//           <button
//             type="button"
//             className="secondary-button"
//             disabled={saving || addingType}
//             onClick={() => navigate("/devices")}
//           >
//             Hủy
//           </button>

//           <button
//             type="submit"
//             className="primary-button"
//             disabled={
//               saving ||
//               addingType ||
//               showNewType ||
//               loadingMasterData ||
//               areas.length === 0 ||
//               categories.length === 0
//             }
//           >
//             {saving ? "Đang lưu..." : "Lưu thiết bị"}
//           </button>
//         </div>
//       </form>
//     </main>
//   );
// }
import { useEffect, useState, type FormEvent } from "react";
import {
  addDoc,
  collection,
  doc,
  getDoc,
  getDocs,
  runTransaction,
  serverTimestamp,
  query,
  where,
} from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import { db } from "../config/firebase";
import { showAppConfirm } from "../services/appDialog";
import { invalidateAppCollection } from "../services/sharedCollectionCache";
import { isAdmin, type AppUser } from "../types/user";

// ======================================================
// 1. KIỂU DỮ LIỆU
// ======================================================

interface Area {
  id: string;
  code: string;
  name: string;
  status?: string;
}

interface SubArea {
  id: string;
  factoryId: string;
  code: string;
  name: string;
  status?: string;
}

interface DeviceCategory {
  id: string;
  name: string;
  status: string;
}

interface DeviceType {
  id: string;
  code: string;
  name: string;
  categoryId: string;
  isActive: boolean;
  areaIds: string[];
}

// Mã thiết bị (code, đồng thời là Document ID và nội dung QR) do hệ thống tự sinh:
// TB-000001, TB-000002... Mã vật tư KHÔNG dùng làm ID vì có thể lặp lại ở nhiều nơi.
const DEVICE_CODE_PREFIX = "TB-";
const MAX_QUANTITY = 50;
const FREE_CODE_PATTERN = /^[A-Z0-9._-]*$/;

function formatDeviceCode(sequence: number) {
  return DEVICE_CODE_PREFIX + String(sequence).padStart(6, "0");
}

// ======================================================
// 2. KIỂM TRA ĐỊA CHỈ IP VÀ MAC
// ======================================================

function isValidIPv4(ip: string) {
  if (!ip) return true;

  const parts = ip.split(".");
  if (parts.length !== 4) return false;

  return parts.every(
    (part) =>
      /^\d{1,3}$/.test(part) &&
      Number(part) >= 0 &&
      Number(part) <= 255
  );
}

function isValidMac(mac: string) {
  if (!mac) return true;

  return /^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/.test(mac);
}

// ======================================================
// 3. COMPONENT
// ======================================================

export default function AddDevice({ appUser }: { appUser: AppUser }) {
  const navigate = useNavigate();

  // Danh mục
  const [areas, setAreas] = useState<Area[]>([]);
  const [subAreas, setSubAreas] = useState<SubArea[]>([]);
  const [categories, setCategories] = useState<DeviceCategory[]>([]);
  const [deviceTypes, setDeviceTypes] = useState<DeviceType[]>([]);

  // Thông tin thiết bị
  const [materialCode, setMaterialCode] = useState("");
  const [locationCode, setLocationCode] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [name, setName] = useState("");
  const [areaId, setAreaId] = useState("");
  const [subAreaId, setSubAreaId] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [deviceTypeId, setDeviceTypeId] = useState("");

  const [manufacturer, setManufacturer] = useState("");
  const [model, setModel] = useState("");
  const [serialNumber, setSerialNumber] = useState("");
  const [ipAddress, setIpAddress] = useState("");
  const [macAddress, setMacAddress] = useState("");
  const [status, setStatus] = useState("ACTIVE");
  const [description, setDescription] = useState("");

  // Thêm loại thiết bị ngay tại biểu mẫu
  const [showNewType, setShowNewType] = useState(false);
  const [newTypeName, setNewTypeName] = useState("");
  const [newTypeDescription, setNewTypeDescription] = useState("");
  const [addingType, setAddingType] = useState(false);

  // Trạng thái
  const [loadingMasterData, setLoadingMasterData] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [typeMessage, setTypeMessage] = useState("");

  // ====================================================
  // 4. TẢI DANH MỤC
  // ====================================================

  useEffect(() => {
    let cancelled = false;

    async function loadMasterData() {
      try {
        setLoadingMasterData(true);
        setError("");

        const areaPromise = isAdmin(appUser)
          ? getDocs(collection(db, "areas")).then((snapshot) => snapshot.docs)
          : Promise.all(appUser.areaIds.map((id) => getDoc(doc(db, "areas", id))))
              .then((snapshots) => snapshots.filter((snapshot) => snapshot.exists()));
        const subAreaPromise = isAdmin(appUser)
          ? getDocs(collection(db, "subAreas")).then((snapshot) => snapshot.docs)
          : Promise.all(appUser.areaIds.map((factoryId) => getDocs(query(
              collection(db, "subAreas"), where("factoryId", "==", factoryId),
            )))).then((snapshots) => snapshots.flatMap((snapshot) => snapshot.docs));
        const [areaDocs, categorySnap, typeSnap, subAreaDocs] =
          await Promise.all([
            areaPromise,
            getDocs(collection(db, "deviceCategories")),
            getDocs(collection(db, "deviceTypes")),
            subAreaPromise,
          ]);

        if (cancelled) return;

        const areaData: Area[] = areaDocs.map((item) => ({
          ...(item.data() as Omit<Area, "id">),
          id: item.id,
        }));

        const categoryData: DeviceCategory[] =
          categorySnap.docs.map((item) => ({
            id: item.id,
            name: String(item.data().name || ""),
            status: String(item.data().status || "ACTIVE"),
          }));

        const typeData: DeviceType[] = typeSnap.docs.map(
          (item) => ({
            id: item.id,
            code: String(item.data().code || ""),
            name: String(item.data().name || ""),
            categoryId: String(item.data().categoryId || ""),
            isActive: item.data().isActive !== false,
            areaIds: Array.isArray(item.data().areaIds)
              ? item.data().areaIds.filter((value: unknown): value is string => typeof value === "string")
              : [],
          })
        );

        setAreas(
          areaData
            .filter((item) => item.status !== "INACTIVE")
            .sort((a, b) => a.code.localeCompare(b.code))
        );
        setSubAreas(subAreaDocs.map((item) => ({ id: item.id, ...(item.data() as Omit<SubArea, "id">) })));

        setCategories(
          categoryData
            .filter((item) => item.status === "ACTIVE")
            .sort((a, b) =>
              a.name.localeCompare(b.name, "vi")
            )
        );

        setDeviceTypes(
          typeData.sort((a, b) =>
            a.name.localeCompare(b.name, "vi")
          )
        );
      } catch (err) {
        console.error("Lỗi tải danh mục:", err);

        if (!cancelled) {
          setError(
            "Không thể tải danh mục khu vực, lĩnh vực hoặc loại thiết bị."
          );
        }
      } finally {
        if (!cancelled) setLoadingMasterData(false);
      }
    }

    void loadMasterData();

    return () => {
      cancelled = true;
    };
  }, [appUser]);

  // ====================================================
  // 5. LỌC LOẠI THIẾT BỊ THEO LĨNH VỰC
  // ====================================================

  const filteredTypes = deviceTypes.filter(
    (item) =>
      item.categoryId === categoryId &&
      item.isActive &&
      (item.areaIds.length === 0 || item.areaIds.includes(areaId))
  );

  function handleCategoryChange(value: string) {
    setCategoryId(value);

    // Khi đổi lĩnh vực phải bỏ loại đã chọn trước đó.
    setDeviceTypeId("");
    setShowNewType(false);
    setNewTypeName("");
    setNewTypeDescription("");
    setTypeMessage("");
    setError("");
  }

  // ====================================================
  // 6. THÊM LOẠI THIẾT BỊ MỚI
  // ====================================================

  async function handleAddType() {
    const cleanName = newTypeName.trim();
    const cleanDescription = newTypeDescription.trim();

    setError("");
    setTypeMessage("");

    if (!categoryId || !cleanName) {
      setError("Vui lòng chọn lĩnh vực và nhập tên loại thiết bị.");
      return;
    }

    try {
      setAddingType(true);

      // Kiểm tra lĩnh vực còn hoạt động.
      const categorySnap = await getDoc(
        doc(db, "deviceCategories", categoryId)
      );

      if (
        !categorySnap.exists() ||
        categorySnap.data().status !== "ACTIVE"
      ) {
        setError("Lĩnh vực đã ngừng sử dụng hoặc không tồn tại.");
        return;
      }

      // Đọc danh mục mới nhất trước khi thêm.
      const latestSnap = await getDocs(
        collection(db, "deviceTypes")
      );

      const duplicate = latestSnap.docs.find((item) => {
        const data = item.data();

        return (
          data.categoryId === categoryId &&
          String(data.name || "")
            .trim()
            .toLocaleLowerCase("vi") ===
            cleanName.toLocaleLowerCase("vi")
        );
      });

      if (duplicate) {
        // Nếu đã có loại cùng tên, không tạo bản ghi trùng.
        if (duplicate.data().isActive === false) {
          setError(
            "Loại thiết bị đã tồn tại nhưng đang ngừng sử dụng. " +
            "Vui lòng kích hoạt lại trong trang Quản trị."
          );
          return;
        }

        const existingType: DeviceType = {
          id: duplicate.id,
          code: String(duplicate.data().code || ""),
          name: String(duplicate.data().name || ""),
          categoryId,
          isActive: true,
          areaIds: Array.isArray(duplicate.data().areaIds)
            ? duplicate.data().areaIds.filter((value: unknown): value is string => typeof value === "string")
            : [],
        };

        setDeviceTypes((previous) => [
          ...previous.filter((item) => item.id !== existingType.id),
          existingType,
        ]);

        setDeviceTypeId(existingType.id);
        setShowNewType(false);
        setTypeMessage(
          "Loại thiết bị đã tồn tại. Hệ thống đã chọn loại này."
        );
        return;
      }

      // Tạo loại mới với Document ID tự động.
      const codeValue =
        "TYPE-" +
        Date.now().toString(36).toUpperCase() +
        "-" +
        Math.random().toString(36).slice(2, 7).toUpperCase();

      const newRef = await addDoc(
        collection(db, "deviceTypes"),
        {
          code: codeValue,
          name: cleanName,
          description: cleanDescription,
          categoryId,
          areaIds: [],
          isActive: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        }
      );

      invalidateAppCollection("deviceTypes");

      // Cập nhật dropdown mà không cần tải lại trang.
      setDeviceTypes((previous) =>
        [
          ...previous,
          {
            id: newRef.id,
            code: codeValue,
            name: cleanName,
            categoryId,
            areaIds: [],
            isActive: true,
          },
        ].sort((a, b) =>
          a.name.localeCompare(b.name, "vi")
        )
      );

      // Tự chọn loại vừa tạo.
      setDeviceTypeId(newRef.id);
      setShowNewType(false);
      setNewTypeName("");
      setNewTypeDescription("");

      setTypeMessage(
        `Đã thêm loại "${cleanName}" và tự động chọn loại này.`
      );
    } catch (err) {
      console.error("Lỗi thêm loại thiết bị:", err);
      setError("Không thể thêm loại thiết bị. Vui lòng thử lại.");
    } finally {
      setAddingType(false);
    }
  }

  // ====================================================
  // 7. LƯU THIẾT BỊ
  // ====================================================

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");

    const normalizedMaterial = materialCode.trim().toUpperCase();
    const normalizedLocation = locationCode.trim().toUpperCase();
    const normalizedName = name.trim();
    const normalizedIp = ipAddress.trim();
    const normalizedMac = macAddress.trim().toUpperCase();
    const normalizedSerial = serialNumber.trim();
    const count = Number(quantity);

    if (!normalizedName || !areaId || !categoryId || !deviceTypeId) {
      setError("Vui lòng nhập đầy đủ các trường bắt buộc.");
      return;
    }

    if (
      !FREE_CODE_PATTERN.test(normalizedMaterial) ||
      !FREE_CODE_PATTERN.test(normalizedLocation)
    ) {
      setError("Mã vật tư và mã vị trí chỉ gồm chữ, số và các ký tự . _ -");
      return;
    }

    if (!Number.isInteger(count) || count < 1 || count > MAX_QUANTITY) {
      setError(`Số lượng phải là số nguyên từ 1 đến ${MAX_QUANTITY}.`);
      return;
    }

    if (count > 1 && (normalizedSerial || normalizedIp || normalizedMac)) {
      setError(
        "Serial, IP và MAC là riêng của từng thiết bị. " +
        "Hãy để trống các ô này khi thêm nhiều thiết bị một lần."
      );
      return;
    }

    if (!isValidIPv4(normalizedIp)) {
      setError("Địa chỉ IP không hợp lệ.");
      return;
    }

    if (!isValidMac(normalizedMac)) {
      setError(
        "MAC Address không hợp lệ. Ví dụ: AA:BB:CC:DD:EE:FF"
      );
      return;
    }

    try {
      setSaving(true);

      // ----- Kiểm tra trùng (trong phạm vi nhà máy đang chọn) -----
      const sameAreaQuery = (field: string, value: string) =>
        getDocs(
          query(
            collection(db, "devices"),
            where("areaId", "==", areaId),
            where(field, "==", value),
          ),
        );

      if (normalizedSerial) {
        const snap = await sameAreaQuery("serialNumber", normalizedSerial);
        if (!snap.empty) {
          throw new Error(
            `Serial "${normalizedSerial}" đã được dùng cho thiết bị ${snap.docs[0].id}.`
          );
        }
      }

      if (normalizedIp) {
        const snap = await sameAreaQuery("ipAddress", normalizedIp);
        if (!snap.empty) {
          throw new Error(
            `Địa chỉ IP ${normalizedIp} đã được dùng cho thiết bị ${snap.docs[0].id}.`
          );
        }
      }

      // Cùng mã vật tư tại cùng vị trí là hợp lệ (nhiều cái giống nhau),
      // nhưng hỏi lại để tránh bấm lưu hai lần.
      if (normalizedMaterial) {
        const snap = await sameAreaQuery("materialCode", normalizedMaterial);
        const sameSpot = snap.docs.filter(
          (item) =>
            item.data().isActive !== false &&
            String(item.data().subAreaId || "") === subAreaId &&
            String(item.data().locationCode || "") === normalizedLocation,
        );

        if (sameSpot.length > 0) {
          const confirmed = await showAppConfirm(
            `Đã có ${sameSpot.length} thiết bị cùng mã vật tư tại vị trí này. ` +
            `Vẫn thêm ${count} thiết bị nữa?`,
            { confirmLabel: "Vẫn thêm" },
          );
          if (!confirmed) return;
        }
      }

      // ----- Tạo thiết bị: mã tự sinh bằng bộ đếm trong transaction -----
      const areaRef = doc(db, "areas", areaId);
      const subAreaRef = subAreaId ? doc(db, "subAreas", subAreaId) : null;
      const categoryRef = doc(db, "deviceCategories", categoryId);
      const typeRef = doc(db, "deviceTypes", deviceTypeId);
      const counterRef = doc(db, "counters", "devices");

      await runTransaction(db, async (transaction) => {
        const [areaSnap, categorySnap, typeSnap, subAreaSnap, counterSnap] =
          await Promise.all([
            transaction.get(areaRef),
            transaction.get(categoryRef),
            transaction.get(typeRef),
            subAreaRef ? transaction.get(subAreaRef) : Promise.resolve(null),
            transaction.get(counterRef),
          ]);

        if (!areaSnap.exists()) {
          throw new Error("Khu vực không tồn tại.");
        }

        if (areaSnap.data().status === "INACTIVE") {
          throw new Error("Khu vực đã ngừng sử dụng.");
        }
        if (subAreaId && (!subAreaSnap?.exists() || subAreaSnap.data().factoryId !== areaId || subAreaSnap.data().status === "INACTIVE")) {
          throw new Error("Khu vực con không hợp lệ hoặc không thuộc nhà máy đã chọn.");
        }

        if (
          !categorySnap.exists() ||
          categorySnap.data().status !== "ACTIVE"
        ) {
          throw new Error("Lĩnh vực không còn hoạt động.");
        }

        if (
          !typeSnap.exists() ||
          typeSnap.data().isActive === false ||
          typeSnap.data().categoryId !== categoryId
        ) {
          throw new Error(
            "Loại thiết bị không hợp lệ hoặc đã ngừng sử dụng."
          );
        }

        const firstSequence = counterSnap.exists()
          ? Number(counterSnap.data().next) || 1
          : 1;

        const newRefs = Array.from({ length: count }, (_, index) =>
          doc(db, "devices", formatDeviceCode(firstSequence + index)),
        );

        // Phòng trường hợp mã tự sinh đã bị dùng (vd. nhập tay trước đây).
        const existingSnaps = await Promise.all(
          newRefs.map((ref) => transaction.get(ref)),
        );
        if (existingSnaps.some((snap) => snap.exists())) {
          throw new Error("Mã tự sinh đã tồn tại. Vui lòng liên hệ quản trị.");
        }

        transaction.set(counterRef, {
          next: firstSequence + count,
          updatedAt: serverTimestamp(),
        });

        newRefs.forEach((ref) => {
          transaction.set(ref, {
            code: ref.id,
            materialCode: normalizedMaterial,
            locationCode: normalizedLocation,
            name: normalizedName,

            areaId,
            ...(subAreaId ? { subAreaId } : {}),
            deviceTypeId,

            manufacturer: manufacturer.trim(),
            model: model.trim(),
            serialNumber: normalizedSerial,

            ipAddress: normalizedIp,
            macAddress: normalizedMac,

            status,
            description: description.trim(),

            isActive: true,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        });
      });

      invalidateAppCollection("devices");

      navigate("/devices");
    } catch (err) {
      console.error("Lỗi lưu thiết bị:", err);

      setError(
        err instanceof Error
          ? err.message
          : "Không thể lưu thiết bị."
      );
    } finally {
      setSaving(false);
    }
  }

  // ====================================================
  // 8. GIAO DIỆN
  // ====================================================

  return (
    <main className="add-device-page">
      <div className="page-header">
        <div>
          <h1>Thêm thiết bị</h1>
          <p className="page-subtitle">
            Thêm thiết bị mới vào hệ thống quản lý
          </p>
        </div>
      </div>

      <form className="device-form" onSubmit={handleSubmit}>
        {error && (
          <div className="error-message">{error}</div>
        )}

        {typeMessage && (
          <div
            style={{
              padding: 12,
              marginBottom: 16,
              borderRadius: 8,
              background: "#dcfce7",
              color: "#166534",
            }}
          >
            {typeMessage}
          </div>
        )}

        <div className="form-grid">
          

          {/* KHU VỰC */}
          <label>
            Nhà máy *
            <select
              value={areaId}
              onChange={(e) => {
                setAreaId(e.target.value);
                setSubAreaId("");
                setDeviceTypeId("");
              }}
              disabled={loadingMasterData}
              required
            >
              <option value="">-- Chọn nhà máy --</option>

              {areas.map((area) => (
                <option key={area.id} value={area.id}>
                  {area.code} - {area.name}
                </option>
              ))}
            </select>

            {!loadingMasterData && areas.length === 0 && (
              <small className="form-warning-text">
                Không có nhà máy đang hoạt động.
              </small>
            )}
          </label>

          <label>
            Khu vực
            <select value={subAreaId} onChange={(e) => setSubAreaId(e.target.value)} disabled={!areaId || loadingMasterData}>
              <option value="">-- Chưa xác định --</option>
              {subAreas.filter((item) => item.factoryId === areaId && item.status !== "INACTIVE").map((item) => (
                <option key={item.id} value={item.id}>{item.code} - {item.name}</option>
              ))}
            </select>
          </label>
          {/* MÃ VẬT TƯ (có thể trùng giữa nhiều thiết bị) */}
          <label>
            Mã vật tư
            <input
              value={materialCode}
              onChange={(e) =>
                setMaterialCode(e.target.value.toUpperCase())
              }
              placeholder="VD: 1060080701333"
            />
            <small>Mã thiết bị/QR do hệ thống tự cấp (TB-xxxxxx).</small>
          </label>

          {/* MÃ VỊ TRÍ */}
          <label>
            Mã vị trí
            <input
              value={locationCode}
              onChange={(e) =>
                setLocationCode(e.target.value.toUpperCase())
              }
              placeholder="VD: 1-06-LC1-1"
            />
          </label>

          {/* SỐ LƯỢNG */}
          <label>
            Số lượng
            <input
              type="number"
              min={1}
              max={MAX_QUANTITY}
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
            />
          </label>

          {/* TÊN THIẾT BỊ */}
          <label>
            Tên thiết bị *
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Tên thiết bị"
              required
            />
          </label>
          {/* LĨNH VỰC */}
          <label>
            Lĩnh vực *
            <select
              value={categoryId}
              onChange={(e) =>
                handleCategoryChange(e.target.value)
              }
              disabled={loadingMasterData}
              required
            >
              <option value="">-- Chọn lĩnh vực --</option>

              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </label>

          {/* LOẠI THIẾT BỊ */}
          <label>
            Loại thiết bị *
            <select
              value={deviceTypeId}
              onChange={(e) =>
                setDeviceTypeId(e.target.value)
              }
              disabled={
                loadingMasterData ||
                !categoryId ||
                showNewType
              }
              required
            >
              <option value="">
                -- Chọn loại thiết bị --
              </option>

              {filteredTypes.map((type) => (
                <option key={type.id} value={type.id}>
                  {type.name}
                </option>
              ))}
            </select>
          </label>

          {/* THÊM LOẠI MỚI
          <div
            style={{
              display: "flex",
              alignItems: "flex-end",
            }}
          >
            {isAdmin(appUser) && <button
              type="button"
              className="secondary-button"
              disabled={
                !categoryId ||
                loadingMasterData ||
                saving ||
                addingType
              }
              onClick={() => {
                setShowNewType((previous) => !previous);
                setError("");
              }}
            >
              {showNewType
                ? "Hủy thêm loại mới"
                : "+ Thêm loại thiết bị mới"}
            </button>}
          </div> */}

          {/* HÃNG SẢN XUẤT */}
          <label>
            Hãng sản xuất
            <input
              value={manufacturer}
              onChange={(e) =>
                setManufacturer(e.target.value)
              }
              placeholder="VD: Dell, Siemens, Hikvision"
            />
          </label>

          {/* MODEL */}
          <label>
            Model
            <input
              value={model}
              onChange={(e) => setModel(e.target.value)}
            />
          </label>

          {/* SERIAL */}
          <label>
            Serial Number
            <input
              value={serialNumber}
              onChange={(e) =>
                setSerialNumber(e.target.value)
              }
            />
          </label>

          {/* IP */}
          <label>
            Địa chỉ IP
            <input
              value={ipAddress}
              onChange={(e) =>
                setIpAddress(e.target.value)
              }
              placeholder="10.192.x.x"
            />
          </label>

          {/* MAC */}
          <label>
            MAC Address
            <input
              value={macAddress}
              onChange={(e) =>
                setMacAddress(e.target.value)
              }
              placeholder="AA:BB:CC:DD:EE:FF"
            />
          </label>

          {/* TRẠNG THÁI */}
          <label>
            Trạng thái
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              <option value="ACTIVE">Hoạt động</option>
              <option value="WARNING">Cảnh báo</option>
              <option value="OFFLINE">Mất kết nối</option>
              <option value="MAINTENANCE">Bảo trì</option>
            </select>
          </label>
        </div>

        {/* BIỂU MẪU THÊM LOẠI MỚI */}
        {showNewType && isAdmin(appUser) && (
          <section
            style={{
              marginTop: 20,
              padding: 20,
              background: "#eff6ff",
              border: "1px solid #bfdbfe",
              borderRadius: 10,
            }}
          >
            <h3>Thêm loại thiết bị mới</h3>

            <p>
              Lĩnh vực:{" "}
              <strong>
                {
                  categories.find(
                    (item) => item.id === categoryId
                  )?.name
                }
              </strong>
            </p>

            <label>
              Tên loại thiết bị *
              <input
                value={newTypeName}
                onChange={(e) =>
                  setNewTypeName(e.target.value)
                }
                placeholder="VD: Động cơ điện"
                disabled={addingType}
              />
            </label>

            <label
              style={{
                display: "block",
                marginTop: 12,
              }}
            >
              Mô tả
              <textarea
                value={newTypeDescription}
                onChange={(e) =>
                  setNewTypeDescription(e.target.value)
                }
                rows={2}
                disabled={addingType}
              />
            </label>

            <button
              type="button"
              className="primary-button"
              onClick={handleAddType}
              disabled={addingType || !newTypeName.trim()}
              style={{ marginTop: 12 }}
            >
              {addingType
                ? "Đang thêm..."
                : "Lưu loại thiết bị"}
            </button>
          </section>
        )}

        {/* GHI CHÚ */}
        <label className="full-field">
          Ghi chú
          <textarea
            value={description}
            onChange={(e) =>
              setDescription(e.target.value)
            }
            rows={4}
          />
        </label>

        {/* NÚT THAO TÁC */}
        <div className="form-actions">
          <button
            type="button"
            className="secondary-button"
            disabled={saving || addingType}
            onClick={() => navigate("/devices")}
          >
            Hủy
          </button>

          <button
            type="submit"
            className="primary-button"
            disabled={
              saving ||
              addingType ||
              showNewType ||
              loadingMasterData ||
              areas.length === 0 ||
              categories.length === 0
            }
          >
            {saving ? "Đang lưu..." : "Lưu thiết bị"}
          </button>
        </div>
      </form>
    </main>
  );
}