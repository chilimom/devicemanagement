import { useEffect, useState } from "react";
import {
  collection,
  doc,
  getDocs,
  query,
  serverTimestamp,
  updateDoc,
  where,
} from "firebase/firestore";
import { useNavigate } from "react-router-dom";

import { db } from "../config/firebase";
import PaginationControls, { DEFAULT_PAGE_SIZE } from "../components/PaginationControls";
import ActionIconButton from "../components/ActionIconButton";
import { isAdmin, isManager, type AppUser } from "../types/user";
import { showAppAlert, showAppConfirm } from "../services/appDialog";

const FIRESTORE_IN_LIMIT = 30;

interface FirestoreTimestamp {
  toDate(): Date;
  toMillis(): number;
}

function chunkIds(ids: string[]): string[][] {
  const chunks: string[][] = [];
  for (let index = 0; index < ids.length; index += FIRESTORE_IN_LIMIT) {
    chunks.push(ids.slice(index, index + FIRESTORE_IN_LIMIT));
  }
  return chunks;
}

async function getDocumentsByField(
  collectionName: string,
  fieldName: string,
  values: string[],
) {
  const snapshots = await Promise.all(
    chunkIds(values).map((valuesChunk) =>
      getDocs(
        query(
          collection(db, collectionName),
          where(fieldName, "in", valuesChunk),
        ),
      ),
    ),
  );
  return snapshots.flatMap((snapshot) => snapshot.docs);
}

async function getDocumentsForDevices(
  collectionName: string,
  deviceIds: string[],
) {
  const snapshots = await Promise.all(
    [...new Set(deviceIds)].map((deviceId) =>
      getDocs(
        query(
          collection(db, collectionName),
          where("deviceId", "==", deviceId),
        ),
      ),
    ),
  );

  const documentsById = new Map<string, (typeof snapshots)[number]["docs"][number]>();
  for (const snapshot of snapshots) {
    for (const document of snapshot.docs) {
      documentsById.set(document.id, document);
    }
  }

  return [...documentsById.values()];
}

interface Maintenance {
  id: string;
  deviceId?: string;
  deviceCode?: string;
  deviceName?: string;

  title?: string;
  description?: string;

  maintenanceType?: string;

  performedBy?: string;
  performedAt?: FirestoreTimestamp;

  result?: string;
  status?: string;
  approvedAt?: FirestoreTimestamp;
  inspectionSource?: { recordId?: string; taskId?: string; criterionId?: string };

  createdAt?: FirestoreTimestamp;
}

interface MaintenancesProps {
  appUser: AppUser;
}

export default function Maintenances({ appUser }: MaintenancesProps) {
  const navigate = useNavigate();
  const isAdminUser = isAdmin(appUser);
  const canApproveMaintenance = isManager(appUser);

  const [maintenances, setMaintenances] = useState<Maintenance[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("ALL");
  const [currentPage, setCurrentPage] = useState(1);
  const [approvingId, setApprovingId] = useState("");

  async function approveMaintenance(maintenance: Maintenance) {
    if (!canApproveMaintenance || maintenance.status !== "PENDING_APPROVAL") return;
    if (!await showAppConfirm("Xác nhận kết quả bảo trì này và hoàn tất xử lý?", { confirmLabel: "Xác nhận" })) return;
    try {
      setApprovingId(maintenance.id);
      await updateDoc(doc(db, "maintenances", maintenance.id), {
        status: "COMPLETED",
        approvedByUid: appUser.uid,
        approvedAt: serverTimestamp(),
      });
      setMaintenances((current) => current.map((item) => item.id === maintenance.id
        ? { ...item, status: "COMPLETED" }
        : item));
      if (maintenance.inspectionSource?.recordId) {
        await showAppAlert("Đã xác nhận kết quả bảo trì. Tiêu chí tuần kiểm được hoàn tất, không cần kiểm tra bổ sung.", { tone: "success" });
      }
    } catch (approveError) {
      console.error(approveError);
      await showAppAlert("Không thể xác nhận kết quả bảo trì.", { tone: "error" });
    } finally {
      setApprovingId("");
    }
  }

  useEffect(() => {
    let cancelled = false;

    async function loadMaintenances() {
      try {
        setLoading(true);
        setError("");

        if (!isAdminUser && appUser.areaIds.length === 0) {
          if (!cancelled) {
            setMaintenances([]);
          }
          return;
        }

        const deviceDocuments = isAdminUser
          ? []
          : await getDocumentsByField(
              "devices",
              "areaId",
              appUser.areaIds,
            );
        if (cancelled) {
          return;
        }

        const deviceIds = deviceDocuments.map((device) => device.id);
        const maintenanceDocuments = isAdminUser
          ? await getDocs(collection(db, "maintenances")).then(
              (snapshot) => snapshot.docs,
            )
          : deviceIds.length === 0
            ? []
            : await getDocumentsForDevices(
                "maintenances",
                deviceIds,
              );

        if (cancelled) {
          return;
        }

        const data: Maintenance[] = maintenanceDocuments.map((item) => ({
          id: item.id,
          ...item.data(),
        }));

        // Bảo trì mới nhất hiển thị trước
        data.sort((a, b) => {
          const timeA =
            a.performedAt?.toMillis?.() ??
            a.createdAt?.toMillis?.() ??
            0;

          const timeB =
            b.performedAt?.toMillis?.() ??
            b.createdAt?.toMillis?.() ??
            0;

          return timeB - timeA;
        });

        setMaintenances(data);
      } catch (err) {
        console.error(err);
        if (!cancelled) {
          setError("Không thể tải danh sách bảo trì.");
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    void loadMaintenances();

    return () => {
      cancelled = true;
    };
  }, [appUser.areaIds, isAdminUser]);

  // ===== KPI =====

  const totalMaintenances = maintenances.length;

  const preventiveCount = maintenances.filter(
    (item) => item.maintenanceType === "PREVENTIVE"
  ).length;

  const correctiveCount = maintenances.filter(
    (item) => item.maintenanceType === "CORRECTIVE"
  ).length;

  const replacementCount = maintenances.filter(
    (item) => item.maintenanceType === "REPLACEMENT"
  ).length;

  // ===== FILTER =====

  const filteredMaintenances = maintenances.filter((item) => {
    const keyword = search.trim().toLowerCase();

    const matchSearch =
      !keyword ||
      item.deviceCode?.toLowerCase().includes(keyword) ||
      item.deviceName?.toLowerCase().includes(keyword) ||
      item.title?.toLowerCase().includes(keyword) ||
      item.description?.toLowerCase().includes(keyword) ||
      item.performedBy?.toLowerCase().includes(keyword);

    const matchType =
      typeFilter === "ALL" ||
      item.maintenanceType === typeFilter;

    return matchSearch && matchType;
  });
  const totalMaintenancePages = Math.max(1, Math.ceil(filteredMaintenances.length / DEFAULT_PAGE_SIZE));
  const safeMaintenancePage = Math.min(currentPage, totalMaintenancePages);
  const paginatedMaintenances = filteredMaintenances.slice(
    (safeMaintenancePage - 1) * DEFAULT_PAGE_SIZE,
    safeMaintenancePage * DEFAULT_PAGE_SIZE,
  );

  function getMaintenanceTypeLabel(type?: string) {
    switch (type) {
      case "PREVENTIVE":
        return "Bảo trì định kỳ";

      case "CORRECTIVE":
        return "Sửa chữa";

      case "REPLACEMENT":
        return "Thay thế";

      default:
        return type || "-";
    }
  }

  function formatDate(timestamp?: FirestoreTimestamp | null) {
    if (!timestamp?.toDate) {
      return "-";
    }

    return timestamp.toDate().toLocaleString("vi-VN");
  }

  if (loading) {
    return <p>Đang tải danh sách bảo trì...</p>;
  }

  return (
    <>
      {/* HEADER */}

      <div className="page-header">
        <div>
          <h1>Quản lý bảo trì</h1>

          <p className="page-subtitle">
            Theo dõi lịch sử bảo trì, sửa chữa và thay thế thiết bị
          </p>
        </div>
      
      
                {appUser?.isActive === true &&
                  (appUser.role === "ADMIN" || appUser.role === "AREA_ADMIN") && (
                <div className="device-header-actions">
                  <ActionIconButton
                    icon="add"
                    label="Thêm loại bảo trì"
                    variant="primary"
                    type="button"
                    onClick={() => navigate("/maintenance/types/new")}
                  />
                </div>
                )}
                </div>
                
      {/* KPI */}

      <div className="maintenance-kpi-grid">
        <div className="maintenance-kpi-card">
          <span>Tổng lượt bảo trì</span>
          <strong>{totalMaintenances}</strong>
        </div>

        <div className="maintenance-kpi-card kpi-preventive">
          <span>Bảo trì định kỳ</span>
          <strong>{preventiveCount}</strong>
        </div>

        <div className="maintenance-kpi-card kpi-corrective">
          <span>Sửa chữa</span>
          <strong>{correctiveCount}</strong>
        </div>

        <div className="maintenance-kpi-card kpi-replacement">
          <span>Thay thế</span>
          <strong>{replacementCount}</strong>
        </div>
      </div>

      {/* FILTER */}

      <div className="maintenance-filters">
        <input
          type="text"
          placeholder="Tìm mã thiết bị, nội dung, người thực hiện..."
          value={search}
          onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
        />

        <select
          value={typeFilter}
          onChange={(e) => { setTypeFilter(e.target.value); setCurrentPage(1); }}
        >
          <option value="ALL">Tất cả loại bảo trì</option>
          <option value="PREVENTIVE">Bảo trì định kỳ</option>
          <option value="CORRECTIVE">Sửa chữa</option>
          <option value="REPLACEMENT">Thay thế</option>
        </select>
      </div>

      {error && (
        <div className="form-error">
          {error}
        </div>
      )}

      {/* TABLE */}

      <section className="panel">
        {filteredMaintenances.length === 0 ? (
          <div className="empty-history">
            Không có dữ liệu bảo trì phù hợp.
          </div>
        ) : (
          <div className="table-wrapper">
            <table className="device-table table-cards">
              <thead>
                <tr>
                  <th>Thiết bị</th>
                  <th>Nội dung bảo trì</th>
                  <th>Loại</th>
                  <th>Người thực hiện</th>
                  <th>Thời gian</th>
                  <th>Kết quả</th>
                  <th>Thao tác</th>
                </tr>
              </thead>

              <tbody>
                {paginatedMaintenances.map((maintenance) => (
                  <tr key={maintenance.id}>
                    <td>
                      <strong>
                        {maintenance.deviceCode || "-"}
                      </strong>

                      <div>
                        {maintenance.deviceName || ""}
                      </div>
                    </td>

                    <td data-label="Nội dung">
                      <div className="cell-stack">
                        <strong>
                          {maintenance.title || "-"}
                        </strong>

                        {maintenance.description && (
                          <div>
                            {maintenance.description}
                          </div>
                        )}
                      </div>
                    </td>

                    <td data-label="Loại">
                      {getMaintenanceTypeLabel(
                        maintenance.maintenanceType
                      )}
                    </td>

                    <td data-label="Người thực hiện">
                      {maintenance.performedBy || "-"}
                    </td>

                    <td data-label="Thời gian">
                      {formatDate(maintenance.performedAt)}
                    </td>

                    <td data-label="Kết quả">
                      <div className="cell-stack">
                        {maintenance.result || "-"}
                        {maintenance.status === "PENDING_APPROVAL" && <div className="maintenance-approval-status">Chờ quản lý khu vực xác nhận</div>}
                        {maintenance.status === "COMPLETED" && <div className="maintenance-approval-complete">Đã xác nhận</div>}
                      </div>
                    </td>

                    <td className="cell-actions">
                      {canApproveMaintenance && maintenance.status === "PENDING_APPROVAL" && (
                        <button type="button" className="btn-primary" disabled={approvingId === maintenance.id} onClick={() => void approveMaintenance(maintenance)}>
                          {approvingId === maintenance.id ? "Đang xác nhận..." : "Xác nhận"}
                        </button>
                      )}
                      <ActionIconButton
                        icon="view" label={`Xem thiết bị ${maintenance.deviceCode || maintenance.deviceId || ""}`}
                        onClick={() =>
                          navigate(
                            `/devices/${maintenance.deviceId}`
                          )
                        }
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <PaginationControls currentPage={safeMaintenancePage} totalItems={filteredMaintenances.length} onPageChange={setCurrentPage} />
          </div>
        )}
      </section>
    </>
  );
}