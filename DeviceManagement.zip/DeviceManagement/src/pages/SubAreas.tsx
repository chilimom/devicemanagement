import { useEffect, useState, type FormEvent } from "react";
import { addDoc, collection, doc, getDoc, getDocs, query, runTransaction, serverTimestamp, updateDoc, where } from "firebase/firestore";
import { useParams } from "react-router-dom";
import { db } from "../config/firebase";
import { invalidateAppCollection } from "../services/sharedCollectionCache";
import { isAdmin, type AppUser } from "../types/user";
import "../styles/sub-areas.css";

interface SubArea { id: string; factoryId: string; code: string; name: string; description?: string; status?: string }

function ActionIcon({ kind }: { kind: "edit" | "disable" | "enable" }) {
  if (kind === "edit") return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"/></svg>;
  if (kind === "enable") return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4L19 6"/><path d="M21 12a9 9 0 1 1-3-6.7"/></svg>;
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h18"/><path d="M8 6V4h8v2m3 0-1 14H6L5 6"/><path d="M10 11v5m4-5v5"/></svg>;
}

export default function SubAreas({ appUser }: { appUser: AppUser }) {
  const { areaId = "" } = useParams<{ areaId: string }>();
  const [factory, setFactory] = useState<{code?: string; name?: string} | null>(null);
  const [items, setItems] = useState<SubArea[]>([]);
  const [editing, setEditing] = useState("");
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const [factorySnap, subAreaSnap] = await Promise.all([
        getDoc(doc(db, "areas", areaId)),
        getDocs(query(collection(db, "subAreas"), where("factoryId", "==", areaId))),
      ]);
      if (!factorySnap.exists() || (!isAdmin(appUser) && !appUser.areaIds.includes(areaId))) throw new Error("Bạn không có quyền quản lý nhà máy này.");
      const data = factorySnap.data(); setFactory({ code: String(data.code || ""), name: String(data.name || "") });
      setItems(subAreaSnap.docs.map((item) => ({ id: item.id, ...(item.data() as Omit<SubArea, "id">) })).sort((a,b) => a.code.localeCompare(b.code)));
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Không thể tải danh mục khu vực con."); }
    finally { setLoading(false); }
  }

  useEffect(() => {
    let cancelled = false;
    async function loadForRoute() {
      try {
        const [factorySnap, subAreaSnap] = await Promise.all([
          getDoc(doc(db, "areas", areaId)),
          getDocs(query(collection(db, "subAreas"), where("factoryId", "==", areaId))),
        ]);
        if (!factorySnap.exists() || (!isAdmin(appUser) && !appUser.areaIds.includes(areaId))) throw new Error("Bạn không có quyền quản lý nhà máy này.");
        const data = factorySnap.data();
        if (cancelled) return;
        setFactory({ code: String(data.code || ""), name: String(data.name || "") });
        setItems(subAreaSnap.docs.map((item) => ({ id: item.id, ...(item.data() as Omit<SubArea, "id">) })).sort((a,b) => a.code.localeCompare(b.code)));
      } catch (cause) { if (!cancelled) setError(cause instanceof Error ? cause.message : "Không thể tải danh mục khu vực con."); }
      finally { if (!cancelled) setLoading(false); }
    }
    void loadForRoute();
    return () => { cancelled = true; };
  }, [areaId, appUser]);

  function beginEdit(item?: SubArea) {
    setEditing(item?.id || ""); setCode(item?.code || ""); setName(item?.name || ""); setDescription(item?.description || ""); setError("");
  }

  async function save(event: FormEvent) {
    event.preventDefault(); setError("");
    const normalizedCode = code.trim().toUpperCase(); const normalizedName = name.trim();
    if (!normalizedCode || !normalizedName) { setError("Cần nhập mã và tên khu vực con."); return; }
    if (items.some((item) => item.id !== editing && item.code.trim().toLowerCase() === normalizedCode.toLowerCase())) { setError("Mã khu vực con đã tồn tại trong nhà máy."); return; }
    try {
      if (editing) await updateDoc(doc(db, "subAreas", editing), { code: normalizedCode, name: normalizedName, description: description.trim(), updatedAt: serverTimestamp() });
      else await addDoc(collection(db, "subAreas"), { factoryId: areaId, code: normalizedCode, name: normalizedName, description: description.trim(), status: "ACTIVE", createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
      invalidateAppCollection("subAreas"); beginEdit(); await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Không thể lưu khu vực con."); }
  }

  async function toggle(item: SubArea) {
    const nextStatus = item.status === "INACTIVE" ? "ACTIVE" : "INACTIVE";
    try {
      if (nextStatus === "INACTIVE") {
        const devices = await getDocs(query(collection(db, "devices"), where("subAreaId", "==", item.id)));
        if (!devices.empty) throw new Error("Không thể ngừng khu vực con đang được thiết bị sử dụng.");
      }
      await runTransaction(db, async (transaction) => {
        const ref = doc(db, "subAreas", item.id); const current = await transaction.get(ref);
        if (!current.exists() || current.data().factoryId !== areaId) throw new Error("Khu vực con không còn hợp lệ.");
        transaction.update(ref, { status: nextStatus, updatedAt: serverTimestamp() });
      });
      invalidateAppCollection("subAreas"); await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Không thể cập nhật trạng thái."); }
  }

  if (loading) return <p>Đang tải khu vực con...</p>;
  return <main className="sub-areas-page">
    <header className="sub-areas-heading"><h1>Khu vực con</h1><p>{factory?.code} <span aria-hidden="true">·</span> {factory?.name}</p></header>
    {error && <div className="error-message" role="alert">{error}</div>}
    <form className="sub-areas-form" onSubmit={save}>
      <h2>{editing ? "Sửa khu vực con" : "Thêm khu vực con"}</h2>
      <div className="sub-areas-fields">
        <label>Mã khu vực con *<input value={code} onChange={(e) => setCode(e.target.value)} required /></label>
        <label>Tên khu vực con *<input value={name} onChange={(e) => setName(e.target.value)} required /></label>
        <label className="sub-areas-description">Mô tả<input value={description} onChange={(e) => setDescription(e.target.value)} /></label>
      </div>
      <div className="sub-areas-form-actions"><button className="primary-button" type="submit">{editing ? "Lưu thay đổi" : "Thêm khu vực con"}</button>{editing && <button type="button" className="secondary-button" onClick={() => beginEdit()}>Hủy</button>}</div>
    </form>
    <section className="sub-areas-list panel" aria-label="Danh sách khu vực con">
      <div className="sub-areas-list-heading"><h2>Danh sách khu vực con</h2><span>{items.length}</span></div>
      {items.length === 0 ? <p className="sub-areas-empty">Chưa có khu vực con.</p> : <div className="sub-areas-table-wrap"><table><thead><tr><th>Mã</th><th>Tên</th><th>Trạng thái</th><th className="sub-areas-action-heading">Thao tác</th></tr></thead><tbody>
        {items.map((item) => <tr key={item.id}><td className="sub-areas-code">{item.code}</td><td><strong>{item.name}</strong>{item.description ? <small>{item.description}</small> : null}</td><td><span className={`sub-areas-status ${item.status === "INACTIVE" ? "is-inactive" : "is-active"}`}>{item.status === "INACTIVE" ? "Ngừng sử dụng" : "Hoạt động"}</span></td><td><div className="sub-areas-row-actions"><button type="button" className="sub-areas-icon-button" onClick={() => beginEdit(item)} aria-label={`Sửa ${item.name}`} title="Sửa"><ActionIcon kind="edit" /></button><button type="button" className="sub-areas-icon-button" onClick={() => void toggle(item)} aria-label={`${item.status === "INACTIVE" ? "Kích hoạt" : "Ngừng sử dụng"} ${item.name}`} title={item.status === "INACTIVE" ? "Kích hoạt" : "Ngừng sử dụng"}><ActionIcon kind={item.status === "INACTIVE" ? "enable" : "disable"} /></button></div></td></tr>)}
      </tbody></table></div>}
    </section>
  </main>;
}
