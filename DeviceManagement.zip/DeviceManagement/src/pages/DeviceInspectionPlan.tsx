
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { doc, getDoc } from "firebase/firestore";

import { db } from "../config/firebase";
import { showAppAlert } from "../services/appDialog";
import ActionIconButton from "../components/ActionIconButton";
import {
  getInspectionTemplates,
} from "../services/inspectionService";

import {
  createDeviceInspectionPlan,
  getDeviceInspectionPlan,
  updateDeviceInspectionPlan,
} from "../services/deviceInspectionPlanService";

import type {
  DeviceInspectionPlan,
  InspectionTask,
  InspectionTemplate,
} from "../types/inspection";
import type { AppUser } from "../types/user";
import { canAccessArea, isAdmin, isAreaAdmin } from "../types/user";

import "../styles/inspection-template-form.css";

const WEEKDAYS = [
  { value: 1, label: "T2" },
  { value: 2, label: "T3" },
  { value: 3, label: "T4" },
  { value: 4, label: "T5" },
  { value: 5, label: "T6" },
  { value: 6, label: "T7" },
  { value: 7, label: "CN" },
];

interface DeviceInfo {
  id: string;
  code?: string;
  name?: string;
  isActive?: boolean;
  areaId?: string;
}

export default function DeviceInspectionPlan({ appUser }: { appUser: AppUser }) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [device, setDevice] = useState<DeviceInfo | null>(null);
  const [templates, setTemplates] = useState<InspectionTemplate[]>([]);
  const [existingPlan, setExistingPlan] =
    useState<DeviceInspectionPlan | null>(null);

  const [selectedTemplateId, setSelectedTemplateId] = useState("");
  const [planName, setPlanName] = useState("");
  const [tasks, setTasks] = useState<InspectionTask[]>([]);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editingPlan, setEditingPlan] = useState(false);
  const [error, setError] = useState("");
  const [saveError, setSaveError] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function loadData() {
      if (!id) {
        setError("Không xác định được ID thiết bị.");
        setLoading(false);
        return;
      }

      setLoading(true);
      setError("");

      try {
        const deviceSnapshot = await getDoc(
          doc(db, "devices", id)
        );

        if (!deviceSnapshot.exists()) {
          throw new Error("Không tìm thấy thiết bị.");
        }

        const deviceData = deviceSnapshot.data();

        const [templateData, planData] = await Promise.all([
          getInspectionTemplates(appUser),
          getDeviceInspectionPlan(id),
        ]);

        if (cancelled) return;

        setDevice({
          id: deviceSnapshot.id,
          code: deviceData.code,
          name: deviceData.name,
          isActive: deviceData.isActive,
          areaId: deviceData.areaId,
        });

        setTemplates(templateData.filter((item) =>
          item.isActive &&
          Array.isArray(item.areaIds) &&
          typeof deviceData.areaId === "string" &&
          item.areaIds.includes(deviceData.areaId)
        ));
        setExistingPlan(planData);
        setEditingPlan(false);

        if (planData) {
          setPlanName(planData.name);
          setTasks(planData.tasks);
          setSelectedTemplateId(planData.templateId ?? "");
        }
      } catch (err: unknown) {
        if (cancelled) return;

        setError(
          err instanceof Error
            ? err.message
            : "Không thể tải dữ liệu."
        );
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    void loadData();

    return () => {
      cancelled = true;
    };
  }, [appUser, id]);

  const selectTemplate = (templateId: string) => {
    setSelectedTemplateId(templateId);
    setSaveError("");

    const template = templates.find(
      (item) => item.id === templateId
    );

    if (!template) {
      setPlanName("");
      setTasks([]);
      return;
    }

    setPlanName(template.name);

    // Sao chép sâu để không chỉnh sửa dữ liệu mẫu gốc.
    setTasks(
      template.tasks.map((task) => ({
        ...task,
        weekdays: [...task.weekdays],
        criteria: task.criteria.map((criterion) => ({
          ...criterion,
        })),
      }))
    );
  };

  const toggleWeekday = (taskId: string, day: number) => {
    setTasks((current) =>
      current.map((task) => {
        if (task.id !== taskId) return task;

        const weekdays = task.weekdays.includes(day)
          ? task.weekdays.filter((value) => value !== day)
          : [...task.weekdays, day];

        return {
          ...task,
          weekdays: weekdays.sort((a, b) => a - b),
        };
      })
    );
  };

  const handleSave = async () => {
    if (saving || !id || !device || (existingPlan && !editingPlan)) return;

    if (device.isActive === false && !existingPlan) {
      setSaveError(
        "Thiết bị đang ngừng hoạt động, không thể gán kế hoạch."
      );
      return;
    }

    if (!existingPlan && !selectedTemplateId) {
      setSaveError("Vui lòng chọn mẫu tuần kiểm.");
      return;
    }

    if (!planName.trim()) {
      setSaveError("Vui lòng nhập tên kế hoạch.");
      return;
    }

    setSaving(true);
    setSaveError("");

    try {
      if (existingPlan) {
        if (!canEditPlan) throw new Error("Bạn không có quyền sửa lịch khu vực này.");
        const version = await updateDeviceInspectionPlan({
          deviceId: id,
          expectedVersion: existingPlan.version,
          name: planName,
          tasks,
        });
        setExistingPlan({ ...existingPlan, name: planName.trim(), tasks, version });
        setEditingPlan(false);
        await showAppAlert("Đã cập nhật lịch tuần kiểm!", { tone: "success" });
        return;
      }

      await createDeviceInspectionPlan({
        deviceId: id,
        templateId: selectedTemplateId,
        name: planName.trim(),
        tasks,
        isActive: true,
      });
      await showAppAlert("Đã gán kế hoạch tuần kiểm thành công!", { tone: "success" });

      navigate(`/devices/${id}`);
    } catch (err: unknown) {
      console.error("Lỗi lưu kế hoạch:", err);

      setSaveError(
        err instanceof Error
          ? err.message
          : "Không thể lưu kế hoạch tuần kiểm."
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <p>Đang tải thông tin thiết bị và mẫu tuần kiểm...</p>;
  }

  if (error) {
    return (
      <section className="panel">
        <h2>Không thể mở kế hoạch tuần kiểm</h2>
        <p role="alert">{error}</p>
        <button
          type="button"
          className="itf-btn"
          onClick={() => navigate("/devices")}
        >
          Quay về danh sách thiết bị
        </button>
      </section>
    );
  }

  if (!device) return null;

  const canEditPlan = isAdmin(appUser)
    || (isAreaAdmin(appUser) && Boolean(device.areaId) && canAccessArea(appUser, device.areaId ?? ""));

  return (
    <div className="itf-page">
      <header className="itf-header">
        <div>
          <div className="itf-eyebrow">
            QUẢN LÝ THIẾT BỊ / KẾ HOẠCH TUẦN KIỂM
          </div>
          <h1>Kế hoạch tuần kiểm thiết bị</h1>
          <p className="itf-subtitle">
            {device.name || "Chưa có tên"}
            {" · "}
            {device.code || device.id}
          </p>
        </div>

        <ActionIconButton
          icon="back"
          label="Quay lại thiết bị"
          onClick={() => navigate(`/devices/${device.id}`)}
        />
          
        
      </header>

      {device.isActive === false && !existingPlan && (
        <section className="itf-card">
          <p style={{ color: "#b91c1c" }}>
            Thiết bị đang ngừng hoạt động.
            Không thể tạo kế hoạch mới.
          </p>
        </section>
      )}

      {existingPlan && !editingPlan ? (
        <section className="itf-card">
          <div className="itf-plan-heading">
            <h2>Kế hoạch tuần kiểm</h2>
            {canEditPlan && <button type="button" className="itf-edit-button" onClick={() => setEditingPlan(true)}>
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75-10.06 10.06zM20.71 7.21a1 1 0 000-1.42l-2.5-2.5a1 1 0 00-1.42 0l-1.83 1.83 3.75 3.75 2.58 2.09z" /></svg>
              Sửa lịch
            </button>}
          </div>

          <p>
            Tên kế hoạch: <strong>{existingPlan.name}</strong>
          </p>

          <p>
            Phiên bản: <strong>V{existingPlan.version}</strong>
          </p>

          <p>
            Trạng thái:{" "}
            <strong>
              {existingPlan.isActive
                ? "Đang hoạt động"
                : "Ngừng hoạt động"}
            </strong>
          </p>

          <h3>Danh sách công việc</h3>

          {existingPlan.tasks.map((task, index) => (
            <div
              key={task.id}
              className="itf-criterion"
            >
              <strong>
                {index + 1}. {task.name}
              </strong>

              <p>
                Lịch:{" "}
                {task.weekdays
                  .map(
                    (day) =>
                      WEEKDAYS.find(
                        (item) => item.value === day
                      )?.label ?? day
                  )
                  .join(", ")}
              </p>

              <p>
                Số tiêu chuẩn: {task.criteria.length}
              </p>
            </div>
          ))}

          <p className="itf-note">Phiếu tuần kiểm đã lưu sẽ giữ nguyên ảnh chụp kế hoạch tại thời điểm thực hiện.</p>
        </section>
      ) : (
        <>
          <section className="itf-card">
            <h2 className="itf-section-title">
              {existingPlan ? "Chỉnh sửa lịch tuần kiểm" : "Chọn mẫu tuần kiểm"}
            </h2>

            {!existingPlan && <div className="itf-field">
              <label htmlFor="plan-template">
                Mẫu tuần kiểm *
              </label>

              <select
                id="plan-template"
                className="itf-input"
                value={selectedTemplateId}
                disabled={device.isActive === false && !existingPlan}
                onChange={(e) =>
                  selectTemplate(e.target.value)
                }
              >
                <option value="">-- Chọn mẫu --</option>

                {templates.map((template) => (
                  <option
                    key={template.id}
                    value={template.id}
                  >
                    {template.name}
                  </option>
                ))}
              </select>
            </div>}

            {!existingPlan && templates.length === 0 && (
              <p className="itf-note">
                Chưa có mẫu tuần kiểm đang hoạt động.
                Hãy tạo mẫu trước khi gán.
              </p>
            )}

            <div className="itf-field">
              <label htmlFor="plan-name">
                Tên kế hoạch *
              </label>

              <input
                id="plan-name"
                className="itf-input"
                value={planName}
                disabled={device.isActive === false && !existingPlan}
                onChange={(e) =>
                  setPlanName(e.target.value)
                }
                placeholder="Ví dụ: Tuần kiểm động cơ số 1"
              />
            </div>
          </section>

          {tasks.length > 0 && (
            <section className="itf-card">
              <h2 className="itf-section-title">
                Lịch kiểm tra theo công việc
              </h2>

              <p className="itf-note">
                Lịch tại đây chỉ áp dụng cho thiết bị
                này, không thay đổi mẫu gốc.
              </p>

              {tasks.map((task, index) => (
                <div
                  key={task.id}
                  className="itf-criterion"
                  style={{ marginBottom: 16 }}
                >
                  <h3>
                    {index + 1}. {task.name}
                  </h3>

                  {task.description && (
                    <p>{task.description}</p>
                  )}

                  <div className="itf-field">
                    <label>Ngày kiểm tra</label>

                    <div className="itf-weekdays">
                      {WEEKDAYS.map((day) => (
                        <button
                          key={day.value}
                          type="button"
                          className={
                            "itf-day" +
                            (task.weekdays.includes(day.value)
                              ? " active"
                              : "")
                          }
                          disabled={device.isActive === false && !existingPlan}
                          aria-pressed={task.weekdays.includes(
                            day.value
                          )}
                          onClick={() =>
                            toggleWeekday(task.id, day.value)
                          }
                        >
                          {day.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <p>
                    Số tiêu chuẩn đánh giá:{" "}
                    <strong>{task.criteria.length}</strong>
                  </p>
                </div>
              ))}
            </section>
          )}

          {saveError && (
            <p role="alert" style={{ color: "#b91c1c" }}>
              {saveError}
            </p>
          )}

          <div className="itf-actions">
            {existingPlan && <button
              type="button"
              className="itf-btn"
              disabled={saving}
              onClick={() => {
                setEditingPlan(false);
                setPlanName(existingPlan.name);
                setTasks(existingPlan.tasks);
                setSaveError("");
              }}
            >Hủy</button>}
            <button
              type="button"
              className="itf-btn itf-btn-primary"
              disabled={
                saving ||
                (device.isActive === false && !existingPlan) ||
                (!existingPlan && !selectedTemplateId) ||
                (existingPlan !== null && !canEditPlan)
              }
              onClick={() => void handleSave()}
            >
              {saving
                ? "Đang lưu..."
                : existingPlan ? "Lưu thay đổi lịch" : "Lưu kế hoạch cho thiết bị"}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
