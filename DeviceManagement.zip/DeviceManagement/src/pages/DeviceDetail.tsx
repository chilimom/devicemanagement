import { useCallback, useEffect, useRef, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import "../styles/device-detail.css";

import {
  doc,
  getDoc,
  collection,
  getDocs,
  query,
  where,
  updateDoc,
  serverTimestamp,
} from "firebase/firestore";

import { useLocation, useNavigate, useParams } from "react-router-dom";
import { db } from "../config/firebase";
import {
  invalidateAppCollection,
  readAppCollectionCache,
} from "../services/sharedCollectionCache";
import { isPermissionDenied } from "../services/sharedRamCache";
import { canAccessArea, isAdmin, isManager, type AppUser } from "../types/user";
/* Component hiển thị lịch sử sự cố và bảo trì */
import DeviceHistory from "../components/device-history/DeviceHistory";
import ActionIconButton from "../components/ActionIconButton";

interface FirestoreTimestamp {
  toDate(): Date;
  toMillis(): number;
}
/* =========================================================
   INTERFACE
========================================================= */

interface Device {
  id: string;
  code?: string;
  name?: string;
  description?: string;

  areaId?: string;
  subAreaId?: string;
  deviceTypeId?: string;

  manufacturer?: string;
  model?: string;
  serialNumber?: string;

  ipAddress?: string;
  macAddress?: string;

  status?: string;
  isActive?: boolean;

  inactiveReason?: string;
  inactiveAt?: FirestoreTimestamp;

  reactivatedAt?: FirestoreTimestamp;
}

interface Incident {
  id: string;

  deviceId?: string;
  deviceCode?: string;
  deviceName?: string;

  title?: string;
  description?: string;

  severity?: string;
  status?: string;

  reportedAt?: FirestoreTimestamp;
  resolvedAt?: FirestoreTimestamp;
  resolution?: string;
}

/* =========================================================
   LỊCH SỬ KHẮC PHỤC SỰ CỐ

   Dữ liệu lấy từ collection incidentResolutions.
   Chỉ dùng để đọc và hiển thị.
========================================================= */

interface IncidentResolution {
  id: string;
  incidentId: string;
  deviceId: string;
  resolution: string;
  attemptNumber: number;
  resolvedByUid: string;
  resolvedByName: string;
  resolvedByEmail: string;
  resolvedAt: FirestoreTimestamp;
  outcome?: "OPEN" | "RESOLVED";
}

interface Maintenance {
  id: string;

  deviceId?: string;
  deviceCode?: string;
  deviceName?: string;

  title?: string;
  description?: string;

  maintenanceType?: string;
  performedBy?: string;
  performedAt?: FirestoreTimestamp;

  result?: string;
  status?: string;

  createdAt?: FirestoreTimestamp;
}

interface MasterItem {
  id: string;
  code?: string;
  name?: string;
  // Dùng cho loại thiết bị, liên kết đến deviceCategories
  categoryId?: string;
}

type HistoryItem =
  | {
      type: "INCIDENT";
      timestamp?: FirestoreTimestamp;
      data: Incident;
    }
  | {
      type: "MAINTENANCE";
      timestamp?: FirestoreTimestamp;
      data: Maintenance;
    };

/* =========================================================
   COMPONENT
========================================================= */

interface DeviceDetailProps {
  appUser: AppUser | null;
}

export default function DeviceDetail({ appUser }: DeviceDetailProps) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const historyOnly = location.pathname.endsWith("/history");
  const isAdminUser = isAdmin(appUser);
  const isManagerUser = isManager(appUser);

  /* =======================================================
     STATE - DỮ LIỆU
  ======================================================= */

  const [device, setDevice] = useState<Device | null>(null);

  const [area, setArea] = useState<MasterItem | null>(null);
  const [subArea, setSubArea] = useState<MasterItem | null>(null);

  const [deviceType, setDeviceType] = useState<MasterItem | null>(null);
  // Lĩnh vực của loại thiết bị hiện tại
  const [deviceCategory, setDeviceCategory] = useState<MasterItem | null>(null);
  const [incidents, setIncidents] = useState<Incident[]>([]);

  const [maintenances, setMaintenances] = useState<Maintenance[]>([]);

/* Lưu danh sách lịch sử khắc phục sự cố */
const [incidentResolutions, setIncidentResolutions] =
  useState<IncidentResolution[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyLoaded, setHistoryLoaded] = useState(false);
  const [historyError, setHistoryError] = useState("");
  const historyRequestIdRef = useRef(0);
  const historyAutoLoadIdRef = useRef<string | null>(null);

  /* =======================================================
     STATE - TRẠNG THÁI TRANG
  ======================================================= */

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [refreshError, setRefreshError] = useState("");

  /* =======================================================
     STATE - NGỪNG SỬ DỤNG
  ======================================================= */

  const [showInactiveForm, setShowInactiveForm] = useState(false);

  const [inactiveReason, setInactiveReason] = useState("");

  const [stopping, setStopping] = useState(false);

  const [inactiveError, setInactiveError] = useState("");

  /* =======================================================
     STATE - ĐƯA VÀO SỬ DỤNG LẠI
  ======================================================= */

  const [showReactivateForm, setShowReactivateForm] = useState(false);

  const [reactivating, setReactivating] = useState(false);

  /* =========================================================
     LOAD DỮ LIỆU
  ========================================================= */

  useEffect(() => {
    let isCurrent = true;

    async function loadDevice() {
      if (!id) {
        setError("Không xác định được thiết bị.");
        setLoading(false);
        return;
      }

      let hasCachedDevice = false;

      try {
        const cachedDevices = appUser
          ? readAppCollectionCache<Device[]>(appUser, "devices").data
          : undefined;
        const cachedDevice = cachedDevices?.find((item) => item.id === id);
        const canUseCachedDevice = Boolean(
          cachedDevice &&
          (isAdminUser || canAccessArea(
            appUser,
            cachedDevice.areaId?.trim() || "",
          )),
        );
        hasCachedDevice = canUseCachedDevice;

        const cachedAreas = appUser
          ? readAppCollectionCache<MasterItem[]>(appUser, "areas").data
          : undefined;
        const cachedTypes = appUser
          ? readAppCollectionCache<MasterItem[]>(appUser, "deviceTypes").data
          : undefined;
        const cachedCategories = appUser
          ? readAppCollectionCache<MasterItem[]>(
              appUser,
              "deviceCategories",
            ).data
          : undefined;
        const cachedType = canUseCachedDevice
          ? cachedTypes?.find(
              (item) => item.id === cachedDevice?.deviceTypeId,
            ) ?? null
          : null;

        setLoading(!canUseCachedDevice);
        setError("");
        setRefreshError("");
        setDevice(canUseCachedDevice ? cachedDevice ?? null : null);
        setArea(canUseCachedDevice
          ? cachedAreas?.find((item) => item.id === cachedDevice?.areaId) ?? null
          : null);
        setDeviceType(cachedType);
        setDeviceCategory(cachedType?.categoryId
          ? cachedCategories?.find(
              (item) => item.id === cachedType.categoryId,
            ) ?? null
          : null);
        setIncidents([]);
        setMaintenances([]);
        setIncidentResolutions([]);
        setHistoryLoading(false);
        setHistoryLoaded(false);
        setHistoryError("");
        historyRequestIdRef.current += 1;

        /* ---------------------------------------------------
           1. ĐỌC THIẾT BỊ
        --------------------------------------------------- */

        const deviceRef = doc(db, "devices", id);
        const deviceSnap = await getDoc(deviceRef);

        if (!isCurrent) {
          return;
        }

        if (!deviceSnap.exists()) {
          setDevice(null);
          setError("Không tìm thấy thiết bị.");
          return;
        }

        const deviceData: Device = {
          id: deviceSnap.id,
          ...deviceSnap.data(),
        };

        if (
          !isAdminUser &&
          !canAccessArea(appUser, deviceData.areaId?.trim() || "")
        ) {
          setDevice(null);
          setError("Bạn không có quyền truy cập thiết bị này.");
          return;
        }

        setDevice(deviceData);
        setLoading(false);

        const readArea = async (): Promise<MasterItem | null> => {
          if (!deviceData.areaId) return null;

          const areaSnap = await getDoc(doc(db, "areas", deviceData.areaId));
          return areaSnap.exists()
            ? { id: areaSnap.id, ...areaSnap.data() }
            : null;
        };
        const readSubArea = async (): Promise<MasterItem | null> => {
          if (!deviceData.subAreaId) return null;
          const snapshot = await getDoc(doc(db, "subAreas", deviceData.subAreaId));
          return snapshot.exists() ? { id: snapshot.id, ...snapshot.data() } : null;
        };

        const readTypeAndCategory = async (): Promise<{
          type: MasterItem | null;
          category: MasterItem | null;
        }> => {
          if (!deviceData.deviceTypeId) {
            return { type: null, category: null };
          }

          const typeSnap = await getDoc(
            doc(db, "deviceTypes", deviceData.deviceTypeId),
          );
          if (!typeSnap.exists()) {
            return { type: null, category: null };
          }

          const typeData: MasterItem = {
            ...typeSnap.data(),
            id: typeSnap.id,
          };
          if (!typeData.categoryId) {
            return { type: typeData, category: null };
          }

          const categorySnap = await getDoc(
            doc(db, "deviceCategories", typeData.categoryId),
          );
          return {
            type: typeData,
            category: categorySnap.exists()
              ? { ...categorySnap.data(), id: categorySnap.id }
              : null,
          };
        };

        try {
          const [areaData, subAreaData, typeData] = await Promise.all([
            readArea(),
            readSubArea(),
            readTypeAndCategory(),
          ]);

          if (!isCurrent) return;

          setArea(areaData);
          setSubArea(subAreaData);
          setDeviceType(typeData.type);
          setDeviceCategory(typeData.category);
        } catch (metadataError) {
          if (!isCurrent) return;

          console.error("Lỗi tải danh mục thiết bị:", metadataError);
        }

      } catch (err) {
        if (!isCurrent) {
          return;
        }

        console.error("Lỗi tải hồ sơ thiết bị:", err);

        if (isPermissionDenied(err)) {
          setDevice(null);
          setError("Bạn không có quyền tải hồ sơ thiết bị này.");
        } else if (hasCachedDevice) {
          setRefreshError(
            "Không thể làm mới hồ sơ. Đang hiển thị dữ liệu gần nhất.",
          );
        } else {
          setError("Không thể tải hồ sơ thiết bị.");
        }
      } finally {
        if (isCurrent) {
          setLoading(false);
        }
      }
    }

    loadDevice();

    return () => {
      isCurrent = false;
      historyRequestIdRef.current += 1;
    };
  }, [appUser, id, isAdminUser]);

  const loadHistory = useCallback(async () => {
    if (!device || historyLoading || historyLoaded) return;

    const targetDevice = device;
    const requestId = historyRequestIdRef.current + 1;
    historyRequestIdRef.current = requestId;
    setHistoryLoading(true);
    setHistoryError("");

    try {
      const incidentQueries = [
        getDocs(
          query(
            collection(db, "incidents"),
            where("deviceId", "==", targetDevice.id),
          ),
        ),
      ];
      const maintenanceQueries = [
        getDocs(
          query(
            collection(db, "maintenances"),
            where("deviceId", "==", targetDevice.id),
          ),
        ),
      ];

      if (isAdminUser && targetDevice.code) {
        incidentQueries.push(
          getDocs(
            query(
              collection(db, "incidents"),
              where("deviceCode", "==", targetDevice.code),
            ),
          ),
        );
        maintenanceQueries.push(
          getDocs(
            query(
              collection(db, "maintenances"),
              where("deviceCode", "==", targetDevice.code),
            ),
          ),
        );
      }

      const [incidentSnapshots, maintenanceSnapshots, resolutionSnapshot] =
        await Promise.all([
          Promise.all(incidentQueries),
          Promise.all(maintenanceQueries),
          getDocs(
            query(
              collection(db, "incidentResolutions"),
              where("deviceId", "==", targetDevice.id),
            ),
          ),
        ]);

      if (historyRequestIdRef.current !== requestId) return;

      const incidentData = incidentSnapshots
        .flatMap((snapshot) => snapshot.docs)
        .reduce<Incident[]>((records, item) => {
          if (records.some((record) => record.id === item.id)) return records;

          const record: Incident = { id: item.id, ...item.data() };
          return record.deviceId === targetDevice.id ||
            (!record.deviceId && record.deviceCode === targetDevice.code)
            ? [...records, record]
            : records;
        }, []);
      const maintenanceData = maintenanceSnapshots
        .flatMap((snapshot) => snapshot.docs)
        .reduce<Maintenance[]>((records, item) => {
          if (records.some((record) => record.id === item.id)) return records;

          const record: Maintenance = { id: item.id, ...item.data() };
          return record.deviceId === targetDevice.id ||
            (!record.deviceId && record.deviceCode === targetDevice.code)
            ? [...records, record]
            : records;
        }, []);
      const resolutionData = resolutionSnapshot.docs.map((item) => ({
        ...item.data(),
        id: item.id,
      })) as IncidentResolution[];

      setIncidents(incidentData);
      setMaintenances(maintenanceData);
      setIncidentResolutions(resolutionData);
      setHistoryLoaded(true);
    } catch (err) {
      if (historyRequestIdRef.current !== requestId) return;

      console.error("Lỗi tải lịch sử thiết bị:", err);
      setHistoryError("Không thể tải lịch sử thiết bị. Vui lòng thử lại.");
    } finally {
      if (historyRequestIdRef.current === requestId) {
        setHistoryLoading(false);
      }
    }
  }, [device, historyLoading, historyLoaded, isAdminUser]);

  useEffect(() => {
    if (!historyOnly) {
      historyAutoLoadIdRef.current = null;
      return;
    }
    if (!id || !device || device.id !== id || historyAutoLoadIdRef.current === id) return;

    historyAutoLoadIdRef.current = id;
    void loadHistory();
  }, [historyOnly, id, device, loadHistory]);

  /* =========================================================
     HELPER - TRẠNG THÁI THIẾT BỊ
  ========================================================= */

  function getStatusLabel(status?: string) {
    switch (status) {
      case "ACTIVE":
        return "Hoạt động";

      case "WARNING":
        return "Cảnh báo";

      case "OFFLINE":
        return "Mất kết nối";

      case "MAINTENANCE":
        return "Bảo trì";

      default:
        return status || "Không xác định";
    }
  }
  /* =========================================================
     HELPER - FORMAT THỜI GIAN
  ========================================================= */

  function formatDate(timestamp?: FirestoreTimestamp | null) {
    if (!timestamp?.toDate) {
      return "-";
    }

    return timestamp.toDate().toLocaleString("vi-VN");
  }

  function getTimestampMillis(timestamp?: FirestoreTimestamp | null) {
    return timestamp?.toMillis?.() ?? 0;
  }

  /* =========================================================
     GỘP LỊCH SỬ SỰ CỐ + BẢO TRÌ
  ========================================================= */

  const historyItems: HistoryItem[] = [
    ...incidents.map((incident) => ({
      type: "INCIDENT" as const,
      timestamp: incident.reportedAt,
      data: incident,
    })),

    ...maintenances.map((maintenance) => ({
      type: "MAINTENANCE" as const,
      timestamp: maintenance.performedAt || maintenance.createdAt,
      data: maintenance,
    })),
  ].sort(
    (a, b) => getTimestampMillis(b.timestamp) - getTimestampMillis(a.timestamp),
  );

  /* =========================================================
     KIỂM TRA SỰ CỐ CHƯA XỬ LÝ

     Không cho ngừng sử dụng khi thiết bị còn:
     - OPEN
     - IN_PROGRESS
  ========================================================= */

  const unresolvedIncidents = incidents.filter(
    (incident) =>
      incident.status === "OPEN" || incident.status === "IN_PROGRESS",
  );

  const unresolvedIncidentCount = unresolvedIncidents.length;

  /* =========================================================
     NGỪNG SỬ DỤNG THIẾT BỊ
  ========================================================= */

  async function handleDeactivateDevice() {
    if (!device || !id) {
      return;
    }

    if (!historyLoaded) {
      setInactiveError(
        "Hãy tải Lịch sử thiết bị trước khi thực hiện ngừng sử dụng.",
      );
      return;
    }

    /* -------------------------------------------------------
       BẢO VỆ NGHIỆP VỤ:
       Không được ngừng thiết bị nếu còn sự cố chưa xử lý.
    ------------------------------------------------------- */

    if (unresolvedIncidentCount > 0) {
      setInactiveError(
        `Không thể ngừng sử dụng thiết bị vì còn ${unresolvedIncidentCount} sự cố chưa xử lý. Hãy xử lý hoặc đóng các sự cố trước.`,
      );

      return;
    }

    /* -------------------------------------------------------
       Kiểm tra lý do
    ------------------------------------------------------- */

    const reason = inactiveReason.trim();

    if (!reason) {
      setInactiveError("Vui lòng nhập lý do ngừng sử dụng.");

      return;
    }

    try {
      setStopping(true);
      setInactiveError("");

      /* -----------------------------------------------------
         CẬP NHẬT FIRESTORE
      ----------------------------------------------------- */

      await updateDoc(doc(db, "devices", id), {
        // Kết thúc vòng đời đang sử dụng
        isActive: false,

        // Trạng thái nghiệp vụ
        status: "INACTIVE",

        // Lý do ngừng
        inactiveReason: reason,

        // Thời điểm ngừng
        inactiveAt: serverTimestamp(),

        // Thời điểm cập nhật
        updatedAt: serverTimestamp(),
      });

      invalidateAppCollection("devices");

      /* -----------------------------------------------------
         CẬP NHẬT GIAO DIỆN NGAY
      ----------------------------------------------------- */

      setDevice((current) => {
        if (!current) {
          return current;
        }

        return {
          ...current,
          isActive: false,
          status: "INACTIVE",
          inactiveReason: reason,

          /*
           * inactiveAt thật sẽ là Timestamp từ Firestore.
           * Không cần giả lập tại đây.
           * Khi tải lại trang sẽ lấy đúng Timestamp.
           */
        };
      });

      setShowInactiveForm(false);
      setInactiveReason("");
    } catch (err) {
      console.error("Lỗi ngừng sử dụng thiết bị:", err);

      setInactiveError("Không thể ngừng sử dụng thiết bị. Vui lòng thử lại.");
    } finally {
      setStopping(false);
    }
  }

  /* =========================================================
     ĐƯA THIẾT BỊ VÀO SỬ DỤNG LẠI

     Đây là hàm độc lập.
     KHÔNG nằm trong handleDeactivateDevice().
  ========================================================= */

  async function handleReactivateDevice() {
    if (!device || !id) {
      return;
    }

    try {
      setReactivating(true);
      setError("");

      /* -----------------------------------------------------
         CẬP NHẬT FIRESTORE
      ----------------------------------------------------- */

      await updateDoc(doc(db, "devices", id), {
        // Đưa thiết bị trở lại vòng đời sử dụng
        isActive: true,

        // Trạng thái mặc định khi kích hoạt lại
        status: "ACTIVE",

        // Lưu thời điểm đưa vào sử dụng lại
        reactivatedAt: serverTimestamp(),

        // Thời điểm cập nhật document
        updatedAt: serverTimestamp(),
      });

      invalidateAppCollection("devices");

      /* -----------------------------------------------------
         CẬP NHẬT GIAO DIỆN NGAY
      ----------------------------------------------------- */

      setDevice((current) => {
        if (!current) {
          return current;
        }

        return {
          ...current,
          isActive: true,
          status: "ACTIVE",
        };
      });

      /* Đóng hộp xác nhận */
      setShowReactivateForm(false);
    } catch (err) {
      console.error("Lỗi khi đưa thiết bị vào sử dụng lại:", err);

      setError("Không thể đưa thiết bị vào sử dụng lại. Vui lòng thử lại.");
    } finally {
      setReactivating(false);
    }
  }

  /* =========================================================
     LOADING
  ========================================================= */

  if (loading) {
    return <p>Đang tải hồ sơ thiết bị...</p>;
  }

  /* =========================================================
     ERROR
  ========================================================= */

  if (error || !device) {
    return (
      <section className="panel">
        <h2>Không thể mở hồ sơ thiết bị</h2>

        <p>{error}</p>

        <button className="table-action" onClick={() => navigate("/devices")}>
          ← Quay lại danh sách
        </button>
      </section>
    );
  }

  if (historyOnly) {
    return (
      <main className="device-detail-page device-history-page">
        <div className="page-header device-history-page-header">
          <div>
            <ActionIconButton
              icon="back"
              label="Quay lại chi tiết thiết bị"
              onClick={() => navigate(`/devices/${device.id}`)}
            />
            <h1>Lịch sử thiết bị</h1>
            <p>{device.code} · {device.name || "Chưa có tên thiết bị"}</p>
          </div>
        </div>
        <DeviceHistory
          deviceId={device.id}
          historyItems={historyItems}
          incidentResolutions={incidentResolutions}
          canCreateMaintenance={isManagerUser}
          historyVisible
          historyLoading={historyLoading}
          historyError={historyError}
          onShowHistory={() => void loadHistory()}
          standalone
        />
      </main>
    );
  }

  /* =========================================================
     URL QR
  ========================================================= */

  const qrUrl = `${window.location.origin}/q/${encodeURIComponent(
    device.code || device.id,
  )}`;

  /* =========================================================
     GIAO DIỆN
  ========================================================= */

  return (
    <main className="device-detail-page">
      {refreshError && <p role="status">{refreshError}</p>}
      {/* =====================================================
          HEADER
      ===================================================== */}

      <div className="page-header">
        <div>
          <ActionIconButton icon="back" label="Quay lại danh sách thiết bị" onClick={() => navigate("/devices")} />

          <h1>{device.code}</h1>

          <p>{device.name || "Chưa có tên thiết bị"}</p>
        </div>

        <div className="device-header-actions">
          {/* SỬA THIẾT BỊ */}

          <ActionIconButton
            icon="edit" variant="primary" label={`Sửa thiết bị ${device.code}`}
            hidden={!isManagerUser}
            onClick={() => navigate(`/devices/${device.id}/edit`)}
          />

          {/* =================================================
              NÚT VÒNG ĐỜI THIẾT BỊ
          ================================================= */}

          {device.isActive === false ? (
            /*
             * Thiết bị đã ngừng sử dụng
             * -> cho phép đưa vào sử dụng lại.
             */
            <ActionIconButton
              icon="activate" label={`Kích hoạt lại thiết bị ${device.code}`}
              type="button"
              hidden={!isManagerUser}
              onClick={() => setShowReactivateForm(true)}
            />
          ) : (
            /*
             * Thiết bị đang hoạt động
             * -> cho phép ngừng sử dụng.
             */
            <ActionIconButton
              icon="deactivate" variant="danger" label={`Ngừng sử dụng thiết bị ${device.code}`}
              type="button"
              hidden={!isManagerUser}
              onClick={() => {
                /*
                 * Nếu còn sự cố chưa xử lý:
                 * vẫn mở form để người dùng nhìn thấy
                 * nguyên nhân tại sao không được ngừng.
                 */

                if (!historyLoaded) {
                  setInactiveError(
                    "Hãy tải Lịch sử thiết bị trước khi thực hiện ngừng sử dụng.",
                  );
                } else if (unresolvedIncidentCount > 0) {
                  setInactiveError(
                    `Không thể ngừng sử dụng thiết bị vì còn ${unresolvedIncidentCount} sự cố chưa xử lý.`,
                  );
                } else {
                  setInactiveError("");
                }

                setShowInactiveForm(true);
              }}
            />
          )}
        </div>
      </div>

      {/* =====================================================
          FORM XÁC NHẬN NGỪNG SỬ DỤNG
      ===================================================== */}

      {showInactiveForm && device.isActive !== false && (
        <section className="panel device-deactivate-panel">
          <div className="device-deactivate-header">
            <div>
              <h2>Xác nhận ngừng sử dụng</h2>

              <p>
                Thiết bị <strong>{device.code}</strong> sẽ được đánh dấu là
                ngừng sử dụng. Hồ sơ, QR, sự cố và lịch sử bảo trì vẫn được giữ
                nguyên.
              </p>
            </div>
          </div>

          <label className="full-field">
            Lý do ngừng sử dụng *
            <textarea
              rows={3}
              value={inactiveReason}
              onChange={(e) => setInactiveReason(e.target.value)}
              placeholder="VD: Thiết bị hỏng, đã được thay thế bằng thiết bị mới..."
              disabled={stopping}
            />
          </label>

          {inactiveError && (
            <div className="error-message">{inactiveError}</div>
          )}

          <div className="form-actions">
            <button
              type="button"
              className="secondary-button"
              disabled={stopping}
              onClick={() => {
                setShowInactiveForm(false);

                setInactiveReason("");
                setInactiveError("");
              }}
            >
              Hủy
            </button>

            <button
              type="button"
              className="danger-button"
              disabled={
                stopping ||
                !historyLoaded ||
                unresolvedIncidentCount > 0 ||
                !inactiveReason.trim()
              }
              onClick={handleDeactivateDevice}
            >
              {stopping ? "Đang xử lý..." : "Xác nhận ngừng sử dụng"}
            </button>
          </div>
        </section>
      )}

      {/* =====================================================
          TRẠNG THÁI THIẾT BỊ
      ===================================================== */}

      <div className="device-detail-status">
        {/* ---------------------------------------------------
            BANNER NGỪNG SỬ DỤNG
        --------------------------------------------------- */}

        {device.isActive === false && (
          <div className="device-inactive-banner">
            <div>
              <strong>Thiết bị đã ngừng sử dụng</strong>

              <p>Lý do: {device.inactiveReason || "Không có thông tin"}</p>

              {device.inactiveAt && (
                <p>Thời gian: {formatDate(device.inactiveAt)}</p>
              )}
            </div>
          </div>
        )}

        {/* ---------------------------------------------------
            BADGE TRẠNG THÁI

            isActive được ưu tiên hơn status.
        --------------------------------------------------- */}

        {device.isActive === false ? (
          <span className="status status-inactive">Ngừng sử dụng</span>
        ) : (
          <span
            className={`status status-${(
              device.status || "UNKNOWN"
            ).toLowerCase()}`}
          >
            {getStatusLabel(device.status)}
          </span>
        )}
      </div>

      {/* =====================================================
          XÁC NHẬN ĐƯA VÀO SỬ DỤNG LẠI
      ===================================================== */}

      {showReactivateForm && device.isActive === false && (
        <div className="device-reactivate-confirm">
          <div className="device-reactivate-confirm-content">
            <h3>Xác nhận đưa vào sử dụng lại</h3>

            <p>
              Thiết bị <strong>{device.code}</strong> hiện đang ở trạng thái
              ngừng sử dụng.
            </p>

            <p>
              Sau khi xác nhận, thiết bị sẽ được đưa trở lại danh sách thiết bị
              đang sử dụng.
            </p>

            {device.inactiveReason && (
              <div className="reactivate-old-info">
                <span>Lý do ngừng sử dụng trước đó:</span>

                <strong>{device.inactiveReason}</strong>
              </div>
            )}
          </div>

          <div className="device-reactivate-confirm-actions">
            <button
              type="button"
              className="secondary-button"
              disabled={reactivating}
              onClick={() => setShowReactivateForm(false)}
            >
              Hủy
            </button>

            {/* =================================================
                  QUAN TRỌNG:
                  Nút này gọi trực tiếp
                  handleReactivateDevice()
              ================================================= */}

            <button
              type="button"
              className="reactivate-button"
              onClick={handleReactivateDevice}
              disabled={reactivating}
            >
              {reactivating ? "Đang xử lý..." : "Xác nhận đưa vào sử dụng lại"}
            </button>
          </div>
        </div>
      )}

      {/* =====================================================
          THÔNG TIN THIẾT BỊ
      ===================================================== */}

      <div className="detail-grid">
        <section className="panel detail-card">
          <h2>Thông tin chung</h2>

          <div className="detail-list">
            <div>
              <span>Khu vực</span>

              <strong>
                {area
                  ? `${area.code || ""}${
                      area.code && area.name ? " - " : ""
                    }${area.name || ""}`
                  : "-"}
                {subArea ? ` / ${subArea.code || ""}${subArea.code && subArea.name ? " - " : ""}${subArea.name || ""}` : ""}
              </strong>
            </div>
            {/* LĨNH VỰC THIẾT BỊ */}
            <div>
              <span>Lĩnh vực</span>

              <strong>
                {deviceCategory?.name || deviceCategory?.code || "-"}
              </strong>
            </div>
            <div>
              <span>Loại thiết bị</span>

              <strong>{deviceType?.name || "-"}</strong>
            </div>

            <div>
              <span>Hãng sản xuất</span>

              <strong>{device.manufacturer || "-"}</strong>
            </div>

            <div>
              <span>Model</span>

              <strong>{device.model || "-"}</strong>
            </div>

            <div>
              <span>Serial Number</span>

              <strong>{device.serialNumber || "-"}</strong>
            </div>
            <div>
              <span>Địa chỉ IP</span>
              <strong>{device.ipAddress || "-"}</strong>
            </div>
            <div>
              <span>MAC Address</span>
              <strong>{device.macAddress || "-"}</strong>
            </div>
          </div>
        </section>

        {/* =====================================================
          MÃ QR THIẾT BỊ
      ===================================================== */}

        <section className="panel detail-card qr-device-card">
          <div className="qr-device-header">
            <div>
              <h2>Mã QR thiết bị</h2>

              <p>Quét mã QR để mở nhanh hồ sơ thiết bị trên điện thoại.</p>
            </div>
          </div>

          <div className="qr-device-content">
            <div className="qr-code-box">
              <QRCodeSVG
                value={qrUrl}
                size={180}
                level="H"
                includeMargin={true}
              />
            </div>

            <div className="qr-device-info">
              <span>Mã thiết bị</span>

              <strong>{device.code || "-"}</strong>

              <p>{device.name || "Chưa có tên thiết bị"}</p>

              <div className="qr-url-preview">{qrUrl}</div>

              <div className="qr-device-actions">
                <ActionIconButton
                  icon="view" label="Mở thử mã QR"
                  onClick={() => window.open(qrUrl, "_blank")}
                />

                <ActionIconButton
                  icon="print" variant="primary" label={`In tem QR cho ${device.code}`}
                  hidden={!isManagerUser}
                  onClick={() => navigate(`/devices/${device.id}/qr`)}
                />
              </div>
            </div>
          </div>
        </section>
      </div>
      {/* =====================================================
    TUẦN KIỂM THIẾT BỊ
===================================================== */}
      <div className="device-detail-work-grid">
      <section className="panel detail-card device-inspection-card">
        <div style={{ marginBottom: 16 }}>
          <h2>Tuần kiểm thiết bị</h2>
          <p style={{ color: "#64748b", marginTop: 8 }}>
            Thực hiện kiểm tra định kỳ, theo dõi kết quả và quản lý kế hoạch
            tuần kiểm của thiết bị.
          </p>
        </div>
        <div className="device-inspection-actions">
          <ActionIconButton
            icon="inspect" variant="primary" label={`Thực hiện tuần kiểm ${device.code}`}
            type="button"
            disabled={device.isActive === false}
            onClick={() => navigate(`/devices/${device.id}/inspection`)}
          />

          <ActionIconButton
            icon="history" label={`Lịch sử tuần kiểm ${device.code}`}
            type="button"
            onClick={() => navigate(`/devices/${device.id}/inspection-history`)}
          />

          <ActionIconButton
            icon="schedule" label={`Kế hoạch tuần kiểm ${device.code}`}
            type="button"
            hidden={!isManagerUser}
            onClick={() => navigate(`/devices/${device.id}/inspection-plan`)}
          />
        </div>

        {device.isActive === false && (
          <p style={{ color: "#b45309", marginTop: 12 }}>
            Thiết bị đã ngừng hoạt động. Không thể thực hiện tuần kiểm mới,
            nhưng vẫn có thể xem lịch sử và kế hoạch.
          </p>
        )}
      </section>

      <section className="panel detail-card device-history-link-card">
        <div>
          <h2>Lịch sử thiết bị</h2>
          <p>Theo dõi sự cố, bảo trì và thay thế trong suốt vòng đời thiết bị.</p>
        </div>
        <div className="device-history-link-actions">
          <ActionIconButton
            icon="incident" label="Ghi nhận sự cố"
            onClick={() => navigate(`/devices/${device.id}/incidents/new`)}
          />
          <ActionIconButton
            icon="repair" variant="primary" label="Tạo bản ghi bảo trì"
            hidden={!isManagerUser}
            onClick={() => navigate(`/devices/${device.id}/maintenance/new`)}
          />
          <ActionIconButton
            icon="history" label="Mở lịch sử thiết bị"
            onClick={() => navigate(`/devices/${device.id}/history`)}
          />
        </div>
      </section>
      </div>

      <section className="panel detail-card device-notes-card">
        <h2>Ghi chú</h2>
        <p className="device-description">
          {device.description || "Chưa có ghi chú."}
        </p>
      </section>
    </main>
  );
}
