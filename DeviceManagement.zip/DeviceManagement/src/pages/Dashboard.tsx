import { useEffect, useMemo, useState } from "react";
import {
  collection,
  documentId,
  getDocs,
  query,
  where,
} from "firebase/firestore";
import { useNavigate } from "react-router-dom";

import { db } from "../config/firebase";
import { loadInspectionScheduleStatuses } from "../services/inspectionScheduleReader";
import type { InspectionScheduleStatus } from "../services/inspectionScheduleStatus";
import { publishPublicPortal } from "../services/publicPortalService";
import { showAppAlert, showAppConfirm } from "../services/appDialog";
import { beginAppCollectionRead } from "../services/sharedCollectionCache";
import { isPermissionDenied } from "../services/sharedRamCache";
import { isAdmin, isManager, type AppUser } from "../types/user";
import ActionIconButton from "../components/ActionIconButton";
import "../styles/Dashboard.css";

const FIRESTORE_IN_LIMIT = 30;

/* =========================================================
   ICON DÙNG TRONG DASHBOARD
   Tất cả nút thao tác đều dùng ActionIconButton.
   Nếu tên icon trong ActionIconButton khác, chỉ cần đổi tại đây.
   ========================================================= */
const DASHBOARD_ICONS = {
  view: "view",
  scan: "scan",
  add: "add",
  // Tạm dùng icon "export" (đã có sẵn). Đổi thành "publish" khi ActionIconButton có icon này.
  publish: "export",
} as const;

/* Nhóm màu của thẻ lĩnh vực (màu định nghĩa trong Dashboard.css) */
type CategoryTone = "it" | "electric" | "mechanical" | "default";

function getCategoryTone(code?: string, name?: string): CategoryTone {
  const key = (code || name || "").trim().toUpperCase();

  if (key === "IT" || key === "CNTT" || key.includes("CÔNG NGHỆ THÔNG TIN")) {
    return "it";
  }
  if (key === "DIEN" || key === "ĐIỆN" || key === "ELECTRICAL") {
    return "electric";
  }
  if (
    key === "COKHI" || key === "CO KHI" ||
    key === "CƠ KHÍ" || key === "MECHANICAL"
  ) {
    return "mechanical";
  }
  return "default";
}

interface FirestoreTimestamp {
  toDate(): Date;
  toMillis(): number;
}

function chunkIds(ids: string[]): string[][] {
  const chunks: string[][] = [];

  for (let index = 0; index < ids.length; index += FIRESTORE_IN_LIMIT) {
    chunks.push(ids.slice(index, index + FIRESTORE_IN_LIMIT));
  }

  return chunks;
}

async function getDocumentsByField(
  collectionName: string,
  fieldName: string,
  values: string[],
) {
  const snapshots = await Promise.all(
    chunkIds(values).map((valuesChunk) =>
      getDocs(
        query(
          collection(db, collectionName),
          where(fieldName, "in", valuesChunk),
        ),
      ),
    ),
  );

  return snapshots.flatMap((snapshot) => snapshot.docs);
}

async function getDocumentsForDevices(
  collectionName: string,
  deviceIds: string[],
) {
  const snapshots = await Promise.all(
    [...new Set(deviceIds)].map((deviceId) =>
      getDocs(
        query(
          collection(db, collectionName),
          where("deviceId", "==", deviceId),
        ),
      ),
    ),
  );

  const documentsById = new Map<string, (typeof snapshots)[number]["docs"][number]>();
  for (const snapshot of snapshots) {
    for (const document of snapshot.docs) {
      documentsById.set(document.id, document);
    }
  }

  return [...documentsById.values()];
}

type DashboardDocument = Awaited<
  ReturnType<typeof getDocumentsForDevices>
>[number];

async function getAreasByIds(areaIds: string[]) {
  const snapshots = await Promise.all(
    chunkIds(areaIds).map((areaIdsChunk) =>
      getDocs(
        query(
          collection(db, "areas"),
          where(documentId(), "in", areaIdsChunk),
        ),
      ),
    ),
  );

  return snapshots.flatMap((snapshot) => snapshot.docs);
}

/* =========================================================
   INTERFACE - THIẾT BỊ
   ========================================================= */

interface Device {
  id: string;

  code?: string;
  name?: string;

  areaId?: string;
  subAreaId?: string;

  manufacturer?: string;
  model?: string;

  ipAddress?: string;
  deviceTypeId?: string;

  // Trạng thái vận hành:
  // ACTIVE
  // WARNING
  // OFFLINE
  // MAINTENANCE
  status?: string;

  // Vòng đời thiết bị:
  // false = đã ngừng sử dụng
  // true hoặc chưa có field = đang sử dụng
  isActive?: boolean;
}

/* =========================================================
   INTERFACE - KHU VỰC
   ========================================================= */

/* =========================================================
   DANH MỤC LĨNH VỰC THIẾT BỊ
   CNTT - ĐIỆN - CƠ KHÍ
========================================================= */
interface DeviceCategory {
  id: string;
  code?: string;
  name?: string;
  status?: string;
}

/* =========================================================
   DANH MỤC LOẠI THIẾT BỊ

   categoryId liên kết với Document ID của lĩnh vực.
   Tên loại thiết bị có thể chỉnh sửa sau này.
========================================================= */
interface DeviceType {
  id: string;
  code?: string;
  name?: string;
  categoryId?: string;
  isActive?: boolean;
}

interface Area {
  id: string;

  code?: string;
  name?: string;
  description?: string;

  // Trạng thái khu vực trong Firestore:
  // ACTIVE   = đang sử dụng
  // INACTIVE = ngừng sử dụng
  status?: string;
}

/* =========================================================
   INTERFACE - SỰ CỐ
   ========================================================= */

interface Incident {
  id: string;

  deviceId?: string;
  deviceCode?: string;
  deviceName?: string;

  title?: string;
  description?: string;

  severity?: string;

  // OPEN
  // IN_PROGRESS
  // RESOLVED
  status?: string;

  reportedAt?: FirestoreTimestamp;
}

/* =========================================================
   INTERFACE - BẢO TRÌ
   ========================================================= */

interface Maintenance {
  id: string;

  deviceId?: string;
  deviceCode?: string;
  deviceName?: string;

  title?: string;

  maintenanceType?: string;
  status?: string;

  performedAt?: FirestoreTimestamp;
  createdAt?: FirestoreTimestamp;
}

/* =========================================================
   DASHBOARD
   ========================================================= */

interface DashboardProps {
  appUser: AppUser;
}

export default function Dashboard({ appUser }: DashboardProps) {
  const navigate = useNavigate();
  const isAdminUser = isAdmin(appUser);

  /* =========================================================
     STATE
     ========================================================= */

  const [devices, setDevices] = useState<Device[]>([]);
  const [areas, setAreas] = useState<Area[]>([]);
  const [subAreas, setSubAreas] = useState<Area[]>([]);
  
 const [categories, setCategories] =useState<DeviceCategory[]>([]);

 const [deviceTypes, setDeviceTypes] =useState<DeviceType[]>([]);

  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [maintenances, setMaintenances] = useState<Maintenance[]>([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [inspectionStatuses, setInspectionStatuses] = useState<Map<string, InspectionScheduleStatus>>(new Map());
  const [inspectionStatusLoading, setInspectionStatusLoading] = useState(false);
  const [inspectionStatusError, setInspectionStatusError] = useState("");
  const [publishingGuestData, setPublishingGuestData] = useState(false);

  /* =========================================================
     LOAD DATA TỪ FIRESTORE

     Dashboard cần dữ liệu từ 4 collection:
     - devices
     - areas
     - incidents
     - maintenances
     ========================================================= */

  useEffect(() => {
    let cancelled = false;

    async function loadDashboard() {
      try {
        setLoading(true);
        setError("");

        const assignedAreaIds = appUser.areaIds;

        if (!isAdminUser && assignedAreaIds.length === 0) {
          if (!cancelled) {
            setDevices([]);
            setAreas([]);
            setIncidents([]);
            setMaintenances([]);
            setCategories([]);
            setDeviceTypes([]);
          }
          return;
        }

        const loadDevices = async (): Promise<Device[]> => {
          const documents = isAdminUser
            ? await getDocs(collection(db, "devices")).then(
                (snapshot) => snapshot.docs,
              )
            : await getDocumentsByField(
                "devices",
                "areaId",
                assignedAreaIds,
              );
          return documents.map((item) => ({ id: item.id, ...item.data() }));
        };
        const loadAreas = async (): Promise<Area[]> => {
          const documents = isAdminUser
            ? await getDocs(collection(db, "areas")).then(
                (snapshot) => snapshot.docs,
              )
            : await getAreasByIds(assignedAreaIds);
          return documents.map((item) => ({ id: item.id, ...item.data() }));
        };
        const loadSubAreas = async (): Promise<Area[]> => {
          const documents = isAdminUser
            ? (await getDocs(collection(db, "subAreas"))).docs
            : (await Promise.all(chunkIds(assignedAreaIds).map((ids) => getDocs(query(
                collection(db, "subAreas"), where("factoryId", "in", ids),
              ))))).flatMap((snapshot) => snapshot.docs);
          return documents.map((item) => ({ id: item.id, ...item.data() }));
        };
        const loadCategories = async (): Promise<DeviceCategory[]> => {
          const snapshot = await getDocs(collection(db, "deviceCategories"));
          return snapshot.docs.map((item) => ({
            ...(item.data() as Omit<DeviceCategory, "id">),
            id: item.id,
          }));
        };
        const loadDeviceTypes = async (): Promise<DeviceType[]> => {
          const snapshot = await getDocs(collection(db, "deviceTypes"));
          return snapshot.docs.map((item) => ({
            ...(item.data() as Omit<DeviceType, "id">),
            id: item.id,
          }));
        };

        const deviceRead = beginAppCollectionRead(
          appUser,
          "devices",
          loadDevices,
        );
        const areaRead = beginAppCollectionRead(appUser, "areas", loadAreas);
        const subAreaRead = beginAppCollectionRead(appUser, "subAreas", loadSubAreas);
        const categoryRead = beginAppCollectionRead(
          appUser,
          "deviceCategories",
          loadCategories,
        );
        const typeRead = beginAppCollectionRead(
          appUser,
          "deviceTypes",
          loadDeviceTypes,
        );

        if (!deviceRead || !areaRead || !categoryRead || !typeRead || !subAreaRead) {
          throw new Error("Cache scope is not available for verified profile.");
        }

        const deviceDataPromise = deviceRead.request
          ? deviceRead.request.then((result) => result.data)
          : Promise.resolve(deviceRead.snapshot.data ?? []);
        const areaDataPromise = areaRead.request
          ? areaRead.request.then((result) => result.data)
          : Promise.resolve(areaRead.snapshot.data ?? []);
        const categoryDataPromise = categoryRead.request
          ? categoryRead.request.then((result) => result.data)
          : Promise.resolve(categoryRead.snapshot.data ?? []);
        const typeDataPromise = typeRead.request
          ? typeRead.request.then((result) => result.data)
          : Promise.resolve(typeRead.snapshot.data ?? []);
        const subAreaDataPromise = subAreaRead.request
          ? subAreaRead.request.then((result) => result.data)
          : Promise.resolve(subAreaRead.snapshot.data ?? []);
        const historyDocumentsPromise = (async (): Promise<
          [DashboardDocument[], DashboardDocument[]]
        > => {
          if (isAdminUser) {
            return Promise.all([
              getDocs(collection(db, "incidents")).then(
                (snapshot) => snapshot.docs,
              ),
              getDocs(collection(db, "maintenances")).then(
                (snapshot) => snapshot.docs,
              ),
            ]);
          }

          const documents = await deviceDataPromise;
          if (cancelled || documents.length === 0) return [[], []];

          const deviceIds = documents.map((device) => device.id);
          return Promise.all([
            getDocumentsForDevices("incidents", deviceIds),
            getDocumentsForDevices("maintenances", deviceIds),
          ]);
        })();

        const [
          deviceData,
          areaData,
          categoryData,
          typeData,
          subAreaData,
          historyDocuments,
        ] = await Promise.all([
          deviceDataPromise,
          areaDataPromise,
          categoryDataPromise,
          typeDataPromise,
          subAreaDataPromise,
          historyDocumentsPromise,
        ]);

        if (cancelled) return;

        const [incidentDocuments, maintenanceDocuments] = historyDocuments;

        setDevices(deviceData);
        setAreas(areaData);
        setSubAreas(subAreaData);
        setIncidents(
          incidentDocuments.map((item) => ({
            id: item.id,
            ...item.data(),
          })),
        );
        setMaintenances(
          maintenanceDocuments.map((item) => ({
            id: item.id,
            ...item.data(),
          })),
        );
        setCategories(categoryData);
        setDeviceTypes(typeData);
      } catch (err) {
        console.error("Lỗi tải Dashboard:", err);

        if (!cancelled) {
          setError("Không thể tải dữ liệu tổng quan.");
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    void loadDashboard();

    return () => {
      cancelled = true;
    };
  }, [appUser, isAdminUser]);

  useEffect(() => {
    let cancelled = false;

    async function loadInspectionKpis() {
      if (devices.length === 0) {
        setInspectionStatuses(new Map());
        setInspectionStatusError("");
        return;
      }

      try {
        setInspectionStatusLoading(true);
        setInspectionStatusError("");
        const statuses = await loadInspectionScheduleStatuses(
          devices.map((device) => device.id),
        );
        if (!cancelled) setInspectionStatuses(statuses);
      } catch (loadError) {
        console.error("Unable to load dashboard inspection statuses:", loadError);
        if (!cancelled) {
          setInspectionStatuses(new Map());
          setInspectionStatusError(
            isPermissionDenied(loadError)
              ? "Không có quyền đọc trạng thái tuần kiểm trong phạm vi hiện tại."
              : "Không thể tải KPI tuần kiểm.",
          );
        }
      } finally {
        if (!cancelled) setInspectionStatusLoading(false);
      }
    }

    void loadInspectionKpis();
    return () => { cancelled = true; };
  }, [devices]);

  /* =========================================================
     THIẾT BỊ ĐANG SỬ DỤNG

     Quy tắc hiện tại:
     isActive === false
        -> thiết bị đã ngừng sử dụng

     isActive === true hoặc chưa có field
        -> thiết bị đang sử dụng

     Cách này giúp tương thích với dữ liệu thiết bị cũ.
     ========================================================= */

  const operationalDevices = useMemo(
    () => devices.filter((device) => device.isActive !== false),
    [devices]
  );

  /* =========================================================
     THIẾT BỊ ĐÃ NGỪNG SỬ DỤNG
     ========================================================= */

  const retiredDevices = useMemo(
    () => devices.filter((device) => device.isActive === false),
    [devices]
  );

  /* =========================================================
     KHU VỰC ĐANG SỬ DỤNG

     QUAN TRỌNG:

     Firestore của chúng ta hiện lưu:

     status = "ACTIVE"
        -> khu vực đang sử dụng

     status = "INACTIVE"
        -> khu vực đã ngừng sử dụng

     Dữ liệu khu vực cũ nếu chưa có status vẫn được xem
     là đang sử dụng để tránh làm mất dữ liệu cũ khỏi Dashboard.
     ========================================================= */

  const activeAreas = useMemo(
    () =>
      areas.filter(
        (area) => area.status !== "INACTIVE"
      ),
    [areas]
  );
    
/* =========================================================
   DASHBOARD V2 - THỐNG KÊ THEO LĨNH VỰC VÀ LOẠI

   Nguyên tắc:
   - Chỉ tính thiết bị đang sử dụng.
   - Không loại bỏ loại thiết bị đã ngừng sử dụng
     vì vẫn có thể cần thống kê thiết bị lịch sử.
   - Dùng Document ID để liên kết dữ liệu.
   - Không lưu lại số liệu thống kê vào Firestore.
========================================================= */

const typeMap = useMemo(() => {
  return new Map(
    deviceTypes.map((type) => [type.id, type])
  );
}, [deviceTypes]);

const areaMap = useMemo(() => new Map(areas.map((area) => [area.id, area])), [areas]);
const subAreaMap = useMemo(() => new Map(subAreas.map((area) => [area.id, area])), [subAreas]);
const categoryMap = useMemo(() => new Map(categories.map((category) => [category.id, category])), [categories]);

// Thống kê thiết bị đang sử dụng theo lĩnh vực
const categoryStatistics = useMemo(() => {
  return categories.map((category) => {
    const categoryDevices = operationalDevices.filter(
      (device) => {
        const type = device.deviceTypeId
          ? typeMap.get(device.deviceTypeId)
          : undefined;

        return type?.categoryId === category.id;
      }
    );

    return {
      id: category.id,
      code: category.code || "",
      name: category.name || category.code || category.id,
      total: categoryDevices.length,
      active: categoryDevices.filter(
        (device) => device.status === "ACTIVE"
      ).length,
      warning: categoryDevices.filter(
        (device) => device.status === "WARNING"
      ).length,
      offline: categoryDevices.filter(
        (device) => device.status === "OFFLINE"
      ).length,
      maintenance: categoryDevices.filter(
        (device) => device.status === "MAINTENANCE"
      ).length,
    };
  });
}, [categories, operationalDevices, typeMap]);

// Thiết bị chưa liên kết được với lĩnh vực
const uncategorizedCount = useMemo(() => {
  const validCategoryIds = new Set(
    categories.map((category) => category.id)
  );

  return operationalDevices.filter((device) => {
    const type = device.deviceTypeId
      ? typeMap.get(device.deviceTypeId)
      : undefined;

    return (
      !type?.categoryId ||
      !validCategoryIds.has(type.categoryId)
    );
  }).length;
}, [operationalDevices, categories, typeMap]);

  /* =========================================================
     KPI THIẾT BỊ

     Chỉ tính những thiết bị còn đang sử dụng.
     Thiết bị đã retired sẽ không làm sai KPI vận hành.
     ========================================================= */

  const totalDevices = operationalDevices.length;

  const activeCount = operationalDevices.filter(
    (device) => device.status === "ACTIVE"
  ).length;

  const warningCount = operationalDevices.filter(
    (device) => device.status === "WARNING"
  ).length;

  const offlineCount = operationalDevices.filter(
    (device) => device.status === "OFFLINE"
  ).length;

  /*
   * Hiện tại chưa hiển thị retiredCount lên Dashboard.
   * Nhưng giữ biến này để sau này làm thống kê vòng đời thiết bị.
   */
  const retiredCount = retiredDevices.length;

  /* Tránh cảnh báo TypeScript nếu retiredCount chưa được dùng */
  void retiredCount;

  /* =========================================================
     KPI SỰ CỐ

     Sự cố cần xử lý gồm:
     - OPEN
     - IN_PROGRESS
     ========================================================= */

  const openIncidents = useMemo(
    () =>
      incidents.filter(
        (incident) =>
          incident.status === "OPEN" ||
          incident.status === "IN_PROGRESS"
      ),
    [incidents]
  );

  /* =========================================================
     SỰ CỐ NGHIÊM TRỌNG
     ========================================================= */

  const criticalCount = openIncidents.filter(
    (incident) => incident.severity === "CRITICAL"
  ).length;

  const inspectionKpis = useMemo(() => {
    const values = [...inspectionStatuses.values()];
    return {
      overdue: values.filter((status) => status.state === "OVERDUE").length,
      dueToday: values.filter((status) => status.state === "DUE_TODAY").length,
      completedToday: values.filter((status) => status.state === "COMPLETED_TODAY").length,
      withoutPlan: values.filter((status) => status.state === "NO_PLAN").length,
    };
  }, [inspectionStatuses]);

  async function handlePublishGuestData() {
    if (!isAdminUser || publishingGuestData) return;
    if (inspectionStatusLoading || inspectionStatusError) {
      await showAppAlert("Chưa thể phát hành vì trạng thái tuần kiểm chưa tải đầy đủ.", { tone: "warning" });
      return;
    }
    if (!await showAppConfirm("Cập nhật dữ liệu xem công khai từ dữ liệu hiện tại?", { confirmLabel: "Cập nhật" })) return;

    try {
      setPublishingGuestData(true);
      await publishPublicPortal({
        areas: areas.map((area) => ({
          id: area.id,
          code: area.code || "",
          name: area.name || area.code || area.id,
          status: area.status || "ACTIVE",
          totalDevices: devices.filter((device) => device.areaId === area.id).length,
        })),
        devices: devices.map((device) => {
          const schedule = inspectionStatuses.get(device.id);
          const type = device.deviceTypeId ? typeMap.get(device.deviceTypeId) : undefined;
          return {
            id: device.id,
            code: device.code || device.id,
            name: device.name || "",
            areaId: device.areaId || "",
            areaName: `${device.areaId ? (areaMap.get(device.areaId)?.name || areaMap.get(device.areaId)?.code || "") : ""}${device.subAreaId ? ` / ${subAreaMap.get(device.subAreaId)?.name || subAreaMap.get(device.subAreaId)?.code || ""}` : ""}`,
            categoryName: type?.categoryId ? (categoryMap.get(type.categoryId)?.name || categoryMap.get(type.categoryId)?.code || "") : "",
            deviceTypeName: type?.name || type?.code || "",
            status: device.status || "",
            isActive: device.isActive !== false,
            inspectionState: schedule?.state || "NO_PLAN",
            inspectionCount: schedule?.state === "OVERDUE"
              ? schedule.overdueTaskCount
              : schedule?.state === "DUE_TODAY"
                ? schedule.dueTaskCount - schedule.completedTodayCount
                : 0,
          };
        }),
        incidents: incidents.map((incident) => ({
          id: incident.id,
          deviceCode: incident.deviceCode || "",
          deviceName: incident.deviceName || "",
          severity: incident.severity || "",
          status: incident.status || "",
          ...(incident.reportedAt ? { reportedAt: incident.reportedAt } : {}),
        })),
        maintenances: maintenances.filter((maintenance) => maintenance.status === "COMPLETED").map((maintenance) => ({
          id: maintenance.id,
          deviceCode: maintenance.deviceCode || "",
          deviceName: maintenance.deviceName || "",
          maintenanceType: maintenance.maintenanceType || "",
          status: maintenance.status || "COMPLETED",
          ...(maintenance.performedAt ? { performedAt: maintenance.performedAt } : {}),
        })),
      });
      await showAppAlert("Đã cập nhật dữ liệu xem công khai.", { tone: "success" });
    } catch (publishError) {
      console.error("Unable to publish guest data:", publishError);
      await showAppAlert("Không thể cập nhật dữ liệu khách. Kiểm tra Rules đã được triển khai.", { tone: "error" });
    } finally {
      setPublishingGuestData(false);
    }
  }

  /* =========================================================
     DANH SÁCH SỰ CỐ ƯU TIÊN

     Mức độ ưu tiên:
     CRITICAL > HIGH > MEDIUM > LOW

     Nếu cùng mức độ:
     sự cố mới hơn được đưa lên trước.
     ========================================================= */

  const priorityIncidents = useMemo(() => {
    const severityWeight: Record<string, number> = {
      CRITICAL: 4,
      HIGH: 3,
      MEDIUM: 2,
      LOW: 1,
    };

    return [...openIncidents]
      .sort((a, b) => {
        const severityA =
          severityWeight[a.severity || ""] || 0;

        const severityB =
          severityWeight[b.severity || ""] || 0;

        /* Ưu tiên severity cao hơn */
        if (severityA !== severityB) {
          return severityB - severityA;
        }

        /* Nếu cùng severity -> sự cố mới hơn lên trước */
        const timeA =
          a.reportedAt?.toMillis?.() ?? 0;

        const timeB =
          b.reportedAt?.toMillis?.() ?? 0;

        return timeB - timeA;
      })

      /* Dashboard chỉ hiển thị tối đa 5 sự cố */
      .slice(0, 5);
  }, [openIncidents]);

  /* =========================================================
     HELPER - CHUYỂN MỨC ĐỘ SỰ CỐ SANG TIẾNG VIỆT
     ========================================================= */

  function getSeverityLabel(severity?: string) {
    switch (severity) {
      case "LOW":
        return "Thấp";

      case "MEDIUM":
        return "Trung bình";

      case "HIGH":
        return "Cao";

      case "CRITICAL":
        return "Nghiêm trọng";

      default:
        return severity || "-";
    }
  }

  /* =========================================================
     HELPER - FORMAT THỜI GIAN FIRESTORE
     ========================================================= */

  function formatDate(timestamp?: FirestoreTimestamp | null) {
    if (!timestamp?.toDate) {
      return "-";
    }

    return timestamp
      .toDate()
      .toLocaleString("vi-VN");
  }

  /* =========================================================
     LOADING
     ========================================================= */

  if (loading) {
    return <p>Đang tải dữ liệu tổng quan...</p>;
  }

  /* =========================================================
     VIEW
     ========================================================= */

  return (
    <>
      {/* =====================================================
          HEADER
      ====================================================== */}

      <div className="page-header">
        <div>
          <h1>Tổng quan hệ thống</h1>

          <p className="page-subtitle">
            Theo dõi tình trạng thiết bị, sự cố và hoạt động
            bảo trì.
          </p>
        </div>

        <div className="dashboard-header-actions">
          <ActionIconButton
            icon={DASHBOARD_ICONS.scan}
            label="Quét QR"
            onClick={() => navigate("/scan")}
          />

          {isManager(appUser) && (
            <ActionIconButton
              icon={DASHBOARD_ICONS.add}
              label="Thêm thiết bị"
              onClick={() => navigate("/devices/new")}
            />
          )}

          {isAdminUser && (
            <ActionIconButton
              icon={DASHBOARD_ICONS.publish}
              label={
                publishingGuestData
                  ? "Đang cập nhật dữ liệu công khai..."
                  : "Cập nhật dữ liệu công khai"
              }
              disabled={
                publishingGuestData ||
                inspectionStatusLoading ||
                Boolean(inspectionStatusError)
              }
              onClick={() => void handlePublishGuestData()}
            />
          )}
        </div>
      </div>

      {/* =====================================================
          THÔNG BÁO LỖI
      ====================================================== */}

      {error && (
        <div className="error-message">
          {error}
        </div>
      )}

      {/* =====================================================
          KPI THIẾT BỊ
      ====================================================== */}

      <section className="dashboard-kpi-grid">
        {/* Tổng thiết bị còn sử dụng */}

        <div
          className="dashboard-kpi-card"
          onClick={() => navigate("/devices")}
        >
          <span>Tổng thiết bị</span>

          <strong>{totalDevices}</strong>

          <small>Thiết bị đang sử dụng</small>
        </div>

        {/* Thiết bị ACTIVE */}

        <div
          className="dashboard-kpi-card dashboard-kpi-active"
          onClick={() => navigate("/devices")}
        >
          <span>Hoạt động</span>

          <strong>{activeCount}</strong>

          <small>Hoạt động bình thường</small>
        </div>

        {/* Thiết bị WARNING */}

        <div
          className="dashboard-kpi-card dashboard-kpi-warning"
          onClick={() => navigate("/devices")}
        >
          <span>Cảnh báo</span>

          <strong>{warningCount}</strong>

          <small>Thiết bị cần chú ý</small>
        </div>

        {/* Thiết bị OFFLINE */}

        <div
          className="dashboard-kpi-card dashboard-kpi-offline"
          onClick={() => navigate("/devices")}
        >
          <span>Mất kết nối</span>

          <strong>{offlineCount}</strong>

          <small>Thiết bị offline</small>
        </div>
      </section>

      {/* =====================================================
          KPI VẬN HÀNH
      ====================================================== */}

      <section className="dashboard-secondary-grid">
        <div
          className="dashboard-summary-card"
          onClick={() => navigate("/areas")}
        >
          <span>Khu vực</span>

          <strong>{activeAreas.length}</strong>

          <small>Khu vực đang sử dụng</small>
        </div>

        {/* Sự cố đang mở */}

        <div
          className="dashboard-summary-card"
          onClick={() => navigate("/incidents")}
        >
          <span>Sự cố đang mở</span>

          <strong>{openIncidents.length}</strong>

          <small>Cần tiếp tục xử lý</small>
        </div>

        {/* Sự cố CRITICAL */}

        <div
          className="dashboard-summary-card"
          onClick={() => navigate("/incidents")}
        >
          <span>Sự cố nghiêm trọng</span>

          <strong>{criticalCount}</strong>

          <small>Ưu tiên xử lý</small>
        </div>

        {/* Tổng lịch sử bảo trì */}

        <div
          className="dashboard-summary-card"
          onClick={() => navigate("/maintenances")}
        >
          <span>Lượt bảo trì</span>

          <strong>{maintenances.length}</strong>

          <small>Tổng lịch sử bảo trì</small>
        </div>
      </section>

      <section className="dashboard-inspection-section" aria-labelledby="dashboard-inspection-title">
        <div className="dashboard-inspection-heading">
          <div>
            <h2 id="dashboard-inspection-title">Trạng thái tuần kiểm</h2>
            <p>Số liệu theo các xưởng trong phạm vi tài khoản.</p>
          </div>
          <ActionIconButton
            icon={DASHBOARD_ICONS.view}
            label="Xem tuần kiểm"
            onClick={() => navigate("/inspections")}
          />
        </div>

        <div className="dashboard-inspection-kpis">
          <button type="button" className="dashboard-inspection-card is-overdue" onClick={() => navigate("/inspections")}>
            <span>Quá hạn</span><strong>{inspectionKpis.overdue}</strong>
          </button>
          <button type="button" className="dashboard-inspection-card is-due" onClick={() => navigate("/inspections")}>
            <span>Đến hạn hôm nay</span><strong>{inspectionKpis.dueToday}</strong>
          </button>
          <button type="button" className="dashboard-inspection-card is-completed" onClick={() => navigate("/inspections")}>
            <span>Đã hoàn thành hôm nay</span><strong>{inspectionKpis.completedToday}</strong>
          </button>
          <button type="button" className="dashboard-inspection-card" onClick={() => navigate("/inspections")}>
            <span>Chưa lập lịch</span><strong>{inspectionKpis.withoutPlan}</strong>
          </button>
        </div>

        {inspectionStatusLoading && inspectionStatuses.size === 0 && (
          <p className="dashboard-inspection-state">Đang tải trạng thái tuần kiểm...</p>
        )}
        {inspectionKpis.overdue > 0 && (
          <button type="button" className="dashboard-inspection-alert" onClick={() => navigate("/inspections")}>
            Có {inspectionKpis.overdue} thiết bị quá hạn tuần kiểm cần xử lý.
          </button>
        )}
        {inspectionStatusError && <div className="error-message">{inspectionStatusError}</div>}
      </section>

      {/* =====================================================
          DASHBOARD MAIN
      ====================================================== */}
      
{/* =====================================================
    DASHBOARD V2 - PHÂN BỐ THIẾT BỊ
===================================================== */}


{/* =====================================================
    THIẾT BỊ THEO LĨNH VỰC
    - Giao diện thu gọn
    - Màu sắc riêng cho từng lĩnh vực
    - Nhấn vào ô để xem danh sách thiết bị
===================================================== */}

<section className="panel dashboard-panel dashboard-category-panel">
  <div className="dashboard-panel-header">
    <div>
      <h2>Thiết bị theo lĩnh vực</h2>
      <p>Phân bố thiết bị đang sử dụng theo CNTT, Điện và Cơ khí.</p>
    </div>
  </div>

  <div className="dashboard-category-grid">
    {categoryStatistics.map((category) => {
      const tone = getCategoryTone(category.code, category.name);
      const targetUrl = `/devices?category=${encodeURIComponent(category.id)}`;

      return (
        <div
          className={`dashboard-category-card tone-${tone}`}
          key={category.id}
          role="button"
          tabIndex={0}
          title={`Xem thiết bị thuộc lĩnh vực ${category.name}`}
          onClick={() => navigate(targetUrl)}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              navigate(targetUrl);
            }
          }}
        >
          <div className="dashboard-category-name">{category.name}</div>
          <div className="dashboard-category-total">{category.total}</div>

          <div className="dashboard-category-details">
            <div>Hoạt động: {category.active}</div>
            <div>Cảnh báo: {category.warning}</div>
            <div>Offline: {category.offline}</div>
            <div>Bảo trì: {category.maintenance}</div>
          </div>
        </div>
      );
    })}
  </div>

  {uncategorizedCount > 0 && (
    <p className="dashboard-category-warning">
      Có {uncategorizedCount} thiết bị chưa xác định được lĩnh vực.
      Cần kiểm tra dữ liệu loại thiết bị.
    </p>
  )}
</section>

      <div className="dashboard-incident-wrapper">
        {/* ===================================================
            THIẾT BỊ THEO KHU VỰC
        ==================================================== */}
        {/* ===================================================
            SỰ CỐ CẦN XỬ LÝ
        ==================================================== */}
    
        <section className="panel dashboard-panel dashboard-incident-panel">
          <div className="dashboard-panel-header">
            <div>
              <h2>Sự cố cần xử lý</h2>

              <p>
                Các sự cố đang mở được ưu tiên theo mức độ.
              </p>
            </div>

            <ActionIconButton
              icon={DASHBOARD_ICONS.view} label="Xem tất cả sự cố"
              onClick={() => navigate("/incidents")}
            />
          </div>

          {/* Không có sự cố */}

          {priorityIncidents.length === 0 ? (
            <div className="dashboard-success-box">
              Không có sự cố đang chờ xử lý.
            </div>
          ) : (
            <div className="dashboard-incident-list">
              {priorityIncidents.map((incident) => (
                <div
                  key={incident.id}
                  className="dashboard-incident-row"
                  onClick={() =>
                    navigate(
                      incident.status === "RESOLVED"
                        ? `/incidents/${incident.id}/verify`
                        : `/incidents/${incident.id}/resolve`
                    )
                  }
                >
                  {/* Nội dung sự cố */}

                  <div className="dashboard-incident-main">
                    <strong>
                      {incident.title || "Sự cố"}
                    </strong>

                    <span>
                      {incident.deviceCode || "-"}

                      {incident.deviceName
                        ? ` - ${incident.deviceName}`
                        : ""}
                    </span>

                    <small>
                      {formatDate(
                        incident.reportedAt
                      )}
                    </small>
                  </div>

                  {/* Severity */}

                  <span
                    className={`dashboard-severity severity-${(
                      incident.severity || "UNKNOWN"
                    ).toLowerCase()}`}
                  >
                    {getSeverityLabel(
                      incident.severity
                    )}
                  </span>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </>
  );
}