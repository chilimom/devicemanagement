import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  serverTimestamp,
  updateDoc,
  where,
} from "firebase/firestore";
import { useNavigate, useParams } from "react-router-dom";

import { db } from "../config/firebase";
import { invalidateAppCollection } from "../services/sharedCollectionCache";
import { isAdmin, type AppUser } from "../types/user";

interface AreaData {
  code?: string;
  name?: string;
  description?: string;
  status?: string;
}

export default function AreaEdit({ appUser }: { appUser: AppUser }) {
  const navigate = useNavigate();
  const { areaId } = useParams();

  const [code, setCode] = useState("");
  const [originalCode, setOriginalCode] = useState("");

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState("ACTIVE");

  const [deviceCount, setDeviceCount] = useState(0);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [error, setError] = useState("");

  // =========================================================
  // LOAD KHU VỰC + ĐẾM THIẾT BỊ
  // =========================================================

  useEffect(() => {
    async function loadArea() {
      if (!areaId) {
        setError("Không xác định được khu vực.");
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError("");

        // Lấy thông tin khu vực
        const areaRef = doc(db, "areas", areaId);
        const areaSnapshot = await getDoc(areaRef);

        if (!areaSnapshot.exists()) {
          setError("Không tìm thấy khu vực.");
          return;
        }

        const data = areaSnapshot.data() as AreaData;

        const currentCode = data.code || "";

        setCode(currentCode);
        setOriginalCode(currentCode);

        setName(data.name || "");
        setDescription(data.description || "");
        setStatus(data.status || "ACTIVE");

        // Đếm thiết bị đang thuộc khu vực này
        const deviceQuery = query(
          collection(db, "devices"),
          where("areaId", "==", areaId)
        );

        const deviceSnapshot = await getDocs(deviceQuery);

        setDeviceCount(deviceSnapshot.size);
      } catch (err) {
        console.error("Lỗi tải khu vực:", err);

        setError(
          "Không thể tải thông tin khu vực."
        );
      } finally {
        setLoading(false);
      }
    }

    loadArea();
  }, [areaId]);

  // =========================================================
  // SAVE
  // =========================================================

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();

    if (!areaId) {
      setError("Không xác định được khu vực.");
      return;
    }

    const normalizedCode =
      code.trim().toUpperCase();

    const normalizedName =
      name.trim();

    const normalizedDescription =
      description.trim();

    if (!normalizedCode) {
      setError("Vui lòng nhập mã khu vực.");
      return;
    }

    if (!normalizedName) {
      setError("Vui lòng nhập tên khu vực.");
      return;
    }

    // =====================================================
    // KHÔNG CHO NGỪNG KHU VỰC CÒN THIẾT BỊ
    // =====================================================

    if (
      status === "INACTIVE" &&
      deviceCount > 0
    ) {
      setError(
        `Không thể ngừng sử dụng khu vực ${normalizedCode} vì hiện còn ${deviceCount} thiết bị. Hãy chuyển thiết bị sang khu vực khác trước.`
      );

      return;
    }

    try {
      setSaving(true);
      setError("");

      // =====================================================
      // NẾU ĐỔI MÃ → KIỂM TRA TRÙNG
      // =====================================================

      if (isAdmin(appUser) && normalizedCode !== originalCode) {
        const duplicateQuery = query(
          collection(db, "areas"),
          where("code", "==", normalizedCode)
        );

        const duplicateSnapshot =
          await getDocs(duplicateQuery);

        const duplicated =
          duplicateSnapshot.docs.some(
            (item) => item.id !== areaId
          );

        if (duplicated) {
          setError(
            `Mã khu vực ${normalizedCode} đã tồn tại.`
          );

          return;
        }
      }

      // =====================================================
      // UPDATE FIRESTORE
      // =====================================================

      const areaRef = doc(
        db,
        "areas",
        areaId
      );

      await updateDoc(areaRef, {
        code: normalizedCode,
        name: normalizedName,
        description: normalizedDescription,
        status,
        updatedAt: serverTimestamp(),
      });

      invalidateAppCollection("areas");

      navigate("/areas");
    } catch (err) {
      console.error(
        "Lỗi cập nhật khu vực:",
        err
      );

      setError(
        "Không thể cập nhật khu vực. Vui lòng thử lại."
      );
    } finally {
      setSaving(false);
    }
  }

  // =========================================================
  // LOADING
  // =========================================================

  if (loading) {
    return (
      <p>Đang tải thông tin khu vực...</p>
    );
  }

  // =========================================================
  // VIEW
  // =========================================================

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Chỉnh sửa khu vực</h1>

          <p className="page-subtitle">
            Cập nhật thông tin và trạng thái khu vực.
          </p>
        </div>
      </div>

      <section className="panel area-form-panel">

        {error && !code ? (
          <>
            <div className="form-error">
              {error}
            </div>

            <button
              type="button"
              className="btn-secondary"
              onClick={() =>
                navigate("/areas")
              }
            >
              ← Quay lại danh sách khu vực
            </button>
          </>
        ) : (
          <form
            className="area-form"
            onSubmit={handleSubmit}
          >
            {error && (
              <div className="form-error">
                {error}
              </div>
            )}

            {/* MÃ KHU VỰC */}

            <div className="form-group">
              <label>
                Mã khu vực <span>*</span>
              </label>

              <input
                type="text"
            value={code}
            disabled={!isAdmin(appUser)}
                maxLength={30}
                placeholder="Ví dụ: LG1"
                onChange={(e) =>
                  setCode(
                    e.target.value.toUpperCase()
                  )
                }
              />

              <small>
                Mã khu vực phải duy nhất trong hệ thống.
                Chỉ thay đổi khi thực sự cần thiết.
              </small>
            </div>

            {/* TÊN */}

            <div className="form-group">
              <label>
                Tên khu vực <span>*</span>
              </label>

              <input
                type="text"
                value={name}
                maxLength={150}
                placeholder="Ví dụ: PX. Luyện Gang 1"
                onChange={(e) =>
                  setName(e.target.value)
                }
              />
            </div>

            {/* MÔ TẢ */}

            <div className="form-group">
              <label>Mô tả</label>

              <textarea
                value={description}
                rows={4}
                placeholder="Nhập mô tả khu vực..."
                onChange={(e) =>
                  setDescription(e.target.value)
                }
              />
            </div>

            {/* SỐ THIẾT BỊ */}

            <div className="area-device-info">
              <span>Thiết bị thuộc khu vực</span>

              <strong>{deviceCount}</strong>
            </div>

            {/* TRẠNG THÁI */}

            <div className="form-group">
              <label>Trạng thái</label>

              <select
                value={status}
                onChange={(e) =>
                  setStatus(e.target.value)
                }
              >
                <option value="ACTIVE">
                  Hoạt động
                </option>

                <option value="INACTIVE">
                  Ngừng sử dụng
                </option>
              </select>

              {status === "INACTIVE" &&
                deviceCount === 0 && (
                  <div className="area-status-warning">
                    Khu vực sẽ được chuyển sang trạng thái
                    ngừng sử dụng. Dữ liệu lịch sử vẫn được
                    giữ nguyên.
                  </div>
                )}

              {status === "INACTIVE" &&
                deviceCount > 0 && (
                  <div className="area-status-danger">
                    Không thể ngừng sử dụng khu vực này vì
                    hiện còn{" "}
                    <strong>
                      {deviceCount} thiết bị
                    </strong>
                    . Hãy chuyển các thiết bị sang khu vực
                    khác trước.
                  </div>
                )}
            </div>

            {/* ACTION */}

            <div className="form-actions">
              <button
                type="button"
                className="btn-secondary"
                disabled={saving}
                onClick={() =>
                  navigate("/areas")
                }
              >
                Hủy
              </button>

              <button
                type="submit"
                className="primary-button"
                disabled={
                  saving ||
                  (status === "INACTIVE" &&
                    deviceCount > 0)
                }
              >
                {saving
                  ? "Đang lưu..."
                  : "Lưu thay đổi"}
              </button>
            </div>
          </form>
        )}

      </section>
    </>
  );
}
