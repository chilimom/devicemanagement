import { useEffect, useState } from "react";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  query,
  serverTimestamp,
  updateDoc,
} from "firebase/firestore";
import { useNavigate } from "react-router-dom";

import { db } from "../config/firebase";
import ActionIconButton from "../components/ActionIconButton";
import { showAppAlert } from "../services/appDialog";
import type { AppUser } from "../types/user";
import "../styles/MaintenanceTypeCreate.css";

interface FirestoreTimestamp {
  toDate(): Date;
  toMillis(): number;
}

type Category = "PLANNED" | "CORRECTIVE";

interface MaintenanceType {
  id: string;
  code?: string;
  name?: string;
  description?: string;
  isActive?: boolean;
  tasks?: string[];
  scheduleValue?: number;
  scheduleUnit?: string;
  createdAt?: FirestoreTimestamp;
  category?: Category;
  areaIds?: string[];
}

interface AreaOption {
  id: string;
  code?: string;
  name?: string;
}

interface MaintenanceTypeCreateProps {
  appUser: AppUser;
}

const CODE_PATTERN = /^[A-Z0-9_]+$/;
const LIST_PATH = "/maintenances";

/* Icon dùng trong trang (ActionIconButton).
   back/add/delete/edit đã dùng được trong dự án;
   "save" cần có trong ActionIconButton - nếu tên khác thì đổi tại đây. */
const ICONS = {
  back: "back",
  add: "add",
  remove: "delete",
  edit: "edit",
  save: "save", // chưa dùng trực tiếp: xem getSaveIcon bên dưới
} as const;

// Dùng icon đã có sẵn: thêm mới -> "add", cập nhật -> "edit"
// (đổi sang "save" khi ActionIconButton có icon này).
const getSaveIcon = (isEditing: boolean) => (isEditing ? ICONS.edit : ICONS.add);

export default function MaintenanceTypeCreate({ appUser }: MaintenanceTypeCreateProps) {
  const navigate = useNavigate();

  const [types, setTypes] = useState<MaintenanceType[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");

  // State cho form
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [isActive, setIsActive] = useState(true);
  const [tasks, setTasks] = useState<string[]>([""]);
  const [scheduleValue, setScheduleValue] = useState<number | "">(1);
  const [scheduleUnit, setScheduleUnit] = useState<string>("MONTH");
  const [category, setCategory] = useState<Category>("PLANNED");
  const [areas, setAreas] = useState<AreaOption[]>([]);
  const [areaIds, setAreaIds] = useState<string[]>([]);

  const [formError, setFormError] = useState("");
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const isAdmin = appUser.role === "ADMIN";

  async function loadTypes() {
    try {
      setLoading(true);
      setLoadError("");
      const snapshot = await getDocs(query(collection(db, "maintenanceTypes")));
      setTypes(
        snapshot.docs.map((item) => ({
          id: item.id,
          ...item.data(),
        })) as MaintenanceType[],
      );
    } catch (err: any) {
      console.error("LỖI LOAD DATA:", err);
      setLoadError(`Không thể tải danh sách loại bảo trì. Lỗi: ${err.message}`);
    } finally {
      setLoading(false);
    }
  }

  async function loadAreas() {
    try {
      if (isAdmin) {
        const snap = await getDocs(collection(db, "areas"));
        setAreas(
          snap.docs.map((d) => ({ id: d.id, ...d.data() })) as AreaOption[],
        );
        return;
      }

      // AREA_ADMIN: đọc từng khu vực theo ID trong profile
      const ids = appUser.areaIds ?? [];
      const snaps = await Promise.all(
        ids.map((id) => getDoc(doc(db, "areas", id))),
      );
      setAreas(
        snaps
          .filter((s) => s.exists())
          .map((s) => ({ id: s.id, ...s.data() })) as AreaOption[],
      );
    } catch (err) {
      console.error("LỖI LOAD AREAS:", err);
    }
  }

  useEffect(() => {
    void loadTypes();
    void loadAreas();
  }, []);

  function resetForm() {
    setCode("");
    setName("");
    setDescription("");
    setIsActive(true);
    setTasks([""]);
    setCategory("PLANNED");
    setScheduleValue(1);
    setScheduleUnit("MONTH");
    setAreaIds([]);
    setFormError("");
    setEditingId(null);
  }

  function formatDate(timestamp?: FirestoreTimestamp | null) {
    if (!timestamp?.toDate) return "-";
    return timestamp.toDate().toLocaleString("vi-VN");
  }

  // Chỉ để ẩn/hiện nút. Rules Firestore mới là lớp chặn thật.
  function canManageType(item: MaintenanceType) {
    if (isAdmin) return true;
    if (appUser.role !== "AREA_ADMIN") return false;
    const typeAreas = item.areaIds ?? [];
    return (
      typeAreas.length > 0 &&
      typeAreas.every((id) => appUser.areaIds?.includes(id))
    );
  }

  function startEdit(item: MaintenanceType) {
    if (!canManageType(item)) return;
    setEditingId(item.id);
    setCode(item.code ?? "");
    setName(item.name ?? "");
    setDescription(item.description ?? "");
    setIsActive(item.isActive !== false);
    setCategory(item.category ?? "PLANNED");
    setTasks(item.tasks && item.tasks.length > 0 ? item.tasks : [""]);
    setScheduleValue(item.scheduleValue || 1);
    setScheduleUnit(item.scheduleUnit || "MONTH");
    setAreaIds(item.areaIds ?? []);
    setFormError("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    setFormError("");

    const normalizedCode = code.trim().toUpperCase();
    const validTasks = tasks.map((t) => t.trim()).filter((t) => t !== "");

    if (!normalizedCode || !name.trim()) {
      setFormError("Vui lòng nhập mã và tên loại bảo trì.");
      return;
    }

    if (!CODE_PATTERN.test(normalizedCode)) {
      setFormError("Mã loại chỉ được chứa chữ in hoa, số và dấu gạch dưới (VD: PREVENTIVE).");
      return;
    }

    if (!isAdmin && areaIds.length === 0) {
      setFormError("Vui lòng chọn ít nhất một khu vực áp dụng.");
      return;
    }

    if (
      types.some(
        (item) =>
          item.id !== editingId && item.code?.toUpperCase() === normalizedCode,
      )
    ) {
      setFormError(`Mã loại "${normalizedCode}" đã tồn tại.`);
      return;
    }

    try {
      setSaving(true);

      const payload = {
        code: normalizedCode,
        name: name.trim(),
        description: description.trim(),
        isActive,
        category,
        tasks: validTasks,
        areaIds, // ADMIN để rỗng = dùng chung toàn hệ thống
        scheduleValue: category === "PLANNED" ? Number(scheduleValue) || 0 : 0,
        scheduleUnit,
      };

      if (editingId) {
        await updateDoc(doc(db, "maintenanceTypes", editingId), {
          ...payload,
          updatedByUid: appUser.uid,
          updatedAt: serverTimestamp(),
        });
        await showAppAlert("Đã cập nhật loại bảo trì.", { tone: "success" });
      } else {
        await addDoc(collection(db, "maintenanceTypes"), {
          ...payload,
          createdByUid: appUser.uid,
          createdAt: serverTimestamp(),
        });
        await showAppAlert("Đã thêm loại bảo trì.", { tone: "success" });
      }

      resetForm();
      await loadTypes();
    } catch (err: any) {
      console.error(err);
      await showAppAlert(`Không thể lưu loại bảo trì. Lỗi: ${err.message}`, {
        tone: "error",
      });
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(item: MaintenanceType) {
    if (!canManageType(item)) return;

    const ok = window.confirm(
      `Xóa loại bảo trì "${item.code} - ${item.name}"?\n\n` +
        "Các phiếu bảo trì đã tạo vẫn giữ nguyên tên loại đã lưu. " +
        'Thao tác này không thể hoàn tác. Nếu chỉ muốn ngừng sử dụng, hãy chọn Sửa rồi bỏ tick "Đang hoạt động".',
    );
    if (!ok) return;

    try {
      setDeletingId(item.id);
      await deleteDoc(doc(db, "maintenanceTypes", item.id));
      if (editingId === item.id) resetForm();
      await showAppAlert("Đã xóa loại bảo trì.", { tone: "success" });
      await loadTypes();
    } catch (err: any) {
      console.error(err);
      await showAppAlert(`Không thể xóa loại bảo trì. Lỗi: ${err.message}`, {
        tone: "error",
      });
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div className="maintenance-type-page">
      {/* HEADER */}
      <div className="page-header">
        <div>
          <h1>{editingId ? "Sửa loại bảo trì" : "Thêm loại bảo trì"}</h1>
          <p className="page-subtitle">
            Tạo danh mục loại bảo trì dùng cho phiếu bảo trì thiết bị
          </p>
        </div>

        <div className="device-header-actions">
          <ActionIconButton
            icon={ICONS.back}
            label="Quay lại danh sách bảo trì"
            type="button"
            onClick={() => navigate(LIST_PATH)}
          />
        </div>
      </div>

      {/* FORM THÊM / SỬA */}
      <section className="panel">
        <form onSubmit={handleSubmit} className="form-grid">
          <label>
            <span className="field-label">
              Mã loại <span className="required">*</span>
            </span>
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="VD: PREVENTIVE"
              disabled={saving || Boolean(editingId)}
            />
          </label>

          <label>
            <span className="field-label">
              Tên hiển thị <span className="required">*</span>
            </span>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="VD: Bảo trì định kỳ"
              disabled={saving}
            />
          </label>

          <label className="form-grid-full">
            <span className="field-label">Mô tả</span>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Mô tả ngắn về loại bảo trì này"
              rows={3}
              disabled={saving}
            />
          </label>

          <label>
            <span className="field-label">
              Nhóm bảo trì <span className="required">*</span>
            </span>
            <select
              className="form-select"
              value={category}
              onChange={(e) => setCategory(e.target.value as Category)}
              disabled={saving}
            >
              <option value="PLANNED">Có kế hoạch (định kỳ)</option>
              <option value="CORRECTIVE">Khắc phục (từ tuần kiểm / sự cố)</option>
            </select>
          </label>

          {/* LỊCH BẢO TRÌ: chỉ nhóm có kế hoạch */}
          {category === "PLANNED" && (
            <div className="form-grid-full schedule-section">
              <label className="schedule-label">Lịch bảo trì định kỳ</label>
              <div className="schedule-inputs">
                <input
                  type="number"
                  min="1"
                  value={scheduleValue}
                  onChange={(e) =>
                    setScheduleValue(e.target.value === "" ? "" : Number(e.target.value))
                  }
                  placeholder="Số lượng..."
                  disabled={saving}
                  className="schedule-number"
                />
                <select
                  value={scheduleUnit}
                  onChange={(e) => setScheduleUnit(e.target.value)}
                  disabled={saving}
                  className="schedule-select"
                >
                  <option value="DAY">Ngày</option>
                  <option value="WEEK">Tuần</option>
                  <option value="MONTH">Tháng</option>
                  <option value="YEAR">Năm</option>
                </select>
                <span className="schedule-hint">
                  (Khoảng thời gian giữa các lần bảo trì)
                </span>
              </div>
            </div>
          )}

          {/* DANH SÁCH CÔNG VIỆC */}
          <div className="form-grid-full task-section">
            <div className="task-section-header">
              <h3>Danh sách công việc (Checklist)</h3>
              <ActionIconButton
                icon={ICONS.add}
                label="Thêm công việc"
                type="button"
                onClick={() => setTasks([...tasks, ""])}
                disabled={saving}
              />
            </div>

            <div className="task-list">
              {tasks.length === 0 ? (
                <div className="empty-task-text">
                  Chưa có công việc nào. Bấm "Thêm công việc" để bắt đầu.
                </div>
              ) : (
                tasks.map((task, index) => (
                  <div key={index} className="task-item">
                    <input
                      type="text"
                      value={task}
                      onChange={(e) => {
                        const newTasks = [...tasks];
                        newTasks[index] = e.target.value;
                        setTasks(newTasks);
                      }}
                      placeholder={`Công việc ${index + 1} (VD: Vệ sinh máy)`}
                      disabled={saving}
                    />
                    <ActionIconButton
                      icon={ICONS.remove}
                      label="Xóa công việc"
                      type="button"
                      onClick={() => setTasks(tasks.filter((_, i) => i !== index))}
                      disabled={saving}
                    />
                  </div>
                ))
              )}
            </div>
          </div>

          {/* KHU VỰC ÁP DỤNG */}
          <div className="form-grid-full">
            <span className="field-label">
              Khu vực áp dụng {!isAdmin && <span className="required">*</span>}
            </span>
            <div className="area-picker">
              {areas.map((a) => (
                <label key={a.id} className="area-option">
                  <input
                    type="checkbox"
                    checked={areaIds.includes(a.id)}
                    disabled={saving}
                    onChange={(e) =>
                      setAreaIds(
                        e.target.checked
                          ? [...areaIds, a.id]
                          : areaIds.filter((x) => x !== a.id),
                      )
                    }
                  />
                  {a.name || a.code || a.id}
                </label>
              ))}
            </div>
            {isAdmin && (
              <span className="schedule-hint">
                (Để trống = dùng chung toàn hệ thống)
              </span>
            )}
          </div>

          <label className="checkbox-label form-grid-full">
            <input
              type="checkbox"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
              disabled={saving}
            />
            Đang hoạt động
          </label>

          {formError && <div className="form-error form-grid-full">{formError}</div>}

          <div className="form-actions form-grid-full">
            <ActionIconButton
              icon={ICONS.back}
              label={editingId ? "Hủy sửa" : "Hủy"}
              type="button"
              onClick={editingId ? resetForm : () => navigate(LIST_PATH)}
              disabled={saving}
            />

            <ActionIconButton
              icon={getSaveIcon(Boolean(editingId))}
              label={
                saving
                  ? "Đang lưu..."
                  : editingId
                    ? "Cập nhật loại bảo trì"
                    : "Lưu loại bảo trì"
              }
              type="submit"
              disabled={saving}
            />
          </div>
        </form>
      </section>

      {/* DANH SÁCH LOẠI BẢO TRÌ HIỆN CÓ */}
      <section className="panel">
        <h2>Danh sách loại bảo trì</h2>

        {loadError && <div className="form-error">{loadError}</div>}

        {loading ? (
          <p>Đang tải danh sách loại bảo trì...</p>
        ) : types.length === 0 ? (
          <div className="empty-history">Chưa có loại bảo trì nào.</div>
        ) : (
          <div className="table-wrapper">
            <table className="device-table">
              <thead>
                <tr>
                  <th>Mã loại</th>
                  <th>Tên hiển thị</th>
                  <th>Nhóm</th>
                  <th>Chu kỳ</th>
                  <th>Số công việc</th>
                  <th>Trạng thái</th>
                  <th>Ngày tạo</th>
                  <th>Thao tác</th>
                </tr>
              </thead>
              <tbody>
                {types.map((item) => (
                  <tr
                    key={item.id}
                    className={editingId === item.id ? "row-editing" : ""}
                  >
                    <td>
                      <strong>{item.code || "-"}</strong>
                    </td>
                    <td>{item.name || "-"}</td>
                    <td>
                      {item.category === "CORRECTIVE" ? (
                        <span className="category-badge category-corrective">
                          Khắc phục
                        </span>
                      ) : (
                        <span className="category-badge category-planned">
                          Có kế hoạch
                        </span>
                      )}
                    </td>
                    <td>
                      {item.scheduleValue ? (
                        <span className="type-cycle">
                          {item.scheduleValue}{" "}
                          {item.scheduleUnit === "DAY" && "Ngày"}
                          {item.scheduleUnit === "WEEK" && "Tuần"}
                          {item.scheduleUnit === "MONTH" && "Tháng"}
                          {item.scheduleUnit === "YEAR" && "Năm"}
                        </span>
                      ) : (
                        "-"
                      )}
                    </td>
                    <td>
                      <span className="type-task-count">
                        {item.tasks?.length || 0}
                      </span>{" "}
                      công việc
                    </td>
                    <td>
                      {item.isActive ? (
                        <span className="maintenance-approval-complete">
                          Đang hoạt động
                        </span>
                      ) : (
                        <span className="maintenance-approval-status">Tạm ẩn</span>
                      )}
                    </td>
                    <td>{formatDate(item.createdAt)}</td>
                    <td>
                      {canManageType(item) ? (
                        <div className="row-actions">
                          
                          <ActionIconButton
                            icon={ICONS.edit}
                            label="Sửa"
                            onClick={() => startEdit(item)}
                            disabled={saving || deletingId === item.id}
                          />
                          <ActionIconButton
                            icon={ICONS.remove}
                            label={deletingId === item.id ? "Đang xóa..." : "Xóa"}
                            onClick={() => handleDelete(item)}
                            disabled={saving || deletingId === item.id}
                          />
                        </div>
                      ) : (
                        <span className="schedule-hint">-</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}