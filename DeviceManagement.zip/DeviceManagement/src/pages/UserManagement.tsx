import { useEffect, useMemo, useState, type FormEvent } from "react";
import { AccountServiceError, setActiveViaService, setPasswordViaService } from "../services/accountAdminService";
import { collection, doc, getDoc, getDocs } from "firebase/firestore";
import { db } from "../config/firebase";
import { updateManagedUser } from "../services/userManagementService";
import { showAppConfirm } from "../services/appDialog";
import {
  loadDirectManageableUsers,
  provisionAccount,
  ProvisioningIncompleteError,
  ProvisioningStepError,
  type ProvisioningAttempt,
} from "../services/directAccountProvisioning";
import type { AppUser, UserRole } from "../types/user";
import { isAdmin } from "../types/user";
import ActionIconButton from "../components/ActionIconButton";
import "../styles/user-management.css";

interface AreaOption { id: string; name: string }

export default function UserManagement({ appUser }: { appUser: AppUser }) {
  const [users, setUsers] = useState<AppUser[]>([]);
  const [attempts, setAttempts] = useState<ProvisioningAttempt[]>([]);
  const [areas, setAreas] = useState<AreaOption[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [areasLoading, setAreasLoading] = useState(true);
  const [areasError, setAreasError] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [saving, setSaving] = useState(false);
  const [resettingPasswordUid, setResettingPasswordUid] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<AppUser | null>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [newAdminPassword, setNewAdminPassword] = useState("");
  const [confirmAdminPassword, setConfirmAdminPassword] = useState("");
  const [showAdminPassword, setShowAdminPassword] = useState(false);
  const [adminPasswordNotice, setAdminPasswordNotice] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [role, setRole] = useState<UserRole>("USER");
  const [areaIds, setAreaIds] = useState<string[]>([]);

  async function reload() {
    setLoading(true); setAreasLoading(true); setAreasError(""); setError("");
    const managedPromise = loadDirectManageableUsers(appUser)
      .then((managed) => { setUsers(managed.users); setAttempts(managed.attempts); })
      .catch((cause: unknown) => {
        const code = firebaseErrorCode(cause);
        setError(code === "permission-denied"
          ? "Không có quyền tải danh sách tài khoản/provisioning. Cần đối chiếu Firestore Rules đang triển khai."
          : `Không thể tải dữ liệu quản lý người dùng (${code}).`);
      })
      .finally(() => setLoading(false));
    const areasPromise = (isAdmin(appUser)
      ? getDocs(collection(db, "areas")).then((snapshot) => snapshot.docs.map((item) => ({
          id: item.id, name: String(item.data().name ?? item.id),
        })))
      : Promise.all(appUser.areaIds.map(async (id) => {
          const snapshot = await getDoc(doc(db, "areas", id));
          return snapshot.exists() ? { id, name: String(snapshot.data().name ?? id) } : null;
        })).then((items) => items.filter((item): item is AreaOption => item !== null)))
      .then((areaOptions) => {
        setAreas(areaOptions);
        if (areaOptions.length === 0) setAreasError("Không tìm thấy xưởng hợp lệ để phân quyền.");
      })
      .catch((cause: unknown) => {
        setAreas([]);
        const code = firebaseErrorCode(cause);
        setAreasError(code === "permission-denied"
          ? "Không có quyền tải danh sách xưởng. Cần đối chiếu Firestore Rules đang triển khai."
          : `Không thể tải danh sách xưởng (${code}).`);
      })
      .finally(() => setAreasLoading(false));
    await Promise.allSettled([managedPromise, areasPromise]);
  }

  function firebaseErrorCode(cause: unknown): string {
    const raw = cause instanceof ProvisioningStepError
      ? cause.code
      : typeof cause === "object" && cause && "code" in cause
        ? String(cause.code)
        : cause instanceof Error
          ? cause.message
          : "unknown";
    return raw.replace(/^firestore\//, "");
  }

  function provisioningErrorMessage(cause: unknown): string {
    if (cause instanceof ProvisioningIncompleteError) {
      return `Firebase Auth đã tạo tài khoản (UID: ${cause.uid}) nhưng bước ghi profile/kích hoạt thất bại (${cause.code}). Không tạo lại Auth account; hãy thử lại đúng email để chỉ retry profile.`;
    }
    const code = firebaseErrorCode(cause);
    const step = cause instanceof ProvisioningStepError ? cause.step : "VALIDATE";
    if (code.includes("email-already-in-use")) return "Bước Firebase Auth thất bại: email đăng nhập đã tồn tại.";
    if (code.includes("weak-password") || code === "INVALID_PASSWORD") return "Bước kiểm tra mật khẩu thất bại: mật khẩu phải có ít nhất 6 ký tự.";
    if (code.includes("operation-not-allowed")) return "Bước Firebase Auth thất bại: phương thức Email/Password chưa được bật.";
    if (code.includes("failed-precondition")) return `Bước ${step} thất bại do điều kiện Firebase chưa đáp ứng.`;
    if (code.includes("permission-denied")) return `Bước ${step} bị Firestore Rules từ chối. Cần đối chiếu Rules đang triển khai với repository.`;
    if (code === "INVALID_ACCOUNT_DATA") return "Dữ liệu chưa hợp lệ: cần email, họ tên và ít nhất một xưởng.";
    if (code === "OUTSIDE_MANAGEMENT_SCOPE") return "Xưởng hoặc vai trò nằm ngoài phạm vi được quản lý.";
    if (code === "PASSWORD_MISMATCH") return "Xác nhận mật khẩu không khớp.";
    if (code === "ACCOUNT_ALREADY_PROVISIONED") return "Email này đã hoàn tất provisioning.";
    if (code === "PROVISIONING_REQUIRES_CONSOLE_REVIEW") return "Provisioning trước đó chưa hoàn tất và cần được đối chiếu trước khi thử lại.";
    return `Bước ${step} thất bại (${code}).`;
  }

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void reload();
  }, [appUser]); // eslint-disable-line react-hooks/exhaustive-deps

  const filteredUsers = useMemo(() => {
    const keyword = search.trim().toLowerCase();
    return users.filter((user) => `${user.displayName} ${user.email}`.toLowerCase().includes(keyword));
  }, [users, search]);

  function toggleArea(id: string) {
    setAreaIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  }
  function startEdit(user: AppUser) {
    setEditing(user); setEmail(user.email); setDisplayName(user.displayName);
    setRole(user.role); setAreaIds(user.areaIds); setError(""); setNotice("");
    setNewAdminPassword(""); setConfirmAdminPassword(""); setShowAdminPassword(false);
    setAdminPasswordNotice(""); setFormOpen(true);
  }
  function resetForm() {
    setEditing(null); setEmail(""); setPassword(""); setConfirmPassword("");
    setShowPassword(false); setNewAdminPassword(""); setConfirmAdminPassword("");
    setShowAdminPassword(false); setAdminPasswordNotice("");
    setDisplayName(""); setRole("USER"); setAreaIds([]); setFormOpen(false);
  }
  function openCreateForm() {
    setEditing(null); setEmail(""); setPassword(""); setConfirmPassword("");
    setShowPassword(false); setNewAdminPassword(""); setConfirmAdminPassword("");
    setShowAdminPassword(false); setAdminPasswordNotice("");
    setDisplayName(""); setRole("USER"); setAreaIds([]);
    setError(""); setNotice(""); setFormOpen(true);
  }
  async function submit(event: FormEvent) {
    event.preventDefault(); setError(""); setNotice(""); setSaving(true);
    try {
      if (editing) {
        await updateManagedUser(editing.uid, { ...editing, displayName, role, areaIds, isActive: editing.isActive });
      } else {
        if (role === "ADMIN") throw new Error("INVALID_ACCOUNT_ROLE");
        const pendingProfile = attempts.some((attempt) =>
          attempt.email === email.trim().toLowerCase()
          && attempt.status === "AUTH_CREATED_PROFILE_PENDING"
          && Boolean(attempt.targetUid));
        if (!pendingProfile) {
          if (password.length < 6) throw new Error("INVALID_PASSWORD");
          if (password !== confirmPassword) throw new Error("PASSWORD_MISMATCH");
        }
        const result = await provisionAccount(appUser, {
          email,
          displayName,
          role: role as "USER" | "AREA_ADMIN",
          areaIds,
          password: pendingProfile ? undefined : password,
        });
        setNotice(result.resumedProfile
          ? `Đã hoàn tất profile còn dở cho ${result.email}.`
          : `Đã tạo tài khoản ${result.email}.`);
      }
      resetForm(); await reload();
    } catch (cause) {
      setError(provisioningErrorMessage(cause));
    } finally {
      setPassword("");
      setConfirmPassword("");
      setSaving(false);
    }
  }
  async function toggleActive(user: AppUser) {
  try {
    if (isAdmin(appUser)) await setActiveViaService(user.uid, !user.isActive);
    else await updateManagedUser(user.uid, { ...user, isActive: !user.isActive });
    await reload();
  } catch (cause) {
    console.error(cause);
    setError(isAdmin(appUser) ? accountServiceErrorMessage(cause) : "Không thể thay đổi trạng thái tài khoản.");
  }
}
  function accountServiceErrorMessage(cause: unknown): string {
  if (cause instanceof AccountServiceError) {
    if (cause.message === "SERVICE_UNREACHABLE") return "Không kết nối được service quản trị (127.0.0.1:9000). Hãy bật service trên máy này.";
    if (cause.message === "LOCAL_SERVICE_REQUIRES_LOCAL_UI") return "Thao tác quản trị này chỉ dùng trong giao diện local. Hãy mở ứng dụng bằng máy chủ phát triển nội bộ rồi thử lại.";
    if (cause.status === 401) return "Phiên đăng nhập không hợp lệ hoặc đã hết hạn. Hãy đăng nhập lại.";
    if (cause.status === 403) return "Không đủ quyền thực hiện thao tác này.";
    if (cause.status === 404) return "Không tìm thấy tài khoản.";
    if (cause.status === 429) return "Thao tác quá nhiều lần, vui lòng thử lại sau.";
    return `Service quản trị trả lỗi: ${cause.message}`;
  }
  return "Không thể thực hiện thao tác.";
}

async function adminResetPassword() {
  if (
    !editing || !isAdmin(appUser) || editing.uid === appUser.uid ||
    editing.role === "ADMIN" || resettingPasswordUid
  ) return;
  if (newAdminPassword.length < 6) {
    setError("Mật khẩu mới phải có ít nhất 6 ký tự.");
    return;
  }
  if (newAdminPassword !== confirmAdminPassword) {
    setError("Xác nhận mật khẩu mới không khớp.");
    return;
  }
  if (!await showAppConfirm(
    `Đổi mật khẩu cho ${editing.email}? Các phiên đăng nhập hiện tại của tài khoản sẽ bị thu hồi.`,
    { confirmLabel: "Đổi mật khẩu" },
  )) return;

  setError(""); setAdminPasswordNotice("");
  setResettingPasswordUid(editing.uid);
  try {
    await setPasswordViaService(editing.uid, newAdminPassword);
    setNewAdminPassword("");
    setConfirmAdminPassword("");
    setAdminPasswordNotice(`Đã đổi mật khẩu cho ${editing.email}.`);
  } catch (cause) {
    setError(accountServiceErrorMessage(cause));
  } finally {
    setResettingPasswordUid("");
  }
}
  const areaName = (id: string) => areas.find((area) => area.id === id)?.name ?? id;

  return <main className="user-management-page">
    <header className="user-management-header">
      <div>
        <h1>Quản lý người dùng</h1>
        <p>Quản lý phân quyền theo xưởng và quyền truy cập ứng dụng.</p>
      </div>
      <button className="user-management-button user-management-button-primary" type="button" onClick={openCreateForm}>+ Tạo tài khoản</button>
    </header>
    {!isAdmin(appUser) && <div className="user-management-info">Chỉ hiển thị USER được tạo trực tiếp bởi bạn trong phạm vi xưởng được giao.</div>}
    {error && !formOpen && <div className="user-management-alert user-management-alert-error">{error}</div>}
    {notice && <div className="user-management-alert user-management-alert-success">{notice}</div>}
    {formOpen && <div className="user-management-modal-backdrop" role="presentation" onMouseDown={(event) => {
      if (event.target === event.currentTarget && !saving) resetForm();
    }}>
      <section className="user-management-card user-management-form-card user-management-modal" role="dialog" aria-modal="true" aria-labelledby="user-account-form-title">
        <div className="user-management-card-heading">
          <div>
            <h2 id="user-account-form-title">{editing ? "Sửa tài khoản" : "Tạo tài khoản"}</h2>
            <p>{editing ? "Cập nhật thông tin và phạm vi được phân quyền." : "Nhập thông tin đăng nhập và chọn ít nhất một xưởng."}</p>
          </div>
          <button className="user-management-modal-close" type="button" onClick={resetForm} disabled={saving} aria-label="Đóng">×</button>
        </div>
        {error && <div className="user-management-alert user-management-alert-error user-management-modal-alert">{error}</div>}
        <form onSubmit={submit} className="user-management-form">
      <label className="user-management-field user-management-field-wide">
        <span>Email đăng nhập</span>
        <input required type="email" value={email} disabled={Boolean(editing)} placeholder="tennguoidung@congty.com"
          onChange={(event) => setEmail(event.target.value.trim().toLowerCase())} />
      </label>
      {!editing && !attempts.some((attempt) =>
        attempt.email === email.trim().toLowerCase()
        && attempt.status === "AUTH_CREATED_PROFILE_PENDING"
        && Boolean(attempt.targetUid)) && <>
        <label className="user-management-field"><span>Mật khẩu</span>
          <div className="user-management-password">
            <input required type={showPassword ? "text" : "password"} value={password}
              minLength={6} autoComplete="new-password"
              onChange={(event) => setPassword(event.target.value)} />
            <button className="user-management-password-toggle" type="button" onClick={() => setShowPassword((current) => !current)}>
              {showPassword ? "Ẩn" : "Hiện"}
            </button>
          </div>
        </label>
        <label className="user-management-field"><span>Xác nhận mật khẩu</span>
          <input required type={showPassword ? "text" : "password"} value={confirmPassword}
            minLength={6} autoComplete="new-password"
            onChange={(event) => setConfirmPassword(event.target.value)} />
        </label>
      </>}
      <label className="user-management-field"><span>Họ tên</span>
        <input required value={displayName} placeholder="Nhập họ tên" onChange={(event) => setDisplayName(event.target.value)} />
      </label>
      <label className="user-management-field"><span>Vai trò</span>
        <select value={role} onChange={(event) => setRole(event.target.value as UserRole)}>
          <option value="USER">USER</option>
          {isAdmin(appUser) && <option value="AREA_ADMIN">AREA_ADMIN</option>}
        </select>
      </label>
      <fieldset className="user-management-areas user-management-field-wide" disabled={areasLoading}>
        <legend>Xưởng được phân quyền</legend>
        {areasLoading && <p className="user-management-muted">Đang tải danh sách xưởng...</p>}
        {areasError && <p className="user-management-inline-error">{areasError}</p>}
        <div className="user-management-area-grid">{areas.map((area) => <label key={area.id}>
          <input type="checkbox" checked={areaIds.includes(area.id)} onChange={() => toggleArea(area.id)} />
          <span>{area.name}</span>
        </label>)}</div>
      </fieldset>
      {editing && isAdmin(appUser) && editing.uid !== appUser.uid && editing.role !== "ADMIN" && import.meta.env.DEV && <section className="user-management-password-reset user-management-field-wide">
        <h3>Đặt lại mật khẩu</h3>
        <p>Chỉ ADMIN có thể thay đổi mật khẩu. Các phiên đăng nhập hiện tại sẽ bị thu hồi.</p>
        {adminPasswordNotice && <div className="user-management-alert user-management-alert-success">{adminPasswordNotice}</div>}
        <label className="user-management-field"><span>Mật khẩu mới</span>
          <input type={showAdminPassword ? "text" : "password"} value={newAdminPassword} minLength={6} maxLength={128} autoComplete="new-password"
            onChange={(event) => setNewAdminPassword(event.target.value)} />
        </label>
        <label className="user-management-field"><span>Xác nhận mật khẩu mới</span>
          <input type={showAdminPassword ? "text" : "password"} value={confirmAdminPassword} minLength={6} maxLength={128} autoComplete="new-password"
            onChange={(event) => setConfirmAdminPassword(event.target.value)} />
        </label>
        <button className="user-management-password-toggle" type="button" onClick={() => setShowAdminPassword((current) => !current)}>
          {showAdminPassword ? "Ẩn mật khẩu" : "Hiện mật khẩu"}
        </button>
        <button className="user-management-button user-management-button-secondary" type="button"
          disabled={Boolean(resettingPasswordUid) || newAdminPassword.length < 6 || newAdminPassword !== confirmAdminPassword}
          onClick={() => void adminResetPassword()}>
          {resettingPasswordUid === editing.uid ? "Đang cập nhật..." : "Đặt lại mật khẩu"}
        </button>
      </section>}
      <div className="user-management-form-actions user-management-field-wide">
        <button className="user-management-button user-management-button-primary" type="submit" disabled={saving || areasLoading || Boolean(areasError) || areaIds.length === 0}>{saving ? "Đang xử lý..." : editing ? "Lưu thay đổi" : "Tạo tài khoản"}</button>
        <button className="user-management-button user-management-button-secondary" type="button" onClick={resetForm}>Hủy</button>
      </div>
        </form>
      </section>
    </div>}

    <section className="user-management-card">
      <div className="user-management-card-heading user-management-list-heading">
        <div><h2>Danh sách tài khoản</h2><p>{filteredUsers.length} tài khoản được hiển thị</p></div>
        <input className="user-management-search" value={search} placeholder="Tìm tên hoặc email..." onChange={(event) => setSearch(event.target.value)} />
      </div>
      <div className="user-management-table-wrap">
      {loading ? <div className="user-management-loading">Đang tải danh sách...</div> : <table className="user-management-table"><thead><tr>
      <th>Họ tên</th><th>Email</th><th>Vai trò</th><th>Trạng thái</th><th>Xưởng</th><th>Thao tác</th>
    </tr></thead><tbody>{filteredUsers.map((user) => <tr key={user.uid}>
      <td className="user-management-name">{user.displayName}</td><td>{user.email}</td><td><span className={`user-management-role user-management-role-${user.role.toLowerCase()}`}>{user.role}</span></td>
      <td><span className={`user-management-status ${user.isActive ? "is-active" : "is-inactive"}`}>{user.isActive ? "Đang hoạt động" : "Đã khóa"}</span></td>
      <td>{user.role === "ADMIN" ? "Toàn hệ thống" : user.areaIds.map(areaName).join(", ")}</td>
      <td><div className="user-management-row-actions">{user.uid !== appUser.uid && user.role !== "ADMIN" && <>
        <ActionIconButton icon="edit" label={`Sửa tài khoản ${user.displayName}`} onClick={() => startEdit(user)} />
        <ActionIconButton icon={user.isActive ? "deactivate" : "activate"} variant={user.isActive ? "danger" : "default"} label={`${user.isActive ? "Khóa" : "Mở khóa"} tài khoản ${user.displayName}`} onClick={() => void toggleActive(user)} />
      </>}</div></td>
    </tr>)}{filteredUsers.length === 0 && <tr><td className="user-management-empty" colSpan={6}>Không tìm thấy tài khoản phù hợp.</td></tr>}</tbody></table>}
      </div>
    </section>

    <section className="user-management-card">
      <div className="user-management-card-heading"><div><h2>Trạng thái tạo tài khoản</h2><p>Theo dõi các lần tạo tài khoản trực tiếp.</p></div></div>
      <div className="user-management-table-wrap"><table className="user-management-table"><thead><tr><th>Email</th><th>Vai trò</th><th>Xưởng</th><th>Trạng thái</th></tr></thead>
      <tbody>{attempts.map((attempt) => <tr key={attempt.email}><td>{attempt.email}</td><td>{attempt.role}</td>
        <td>{attempt.areaIds.map(areaName).join(", ")}</td><td><span className="user-management-provision-status">{attempt.status}</span></td></tr>)}
        {attempts.length === 0 && <tr><td className="user-management-empty" colSpan={4}>Chưa có dữ liệu tạo tài khoản.</td></tr>}</tbody></table></div>
    </section>
  </main>;
}
