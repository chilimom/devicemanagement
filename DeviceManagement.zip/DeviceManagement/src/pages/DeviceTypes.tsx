
import { useCallback, useEffect, useState, type FormEvent } from "react";
import {
  addDoc,
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  serverTimestamp,
  updateDoc,
  where,
} from "firebase/firestore";

import { db } from "../config/firebase";
import { invalidateAppCollection } from "../services/sharedCollectionCache";
import { showAppAlert, showAppConfirm } from "../services/appDialog";
import { PermanentDeletionBlockedError, permanentlyDeleteInactiveDeviceType } from "../services/permanentDeletionService";
import { isAdmin, type AppUser } from "../types/user";
import ActionIconButton from "../components/ActionIconButton";
import "../styles/device-types.css";

// =====================================================
// 1. ĐỊNH NGHĨA DỮ LIỆU
// =====================================================

interface DeviceCategory {
  id: string;
  code: string;
  name: string;
  status: string;
}

interface DeviceType {
  id: string;
  code: string;
  name: string;
  description: string;
  categoryId: string;
  isActive: boolean;
  areaIds: string[];
}

interface DeviceReference {
  deviceTypeId?: string;
  areaId?: string;
  isActive?: boolean;
}

interface AreaReference {
  id: string;
  name: string;
  code: string;
}

// =====================================================
// 2. COMPONENT CHÍNH
// =====================================================

export default function DeviceTypes({ appUser }: { appUser: AppUser }) {
  const [categories, setCategories] = useState<DeviceCategory[]>([]);
  const [types, setTypes] = useState<DeviceType[]>([]);
  const [devices, setDevices] = useState<DeviceReference[]>([]);
  const [areas, setAreas] = useState<AreaReference[]>([]);

  const [categoryId, setCategoryId] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [selectedAreaIds, setSelectedAreaIds] = useState<string[]>([]);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  // =====================================================
  // 3. TẢI DỮ LIỆU FIRESTORE
  // =====================================================

  const loadData = useCallback(async function loadData() {
    try {
      setLoading(true);

      const areaPromise = isAdmin(appUser)
        ? getDocs(collection(db, "areas")).then((snapshot) => snapshot.docs)
        : Promise.all(appUser.areaIds.map((id) => getDoc(doc(db, "areas", id))))
            .then((snapshots) => snapshots.filter((snapshot) => snapshot.exists()));
      const devicePromise = isAdmin(appUser)
        ? getDocs(collection(db, "devices")).then((snapshot) => snapshot.docs)
        : Promise.all(appUser.areaIds.map((id) =>
            getDocs(query(collection(db, "devices"), where("areaId", "==", id)))
          )).then((snapshots) => snapshots.flatMap((snapshot) => snapshot.docs));

      const [categorySnap, typeSnap, areaDocs, deviceDocs] =
        await Promise.all([
          getDocs(collection(db, "deviceCategories")),
          getDocs(collection(db, "deviceTypes")),
          areaPromise,
          devicePromise,
        ]);

      const categoryData = categorySnap.docs.map((item) => ({
        id: item.id,
        code: String(item.data().code || ""),
        name: String(item.data().name || ""),
        status: String(item.data().status || "ACTIVE"),
      }));

      const typeData = typeSnap.docs.map((item) => ({
        id: item.id,
        code: String(item.data().code || ""),
        name: String(item.data().name || ""),
        description: String(item.data().description || ""),
        categoryId: String(item.data().categoryId || ""),
        isActive: item.data().isActive !== false,
        areaIds: Array.isArray(item.data().areaIds)
          ? item.data().areaIds.filter((value: unknown): value is string => typeof value === "string")
          : [],
      }));

      const deviceData = deviceDocs.map((item) => ({
        deviceTypeId: item.data().deviceTypeId,
        areaId: item.data().areaId,
        isActive: item.data().isActive,
      }));

      const areaData = areaDocs.map((item) => ({
        id: item.id,
        name: String(item.data().name || item.id),
        code: String(item.data().code || ""),
      }));

      categoryData.sort((a, b) =>
        a.name.localeCompare(b.name, "vi")
      );

      typeData.sort((a, b) =>
        a.name.localeCompare(b.name, "vi")
      );

      setCategories(categoryData);
      setTypes(typeData);
      setDevices(deviceData);
      setAreas(areaData.sort((a, b) => a.name.localeCompare(b.name, "vi")));
    } catch (err) {
      console.error(err);
      setError("Không thể tải dữ liệu từ Firestore.");
    } finally {
      setLoading(false);
    }
  }, [appUser]);

  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      void loadData();
    });

    return () => window.cancelAnimationFrame(frame);
  }, [loadData]);

  // =====================================================
  // 4. LÀM MỚI BIỂU MẪU
  // =====================================================

  function resetForm() {
    setEditingId(null);
    setCategoryId("");
    setName("");
    setDescription("");
    setSelectedAreaIds([]);
    setFormOpen(false);
  }

  function openCreateForm() {
    setEditingId(null);
    setCategoryId("");
    setName("");
    setDescription("");
    setSelectedAreaIds([]);
    setError("");
    setMessage("");
    setFormOpen(true);
  }

  // =====================================================
  // 5. CHỌN LOẠI THIẾT BỊ ĐỂ SỬA
  // =====================================================

  function handleEdit(item: DeviceType) {
    if (!canManageType(item)) {
      setError("Bạn không có quyền sửa loại thiết bị ngoài phạm vi xưởng được giao.");
      return;
    }

    setEditingId(item.id);
    setCategoryId(item.categoryId);
    setName(item.name);
    setDescription(item.description);
    setSelectedAreaIds(item.areaIds);

    setError("");
    setMessage("");
    setFormOpen(true);
  }

  // =====================================================
  // 6. TẠO MÃ LOẠI THIẾT BỊ
  //
  // Document ID vẫn do Firestore tự sinh.
  // Code chỉ phục vụ hiển thị, tra cứu.
  // =====================================================

  function generateCode() {
    const date = Date.now().toString(36).toUpperCase();
    const random = Math.random()
      .toString(36)
      .substring(2, 7)
      .toUpperCase();

    return `TYPE-${date}-${random}`;
  }

  // =====================================================
  // 7. THÊM / CẬP NHẬT LOẠI THIẾT BỊ
  // =====================================================

  async function handleSave(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    setError("");
    setMessage("");

    const cleanName = name.trim();
    const cleanDescription = description.trim();
    const normalizedAreaIds = [...new Set(selectedAreaIds)].sort();

    if (!categoryId || !cleanName) {
      setError("Vui lòng chọn lĩnh vực và nhập tên loại thiết bị.");
      return;
    }

    if (!isAdmin(appUser) && (
      normalizedAreaIds.length === 0 ||
      normalizedAreaIds.some((id) => !appUser.areaIds.includes(id))
    )) {
      setError("AREA_ADMIN phải chọn ít nhất một xưởng trong phạm vi được giao.");
      return;
    }

    if (editingId) {
      const removedAreaIds = types.find((item) => item.id === editingId)?.areaIds
        .filter((id) => !normalizedAreaIds.includes(id)) ?? [];
      const hasActiveDeviceInRemovedArea = devices.some((device) =>
        device.deviceTypeId === editingId &&
        device.isActive !== false &&
        typeof device.areaId === "string" &&
        removedAreaIds.includes(device.areaId)
      );
      if (hasActiveDeviceInRemovedArea) {
        setError("Không thể bỏ xưởng đang có thiết bị hoạt động sử dụng loại này.");
        return;
      }
    }

    const selectedCategory = categories.find(
      (item) => item.id === categoryId
    );

    if (!selectedCategory || selectedCategory.status !== "ACTIVE") {
      setError("Lĩnh vực không hợp lệ hoặc đã ngừng sử dụng.");
      return;
    }

    // Không cho tạo hai loại trùng tên trong cùng lĩnh vực.
    const duplicate = types.some(
      (item) =>
        item.id !== editingId &&
        item.categoryId === categoryId &&
        item.name.trim().toLocaleLowerCase("vi") ===
          cleanName.toLocaleLowerCase("vi")
    );

    if (duplicate) {
      setError("Loại thiết bị này đã tồn tại trong lĩnh vực đã chọn.");
      return;
    }

    try {
      setSaving(true);

      if (editingId) {
        // Cập nhật document cũ, KHÔNG đổi Document ID.
        await updateDoc(doc(db, "deviceTypes", editingId), {
          name: cleanName,
          description: cleanDescription,
          categoryId,
          areaIds: normalizedAreaIds,
          updatedAt: serverTimestamp(),
        });

        invalidateAppCollection("deviceTypes");

        setMessage("Cập nhật loại thiết bị thành công.");
      } else {
        // Firestore tự tạo Document ID mới.
        await addDoc(collection(db, "deviceTypes"), {
          code: generateCode(),
          name: cleanName,
          description: cleanDescription,
          categoryId,
          areaIds: normalizedAreaIds,
          isActive: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        invalidateAppCollection("deviceTypes");

        setMessage("Thêm loại thiết bị thành công.");
      }

      resetForm();
      await loadData();
    } catch (err) {
      console.error(err);
      setError("Không thể lưu loại thiết bị.");
    } finally {
      setSaving(false);
    }
  }

  // =====================================================
  // 8. NGỪNG SỬ DỤNG / KÍCH HOẠT LẠI
  // =====================================================

  async function handleToggle(item: DeviceType) {
    setError("");
    setMessage("");

    if (!canManageType(item)) {
      setError("Bạn không có quyền thay đổi loại thiết bị ngoài phạm vi xưởng được giao.");
      return;
    }

    // Không cho ngừng loại đang có thiết bị hoạt động.
    const activeDeviceCount = devices.filter(
      (device) =>
        device.deviceTypeId === item.id &&
        device.isActive !== false
    ).length;

    if (item.isActive && activeDeviceCount > 0) {
      setError(
        `Không thể ngừng sử dụng "${item.name}" vì còn ` +
        `${activeDeviceCount} thiết bị đang hoạt động.`
      );
      return;
    }

    const action = item.isActive
      ? "ngừng sử dụng"
      : "kích hoạt lại";

    if (!await showAppConfirm(`Xác nhận ${action} "${item.name}"?`)) {
      return;
    }

    try {
      setSaving(true);

      await updateDoc(doc(db, "deviceTypes", item.id), {
        isActive: !item.isActive,
        updatedAt: serverTimestamp(),
      });

      invalidateAppCollection("deviceTypes");

      setMessage(`Đã ${action} loại thiết bị.`);
      await loadData();
    } catch (err) {
      console.error(err);
      setError("Không thể thay đổi trạng thái loại thiết bị.");
    } finally {
      setSaving(false);
    }
  }

  async function handlePermanentDelete(item: DeviceType) {
    if (!isAdmin(appUser) || item.isActive || saving) return;
    const accepted = await showAppConfirm(
      "Thao tác này xóa vĩnh viễn loại thiết bị và không thể khôi phục. Hệ thống sẽ từ chối nếu còn thiết bị hoặc mẫu tuần kiểm tham chiếu.",
      { title: "Xóa vĩnh viễn loại thiết bị", tone: "error", confirmLabel: "Xóa vĩnh viễn", verificationText: item.name },
    );
    if (!accepted) return;
    try {
      setSaving(true);
      setError("");
      setMessage("");
      await permanentlyDeleteInactiveDeviceType(item.id);
      invalidateAppCollection("deviceTypes");
      setMessage("Đã xóa vĩnh viễn loại thiết bị.");
      await loadData();
      await showAppAlert("Đã xóa vĩnh viễn loại thiết bị.", { tone: "success" });
    } catch (cause) {
      const message = cause instanceof PermanentDeletionBlockedError
        ? cause.message
        : cause instanceof Error ? cause.message : "Không thể xóa loại thiết bị.";
      setError(message);
      await showAppAlert(message, { tone: "error" });
    } finally {
      setSaving(false);
    }
  }

  // =====================================================
  // 9. ĐẾM THIẾT BỊ ĐANG SỬ DỤNG
  // =====================================================

  function countActiveDevices(typeId: string) {
    return devices.filter(
      (device) =>
        device.deviceTypeId === typeId &&
        device.isActive !== false
    ).length;
  }

  function canManageType(item: DeviceType) {
    return isAdmin(appUser) || (
      item.areaIds.length > 0 &&
      item.areaIds.every((id) => appUser.areaIds.includes(id))
    );
  }

  function formatTypeAreas(item: DeviceType) {
    if (item.areaIds.length === 0) return "Toàn hệ thống";
    return item.areaIds
      .map((id) => areas.find((area) => area.id === id)?.name || id)
      .join(", ");
  }

  function toggleSelectedArea(areaId: string) {
    setSelectedAreaIds((current) => current.includes(areaId)
      ? current.filter((id) => id !== areaId)
      : [...current, areaId]);
  }

  // =====================================================
  // 10. GIAO DIỆN
  // =====================================================

  return (
    <main className="device-types-page">
      <header className="device-types-header"><div><h1>Quản lý loại thiết bị</h1>
        <p>Danh mục loại thiết bị theo lĩnh vực CNTT, Điện và Cơ khí.</p></div>
        <button className="device-types-button is-primary" type="button" onClick={openCreateForm}>+ Thêm loại thiết bị</button>
      </header>

      {error && !formOpen && (
        <div className="device-types-alert is-error">
          {error}
        </div>
      )}

      {message && !formOpen && (
        <div className="device-types-alert is-success">
          {message}
        </div>
      )}

      {/* FORM THÊM / SỬA */}
      {formOpen && <div className="device-types-modal-backdrop" role="presentation" onMouseDown={(event) => {
        if (event.target === event.currentTarget && !saving) resetForm();
      }}><section className="device-types-modal" role="dialog" aria-modal="true" aria-labelledby="device-type-form-title">
        <div className="device-types-modal-header">
        <h3>
          <span id="device-type-form-title">
          {editingId
            ? "Chỉnh sửa loại thiết bị"
            : "Thêm loại thiết bị mới"}</span>
        </h3>
        <button className="device-types-modal-close" type="button" onClick={resetForm} disabled={saving} aria-label="Đóng">×</button>
        </div>
        {error && <div className="device-types-alert is-error device-types-modal-alert">{error}</div>}
        <form onSubmit={handleSave} className="device-types-form">

        <label className="device-types-field">
          Lĩnh vực *
          <select
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            required
            disabled={saving}
          >
            <option value="">-- Chọn lĩnh vực --</option>

            {categories
              .filter(
                (item) =>
                  item.status === "ACTIVE" ||
                  item.id === categoryId
              )
              .map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
          </select>
        </label>

        <label className="device-types-field">
          Tên loại thiết bị *
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="VD: Máy tính công nghiệp"
            required
            disabled={saving}
          />
        </label>

        <label className="device-types-field">
          Mô tả
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            disabled={saving}
          />
        </label>

        <fieldset className="device-types-area-field" disabled={saving}>
          <legend>Xưởng được áp dụng {!isAdmin(appUser) && "*"}</legend>
          {isAdmin(appUser) && (
            <p>Không chọn xưởng sẽ áp dụng loại thiết bị cho toàn hệ thống.</p>
          )}
          <div className="device-types-area-options">
            {areas.map((area) => (
              <label key={area.id}>
                <input
                  type="checkbox"
                  checked={selectedAreaIds.includes(area.id)}
                  onChange={() => toggleSelectedArea(area.id)}
                />
                <span>{area.name}{area.code ? ` (${area.code})` : ""}</span>
              </label>
            ))}
          </div>
        </fieldset>

        <div className="device-types-form-actions">
          <button className="device-types-button is-primary" type="submit" disabled={saving || loading}>
            {saving
              ? "Đang lưu..."
              : editingId
              ? "Lưu thay đổi"
              : "+ Thêm loại thiết bị"}
          </button>

          <button className="device-types-button" type="button" onClick={resetForm} disabled={saving}>Hủy</button>
        </div>
        </form>
      </section></div>}

      {/* DANH SÁCH THEO LĨNH VỰC */}
      {loading ? (
        <div className="device-types-loading">Đang tải danh mục...</div>
      ) : (
        categories.map((category) => {
          const categoryTypes = types.filter(
            (item) => item.categoryId === category.id
          );

          return (
            <section
              key={category.id}
              className="device-types-category"
            >
              <h2>
                {category.name} ({categoryTypes.length})
              </h2>

              <div className="device-types-table-wrap">
                <table className="device-types-table">
                  <thead>
                    <tr>
                      <th>Tên loại</th><th>Mô tả</th><th>Xưởng áp dụng</th><th>Thiết bị</th><th>Trạng thái</th><th>Thao tác</th>
                    </tr>
                  </thead>

                  <tbody>
                    {categoryTypes.map((item) => (
                      <tr key={item.id}>
                        <td>
                          <strong>{item.name}</strong>
                        </td>

                        <td>
                          {item.description || "-"}
                        </td>

                        <td>{formatTypeAreas(item)}</td>

                        <td>
                          {countActiveDevices(item.id)}
                        </td>

                        <td><span className={`device-types-status ${item.isActive ? "is-active" : "is-inactive"}`}>
                          {item.isActive ? "Hoạt động" : "Ngừng sử dụng"}</span>
                        </td>

                        <td><div className="device-types-row-actions">
                          {canManageType(item) ? <>
                          <ActionIconButton
                            icon="edit" label={`Sửa loại thiết bị ${item.name}`}
                            type="button"
                            onClick={() => handleEdit(item)}
                            disabled={saving}
                          />

                          {" "}

                          <ActionIconButton
                            icon={item.isActive ? "deactivate" : "activate"} variant={item.isActive ? "danger" : "default"} label={`${item.isActive ? "Ngừng sử dụng" : "Kích hoạt"} loại thiết bị ${item.name}`}
                            type="button"
                            onClick={() => handleToggle(item)}
                            disabled={saving}
                          /></> : <span className="device-types-scope-note">Chỉ xem</span>}
                          {isAdmin(appUser) && !item.isActive && (
                            <ActionIconButton
                              icon="delete" variant="danger" label={`Xóa vĩnh viễn loại thiết bị ${item.name}`}
                              type="button"
                              disabled={saving}
                              onClick={() => void handlePermanentDelete(item)}
                            />
                          )}</div>
                        </td>
                      </tr>
                    ))}

                    {categoryTypes.length === 0 && (
                      <tr>
                        <td className="device-types-empty" colSpan={6}>
                          Chưa có loại thiết bị.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </section>
          );
        })
      )}
    </main>
  );
}
