// import { useEffect, useState } from "react";
// import { doc, getDoc } from "firebase/firestore";
// import { useNavigate, useParams } from "react-router-dom";
// import { QRCodeSVG } from "qrcode.react";

// import { db } from "../config/firebase";
// import { canAccessArea, isAdmin, type AppUser } from "../types/user";
// import ActionIconButton from "../components/ActionIconButton";

// interface Device {
//   id: string;
//   code?: string;
//   name?: string;
//   areaId?: string;
//   subAreaId?: string;
//   deviceTypeId?: string;
//   manufacturer?: string;
//   model?: string;
// }

// interface Area {
//   id: string;
//   code?: string;
//   name?: string;
// }

// interface DeviceQrPrintProps {
//   appUser: AppUser;
// }

// export default function DeviceQrPrint({ appUser }: DeviceQrPrintProps) {
//   const { id } = useParams<{ id: string }>();
//   const navigate = useNavigate();

//   const [device, setDevice] = useState<Device | null>(null);
//   const [area, setArea] = useState<Area | null>(null);
//   const [subArea, setSubArea] = useState<Area | null>(null);

//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");

//   useEffect(() => {
//     let isCurrent = true;

//     async function loadDevice() {
//       if (!id) {
//         setError("Không xác định được thiết bị.");
//         setLoading(false);
//         return;
//       }

//       try {
//         setLoading(true);
//         setError("");

//         const deviceRef = doc(db, "devices", id);
//         const deviceSnap = await getDoc(deviceRef);

//         if (!isCurrent) {
//           return;
//         }

//         if (!deviceSnap.exists()) {
//           setError("Không tìm thấy thiết bị.");
//           return;
//         }

//         const deviceData: Device = {
//           id: deviceSnap.id,
//           ...deviceSnap.data(),
//         };

//         if (
//           !isAdmin(appUser) &&
//           !canAccessArea(appUser, deviceData.areaId?.trim() || "")
//         ) {
//           setError("Bạn không có quyền truy cập thiết bị này.");
//           return;
//         }

//         if (!isAdmin(appUser)) {
//           setError("Bạn không có quyền in tem QR cho thiết bị này.");
//           return;
//         }

//         setDevice(deviceData);

//         if (deviceData.areaId) {
//           const areaSnap = await getDoc(
//             doc(db, "areas", deviceData.areaId)
//           );

//           if (!isCurrent) {
//             return;
//           }

//           if (areaSnap.exists()) {
//             setArea({
//               id: areaSnap.id,
//               ...areaSnap.data(),
//             });
//           }
//         }
//         if (deviceData.subAreaId) {
//           const subAreaSnap = await getDoc(doc(db, "subAreas", deviceData.subAreaId));
//           if (isCurrent && subAreaSnap.exists()) setSubArea({ id: subAreaSnap.id, ...subAreaSnap.data() });
//         }
//       } catch (err) {
//         if (!isCurrent) {
//           return;
//         }

//         console.error("Lỗi tải tem QR:", err);
//         setError("Không thể tải thông tin thiết bị.");
//       } finally {
//         if (isCurrent) {
//           setLoading(false);
//         }
//       }
//     }

//     loadDevice();

//     return () => {
//       isCurrent = false;
//     };
//   }, [appUser, id]);

//   if (loading) {
//     return <p>Đang tạo tem QR...</p>;
//   }

//   if (error || !device) {
//     return (
//       <section className="panel">
//         <h2>Không thể tạo tem QR</h2>

//         <p>{error}</p>

//         <ActionIconButton
//           icon="back" label="Quay lại danh sách thiết bị"
//           onClick={() => navigate("/devices")}
//         />
//       </section>
//     );
//   }

//   const qrUrl = `${window.location.origin}/q/${encodeURIComponent(
//     device.code || device.id
//   )}`;

//   const areaName = area
//     ? `${area.code || ""}${
//         area.code && area.name ? " - " : ""
//       }${area.name || ""}${subArea ? ` / ${subArea.code || ""}${subArea.code && subArea.name ? " - " : ""}${subArea.name || ""}` : ""}`
//     : "-";

//   return (
//     <div className="qr-print-page">

//       {/* THANH CÔNG CỤ - KHÔNG IN */}
//       <div className="qr-print-toolbar">
//         <ActionIconButton
//           icon="back" label="Quay lại hồ sơ thiết bị"
//           onClick={() => navigate(`/devices/${device.id}`)}
//         />

//         <ActionIconButton
//           icon="print" variant="primary" label="In tem QR"
//           onClick={() => window.print()}
//         />
//       </div>

//       {/* TEM QR */}
//       <div className="asset-label">

//         <div className="asset-label-title">
//           QUẢN LÝ THIẾT BỊ
//         </div>

//         <div className="asset-label-qr">
//           <QRCodeSVG
//             value={qrUrl}
//             size={190}
//             level="H"
//             includeMargin={false}
//           />
//         </div>

//         <div className="asset-label-code">
//           {device.code || "-"}
//         </div>

//         <div className="asset-label-name">
//           {device.name || "Chưa có tên thiết bị"}
//         </div>

//         <div className="asset-label-area">
//           {areaName}
//         </div>

//         {(device.manufacturer || device.model) && (
//           <div className="asset-label-model">
//             {[device.manufacturer, device.model]
//               .filter(Boolean)
//               .join(" / ")}
//           </div>
//         )}

//         <div className="asset-label-note">
//           Quét QR để xem hồ sơ thiết bị
//         </div>

//       </div>
//     </div>
//   );
// }
import { useEffect, useState } from "react";
import { doc, getDoc } from "firebase/firestore";
import { useNavigate, useParams } from "react-router-dom";
import { QRCodeSVG } from "qrcode.react";

import { db } from "../config/firebase";
import { canAccessArea, isAdmin, isManager, type AppUser } from "../types/user";
import ActionIconButton from "../components/ActionIconButton";

interface Device {
  id: string;
  code?: string;
  name?: string;
  areaId?: string;
  subAreaId?: string;
  deviceTypeId?: string;
  manufacturer?: string;
  model?: string;
}

interface Area {
  id: string;
  code?: string;
  name?: string;
}

interface DeviceQrPrintProps {
  appUser: AppUser;
}

export default function DeviceQrPrint({ appUser }: DeviceQrPrintProps) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [device, setDevice] = useState<Device | null>(null);
  const [area, setArea] = useState<Area | null>(null);
  const [subArea, setSubArea] = useState<Area | null>(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let isCurrent = true;

    async function loadDevice() {
      if (!id) {
        setError("Không xác định được thiết bị.");
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError("");

        const deviceRef = doc(db, "devices", id);
        const deviceSnap = await getDoc(deviceRef);

        if (!isCurrent) {
          return;
        }

        if (!deviceSnap.exists()) {
          setError("Không tìm thấy thiết bị.");
          return;
        }

        const deviceData: Device = {
          id: deviceSnap.id,
          ...deviceSnap.data(),
        };

        if (
          !isAdmin(appUser) &&
          !canAccessArea(appUser, deviceData.areaId?.trim() || "")
        ) {
          setError("Bạn không có quyền truy cập thiết bị này.");
          return;
        }

        // Admin và Quản lý khu vực được in tem. Quản lý khu vực chỉ in được
        // thiết bị thuộc nhà máy được gán (đã kiểm tra canAccessArea ở trên).
        if (!isManager(appUser)) {
          setError("Bạn không có quyền in tem QR cho thiết bị này.");
          return;
        }

        setDevice(deviceData);

        if (deviceData.areaId) {
          const areaSnap = await getDoc(
            doc(db, "areas", deviceData.areaId)
          );

          if (!isCurrent) {
            return;
          }

          if (areaSnap.exists()) {
            setArea({
              id: areaSnap.id,
              ...areaSnap.data(),
            });
          }
        }
        if (deviceData.subAreaId) {
          const subAreaSnap = await getDoc(doc(db, "subAreas", deviceData.subAreaId));
          if (isCurrent && subAreaSnap.exists()) setSubArea({ id: subAreaSnap.id, ...subAreaSnap.data() });
        }
      } catch (err) {
        if (!isCurrent) {
          return;
        }

        console.error("Lỗi tải tem QR:", err);
        setError("Không thể tải thông tin thiết bị.");
      } finally {
        if (isCurrent) {
          setLoading(false);
        }
      }
    }

    loadDevice();

    return () => {
      isCurrent = false;
    };
  }, [appUser, id]);

  if (loading) {
    return <p>Đang tạo tem QR...</p>;
  }

  if (error || !device) {
    return (
      <section className="panel">
        <h2>Không thể tạo tem QR</h2>

        <p>{error}</p>

        <ActionIconButton
          icon="back" label="Quay lại danh sách thiết bị"
          onClick={() => navigate("/devices")}
        />
      </section>
    );
  }

  const qrUrl = `${window.location.origin}/q/${encodeURIComponent(
    device.code || device.id
  )}`;

  const areaName = area
    ? `${area.code || ""}${
        area.code && area.name ? " - " : ""
      }${area.name || ""}${subArea ? ` / ${subArea.code || ""}${subArea.code && subArea.name ? " - " : ""}${subArea.name || ""}` : ""}`
    : "-";

  return (
    <div className="qr-print-page">

      {/* THANH CÔNG CỤ - KHÔNG IN */}
      <div className="qr-print-toolbar">
        <ActionIconButton
          icon="back" label="Quay lại hồ sơ thiết bị"
          onClick={() => navigate(`/devices/${device.id}`)}
        />

        <ActionIconButton
          icon="print" variant="primary" label="In tem QR"
          onClick={() => window.print()}
        />
      </div>

      {/* TEM QR */}
      <div className="asset-label">

        <div className="asset-label-title">
          QUẢN LÝ THIẾT BỊ
        </div>

        <div className="asset-label-qr">
          <QRCodeSVG
            value={qrUrl}
            size={190}
            level="H"
            includeMargin={false}
          />
        </div>

        <div className="asset-label-code">
          {device.code || "-"}
        </div>

        <div className="asset-label-name">
          {device.name || "Chưa có tên thiết bị"}
        </div>

        <div className="asset-label-area">
          {areaName}
        </div>

        {(device.manufacturer || device.model) && (
          <div className="asset-label-model">
            {[device.manufacturer, device.model]
              .filter(Boolean)
              .join(" / ")}
          </div>
        )}

        <div className="asset-label-note">
          Quét QR để xem hồ sơ thiết bị
        </div>

      </div>
    </div>
  );
}