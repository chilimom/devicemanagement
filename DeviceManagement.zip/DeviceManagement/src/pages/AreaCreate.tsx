import { useState } from "react";
import type { FormEvent } from "react";
import {
  addDoc,
  collection,
  getDocs,
  query,
  serverTimestamp,
  where,
} from "firebase/firestore";
import { useNavigate } from "react-router-dom";

import { db } from "../config/firebase";
import { invalidateAppCollection } from "../services/sharedCollectionCache";

export default function AreaCreate() {
  const navigate = useNavigate();

  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState("ACTIVE");

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();

    const normalizedCode = code.trim().toUpperCase();
    const normalizedName = name.trim();
    const normalizedDescription = description.trim();

    if (!normalizedCode) {
      setError("Vui lòng nhập mã khu vực.");
      return;
    }

    if (!normalizedName) {
      setError("Vui lòng nhập tên khu vực.");
      return;
    }

    try {
      setSaving(true);
      setError("");

      // Kiểm tra trùng mã khu vực
      const duplicateQuery = query(
        collection(db, "areas"),
        where("code", "==", normalizedCode)
      );

      const duplicateSnapshot = await getDocs(
        duplicateQuery
      );

      if (!duplicateSnapshot.empty) {
        setError(
          `Mã khu vực ${normalizedCode} đã tồn tại.`
        );

        setSaving(false);
        return;
      }

      await addDoc(collection(db, "areas"), {
        code: normalizedCode,
        name: normalizedName,
        description: normalizedDescription,
        status,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      invalidateAppCollection("areas");

      navigate("/areas");
    } catch (err) {
      console.error("Lỗi thêm khu vực:", err);

      setError(
        "Không thể thêm khu vực. Vui lòng thử lại."
      );
    } finally {
      setSaving(false);
    }
  }

  return (
    <main className="area-create-page">
      <div className="page-header">
        <div>
          <h1>Thêm khu vực</h1>

          <p className="page-subtitle">
            Khai báo khu vực quản lý thiết bị mới.
          </p>
        </div>
      </div>

      <section className="panel area-form-panel">
        <form
          className="area-form"
          onSubmit={handleSubmit}
        >
          {error && (
            <div className="form-error">
              {error}
            </div>
          )}

          <div className="form-group">
            <label>
              Mã khu vực <span>*</span>
            </label>

            <input
              type="text"
              placeholder="Ví dụ: LG1"
              value={code}
              maxLength={30}
              onChange={(e) =>
                setCode(e.target.value.toUpperCase())
              }
            />

            <small>
              Mã dùng để nhận diện khu vực trong hệ thống.
              Ví dụ: LG1, LG2, ND1.
            </small>
          </div>

          <div className="form-group">
            <label>
              Tên khu vực <span>*</span>
            </label>

            <input
              type="text"
              placeholder="Ví dụ: PX. Luyện Gang 1"
              value={name}
              maxLength={150}
              onChange={(e) =>
                setName(e.target.value)
              }
            />
          </div>

          <div className="form-group">
            <label>Mô tả</label>

            <textarea
              placeholder="Nhập mô tả khu vực..."
              value={description}
              rows={4}
              onChange={(e) =>
                setDescription(e.target.value)
              }
            />
          </div>

          <div className="form-group">
            <label>Trạng thái</label>

            <select
              value={status}
              onChange={(e) =>
                setStatus(e.target.value)
              }
            >
              <option value="ACTIVE">
                Hoạt động
              </option>

              <option value="INACTIVE">
                Ngừng sử dụng
              </option>
            </select>
          </div>

          <div className="form-actions">
            <button
              type="button"
              className="btn-secondary"
              disabled={saving}
              onClick={() => navigate("/areas")}
            >
              Hủy
            </button>

            <button
              type="submit"
              className="primary-button"
              disabled={saving}
            >
              {saving
                ? "Đang lưu..."
                : "Lưu khu vực"}
            </button>
          </div>
        </form>
      </section>
    </main>
  );
}
