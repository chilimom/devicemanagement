import { useEffect, useMemo, useState, type ReactNode } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { collection, doc, getDoc, getDocs, query, where, Timestamp, serverTimestamp, updateDoc } from "firebase/firestore";
import "../styles/device-inspection-history.css";
import { db } from "../config/firebase";
import { getDeviceInspectionHistory } from "../services/inspectionResultService";
import { canAccessArea, isManager, type AppUser } from "../types/user";
import { showAppAlert, showAppConfirm } from "../services/appDialog";
import InspectionTimeline, { STATUS_TONE } from "../components/InspectionTimeline";

import type {
  InspectionRecord,
  InspectionResultStatus,
  InspectionTask,
} from "../types/inspection";

type HistoryRecord = InspectionRecord & {
  planSnapshot?: {
    name?: string;
    version?: number;
    tasks?: InspectionTask[];
  };
};

type RemediationMap = Map<string, HistoryRecord[]>;
type LinkedMaintenance = {
  id: string;
  title?: string;
  result?: string;
  performedBy?: string;
  performedAt?: Timestamp;
  status?: string;
  approvedAt?: Timestamp;
  canApprove?: boolean;
  isApproving?: boolean;
  onApprove?: () => void;
};
type MaintenanceMap = Map<string, LinkedMaintenance[]>;

function remediationKey(recordId: string, taskId: string, criterionId: string): string {
  return `${recordId}\u0000${taskId}\u0000${criterionId}`;
}

function getRemediationSource(record: HistoryRecord) {
  if (record.remediationSource) return record.remediationSource;
  if (record.inspectionType !== "EXTRA" || !record.note) return undefined;
  const legacyLink = /^Ki\u1ec3m tra b\u1ed5 sung sau .*?t\u1eeb phi\u1ebfu (.+?), c\u00f4ng vi\u1ec7c (.+?), ti\u00eau ch\u00ed (.+?)\./.exec(record.note);
  if (!legacyLink) return undefined;
  return { recordId: legacyLink[1], taskId: legacyLink[2], criterionId: legacyLink[3] };
}

function getRemediationNote(record: HistoryRecord): string {
  if (!record.note) return "";
  return record.note.replace(/^Ki\u1ec3m tra b\u1ed5 sung sau .*?t\u1eeb phi\u1ebfu .+?, c\u00f4ng vi\u1ec7c .+?, ti\u00eau ch\u00ed .+?\.\s*/, "").trim();
}

function isRemediationRecord(record: HistoryRecord): boolean {
  return Boolean(getRemediationSource(record));
}

function buildRemediationMap(records: HistoryRecord[]): RemediationMap {
  const byId = new Map(records.map((record) => [record.id, record]));
  const map: RemediationMap = new Map();

  for (const record of records) {
    const source = getRemediationSource(record);
    if (record.inspectionType !== "EXTRA" || !source) continue;
    const sourceRecord = byId.get(source.recordId);
    if (!sourceRecord || sourceRecord.deviceId !== record.deviceId) continue;
    const sourceTask = sourceRecord.results.find((result) => result.taskId === source.taskId);
    const sourceCriterion = sourceTask?.criteriaResults.find((result) => result.criterionId === source.criterionId);
    if (sourceCriterion?.status !== "FAIL" && sourceCriterion?.status !== "WARNING") continue;

    const key = remediationKey(source.recordId, source.taskId, source.criterionId);
    map.set(key, [...(map.get(key) ?? []), record]);
  }

  return map;
}

function getLatestRetestStatus(
  recordId: string,
  taskId: string,
  criterionId: string,
  remediations: RemediationMap,
): InspectionResultStatus | undefined {
  const latest = remediations.get(remediationKey(recordId, taskId, criterionId))?.[0];
  return latest?.results
    .find((result) => result.taskId === taskId)
    ?.criteriaResults.find((result) => result.criterionId === criterionId)?.status
    ?? latest?.results.find((result) => result.taskId === taskId)?.status;
}

interface DeviceInfo {
  id: string;
  code?: string;
  name?: string;
}

const STATUS_LABELS: Record<InspectionResultStatus, string> = {
  PASS: "Đạt",
  WARNING: "Cảnh báo",
  FAIL: "Không đạt",
  NOT_CHECKED: "Chưa kiểm tra",
};

function getCurrentCriterionStatus(
  recordId: string,
  taskId: string,
  criterionId: string,
  status: InspectionResultStatus,
  remediations: RemediationMap,
): InspectionResultStatus {
  if (status !== "WARNING" && status !== "FAIL") return status;

  const retestStatus = getLatestRetestStatus(recordId, taskId, criterionId, remediations);
  if (retestStatus === "PASS" || retestStatus === "WARNING" || retestStatus === "FAIL") {
    return retestStatus;
  }

  return status;
}

function getCurrentOverallStatusWithMaintenance(
  record: InspectionRecord,
  remediations: RemediationMap,
  maintenances: MaintenanceMap,
): InspectionResultStatus {
  const statuses = record.results.map((task) => {
    const criterionStatuses = task.criteriaResults.map((criterion) => {
      const key = remediationKey(record.id, task.taskId, criterion.criterionId);
      if ((maintenances.get(key) ?? []).some((item) => item.status === "COMPLETED")) return "PASS" as const;
      return getCurrentCriterionStatus(record.id, task.taskId, criterion.criterionId, criterion.status, remediations);
    });
    if (criterionStatuses.includes("FAIL")) return "FAIL";
    if (criterionStatuses.includes("WARNING")) return "WARNING";
    if (criterionStatuses.includes("NOT_CHECKED")) return "NOT_CHECKED";
    return criterionStatuses.length > 0 ? "PASS" : task.status;
  });
  if (statuses.includes("FAIL")) return "FAIL";
  if (statuses.includes("WARNING")) return "WARNING";
  if (statuses.includes("NOT_CHECKED")) return "NOT_CHECKED";
  return statuses.length > 0 ? "PASS" : "NOT_CHECKED";
}

function getCurrentTaskStatusWithMaintenance(
  recordId: string,
  task: InspectionRecord["results"][number],
  remediations: RemediationMap,
  maintenances: MaintenanceMap,
): InspectionResultStatus {
  const statuses = task.criteriaResults.map((criterion) => {
    const key = remediationKey(recordId, task.taskId, criterion.criterionId);
    return (maintenances.get(key) ?? []).some((item) => item.status === "COMPLETED")
      ? "PASS" as const
      : getCurrentCriterionStatus(recordId, task.taskId, criterion.criterionId, criterion.status, remediations);
  });
  if (statuses.includes("FAIL")) return "FAIL";
  if (statuses.includes("WARNING")) return "WARNING";
  if (statuses.includes("NOT_CHECKED")) return "NOT_CHECKED";
  return statuses.length > 0 ? "PASS" : task.status;
}

function formatTimestamp(value: unknown): string {
  if (value instanceof Timestamp) {
    return value.toDate().toLocaleString("vi-VN", {
      timeZone: "Asia/Ho_Chi_Minh",
    });
  }

  return "Chưa có thời gian";
}

interface DeviceInspectionHistoryProps {
  appUser: AppUser | null;
}

export default function DeviceInspectionHistory({
  appUser,
}: DeviceInspectionHistoryProps) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [device, setDevice] = useState<DeviceInfo | null>(null);
  const [records, setRecords] = useState<HistoryRecord[]>([]);

  /* Lần kiểm lại và bảo trì liên kết được đọc riêng; lịch sử tuần kiểm gốc bất biến. */
  const [remediations, setRemediations] = useState<RemediationMap>(new Map());
  const [maintenances, setMaintenances] = useState<MaintenanceMap>(new Map());

  const [expandedId, setExpandedId] = useState<string | null>(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [approvingMaintenanceId, setApprovingMaintenanceId] = useState("");
  const canApproveMaintenance = isManager(appUser);

  async function approveMaintenance(maintenanceId: string) {
    if (!canApproveMaintenance || !appUser) return;
    if (!await showAppConfirm("Xác nhận kết quả công việc bảo trì này?", { confirmLabel: "Xác nhận" })) return;
    try {
      setApprovingMaintenanceId(maintenanceId);
      setMaintenances((current) => {
        const next = new Map(current);
        for (const [key, items] of next) next.set(key, items.map((item) => item.id === maintenanceId ? { ...item, isApproving: true } : item));
        return next;
      });
      await updateDoc(doc(db, "maintenances", maintenanceId), {
        status: "COMPLETED",
        approvedByUid: appUser.uid,
        approvedAt: serverTimestamp(),
      });
      setMaintenances((current) => {
        const next = new Map(current);
        for (const [key, items] of next) {
          next.set(key, items.map((item) => item.id === maintenanceId ? { ...item, status: "COMPLETED", isApproving: false } : item));
        }
        return next;
      });
      await showAppAlert("Đã xác nhận kết quả bảo trì; tiêu chí tuần kiểm được hoàn tất.", { tone: "success" });
    } catch (approveError) {
      console.error(approveError);
      await showAppAlert("Không thể xác nhận kết quả bảo trì. Kiểm tra quyền và Firestore Rules.", { tone: "error" });
    } finally {
      setApprovingMaintenanceId("");
      setMaintenances((current) => {
        const next = new Map(current);
        for (const [key, items] of next) next.set(key, items.map((item) => item.id === maintenanceId ? { ...item, isApproving: false } : item));
        return next;
      });
    }
  }

  useEffect(() => {
    let cancelled = false;

    async function loadData() {
      if (!id) {
        setError("Không xác định được thiết bị.");
        setLoading(false);
        return;
      }

      setLoading(true);
      setError("");
      setDevice(null);
      setRecords([]);
      setRemediations(new Map());
      setMaintenances(new Map());
      setExpandedId(null);

      try {
        const deviceSnapshot = await getDoc(doc(db, "devices", id));

        if (cancelled) return;

        if (!deviceSnapshot.exists()) {
          throw new Error("Không tìm thấy thiết bị.");
        }

        const deviceData = deviceSnapshot.data();

        if (
          !canAccessArea(
            appUser,
            typeof deviceData.areaId === "string" ? deviceData.areaId : ""
          )
        ) {
          throw new Error("Bạn không có quyền truy cập thiết bị này.");
        }

        const history = await getDeviceInspectionHistory(id);

        if (cancelled) return;

        setDevice({
          id,
          code: deviceData.code,
          name: deviceData.name,
        });

        const orderedHistory = history as HistoryRecord[];
        setRecords(orderedHistory);
        setRemediations(buildRemediationMap(orderedHistory));

        const failedCriterionKeys = new Set(
          orderedHistory
            .filter((record) => !isRemediationRecord(record))
            .flatMap((record) =>
              record.results.flatMap((task) =>
                task.criteriaResults
                  .filter((criterion) => criterion.status === "WARNING" || criterion.status === "FAIL")
                  .map((criterion) => remediationKey(record.id, task.taskId, criterion.criterionId))
              )
            )
        );

        const maintenanceQuery = failedCriterionKeys.size > 0
          ? await getDocs(query(collection(db, "maintenances"), where("deviceId", "==", id)))
          : null;

        if (cancelled) return;

        const linkedMaintenanceMap: MaintenanceMap = new Map();
        for (const snapshot of maintenanceQuery?.docs ?? []) {
          const data = snapshot.data();
          const source = data.inspectionSource as
            | { recordId?: string; taskId?: string; criterionId?: string }
            | undefined;
          if (!source?.recordId || !source.taskId || !source.criterionId) continue;

          const key = remediationKey(source.recordId, source.taskId, source.criterionId);
          if (!failedCriterionKeys.has(key)) continue;

          linkedMaintenanceMap.set(key, [
            ...(linkedMaintenanceMap.get(key) ?? []),
            {
              id: snapshot.id,
              title: data.title,
              result: data.result,
              performedBy: data.performedBy,
              performedAt: data.performedAt,
              status: data.status,
              approvedAt: data.approvedAt,
              canApprove: canApproveMaintenance,
              isApproving: approvingMaintenanceId === snapshot.id,
              onApprove: () => void approveMaintenance(snapshot.id),
            },
          ]);
        }
        setMaintenances(linkedMaintenanceMap);
        setExpandedId(orderedHistory.find((record) => !isRemediationRecord(record))?.id ?? null);
      } catch (err: unknown) {
        if (!cancelled) {
          setError(
            err instanceof Error
              ? err.message
              : "Không thể tải lịch sử tuần kiểm."
          );
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    void loadData();

    return () => {
      cancelled = true;
    };
  }, [appUser, id]);

  const summary = useMemo(() => {
    const result = {
      total: records.filter((record) => !isRemediationRecord(record)).length,
      pass: 0,
      warning: 0,
      fail: 0,
      notChecked: 0,
    };

    for (const record of records) {
      if (isRemediationRecord(record)) continue;
      const status = getCurrentOverallStatusWithMaintenance(record, remediations, maintenances);

      if (status === "PASS") result.pass++;
      else if (status === "WARNING") result.warning++;
      else if (status === "FAIL") result.fail++;
      else result.notChecked++;
    }

    return result;
  }, [records, remediations, maintenances]);

  const exceptionSummary = useMemo(() => {
    let total = 0;
    let verified = 0;

    for (const record of records) {
      if (isRemediationRecord(record)) continue;
      for (const taskResult of record.results) {
        for (const criterionResult of taskResult.criteriaResults) {
          if (criterionResult.status !== "WARNING" && criterionResult.status !== "FAIL") {
            continue;
          }

          total++;
          const key = remediationKey(record.id, taskResult.taskId, criterionResult.criterionId);
          const retestPassed = getLatestRetestStatus(record.id, taskResult.taskId, criterionResult.criterionId, remediations) === "PASS";
          const maintenanceApproved = (maintenances.get(key) ?? []).some((item) => item.status === "COMPLETED");
          if (retestPassed || maintenanceApproved) {
            verified++;
          }
        }
      }
    }

    return { total, verified, pending: total - verified };
  }, [records, remediations, maintenances]);

  const linkedRetestIds = new Set([...remediations.values()].flat().map((record) => record.id));
  const displayedRecords = records.filter((record) => !linkedRetestIds.has(record.id));

  if (loading) {
    return <p style={{ padding: 24 }}>Đang tải lịch sử tuần kiểm...</p>;
  }

  if (error) {
    return (
      <div style={{ padding: 24 }}>
        <h2>Không thể tải lịch sử tuần kiểm</h2>
        <p style={{ color: "#b91c1c" }}>{error}</p>
        <div className="inspection-history-actions">
          <button onClick={() => navigate("/devices")}>
            Quay về danh sách thiết bị
          </button>
        </div>
      </div>
    );
  }

  if (!device) return null;

  return (
    <div className="inspection-history-page">
      <header style={{ marginBottom: 24 }}>
        <h1>Lịch sử tuần kiểm thiết bị</h1>

        <p>
          <strong>{device.name || "Thiết bị"}</strong>
          {" — "}
          {device.code || device.id}
        </p>

        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          <div className="inspection-history-actions">
            <button
              type="button"
              className="inspection-history-action-back"
              onClick={() => navigate(`/devices/${id}`)}
            >
              <span aria-hidden="true">←</span>
              <span>Quay lại thiết bị</span>
            </button>

            <button
              type="button"
              className="inspection-history-action-primary"
              onClick={() => navigate(`/devices/${id}/inspection`)}
            >
              <span aria-hidden="true">▶</span>
              <span>Thực hiện tuần kiểm</span>
            </button>
          </div>
        </div>
      </header>

      <div className="inspection-history-kpis">
        <KpiCard label="Tổng lượt kiểm" value={summary.total} />
        <KpiCard label="Đạt / đã xác minh" value={summary.pass} color="#15803d" />
        <KpiCard label="Cảnh báo chưa xử lý" value={summary.warning} color="#b45309" />
        <KpiCard label="Không đạt chưa xử lý" value={summary.fail} color="#b91c1c" />
        <KpiCard label="Chưa hoàn thành" value={summary.notChecked} />
      </div>

      <p className="inspection-history-result-note">
        KPI và trạng thái tổng hợp phản ánh kết quả hiện tại; phần chi tiết vẫn lưu kết quả ban đầu để bảo toàn lịch sử.
      </p>

      {exceptionSummary.total > 0 && (
        <div
          className={`ih-banner ${exceptionSummary.pending > 0 ? "ih-banner-warn" : "ih-banner-ok"}`}
          aria-live="polite"
        >
          <span>{exceptionSummary.total} bất thường</span>
          <span>{exceptionSummary.verified} đã khắc phục</span>
          <span>{exceptionSummary.pending} chưa hoàn tất</span>
        </div>
      )}

      {/* Tiêu đề danh sách tuần kiểm, dùng chung cho máy tính và điện thoại */}
      <div className="inspection-history-list-header">
        <h2>Danh sách các lần kiểm tra</h2>
        <span>{displayedRecords.length} luồng kiểm tra</span>
      </div>

      {/* Tiêu đề các cột; ẩn trên điện thoại vì mobile hiển thị dạng thẻ */}
      <div className="inspection-history-table-head">
        <span>Ngày kiểm</span>
        <span>Hình thức</span>
        <span>Người kiểm</span>
        <span>Kết quả</span>
        <span>Thao tác</span>
      </div>

      {displayedRecords.length === 0 && (
        <section style={cardStyle}>
          <p>Thiết bị chưa có lịch sử tuần kiểm.</p>
        </section>
      )}

      {displayedRecords.map((record) => {
        const status = getCurrentOverallStatusWithMaintenance(record, remediations, maintenances);
        const expanded = expandedId === record.id;
        const snapshotTasks = record.planSnapshot?.tasks ?? [];

        const hadException = record.results.some((task) =>
          task.criteriaResults.some(
            (criterion) => criterion.status === "WARNING" || criterion.status === "FAIL"
          )
        );
        const fixedOverall = status === "PASS" && hadException;

        return (
          <section key={record.id} className="inspection-history-record">
            <div className="inspection-history-record-row">
              <div className="inspection-history-record-date">
                <strong>{record.inspectionDate}</strong>
                <span>{formatTimestamp(record.createdAt)}</span>
              </div>

              <div className="inspection-history-record-type">
                {record.inspectionType === "EXTRA" ? "Kiểm tra bổ sung" : "Theo lịch"}
              </div>

              <div className="inspection-history-record-inspector">
                {record.inspectorName}
              </div>

              <div className="inspection-history-record-status">
                <span className={`ct-badge ct-badge-${fixedOverall ? "info" : STATUS_TONE[status]}`}>
                  {fixedOverall ? "Đạt sau khắc phục" : STATUS_LABELS[status]}
                </span>
              </div>

              <button
                type="button"
                className="inspection-history-toggle"
                aria-expanded={expanded}
                aria-label={expanded ? "Thu gọn phiếu tuần kiểm" : "Xem chi tiết phiếu tuần kiểm"}
                onClick={() => setExpandedId(expanded ? null : record.id)}
              >
                <span>{expanded ? "Thu gọn" : "Xem chi tiết"}</span>
                <span aria-hidden="true">{expanded ? "▲" : "▼"}</span>
              </button>
            </div>

            {expanded && (
              <div className="ih-detail" style={{ padding: "0 16px 16px" }}>
                <p>
                  Kế hoạch:{" "}
                  <strong>{record.planSnapshot?.name ?? record.planId}</strong>
                  {" — V"}
                  {record.planVersion}
                </p>

                {record.results.map((taskResult, index) => {
                  const task = snapshotTasks.find((item) => item.id === taskResult.taskId);
                  const currentTaskStatus = getCurrentTaskStatusWithMaintenance(
                    record.id,
                    taskResult,
                    remediations,
                    maintenances,
                  );
                  const taskFixed =
                    currentTaskStatus === "PASS" &&
                    taskResult.criteriaResults.some(
                      (criterion) => criterion.status === "WARNING" || criterion.status === "FAIL"
                    );

                  return (
                    <section key={`${taskResult.taskId}-${index}`} className="ct-task">
                      <header className="ct-task-head">
                        <h3>
                          {index + 1}. {task?.name ?? taskResult.taskId}
                        </h3>
                        <span
                          className={`ct-badge ct-badge-${taskFixed ? "info" : STATUS_TONE[currentTaskStatus]}`}
                        >
                          {taskFixed ? "Đã khắc phục" : STATUS_LABELS[currentTaskStatus]}
                        </span>
                      </header>

                      {taskResult.criteriaResults.map((criterionResult) => {
                        const criterion = task?.criteria.find(
                          (item) => item.id === criterionResult.criterionId
                        );
                        const key = remediationKey(
                          record.id,
                          taskResult.taskId,
                          criterionResult.criterionId
                        );
                        const criterionMaintenances = maintenances.get(key) ?? [];

                        const retests = (remediations.get(key) ?? [])
                          .slice()
                          .reverse()
                          .flatMap((retest) => {
                            const result = retest.results
                              .find((item) => item.taskId === taskResult.taskId)
                              ?.criteriaResults.find(
                                (item) => item.criterionId === criterionResult.criterionId
                              );
                            if (!result) return [];
                            return [
                              {
                                id: retest.id,
                                inspectionDate: retest.inspectionDate,
                                inspectorName: retest.inspectorName,
                                createdAt: retest.createdAt,
                                status: result.status,
                                numericValue: result.numericValue,
                                textValue: result.textValue,
                                note: result.note?.trim() || getRemediationNote(retest),
                              },
                            ];
                          });

                        const maintenanceApproved = criterionMaintenances.some((item) => item.status === "COMPLETED");
                        const currentStatus = maintenanceApproved
                          ? "PASS"
                          : getCurrentCriterionStatus(
                              record.id,
                              taskResult.taskId,
                              criterionResult.criterionId,
                              criterionResult.status,
                              remediations
                            );

                        const abnormal =
                          criterionResult.status === "WARNING" ||
                          criterionResult.status === "FAIL";
                        const hasPendingMaintenance = criterionMaintenances.some((item) => item.status === "PENDING_APPROVAL");
                        const hasApprovedMaintenance = maintenanceApproved;
                        const needsAction =
                          abnormal && !hasApprovedMaintenance &&
                          getLatestRetestStatus(
                            record.id,
                            taskResult.taskId,
                            criterionResult.criterionId,
                            remediations
                          ) !== "PASS";

                        let actions: ReactNode = null;
                        if (needsAction) {
                          const hasMaintenance = criterionMaintenances.length > 0;
                          actions = (
                            <>
                              {hasMaintenance && !hasPendingMaintenance && (
                                <button
                                  type="button"
                                  className="ct-btn ct-btn-primary"
                                  onClick={() =>
                                    navigate(
                                      `/devices/${device.id}/inspection?${new URLSearchParams({
                                        inspectionType: "EXTRA",
                                        sourceInspectionRecordId: record.id,
                                        sourceInspectionTaskId: taskResult.taskId,
                                        sourceInspectionCriterionId: criterionResult.criterionId,
                                      })}`
                                    )
                                  }
                                >
                                  Kiểm tra sau bảo trì
                                </button>
                              )}
                              {!hasPendingMaintenance && <button
                                type="button"
                                className={hasMaintenance ? "ct-btn" : "ct-btn ct-btn-primary"}
                                onClick={() =>
                                  navigate(
                                    `/devices/${device.id}/maintenance/new?${new URLSearchParams({
                                      inspectionRecordId: record.id,
                                      inspectionTaskId: taskResult.taskId,
                                      inspectionCriterionId: criterionResult.criterionId,
                                    })}`
                                  )
                                }
                              >
                                {hasMaintenance ? "Ghi nhận thêm bảo trì" : "Ghi nhận bảo trì"}
                              </button>}
                            </>
                          );
                        }

                        return (
                          <InspectionTimeline
                            key={criterionResult.criterionId}
                            title={criterion?.standard ?? criterionResult.criterionId}
                            criterion={criterion}
                            currentStatus={currentStatus}
                            initial={{
                              inspectionDate: record.inspectionDate,
                              inspectorName: record.inspectorName,
                              createdAt: record.createdAt,
                              status: criterionResult.status,
                              numericValue: criterionResult.numericValue,
                              textValue: criterionResult.textValue,
                              note: criterionResult.note,
                            }}
                            retests={retests}
                            maintenances={criterionMaintenances}
                            actions={actions}
                          />
                        );
                      })}

                      {taskResult.note && <p>Ghi chú công việc: {taskResult.note}</p>}
                    </section>
                  );
                })}

                {record.note && (
                  <p style={{ marginTop: 16 }}>Ghi chú chung: {record.note}</p>
                )}

                <p style={{ fontSize: 12, color: "#64748b" }}>
                  Mã phiếu: {record.id}
                </p>
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}

function KpiCard({
  label,
  value,
  color = "#0f172a",
}: {
  label: string;
  value: number;
  color?: string;
}) {
  return (
    <div style={cardStyle}>
      <div style={{ color: "#64748b", fontSize: 13 }}>{label}</div>
      <div
        style={{
          fontSize: 30,
          fontWeight: 800,
          color,
          marginTop: 8,
        }}
      >
        {value}
      </div>
    </div>
  );
}

const cardStyle: React.CSSProperties = {
  padding: 20,
  border: "1px solid #e2e8f0",
  borderRadius: 12,
  background: "#ffffff",
  marginBottom: 12,
};
