import { useEffect, useState } from "react";
import { createIncidentResolution } from "../services/incidentResolutionService";


import {
  doc,
  getDoc,
} from "firebase/firestore";
import { useNavigate, useParams } from "react-router-dom";

import { db } from "../config/firebase";
import { canAccessArea, isAdmin, type AppUser } from "../types/user";

interface Incident {
  id: string;
  deviceId?: string;
  deviceCode?: string;
  deviceName?: string;
  title?: string;
  description?: string;
  severity?: string;
  status?: string;
  resolution?: string;
}

interface DeviceAccessRecord {
  areaId?: string;
}

interface IncidentResolveProps {
  appUser: AppUser;
}

export default function IncidentResolve({ appUser }: IncidentResolveProps) {
  const { incidentId } = useParams();
  const navigate = useNavigate();

  const [incident, setIncident] = useState<Incident | null>(null);
  const [resolution, setResolution] = useState("");
  const [outcome, setOutcome] = useState<"OPEN" | "RESOLVED">("RESOLVED");

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadIncident() {
      if (!incidentId) {
        setError("Không xác định được sự cố.");
        setLoading(false);
        return;
      }

      try {
        const incidentRef = doc(
          db,
          "incidents",
          incidentId
        );

        const snapshot = await getDoc(incidentRef);

        if (!snapshot.exists()) {
          setError("Không tìm thấy sự cố.");
          return;
        }

        const data: Incident = {
          id: snapshot.id,
          ...snapshot.data(),
        };

        if (!data.deviceId) {
          setError("Sự cố không có thông tin thiết bị hợp lệ.");
          return;
        }

        const deviceSnapshot = await getDoc(
          doc(db, "devices", data.deviceId),
        );

        if (!deviceSnapshot.exists()) {
          setError("Không tìm thấy thiết bị của sự cố.");
          return;
        }

        const deviceData = deviceSnapshot.data() as DeviceAccessRecord;

        if (
          !isAdmin(appUser) &&
          !canAccessArea(appUser, deviceData.areaId?.trim() || "")
        ) {
          setError("Bạn không có quyền xử lý sự cố này.");
          return;
        }

        setIncident(data);
        setResolution(data.resolution || "");
      } catch (err) {
  console.error(err);

  if (err instanceof Error) {
    if (err.message === "INCIDENT_NOT_FOUND") {
      setError("Sự cố không còn tồn tại.");
    } else if (err.message === "INCIDENT_STATUS_CHANGED") {
      setError(
        "Trạng thái sự cố đã thay đổi. Vui lòng tải lại trang trước khi tiếp tục."
      );
    } else {
      setError("Không thể cập nhật sự cố.");
    }
  } else {
    setError("Không thể cập nhật sự cố.");
  }
} finally {
        setLoading(false);
      }
    }

    loadIncident();
  }, [appUser, incidentId]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    /* Chỉ cho phép gửi xử lý từ giao diện khi sự cố đang mở */
if (!incidentId || !incident || incident.status !== "OPEN") {
  setError("Sự cố không ở trạng thái cho phép xử lý.");
  return;
}

    if (!resolution.trim()) {
      setError("Vui lòng nhập nội dung xử lý.");
      return;
    }

    try {
      setSaving(true);
      setError("");

/* =========================================================
   LƯU KẾT QUẢ KHẮC PHỤC SỰ CỐ

   - Gọi service dùng chung.
   - Lưu lịch sử từng lần khắc phục.
   - Tự động ghi nhận người xử lý.
   - Chuyển sự cố sang RESOLVED.
========================================================= */

await createIncidentResolution({
  incidentId,
  resolution: resolution.trim(),
  outcome,
});

      navigate(`/devices/${incident.deviceId}`);
    } catch (err) {
      console.error(err);
      setError("Không thể cập nhật sự cố.");
    } finally {
      setSaving(false);
    }
  }
/* =========================================================
   HIỂN THỊ TRẠNG THÁI ĐANG TẢI
========================================================= */

if (loading) {
  return <p>Đang tải thông tin sự cố...</p>;
}

  if (error && !incident) {
    return (
      <div className="panel">
        <h2>Không thể mở sự cố</h2>
        <p>{error}</p>
      </div>
    );
  }

  if (!incident) {
  return null;
}

/* =========================================================
   XÁC ĐỊNH CHẾ ĐỘ HIỂN THỊ SỰ CỐ

   - OPEN: Cho phép nhập và lưu kết quả xử lý.
   - RESOLVED/CLOSED: Chỉ xem, không cho xử lý lại.
   - Trạng thái khác: Không cho cập nhật ngoài quy trình.
========================================================= */
const canResolve = incident.status === "OPEN";

const isResolved =
  incident.status === "RESOLVED" ||
  incident.status === "CLOSED";


  return (
    <div className="page">
      <div className="page-header">
        <div>
          <button
            type="button"
            className="back-button"
            onClick={() =>
              navigate(`/devices/${incident.deviceId}`)
            }
          >
            ← Quay lại thiết bị
          </button>

          {/* Tiêu đề thay đổi theo trạng thái sự cố */}
<h1>
  {canResolve ? "Xử lý sự cố" : "Chi tiết sự cố"}
</h1>

<p className="page-subtitle">
  {canResolve
    ? "Cập nhật kết quả khắc phục sự cố thiết bị"
    : "Xem thông tin và kết quả xử lý sự cố"}
</p>
        </div>
      </div>

      <section className="panel detail-card">
        <h2>Thông tin sự cố</h2>

        <div className="detail-list">
          <div>
            <span>Thiết bị</span>
            <strong>
              {incident.deviceCode || "-"}
              {incident.deviceName
                ? ` - ${incident.deviceName}`
                : ""}
            </strong>
          </div>

          <div>
            <span>Nội dung</span>
            <strong>{incident.title || "-"}</strong>
          </div>

          <div>
            <span>Mức độ</span>
            <strong>{incident.severity || "-"}</strong>
          </div>

          <div>
            <span>Trạng thái</span>
            <strong>
              {incident.status === "OPEN"
                 ? "Đang mở"
                  : incident.status === "RESOLVED"
                  ? "Đã xử lý"
                  : incident.status === "CLOSED"
                  ? "Đã đóng"
                  : incident.status || "-"}
            </strong>
          </div>
        </div>

        {incident.description && (
          <>
            <h3>Mô tả</h3>
            <p>{incident.description}</p>
          </>
        )}
      </section>

      
{/* =========================================================
    KẾT QUẢ XỬ LÝ SỰ CỐ

    OPEN:
      Cho phép nhập và hoàn thành xử lý.

    RESOLVED / CLOSED:
      Chỉ hiển thị kết quả, không cho chỉnh sửa.

    Trạng thái khác:
      Chỉ xem, không cho cập nhật ngoài quy trình.
========================================================= */}
<section className="panel detail-card">
  <h2>Kết quả xử lý</h2>

  {error && (
    <div className="form-error">
      {error}
    </div>
  )}

  {canResolve ? (
    /* =====================================================
       BIỂU MẪU XỬ LÝ SỰ CỐ ĐANG MỞ
    ===================================================== */
    <form onSubmit={handleSubmit}>
      <div className="form-group">
        <label htmlFor="incident-resolution">
          Nội dung xử lý <span>*</span>
        </label>

        <textarea
          id="incident-resolution"
          value={resolution}
          onChange={(e) =>
            setResolution(e.target.value)
          }
          placeholder="Nhập nguyên nhân, biện pháp khắc phục và kết quả kiểm tra sau xử lý."
          rows={6}
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="incident-resolution-outcome">
          Kết quả khắc phục <span>*</span>
        </label>

        <select
          id="incident-resolution-outcome"
          value={outcome}
          onChange={(event) =>
            setOutcome(event.target.value as "OPEN" | "RESOLVED")
          }
        >
          <option value="RESOLVED">Khắc phục đạt — chờ xác minh</option>
          <option value="OPEN">Chưa đạt — giữ sự cố đang mở</option>
        </select>

        <p className="form-help">
          Mỗi lần gửi được lưu thành lịch sử riêng. Sự cố chỉ chuyển sang chờ
          xác minh khi khắc phục đạt.
        </p>
      </div>

      <div className="form-actions">
        <button
          type="button"
          className="btn-secondary"
          onClick={() =>
            navigate(`/devices/${incident.deviceId}`)
          }
        >
          Hủy
        </button>

        <button
          type="submit"
          className="primary-button"
          disabled={saving}
        >
          {saving
            ? "Đang cập nhật..."
            : outcome === "RESOLVED"
              ? "Gửi chờ xác minh"
              : "Lưu lần khắc phục"}
        </button>
      </div>
    </form>
  ) : (
    /* =====================================================
       CHẾ ĐỘ CHỈ XEM - KHÔNG CHO SỬA KẾT QUẢ
    ===================================================== */
    <div className="detail-list">
      <div>
        <span>Trạng thái xử lý</span>
        <strong>
          {isResolved
            ? incident.status === "CLOSED"
              ? "Đã đóng"
              : "Đã xử lý"
            : incident.status || "Không xác định"}
        </strong>
      </div>

      <div>
        <span>Nội dung xử lý</span>
        <strong>
          {incident.resolution ||
            "Chưa có nội dung xử lý."}
        </strong>
      </div>

      <div className="form-actions">
        {incident.status === "RESOLVED" && (
          <button
            type="button"
            className="primary-button"
            onClick={() => navigate(`/incidents/${incident.id}/verify`)}
          >
            Xác minh sự cố
          </button>
        )}

        <button
          type="button"
          className="btn-secondary"
          onClick={() =>
            navigate(`/devices/${incident.deviceId}`)
          }
        >
          ← Quay lại thiết bị
        </button>
      </div>
    </div>
  )}
</section>
    </div>
  );
}
