import { useEffect, useState } from "react";
import {
  collection,
  getDocs,
  query,
  where,
} from "firebase/firestore";
import { useNavigate, useParams } from "react-router-dom";

import { db } from "../config/firebase";
import { canAccessArea, isAdmin, type AppUser } from "../types/user";

const FIRESTORE_IN_LIMIT = 30;

interface QrDeviceRedirectProps {
  appUser: AppUser;
}

function chunkAreaIds(areaIds: string[]): string[][] {
  const chunks: string[][] = [];

  for (let index = 0; index < areaIds.length; index += FIRESTORE_IN_LIMIT) {
    chunks.push(areaIds.slice(index, index + FIRESTORE_IN_LIMIT));
  }

  return chunks;
}

export default function QrDeviceRedirect({ appUser }: QrDeviceRedirectProps) {
  const { deviceCode } = useParams();
  const navigate = useNavigate();

  const [error, setError] = useState("");

  useEffect(() => {
    let isCurrent = true;

    async function findDevice() {
      if (!deviceCode) {
        setError("Mã QR không hợp lệ.");
        return;
      }

      try {
        setError("");

        const normalizedCode = decodeURIComponent(deviceCode).trim();
        if (!normalizedCode) {
          setError("Mã QR không hợp lệ.");
          return;
        }

        const isAdminUser = isAdmin(appUser);
        const assignedAreaIds = [
          ...new Set(
            appUser.areaIds
              .filter((areaId) => typeof areaId === "string")
              .map((areaId) => areaId.trim())
              .filter(Boolean),
          ),
        ];

        if (!isAdminUser && (!appUser.isActive || assignedAreaIds.length === 0)) {
          setError("Bạn chưa được phân công khu vực để truy cập thiết bị.");
          return;
        }

        const deviceQueries = isAdminUser
          ? [
              getDocs(
                query(
                  collection(db, "devices"),
                  where("code", "==", normalizedCode),
                ),
              ),
            ]
          : chunkAreaIds(assignedAreaIds).map((areaIdsChunk) =>
              getDocs(
                query(
                  collection(db, "devices"),
                  where("code", "==", normalizedCode),
                  where("areaId", "in", areaIdsChunk),
                ),
              ),
            );

        const snapshots = await Promise.all(deviceQueries);
        if (!isCurrent) return;

        const devicesById = new Map(
          snapshots
            .flatMap((snapshot) => snapshot.docs)
            .map((device) => [device.id, device]),
        );
        const devices = [...devicesById.values()];

        if (devices.length === 0) {
          setError(
            isAdminUser
              ? `Không tìm thấy thiết bị có mã ${normalizedCode}.`
              : "Không tìm thấy thiết bị trong phạm vi được cấp.",
          );
          return;
        }

        if (devices.length > 1) {
          setError(
            "Phát hiện dữ liệu mã thiết bị trùng. Vui lòng liên hệ quản trị viên.",
          );
          return;
        }

        const device = devices[0];
        const areaId = device.data().areaId;

        if (
          !canAccessArea(
            appUser,
            typeof areaId === "string" ? areaId.trim() : "",
          )
        ) {
          setError("Bạn không có quyền truy cập thiết bị này.");
          return;
        }

        navigate(`/devices/${device.id}`, { replace: true });
      } catch {
        if (!isCurrent) return;

        setError("Không thể tra cứu thiết bị từ mã QR.");
      }
    }

    void findDevice();

    return () => {
      isCurrent = false;
    };
  }, [appUser, deviceCode, navigate]);

  if (error) {
    return (
      <section className="panel">
        <h2>Không thể mở thiết bị</h2>

        <p>{error}</p>

        <button
          className="table-action"
          onClick={() => navigate("/devices")}
        >
          Danh sách thiết bị
        </button>
      </section>
    );
  }

  return (
    <section className="panel">
      <h2>Đang nhận diện thiết bị...</h2>

      <p>Vui lòng chờ trong giây lát.</p>
    </section>
  );
}
