import { useState } from "react";
import { sendEmailVerification, signOut, type User } from "firebase/auth";
import { auth } from "../config/firebase";
import { acceptCurrentUserInvite } from "../services/userManagementService";

export default function InviteActivation({ user }: { user: User }) {
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  async function acceptInvite() {
    setLoading(true); setMessage("");
    try {
      await acceptCurrentUserInvite(user);
      setMessage("Đã kích hoạt hồ sơ. Đang xác minh quyền truy cập...");
    } catch (error) {
      const code = error instanceof Error ? error.message : "";
      setMessage(code === "EMAIL_NOT_VERIFIED"
        ? "Email chưa được xác minh. Hãy xác minh rồi thử lại."
        : "Không có lời mời hợp lệ hoặc lời mời đã được sử dụng.");
    } finally { setLoading(false); }
  }

  return <div style={{ padding: 30, maxWidth: 560 }}>
    <h2>Nhận lời mời</h2>
    <p>Tài khoản {user.email} chưa có hồ sơ trong hệ thống.</p>
    {!user.emailVerified && <button type="button" onClick={() => void sendEmailVerification(user)}>
      Gửi email xác minh
    </button>}
    <button type="button" disabled={loading} onClick={() => void acceptInvite()}>
      {loading ? "Đang kích hoạt..." : "Nhận lời mời"}
    </button>
    <button type="button" onClick={() => void signOut(auth)}>Đăng xuất</button>
    {message && <p>{message}</p>}
  </div>;
}
