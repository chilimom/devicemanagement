import { useEffect, useRef, useState } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { useNavigate } from "react-router-dom";

export default function QrScanner() {
  const navigate = useNavigate();

  const scannerRef = useRef<Html5Qrcode | null>(null);
  const handledRef = useRef(false);

  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState("");
  const [deviceCode, setDeviceCode] = useState("");

  // =========================================================
  // XỬ LÝ NỘI DUNG QR
  // =========================================================

  function handleQrResult(decodedText: string) {
    try {
      const scannedUrl = new URL(
        decodedText,
        window.location.origin
      );

      if (scannedUrl.origin !== window.location.origin) {
        setError(
          "Mã QR không thuộc hệ thống quản lý thiết bị."
        );
        return false;
      }

      if (!scannedUrl.pathname.startsWith("/q/")) {
        setError(
          "Mã QR không phải mã thiết bị hợp lệ."
        );
        return false;
      }

      const code = decodeURIComponent(
        scannedUrl.pathname.substring(3)
      ).trim();

      if (!code) {
        setError("Không xác định được mã thiết bị.");
        return false;
      }

      handledRef.current = true;

      navigate(`/q/${encodeURIComponent(code)}`);

      return true;
    } catch (err) {
      console.error(err);

      setError(
        "Nội dung QR không đúng định dạng của hệ thống."
      );

      return false;
    }
  }

  // =========================================================
  // BẬT CAMERA
  // =========================================================

  async function startCamera() {
    try {
      setError("");
      handledRef.current = false;

      if (!scannerRef.current) {
        scannerRef.current = new Html5Qrcode(
          "qr-camera-reader"
        );
      }

      const scanner = scannerRef.current;

      await scanner.start(
        {
          facingMode: "environment",
        },
        {
          fps: 10,

          qrbox: {
            width: 250,
            height: 250,
          },
        },
        async (decodedText) => {
          if (handledRef.current) {
            return;
          }

          const success = handleQrResult(decodedText);

          if (success && scanner.isScanning) {
            try {
              await scanner.stop();
            } catch (err) {
              console.warn(
                "Không thể dừng camera:",
                err
              );
            }
          }
        },
        () => {
          // Camera chưa phát hiện QR.
          // Không cần hiển thị lỗi.
        }
      );

      setScanning(true);
    } catch (err) {
      console.error("Không thể mở camera:", err);

      setScanning(false);

      setError(
        "Không thể mở camera. Hãy kiểm tra quyền Camera hoặc sử dụng chức năng chọn ảnh QR."
      );
    }
  }

  // =========================================================
  // DỪNG CAMERA
  // =========================================================

  async function stopCamera() {
    if (
      scannerRef.current &&
      scannerRef.current.isScanning
    ) {
      try {
        await scannerRef.current.stop();
      } catch (err) {
        console.warn(err);
      }
    }

    setScanning(false);
  }

  // =========================================================
  // QUÉT QR TỪ ẢNH
  // =========================================================

  async function handleImageUpload(
    event: React.ChangeEvent<HTMLInputElement>
  ) {
    const file = event.target.files?.[0];

    if (!file) {
      return;
    }

    try {
      setError("");

      if (scanning) {
        await stopCamera();
      }

      const imageScanner = new Html5Qrcode(
        "qr-image-reader"
      );

      const decodedText =
        await imageScanner.scanFile(file, true);

      handleQrResult(decodedText);
    } catch (err) {
      console.error("Không đọc được QR:", err);

      setError(
        "Không tìm thấy mã QR hợp lệ trong ảnh đã chọn."
      );
    } finally {
      event.target.value = "";
    }
  }

  // =========================================================
  // NHẬP MÃ THIẾT BỊ
  // =========================================================

  function openDeviceByCode() {
    const code = deviceCode.trim();

    if (!code) {
      setError("Vui lòng nhập mã thiết bị.");
      return;
    }

    setError("");

    navigate(`/q/${encodeURIComponent(code)}`);
  }

  function handleCodeKeyDown(
    event: React.KeyboardEvent<HTMLInputElement>
  ) {
    if (event.key === "Enter") {
      openDeviceByCode();
    }
  }

  // =========================================================
  // CLEANUP CAMERA
  // =========================================================

  useEffect(() => {
    return () => {
      if (
        scannerRef.current &&
        scannerRef.current.isScanning
      ) {
        scannerRef.current.stop().catch(() => {});
      }
    };
  }, []);

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Quét QR thiết bị</h1>

          <p className="page-subtitle">
            Quét mã QR hoặc nhập mã để mở nhanh hồ sơ thiết bị.
          </p>
        </div>
      </div>

      <section className="panel qr-scan-page">

        {error && (
          <div className="qr-scanner-error">
            {error}
          </div>
        )}

        {/* ================================================
            CAMERA
        ================================================= */}

        <div className="qr-method-card">
          <div className="qr-method-title">
            <div>
              <h2>Quét bằng camera</h2>

              <p>
                Sử dụng camera điện thoại hoặc webcam để quét
                tem QR trên thiết bị.
              </p>
            </div>
          </div>

          <div
            id="qr-camera-reader"
            className={
              scanning
                ? "qr-camera-reader active"
                : "qr-camera-reader"
            }
          />

          {!scanning ? (
            <button
              className="primary-button"
              onClick={startCamera}
            >
              Bật camera quét QR
            </button>
          ) : (
            <button
              className="btn-secondary"
              onClick={stopCamera}
            >
              Dừng camera
            </button>
          )}
        </div>

        {/* ================================================
            ẢNH QR
        ================================================= */}

        <div className="qr-method-card">
          <div className="qr-method-title">
            <div>
              <h2>Quét từ ảnh QR</h2>

              <p>
                Chọn ảnh hoặc ảnh chụp màn hình có chứa mã QR.
              </p>
            </div>
          </div>

          <label className="qr-upload-button">
            Chọn ảnh QR

            <input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              hidden
            />
          </label>

          <div
            id="qr-image-reader"
            style={{ display: "none" }}
          />
        </div>

        {/* ================================================
            NHẬP MÃ
        ================================================= */}

        <div className="qr-method-card">
          <div className="qr-method-title">
            <div>
              <h2>Nhập mã thiết bị</h2>

              <p>
                Dùng khi máy không có camera hoặc không quét
                được QR.
              </p>
            </div>
          </div>

          <div className="qr-code-search">
            <input
              type="text"
              placeholder="Ví dụ: CAM-LG1-001"
              value={deviceCode}
              onChange={(e) =>
                setDeviceCode(e.target.value)
              }
              onKeyDown={handleCodeKeyDown}
            />

            <button
              className="primary-button"
              onClick={openDeviceByCode}
            >
              Mở hồ sơ
            </button>
          </div>
        </div>

      </section>
    </>
  );
}