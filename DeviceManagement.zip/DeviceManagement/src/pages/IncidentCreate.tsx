import { useEffect, useState } from "react";
import {
  addDoc,
  collection,
  doc,
  getDoc,
  runTransaction,
  serverTimestamp,
} from "firebase/firestore";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import type { InspectionRecord,InspectionTask,} from "../types/inspection";

import { db } from "../config/firebase";
import { canAccessArea, isAdmin, type AppUser } from "../types/user";
import ActionIconButton from "../components/ActionIconButton";
interface Device {
  code?: string;
  name?: string;
  areaId?: string;
}

interface IncidentCreateProps {
  appUser: AppUser;
}

export default function IncidentCreate({ appUser }: IncidentCreateProps) {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();

const inspectionRecordId = searchParams.get("inspectionRecordId");
const inspectionTaskId = searchParams.get("inspectionTaskId");
const inspectionCriterionId = searchParams.get("inspectionCriterionId");


  const [device, setDevice] = useState<Device | null>(null);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [severity, setSeverity] = useState("MEDIUM");

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  // =========================================================
  // Tải thông tin thiết bị
  // =========================================================
  useEffect(() => {
    let cancelled = false;

    async function loadDevice() {
      if (!id) {
        setError("Không xác định được thiết bị.");
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError("");
        setDevice(null);
        setTitle("");
        setDescription("");
        setSeverity("MEDIUM");

        const snapshot = await getDoc(doc(db, "devices", id));

        if (cancelled) return;

        if (!snapshot.exists()) {
          setError("Không tìm thấy thiết bị.");
          return;
        }

        const deviceData = snapshot.data() as Device;

        if (
          !isAdmin(appUser) &&
          !canAccessArea(appUser, deviceData.areaId?.trim() || "")
        ) {
          setError("Bạn không có quyền báo cáo sự cố cho thiết bị này.");
          return;
        }

        setDevice(deviceData);
      } catch (err) {
        if (cancelled) return;
        console.error("Lỗi tải thiết bị:", err);
        setError("Không thể tải thông tin thiết bị.");
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    void loadDevice();

    return () => {
      cancelled = true;
    };
  }, [appUser, id]);
    
useEffect(() => {
  let cancelled = false;

  async function loadInspectionSource() {
    if (
      !id ||
      !device ||
      !inspectionRecordId ||
      !inspectionTaskId ||
      !inspectionCriterionId ||
      (!isAdmin(appUser) &&
        !canAccessArea(appUser, device.areaId?.trim() || ""))
    ) {
      return;
    }

    try {
      const snapshot = await getDoc(
        doc(db, "inspectionResults", inspectionRecordId)
      );

      if (cancelled) return;

      if (!snapshot.exists()) {
        throw new Error("Không tìm thấy phiếu tuần kiểm nguồn.");
      }

      const record = snapshot.data() as InspectionRecord;

      if (record.deviceId !== id) {
        throw new Error("Phiếu tuần kiểm không thuộc thiết bị này.");
      }

      const taskResult = record.results.find(
        (item) => item.taskId === inspectionTaskId
      );

      const criterionResult = taskResult?.criteriaResults.find(
        (item) => item.criterionId === inspectionCriterionId
      );

      if (
        !criterionResult ||
        !["FAIL", "WARNING"].includes(criterionResult.status)
      ) {
        throw new Error("Không tìm thấy bất thường hợp lệ.");
      }

      const snapshotData = record as InspectionRecord & {
        planSnapshot?: {
          tasks?: InspectionTask[];
        };
      };

      const task = snapshotData.planSnapshot?.tasks?.find(
        (item) => item.id === inspectionTaskId
      );

      const criterion = task?.criteria.find(
        (item) => item.id === inspectionCriterionId
      );

      const criterionName =
        criterion?.standard || "Bất thường tuần kiểm";

      setTitle(criterionName);

      setDescription(
        [
          `Nguồn: Tuần kiểm ngày ${record.inspectionDate}`,
          `Công việc: ${task?.name || inspectionTaskId}`,
          `Tiêu chuẩn: ${criterionName}`,
          `Kết quả: ${criterionResult.status}`,
          criterionResult.numericValue != null
            ? `Giá trị đo: ${criterionResult.numericValue} ${criterion?.unit || ""}`
            : "",
          criterionResult.note
            ? `Ghi chú: ${criterionResult.note}`
            : "",
        ]
          .filter(Boolean)
          .join("\n")
      );

      setSeverity(
        criterionResult.status === "FAIL" ? "HIGH" : "MEDIUM"
      );
    } catch (err) {
      if (cancelled) return;
      console.error("Lỗi đọc nguồn tuần kiểm:", err);

      setError(
        err instanceof Error
          ? err.message
          : "Không thể tải dữ liệu tuần kiểm."
      );
    }
  }

  void loadInspectionSource();

  return () => {
    cancelled = true;
  };
}, [
  appUser,
  device,
  id,
  inspectionRecordId,
  inspectionTaskId,
  inspectionCriterionId,
]);

async function validateInspectionSource() {
  const sourceIds = [
    inspectionRecordId,
    inspectionTaskId,
    inspectionCriterionId,
  ];

  // Không có tham số nguồn: tạo sự cố thủ công như trước
  if (sourceIds.every((value) => value === null)) {
    return;
  }

  if (!id || sourceIds.some((value) => !value)) {
    throw new Error("Thông tin nguồn tuần kiểm không đầy đủ.");
  }

  const snapshot = await getDoc(
    doc(db, "inspectionResults", inspectionRecordId!)
  );

  if (!snapshot.exists()) {
    throw new Error("Phiếu tuần kiểm nguồn không tồn tại.");
  }

  const record = snapshot.data() as InspectionRecord;

  if (record.deviceId !== id) {
    throw new Error("Phiếu tuần kiểm không thuộc thiết bị này.");
  }

  const task = record.results.find(
    (item) => item.taskId === inspectionTaskId
  );

  const criterion = task?.criteriaResults.find(
    (item) => item.criterionId === inspectionCriterionId
  );

  if (
    !criterion ||
    !["WARNING", "FAIL"].includes(criterion.status)
  ) {
    throw new Error(
      "Tiêu chí nguồn không tồn tại hoặc không có bất thường."
    );
  }
}

  // =========================================================
  // Lưu sự cố
  // =========================================================
 
async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
  e.preventDefault();

  if (saving) return;

  if (!id || !device) {
    setError("Không xác định được thiết bị.");
    return;
  }

  if (
    !isAdmin(appUser) &&
    !canAccessArea(appUser, device.areaId?.trim() || "")
  ) {
    setError("Bạn không có quyền báo cáo sự cố cho thiết bị này.");
    return;
  }

  if (!title.trim()) {
    setError("Vui lòng nhập nội dung sự cố.");
    return;
  }

  const sourceIds = [
    inspectionRecordId,
    inspectionTaskId,
    inspectionCriterionId,
  ];

  const hasSourceParams = sourceIds.some(
    (value) => value !== null
  );

  if (hasSourceParams && sourceIds.some((value) => !value)) {
    setError("Thông tin nguồn tuần kiểm không đầy đủ.");
    return;
  }

  try {
    setSaving(true);
    setError("");

    const incidentData = {
      deviceId: id,
      deviceCode: device.code || "",
      deviceName: device.name || "",

      title: title.trim(),
      description: description.trim(),
      severity,

      status: "OPEN",
      reportedAt: serverTimestamp(),
      resolvedAt: null,
      resolution: "",
    };

    if (hasSourceParams) {
      await validateInspectionSource();

      const recordId = inspectionRecordId!;
      const taskId = inspectionTaskId!;
      const criterionId = inspectionCriterionId!;

      // Một tiêu chí lỗi của một lần kiểm tra
      // chỉ được tạo một sự cố theo luồng mới.
      const incidentId = [
        "inspection",
        recordId,
        taskId,
        criterionId,
      ].join("_");

      const incidentRef = doc(
        db,
        "incidents",
        incidentId
      );

      const inspectionRef = doc(
        db,
        "inspectionResults",
        recordId
      );

      await runTransaction(db, async (transaction) => {
        // Tất cả thao tác đọc phải thực hiện trước ghi.
        const existingIncident = await transaction.get(
          incidentRef
        );

        const inspectionSnapshot = await transaction.get(
          inspectionRef
        );

        if (existingIncident.exists()) {
          throw new Error(
            "Bất thường này đã được chuyển thành sự cố trước đó."
          );
        }

        if (!inspectionSnapshot.exists()) {
          throw new Error(
            "Phiếu tuần kiểm nguồn không tồn tại."
          );
        }

        const record =
          inspectionSnapshot.data() as InspectionRecord;

        if (record.deviceId !== id) {
          throw new Error(
            "Phiếu tuần kiểm không thuộc thiết bị này."
          );
        }

        const task = record.results.find(
          (item) => item.taskId === taskId
        );

        const criterion = task?.criteriaResults.find(
          (item) => item.criterionId === criterionId
        );

        if (
          !criterion ||
          !["WARNING", "FAIL"].includes(criterion.status)
        ) {
          throw new Error(
            "Tiêu chí nguồn không có bất thường hợp lệ."
          );
        }

        transaction.set(incidentRef, {
          ...incidentData,
          sourceType: "INSPECTION",
          inspectionRecordId: recordId,
          inspectionTaskId: taskId,
          inspectionCriterionId: criterionId,
        });
      });
    } else {
      // Tạo sự cố thủ công như trước.
      await addDoc(
        collection(db, "incidents"),
        incidentData
      );
    }

    navigate(`/devices/${id}`);
  } catch (err) {
    console.error("Lỗi lưu sự cố:", err);

    setError(
      err instanceof Error
        ? err.message
        : "Không thể lưu sự cố."
    );
  } finally {
    setSaving(false);
  }
}


  // =========================================================
  // Loading
  // =========================================================
  if (loading) {
    return (
      <div className="page">
        <p>Đang tải thông tin thiết bị...</p>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <ActionIconButton
            icon = "back"
            label="Quay lại chi tiết thiết bị"
            onClick={() => navigate(`/devices/${id}`)}
          />

          <h1>Ghi nhận sự cố</h1>

          <p className="page-subtitle">
            Ghi nhận sự cố phát sinh của thiết bị
          </p>
        </div>
      </div>

      <div className="form-card">
        <div className="device-summary">
          <strong>{device?.code ?? "-"}</strong>
          <span>{device?.name ?? "-"}</span>
        </div>

        {error && <div className="form-error">{error}</div>}

        {device && (
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>
                Nội dung sự cố <span>*</span>
              </label>

              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="VD: Camera mất tín hiệu"
                disabled={saving}
              />
            </div>

            <div className="form-group">
              <label>Mức độ</label>

              <select
                value={severity}
                onChange={(e) => setSeverity(e.target.value)}
                disabled={saving}
              >
                <option value="LOW">Thấp</option>
                <option value="MEDIUM">Trung bình</option>
                <option value="HIGH">Cao</option>
                <option value="CRITICAL">Nghiêm trọng</option>
              </select>
            </div>

            <div className="form-group">
              <label>Mô tả chi tiết</label>

              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Mô tả hiện tượng, thời điểm phát hiện..."
                rows={5}
                disabled={saving}
              />
            </div>

            <div className="form-actions">
              <button
                type="button"
                className="btn-secondary"
                onClick={() => navigate(`/devices/${id}`)}
                disabled={saving}
              >
                Hủy
              </button>

              <button
                type="submit"
                className="btn-primary"
                disabled={saving}
              >
                {saving ? "Đang lưu..." : "Lưu sự cố"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
