import { useEffect, useState } from "react";
import {
  collection,
  documentId,
  getDocs,
  query,
  where,
} from "firebase/firestore";
import { useNavigate } from "react-router-dom";

import { db } from "../config/firebase";
import { beginAppCollectionRead, invalidateAppCollection } from "../services/sharedCollectionCache";
import { isPermissionDenied } from "../services/sharedRamCache";
import { showAppAlert, showAppConfirm } from "../services/appDialog";
import { PermanentDeletionBlockedError, permanentlyDeleteInactiveArea } from "../services/permanentDeletionService";
import { isAdmin, isManager, type AppUser } from "../types/user";
import ActionIconButton from "../components/ActionIconButton";
import "../styles/sub-areas.css";

const FIRESTORE_IN_LIMIT = 30;

function chunkIds(ids: string[]): string[][] {
  const chunks: string[][] = [];
  for (let index = 0; index < ids.length; index += FIRESTORE_IN_LIMIT) {
    chunks.push(ids.slice(index, index + FIRESTORE_IN_LIMIT));
  }
  return chunks;
}

async function getDocumentsByField(
  collectionName: string,
  fieldName: string,
  values: string[],
) {
  const snapshots = await Promise.all(
    chunkIds(values).map((valuesChunk) =>
      getDocs(
        query(
          collection(db, collectionName),
          where(fieldName, "in", valuesChunk),
        ),
      ),
    ),
  );
  return snapshots.flatMap((snapshot) => snapshot.docs);
}

async function getAreasByIds(areaIds: string[]) {
  const snapshots = await Promise.all(
    chunkIds(areaIds).map((areaIdsChunk) =>
      getDocs(
        query(
          collection(db, "areas"),
          where(documentId(), "in", areaIdsChunk),
        ),
      ),
    ),
  );
  return snapshots.flatMap((snapshot) => snapshot.docs);
}

interface Area {
  id: string;
  code?: string;
  name?: string;
  description?: string;
  status?: string;
}

interface Device {
  id: string;
  areaId?: string;
  status?: string;
}

interface AreaWithStats extends Area {
  totalDevices: number;
  activeDevices: number;
  warningDevices: number;
  offlineDevices: number;
}

interface AreasProps {
  appUser: AppUser;
}

export default function Areas({ appUser }: AreasProps) {
  const navigate = useNavigate();
  const isAdminUser = isAdmin(appUser);

  const [areas, setAreas] = useState<AreaWithStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [deletingAreaId, setDeletingAreaId] = useState("");

  // =========================================================
  // LOAD DATA
  // =========================================================

  useEffect(() => {
    let cancelled = false;

    async function loadAreas() {
      try {
        setLoading(true);
        setError("");

        if (!isAdminUser && appUser.areaIds.length === 0) {
          if (!cancelled) {
            setAreas([]);
          }
          return;
        }

        const loadAreaData = async (): Promise<Area[]> => {
          const documents = isAdminUser
            ? await getDocs(collection(db, "areas")).then(
                (snapshot) => snapshot.docs,
              )
            : await getAreasByIds(appUser.areaIds);
          return documents.map((item) => ({
            id: item.id,
            ...item.data(),
          }));
        };
        const loadDeviceData = async (): Promise<Device[]> => {
          const documents = isAdminUser
            ? await getDocs(collection(db, "devices")).then(
                (snapshot) => snapshot.docs,
              )
            : await getDocumentsByField(
                "devices",
                "areaId",
                appUser.areaIds,
              );
          return documents.map((item) => ({
            id: item.id,
            ...item.data(),
          }));
        };

        const areaRead = beginAppCollectionRead(
          appUser,
          "areas",
          loadAreaData,
        );
        const deviceRead = beginAppCollectionRead(
          appUser,
          "devices",
          loadDeviceData,
        );
        if (!areaRead || !deviceRead) {
          throw new Error("Cache scope is not available for verified profile.");
        }

        const applyAreaStats = (areaData: Area[], deviceData: Device[]) => {
          const areasWithStats: AreaWithStats[] = areaData.map((area) => {
            const areaDevices = deviceData.filter(
              (device) => device.areaId === area.id,
            );

            return {
              ...area,
              totalDevices: areaDevices.length,
              activeDevices: areaDevices.filter(
                (device) => device.status === "ACTIVE",
              ).length,
              warningDevices: areaDevices.filter(
                (device) => device.status === "WARNING",
              ).length,
              offlineDevices: areaDevices.filter(
                (device) => device.status === "OFFLINE",
              ).length,
            };
          });
          areasWithStats.sort((a, b) =>
            (a.code || "").localeCompare(b.code || ""),
          );
          setAreas(areasWithStats);
        };

        if (!cancelled && areaRead.snapshot.data && deviceRead.snapshot.data) {
          applyAreaStats(areaRead.snapshot.data, deviceRead.snapshot.data);
          setLoading(false);
        }

        const [areaResult, deviceResult] = await Promise.all([
          areaRead.request,
          deviceRead.request,
        ]);

        if (cancelled) return;
        const finalAreas = areaResult?.committed
          ? areaResult.data
          : areaRead.snapshot.data;
        const finalDevices = deviceResult?.committed
          ? deviceResult.data
          : deviceRead.snapshot.data;
        if (finalAreas && finalDevices) {
          applyAreaStats(finalAreas, finalDevices);
        }

        // =====================================================
        // THỐNG KÊ THIẾT BỊ THEO KHU VỰC
        // =====================================================

      } catch (err) {
        console.error(
          "Lỗi tải khu vực:",
          err
        );

        if (!cancelled) {
          if (isPermissionDenied(err)) {
            setAreas([]);
          }
          setError(
            "Không thể tải danh sách khu vực."
          );
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    void loadAreas();

    return () => {
      cancelled = true;
    };
  }, [appUser, isAdminUser]);

  // =========================================================
  // SEARCH
  // =========================================================

  const filteredAreas = areas.filter(
    (area) => {
      const keyword =
        search.trim().toLowerCase();

      if (!keyword) {
        return true;
      }

      return (
        area.code
          ?.toLowerCase()
          .includes(keyword) ||
        area.name
          ?.toLowerCase()
          .includes(keyword) ||
        area.description
          ?.toLowerCase()
          .includes(keyword)
      );
    }
  );

  async function handlePermanentDelete(area: AreaWithStats) {
    if (!isAdminUser || area.status !== "INACTIVE" || deletingAreaId) return;
    const verificationText = area.code || area.name || area.id;
    const accepted = await showAppConfirm(
      "Thao tác này xóa vĩnh viễn khu vực và không thể khôi phục. Hệ thống sẽ từ chối nếu còn dữ liệu tham chiếu.",
      { title: "Xóa vĩnh viễn khu vực", tone: "error", confirmLabel: "Xóa vĩnh viễn", verificationText },
    );
    if (!accepted) return;
    try {
      setDeletingAreaId(area.id);
      setError("");
      await permanentlyDeleteInactiveArea(area.id);
      invalidateAppCollection("areas");
      setAreas((current) => current.filter((item) => item.id !== area.id));
      await showAppAlert("Đã xóa vĩnh viễn khu vực. Hãy cập nhật dữ liệu khách nếu snapshot công khai đang sử dụng khu vực này.", { tone: "success" });
    } catch (cause) {
      const message = cause instanceof PermanentDeletionBlockedError
        ? cause.message
        : cause instanceof Error ? cause.message : "Không thể xóa khu vực.";
      setError(message);
      await showAppAlert(message, { tone: "error" });
    } finally {
      setDeletingAreaId("");
    }
  }

  // =========================================================
  // KPI
  // =========================================================

  const totalAreas = areas.length;

  const totalDevices = areas.reduce(
    (sum, area) =>
      sum + area.totalDevices,
    0
  );

  // Số KHU VỰC đang hoạt động
  const activeAreas = areas.filter(
    (area) => area.status !== "INACTIVE"
  ).length;

  // Tổng thiết bị WARNING + OFFLINE
  const totalAttention = areas.reduce(
    (sum, area) =>
      sum +
      area.warningDevices +
      area.offlineDevices,
    0
  );

  // =========================================================
  // LOADING
  // =========================================================

  if (loading) {
    return (
      <p>Đang tải danh sách khu vực...</p>
    );
  }

  // =========================================================
  // VIEW
  // =========================================================

  return (
    <>
      {/* HEADER */}

      <div className="page-header">
        <div>
          <h1>Quản lý khu vực</h1>

          <p className="page-subtitle">
            Theo dõi thiết bị theo từng nhà máy,
            xưởng và khu vực
          </p>
        </div>

        {isAdminUser && (
          <button
            className="primary-button"
            onClick={() =>
              navigate("/areas/new")
            }
          >
            + 
          </button>
        )}
      </div>

      {/* KPI */}

      <div className="area-kpi-grid">

        <div className="area-kpi-card">
          <span>Tổng khu vực</span>
          <strong>{totalAreas}</strong>
        </div>

        <div className="area-kpi-card">
          <span>Tổng thiết bị</span>
          <strong>{totalDevices}</strong>
        </div>

        <div className="area-kpi-card kpi-active">
          <span>Khu vực hoạt động</span>
          <strong>{activeAreas}</strong>
        </div>

        <div className="area-kpi-card kpi-attention">
          <span>Thiết bị cần chú ý</span>
          <strong>{totalAttention}</strong>
        </div>

      </div>

      {/* SEARCH */}

      <div className="area-filters">
        <input
          type="text"
          placeholder="Tìm mã khu vực, tên khu vực..."
          value={search}
          onChange={(e) =>
            setSearch(e.target.value)
          }
        />
      </div>

      {error && (
        <div className="form-error">
          {error}
        </div>
      )}

      {/* AREA LIST */}

      <section className="panel">

        {filteredAreas.length === 0 ? (
          <div className="empty-history">
            Không có khu vực phù hợp.
          </div>
        ) : (
          <div className="area-list-table-wrap">
          <table className="area-list-table">
            <thead><tr>
              <th>Khu vực</th>
              <th>Trạng thái</th>
              <th>Thiết bị</th>
              <th>Hoạt động</th>
              <th>Cảnh báo</th>
              <th>Offline</th>
              <th>Thao tác</th>
            </tr></thead>
            <tbody>{filteredAreas.map((area) => {
              const isInactive =
                area.status === "INACTIVE";

              return (
                <tr
                  key={area.id}
                  className={`area-list-row ${
                    isInactive
                      ? "is-inactive"
                      : ""
                  }`}
                >
                  <td data-label="Khu vực"><div className="area-list-identity">
                    <span className="area-code">{area.code || "Chưa có mã"}</span>
                    <strong>{area.name || "Chưa có tên"}</strong>
                    {area.description && <small>{area.description}</small>}
                  </div></td>
                  <td data-label="Trạng thái">
                    <span
                      className={
                        isInactive
                          ? "area-status inactive"
                          : "area-status active"
                      }
                    >
                      {isInactive
                        ? "Ngừng sử dụng"
                        : "Hoạt động"}
                    </span>
                  </td>
                  <td data-label="Thiết bị"><strong className="area-list-number">{area.totalDevices}</strong></td>
                  <td data-label="Hoạt động"><strong className="area-list-number is-active">{area.activeDevices}</strong></td>
                  <td data-label="Cảnh báo"><strong className="area-list-number is-warning">{area.warningDevices}</strong></td>
                  <td data-label="Offline"><strong className="area-list-number is-offline">{area.offlineDevices}</strong></td>
                  <td data-label="Thao tác"><div className="area-list-actions">

                    {isManager(appUser) && (
                      <>
                      <ActionIconButton icon="subareas" label={`Quản lý khu vực con ${area.name || area.code}`} onClick={() => navigate(`/areas/${area.id}/subareas`)} />
                      <ActionIconButton
                        icon="edit" label={`Sửa ${area.name || area.code}`}
                        onClick={() =>
                          navigate(
                            `/areas/${area.id}/edit`
                          )
                        }
                      />
                      </>
                    )}

                    {isAdminUser && isInactive && (
                      <ActionIconButton
                        icon="delete" variant="danger" label={`Xóa vĩnh viễn ${area.name || area.code}`}
                        type="button"
                        disabled={Boolean(deletingAreaId)}
                        onClick={() => void handlePermanentDelete(area)}
                      />
                    )}

                    <ActionIconButton
                      icon="view" label={`Xem thiết bị nhà máy ${area.name || area.code}`}
                      onClick={() =>
                        navigate(
                          `/devices?area=${area.id}`
                        )
                      }
                    />

                  </div></td>

                </tr>
              );
            })}</tbody>
          </table></div>
        )}

      </section>
    </>
  );
}
