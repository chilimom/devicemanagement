
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { collection, doc, getDoc, getDocs } from "firebase/firestore";
import { db } from "../config/firebase";
import { createInspectionTemplate, getInspectionTemplate, updateInspectionTemplate } from "../services/inspectionService";
import { showAppAlert } from "../services/appDialog";
import { isAdmin, type AppUser } from "../types/user";
import type {
  InspectionTask,
  InspectionCriterion,
  InspectionCategory,
  InspectionInputType,
} from "../types/inspection";

import "../styles/inspection-template-form.css";

const WEEKDAYS = [
  { value: 1, label: "T2" },
  { value: 2, label: "T3" },
  { value: 3, label: "T4" },
  { value: 4, label: "T5" },
  { value: 5, label: "T6" },
  { value: 6, label: "T7" },
  { value: 7, label: "CN" },
];

const CATEGORIES: {
  value: InspectionCategory;
  label: string;
}[] = [
  { value: "VISUAL", label: "Ngoại quan" },
  { value: "VIBRATION", label: "Độ rung" },
  { value: "TEMPERATURE", label: "Nhiệt độ" },
  { value: "NOISE", label: "Tiếng ồn" },
  { value: "LEAK", label: "Rò rỉ / nứt vỡ" },
  { value: "ELECTRICAL", label: "Điện áp / dòng điện" },
  { value: "LUBRICATION", label: "Mức dầu / mỡ" },
];

const DAY_NAMES: Record<number, string> = {
  1: "T2",
  2: "T3",
  3: "T4",
  4: "T5",
  5: "T6",
  6: "T7",
  7: "CN",
};

function createCriterion(): InspectionCriterion {
  return {
    id: crypto.randomUUID(),
    category: "VISUAL",
    standard: "",
    inputType: "PASS_FAIL",
    isRequired: true,
  };
}

function createTask(order: number): InspectionTask {
  return {
    id: crypto.randomUUID(),
    name: "",
    description: "",
    order,
    frequency: "WEEKLY",
    weekdays: [1],
    criteria: [createCriterion()],
    isActive: true,
  };
}

interface TemplateArea {
  id: string;
  name: string;
  code: string;
}

export default function InspectionTemplateForm({ appUser }: { appUser: AppUser }) {
  const navigate = useNavigate();
  const { templateId } = useParams<{ templateId: string }>();
  const isEditing = Boolean(templateId);

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [areas, setAreas] = useState<TemplateArea[]>([]);
  const [selectedAreaIds, setSelectedAreaIds] = useState<string[]>([]);

  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState("");
  const [templateLoading, setTemplateLoading] = useState(Boolean(templateId));
  const [templateVersion, setTemplateVersion] = useState(1);
  
const [initialTask] = useState<InspectionTask>(() =>
  createTask(1)
);

const [tasks, setTasks] = useState<InspectionTask[]>([
  initialTask,
]);

const [expandedTaskIds, setExpandedTaskIds] = useState<string[]>([
  initialTask.id,
]);

  useEffect(() => {
    let cancelled = false;

    async function loadAreas() {
      try {
        const documents = isAdmin(appUser)
          ? await getDocs(collection(db, "areas")).then((snapshot) => snapshot.docs)
          : await Promise.all(appUser.areaIds.map((id) => getDoc(doc(db, "areas", id))))
              .then((snapshots) => snapshots.filter((snapshot) => snapshot.exists()));
        if (cancelled) return;
        const nextAreas = documents.map((item) => ({
          id: item.id,
          name: String(item.data().name || item.id),
          code: String(item.data().code || ""),
        })).sort((a, b) => a.name.localeCompare(b.name, "vi"));
        setAreas(nextAreas);
        if (!templateId && !isAdmin(appUser)) setSelectedAreaIds(nextAreas.map((area) => area.id));
      } catch (error) {
        console.error("Không thể tải xưởng cho mẫu tuần kiểm:", error);
        if (!cancelled) setSaveError("Không thể tải danh sách xưởng được phân quyền.");
      }
    }

    void loadAreas();
    return () => { cancelled = true; };
  }, [appUser, templateId]);

  useEffect(() => {
    if (!templateId) return;
    let cancelled = false;

    async function loadTemplate() {
      setTemplateLoading(true);
      setSaveError("");
      try {
        const template = await getInspectionTemplate(templateId!);
        if (!template) throw new Error("Không tìm thấy mẫu tuần kiểm.");
        const templateAreaIds = Array.isArray(template.areaIds) ? template.areaIds : [];
        if (!isAdmin(appUser) && (
          templateAreaIds.length === 0 ||
          templateAreaIds.some((areaId) => !appUser.areaIds.includes(areaId))
        )) {
          throw new Error("Bạn không có quyền xem hoặc sửa mẫu ngoài phạm vi xưởng được giao.");
        }
        if (cancelled) return;
        setName(template.name ?? "");
        setDescription(template.description ?? "");
        setSelectedAreaIds(templateAreaIds);
        const loadedTasks = Array.isArray(template.tasks) ? template.tasks : [];
        setTasks(loadedTasks);
        setExpandedTaskIds(loadedTasks.map((task) => task.id));
        setTemplateVersion(Number(template.version) || 1);
      } catch (error) {
        if (!cancelled) setSaveError(error instanceof Error ? error.message : "Không thể tải mẫu tuần kiểm.");
      } finally {
        if (!cancelled) setTemplateLoading(false);
      }
    }

    void loadTemplate();
    return () => { cancelled = true; };
  }, [appUser, templateId]);


  const toggleExpanded = (taskId: string) => {
    setExpandedTaskIds((current) =>
      current.includes(taskId)
        ? current.filter((id) => id !== taskId)
        : [...current, taskId]
    );
  };

  const updateTask = (
    taskId: string,
    changes: Partial<InspectionTask>
  ) => {
    setTasks((current) =>
      current.map((task) =>
        task.id === taskId ? { ...task, ...changes } : task
      )
    );
  };

  const updateCriterion = (
    taskId: string,
    criterionId: string,
    changes: Partial<InspectionCriterion>
  ) => {
    setTasks((current) =>
      current.map((task) =>
        task.id !== taskId
          ? task
          : {
              ...task,
              criteria: task.criteria.map((criterion) =>
                criterion.id === criterionId
                  ? { ...criterion, ...changes }
                  : criterion
              ),
            }
      )
    );
  };

  const addTask = () => {
    const newTask = createTask(tasks.length + 1);
    setTasks((current) => [...current, newTask]);
    setExpandedTaskIds((current) => [...current, newTask.id]);
  };

  const removeTask = (taskId: string) => {
    setTasks((current) =>
      current
        .filter((task) => task.id !== taskId)
        .map((task, index) => ({
          ...task,
          order: index + 1,
        }))
    );
    setExpandedTaskIds((current) =>
      current.filter((id) => id !== taskId)
    );
  };

  const addCriterion = (taskId: string) => {
    setTasks((current) =>
      current.map((task) =>
        task.id === taskId
          ? {
              ...task,
              criteria: [...task.criteria, createCriterion()],
            }
          : task
      )
    );
  };

  const removeCriterion = (
    taskId: string,
    criterionId: string
  ) => {
    setTasks((current) =>
      current.map((task) =>
        task.id === taskId
          ? {
              ...task,
              criteria: task.criteria.filter(
                (criterion) => criterion.id !== criterionId
              ),
            }
          : task
      )
    );
  };

  const toggleWeekday = (task: InspectionTask, day: number) => {
    const weekdays = task.weekdays.includes(day)
      ? task.weekdays.filter((value) => value !== day)
      : [...task.weekdays, day].sort((a, b) => a - b);

    updateTask(task.id, { weekdays });
  };

  const validate = (): string | null => {
    if (!name.trim()) return "Vui lòng nhập tên mẫu.";

    if (selectedAreaIds.length === 0)
      return "Vui lòng chọn ít nhất một xưởng áp dụng mẫu.";

    if (!isAdmin(appUser) && selectedAreaIds.some((id) => !appUser.areaIds.includes(id)))
      return "Phạm vi xưởng của mẫu không hợp lệ.";

    if (tasks.length === 0)
      return "Mẫu phải có ít nhất một công việc.";

    for (const [index, task] of tasks.entries()) {
      if (!task.name.trim())
        return `Công việc ${index + 1} chưa có tên.`;

      if (task.weekdays.length === 0)
        return `Công việc ${index + 1} chưa chọn ngày kiểm tra.`;

      if (task.criteria.length === 0)
        return `Công việc ${index + 1} chưa có tiêu chuẩn.`;

      for (const criterion of task.criteria) {
        if (!criterion.standard.trim())
          return `Công việc ${index + 1} có tiêu chuẩn chưa nhập nội dung.`;

        if (
          criterion.inputType === "NUMBER" &&
          criterion.minValue != null &&
          criterion.maxValue != null &&
          criterion.minValue > criterion.maxValue
        ) {
          return `Công việc ${index + 1}: giá trị tối thiểu lớn hơn tối đa.`;
        }
      }
    }

    return null;
  };

  const handleSave = async () => {
  if (isSaving) return;

  const error = validate();

  if (error) {
    await showAppAlert(error, { tone: "warning" });
    return;
  }

  setIsSaving(true);
  setSaveError("");

  try {
    const normalizedTasks: InspectionTask[] = tasks.map(
      (task, index) => ({
        id: task.id,
        name: task.name.trim(),
        description: (task.description ?? "").trim(),
        order: index + 1,
        frequency: "WEEKLY",
        weekdays: [...task.weekdays].sort((a, b) => a - b),
        isActive: task.isActive,
        criteria: task.criteria.map((criterion) => ({
          id: criterion.id,
          category: criterion.category,
          standard: criterion.standard.trim(),
          inputType: criterion.inputType,
          isRequired: criterion.isRequired,

          ...(criterion.inputType === "NUMBER"
            ? {
                unit: (criterion.unit ?? "").trim(),
                minValue: criterion.minValue ?? null,
                maxValue: criterion.maxValue ?? null,
              }
            : {}),
        })),
      })
    );

    const data = {
      name: name.trim(),
      description: description.trim(),
      tasks: normalizedTasks,
      areaIds: [...new Set(selectedAreaIds)].sort(),
    };
    if (templateId) {
      await updateInspectionTemplate(templateId, data, { expectedVersion: templateVersion });
    } else {
      await createInspectionTemplate({ ...data, isActive: true, version: 1 });
    }

    await showAppAlert(isEditing ? "Đã cập nhật mẫu tuần kiểm thành công!" : "Đã lưu mẫu tuần kiểm thành công!", { tone: "success" });

    navigate("/inspections/templates");
  } catch (error: unknown) {
    console.error("Lỗi lưu mẫu tuần kiểm:", error);

    const message =
      error instanceof Error
        ? error.message
        : "Không thể lưu mẫu tuần kiểm.";

    setSaveError(message);
  } finally {
    setIsSaving(false);
  }
};

  if (templateLoading) {
    return <div className="itf-page"><p role="status">Đang tải mẫu tuần kiểm...</p></div>;
  }

  return (
    <div className="itf-page">
      <header className="itf-header">
        <div>
          <div className="itf-eyebrow">
            QUẢN LÝ TUẦN KIỂM / {isEditing ? "XEM VÀ SỬA MẪU" : "TẠO MẪU"}
          </div>
          <h1>{isEditing ? "Xem và sửa mẫu tuần kiểm" : "Tạo mẫu tuần kiểm"}</h1>
          <p className="itf-subtitle">
            Thiết lập công việc, tiêu chuẩn và lịch kiểm tra
            mặc định. Lịch có thể tùy chỉnh khi áp dụng
            cho từng thiết bị.
          </p>
        </div>
        <span className="itf-badge">V{templateVersion}</span>
      </header>

      <section className="itf-card">
        <h2 className="itf-section-title">Thông tin mẫu</h2>

        <div className="itf-field">
          <label htmlFor="template-name">Tên mẫu kiểm tra *</label>
          <input
            id="template-name"
            className="itf-input"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ví dụ: Kiểm tra động cơ điện"
          />
        </div>

        <div className="itf-field">
          <label>Xưởng áp dụng *</label>
          <div className="itf-area-options">
            {areas.map((area) => (
              <label key={area.id} className="itf-area-option">
                <input
                  type="checkbox"
                  checked={selectedAreaIds.includes(area.id)}
                  disabled={isSaving}
                  onChange={() => setSelectedAreaIds((current) =>
                    current.includes(area.id)
                      ? current.filter((id) => id !== area.id)
                      : [...current, area.id]
                  )}
                />
                <span>{area.name}{area.code ? ` (${area.code})` : ""}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="itf-field">
          <label htmlFor="template-description">Mô tả</label>
          <textarea
            id="template-description"
            className="itf-input"
            rows={2}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>
      </section>

      <div className="itf-section-header">
        <h2>Danh sách công việc</h2>
        <span className="itf-count">
          {tasks.length} công việc
        </span>
      </div>

      {tasks.map((task, index) => {
        const isExpanded = expandedTaskIds.includes(task.id);

        return (
          <section
            key={task.id}
            className="itf-card itf-task"
          >
            <button
              type="button"
              className="itf-task-header"
              onClick={() => toggleExpanded(task.id)}
              aria-expanded={isExpanded}
            >
              <span className="itf-task-number">
                {String(index + 1).padStart(2, "0")}
              </span>

              <span className="itf-task-heading">
                <strong>
                  {task.name.trim() ||
                    `Công việc ${index + 1}`}
                </strong>
                <span>
                  {task.weekdays
                    .map((day) => DAY_NAMES[day])
                    .join(", ") || "Chưa chọn lịch"}
                  {" · "}
                  {task.criteria.length} tiêu chuẩn
                </span>
              </span>

              <span aria-hidden="true">
                {isExpanded ? "▲" : "▼"}
              </span>
            </button>

            {isExpanded && (
              <div className="itf-task-body">
                <div className="itf-field">
                  <label>Tên công việc *</label>
                  <input
                    className="itf-input"
                    value={task.name}
                    onChange={(e) =>
                      updateTask(task.id, {
                        name: e.target.value,
                      })
                    }
                    placeholder="Ví dụ: Kiểm tra nhiệt độ động cơ"
                  />
                </div>

                <div className="itf-field">
                  <label>Nội dung thực hiện</label>
                  <textarea
                    className="itf-input"
                    rows={2}
                    value={task.description ?? ""}
                    onChange={(e) =>
                      updateTask(task.id, {
                        description: e.target.value,
                      })
                    }
                  />
                </div>

                <div className="itf-field">
                  <label>Ngày kiểm tra mặc định</label>
                  <div className="itf-weekdays">
                    {WEEKDAYS.map((day) => (
                      <button
                        key={day.value}
                        type="button"
                        className={
                          "itf-day" +
                          (task.weekdays.includes(day.value)
                            ? " active"
                            : "")
                        }
                        aria-pressed={task.weekdays.includes(
                          day.value
                        )}
                        onClick={() =>
                          toggleWeekday(task, day.value)
                        }
                      >
                        {day.label}
                      </button>
                    ))}
                  </div>
                </div>

                <h3 className="itf-section-title">
                  Tiêu chuẩn đánh giá
                </h3>

                {task.criteria.map(
                  (criterion, criterionIndex) => (
                    <div
                      key={criterion.id}
                      className="itf-criterion"
                    >
                      <div className="itf-criterion-header">
                        <strong>
                          Tiêu chuẩn {criterionIndex + 1}
                        </strong>
                        <span className="itf-count">
                          {criterion.inputType === "NUMBER"
                            ? "Định lượng"
                            : criterion.inputType === "TEXT"
                            ? "Văn bản"
                            : "Định tính"}
                        </span>
                      </div>

                      <div className="itf-field">
                        <label>Nhóm tiêu chuẩn</label>
                        <select
                          className="itf-input"
                          value={criterion.category}
                          onChange={(e) =>
                            updateCriterion(
                              task.id,
                              criterion.id,
                              {
                                category:
                                  e.target.value as InspectionCategory,
                              }
                            )
                          }
                        >
                          {CATEGORIES.map((category) => (
                            <option
                              key={category.value}
                              value={category.value}
                            >
                              {category.label}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="itf-field">
                        <label>Yêu cầu / tiêu chuẩn đạt *</label>
                        <textarea
                          className="itf-input"
                          rows={2}
                          value={criterion.standard}
                          onChange={(e) =>
                            updateCriterion(
                              task.id,
                              criterion.id,
                              {
                                standard: e.target.value,
                              }
                            )
                          }
                        />
                      </div>

                      <div className="itf-field">
                        <label>Phương thức nhập kết quả</label>
                        <select
                          className="itf-input"
                          value={criterion.inputType}
                          onChange={(e) =>
                            updateCriterion(
                              task.id,
                              criterion.id,
                              {
                                inputType:
                                  e.target.value as InspectionInputType,
                              }
                            )
                          }
                        >
                          <option value="PASS_FAIL">
                            Đạt / Theo dõi / Không đạt
                          </option>
                          <option value="NUMBER">
                            Nhập giá trị đo
                          </option>
                          <option value="TEXT">
                            Nhập nội dung
                          </option>
                        </select>
                      </div>

                      {criterion.inputType === "NUMBER" && (
                        <>
                          <div className="itf-field">
                            <label>Đơn vị đo</label>
                            <input
                              className="itf-input"
                              value={criterion.unit ?? ""}
                              placeholder="°C, mm/s, A..."
                              onChange={(e) =>
                                updateCriterion(
                                  task.id,
                                  criterion.id,
                                  {
                                    unit: e.target.value,
                                  }
                                )
                              }
                            />
                          </div>

                          <div className="itf-grid">
                            {(
                              [
                                [
                                  "minValue",
                                  "Giá trị tối thiểu",
                                ],
                                [
                                  "maxValue",
                                  "Giá trị tối đa",
                                ],
                              ] as const
                            ).map(([field, label]) => (
                              <div
                                key={field}
                                className="itf-field"
                              >
                                <label>{label}</label>
                                <input
                                  type="number"
                                  className="itf-input"
                                  value={
                                    criterion[field] ?? ""
                                  }
                                  onChange={(e) =>
                                    updateCriterion(
                                      task.id,
                                      criterion.id,
                                      {
                                        [field]:
                                          e.target.value === ""
                                            ? null
                                            : Number(
                                                e.target.value
                                              ),
                                      }
                                    )
                                  }
                                />
                              </div>
                            ))}
                          </div>
                        </>
                      )}

                      <label className="itf-checkbox">
                        <input
                          type="checkbox"
                          checked={criterion.isRequired}
                          onChange={(e) =>
                            updateCriterion(
                              task.id,
                              criterion.id,
                              {
                                isRequired:
                                  e.target.checked,
                              }
                            )
                          }
                        />
                        Bắt buộc kiểm tra
                      </label>

                      <button
                        type="button"
                        className="itf-btn itf-btn-danger"
                        onClick={() =>
                          removeCriterion(
                            task.id,
                            criterion.id
                          )
                        }
                      >
                        Xóa tiêu chuẩn
                      </button>
                    </div>
                  )
                )}

                <div className="itf-actions">
                  <button
                    type="button"
                    className="itf-btn"
                    onClick={() => addCriterion(task.id)}
                  >
                    + Thêm tiêu chuẩn
                  </button>

                  <button
                    type="button"
                    className="itf-btn itf-btn-danger"
                    onClick={() => removeTask(task.id)}
                  >
                    Xóa công việc
                  </button>
                </div>
              </div>
            )}
          </section>
        );
      })}

      <div className="itf-actions">
        <button
          type="button"
          className="itf-btn"
          onClick={addTask}
        >
          + Thêm công việc
        </button>

        <button
            type="button"
            className="itf-btn itf-btn-primary"
            onClick={handleSave}
            disabled={isSaving}
            >
            {isSaving ? "Đang lưu..." : isEditing ? "Lưu thay đổi" : "Lưu mẫu tuần kiểm"}
        </button>
      </div>

      {saveError && (
  <p className="itf-note" role="alert" style={{ color: "#b91c1c" }}>
    Không thể lưu mẫu: {saveError}
  </p>
)}

<p className="itf-note">
  Mẫu tuần kiểm được lưu vào Firestore và có thể sử dụng
  làm cấu hình mặc định cho từng thiết bị.
</p>
    </div>
  );
}
