
import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

import { getInspectionTemplates, updateInspectionTemplate } from "../services/inspectionService";
import { showAppAlert, showAppConfirm } from "../services/appDialog";
import { PermanentDeletionBlockedError, permanentlyDeleteInactiveInspectionTemplate } from "../services/permanentDeletionService";
import type { InspectionTemplate } from "../types/inspection";
import { isAdmin, type AppUser } from "../types/user";
import ActionIconButton from "../components/ActionIconButton";
import "../styles/inspection-templates.css";

type StatusFilter = "ALL" | "ACTIVE" | "INACTIVE";

export default function InspectionTemplates({ appUser }: { appUser: AppUser }) {
  const navigate = useNavigate();

  const [templates, setTemplates] = useState<InspectionTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [savingTemplateId, setSavingTemplateId] = useState("");

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("ALL");

  const loadTemplates = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const data = await getInspectionTemplates(appUser);
      setTemplates(data);
    } catch (err: unknown) {
      console.error("Lỗi tải mẫu tuần kiểm:", err);

      setError(
        err instanceof Error
          ? err.message
          : "Không thể tải danh sách mẫu tuần kiểm."
      );
    } finally {
      setLoading(false);
    }
  }, [appUser]);

  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      void loadTemplates();
    });

    return () => window.cancelAnimationFrame(frame);
  }, [loadTemplates]);

  const filteredTemplates = useMemo(() => {
    const keyword = search.trim().toLocaleLowerCase("vi");

    return templates.filter((template) => {
      const name = (template.name ?? "").toLocaleLowerCase("vi");
      const description = (template.description ?? "").toLocaleLowerCase("vi");

      const matchesSearch =
        !keyword ||
        name.includes(keyword) ||
        description.includes(keyword);

      const matchesStatus =
        statusFilter === "ALL" ||
        (statusFilter === "ACTIVE" && template.isActive) ||
        (statusFilter === "INACTIVE" && !template.isActive);

      return matchesSearch && matchesStatus;
    });
  }, [templates, search, statusFilter]);

  const activeCount = templates.filter(
    (template) => template.isActive
  ).length;

  const canManageTemplate = (template: InspectionTemplate) => {
    if (isAdmin(appUser)) return true;
    const templateAreaIds = Array.isArray(template.areaIds) ? template.areaIds : [];
    return templateAreaIds.length > 0
      && templateAreaIds.every((areaId) => appUser.areaIds.includes(areaId));
  };

  const toggleTemplateStatus = async (template: InspectionTemplate) => {
    if (savingTemplateId || !canManageTemplate(template)) return;

    const action = template.isActive ? "ngừng sử dụng" : "khôi phục";
    const accepted = await showAppConfirm(
      `${template.isActive ? "Ngừng sử dụng" : "Khôi phục"} mẫu “${template.name}”?`,
      {
        title: template.isActive ? "Ngừng sử dụng mẫu tuần kiểm" : "Khôi phục mẫu tuần kiểm",
        confirmLabel: template.isActive ? "Ngừng sử dụng" : "Khôi phục",
      },
    );
    if (!accepted) return;

    try {
      setSavingTemplateId(template.id);
      setError("");
      setNotice("");
      await updateInspectionTemplate(template.id, { isActive: !template.isActive });
      await loadTemplates();
      setNotice(`Đã ${action} mẫu tuần kiểm. Các kế hoạch và lịch sử đã tạo vẫn được giữ nguyên.`);
      await showAppAlert(`Đã ${action} mẫu tuần kiểm.`, { tone: "success" });
    } catch (cause) {
      console.error("Không thể thay đổi trạng thái mẫu tuần kiểm:", cause);
      setError("Không thể thay đổi trạng thái mẫu tuần kiểm. Vui lòng kiểm tra quyền và thử lại.");
      await showAppAlert("Không thể thay đổi trạng thái mẫu tuần kiểm.", { tone: "error" });
    } finally {
      setSavingTemplateId("");
    }
  };

  const permanentlyDeleteTemplate = async (template: InspectionTemplate) => {
    if (!isAdmin(appUser) || template.isActive || savingTemplateId) return;
    const accepted = await showAppConfirm(
      "Thao tác này xóa vĩnh viễn mẫu tuần kiểm và không thể khôi phục. Hệ thống sẽ từ chối nếu còn kế hoạch tham chiếu.",
      { title: "Xóa vĩnh viễn mẫu tuần kiểm", tone: "error", confirmLabel: "Xóa vĩnh viễn", verificationText: template.name },
    );
    if (!accepted) return;
    try {
      setSavingTemplateId(template.id);
      setError("");
      setNotice("");
      await permanentlyDeleteInactiveInspectionTemplate(template.id);
      setTemplates((current) => current.filter((item) => item.id !== template.id));
      setNotice("Đã xóa vĩnh viễn mẫu tuần kiểm.");
      await showAppAlert("Đã xóa vĩnh viễn mẫu tuần kiểm.", { tone: "success" });
    } catch (cause) {
      const message = cause instanceof PermanentDeletionBlockedError
        ? cause.message
        : cause instanceof Error ? cause.message : "Không thể xóa mẫu tuần kiểm.";
      setError(message);
      await showAppAlert(message, { tone: "error" });
    } finally {
      setSavingTemplateId("");
    }
  };

  return (
    <main className="inspection-templates-page">
      <div className="inspection-templates-header">
        <div>
          <h1>Mẫu kiểm tra thiết bị</h1>
          <p>
            Quản lý mẫu tuần kiểm, công việc và tiêu chuẩn
            đánh giá thiết bị.
          </p>
        </div>

        <div className="inspection-templates-header-actions">
          <button type="button" className="itf-btn" onClick={() => navigate("/inspections")}>Lịch tuần kiểm</button>
          <button
            type="button"
            className="itf-btn itf-btn-primary"
            onClick={() => navigate("/inspections/templates/new")}
          >
            + Tạo mẫu mới
          </button>
        </div>
      </div>

      <section className="inspection-templates-panel">
        <div className="inspection-templates-panel-heading"><h2>Danh sách mẫu tuần kiểm</h2></div>

        <div className="inspection-templates-body">
        {notice && <div className="inspection-template-notice" role="status">{notice}</div>}
        <div className="inspection-templates-stats">
          <div className="inspection-template-stat">
            <span>Tổng số mẫu</span><strong>{templates.length}</strong>
          </div>
          <div className="inspection-template-stat is-active">
            <span>Đang hoạt động</span><strong>{activeCount}</strong>
          </div>
        </div>

        <div className="inspection-template-filters">
          <div className="inspection-template-field">
            <label htmlFor="inspection-search">
              Tìm kiếm mẫu
            </label>

            <input
              id="inspection-search"
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Nhập tên hoặc mô tả mẫu..."
            />
          </div>

          <div className="inspection-template-field">
            <label htmlFor="inspection-status">
              Trạng thái
            </label>

            <select
              id="inspection-status"
              value={statusFilter}
              onChange={(e) =>
                setStatusFilter(e.target.value as StatusFilter)
              }
            >
              <option value="ALL">Tất cả</option>
              <option value="ACTIVE">Đang hoạt động</option>
              <option value="INACTIVE">Ngừng hoạt động</option>
            </select>
          </div>
        </div>

        {loading && (
          <p className="inspection-template-state" role="status">
            Đang tải danh sách mẫu từ Firestore...
          </p>
        )}

        {!loading && error && (
          <div className="inspection-template-error" role="alert">
            <p>
              Không thể tải dữ liệu: {error}
            </p>

            <button
              type="button"
              className="itf-btn"
              onClick={() => void loadTemplates()}
            >
              Thử tải lại
            </button>
          </div>
        )}

        {!loading && !error && (
          <>
            <p className="inspection-template-result-count">
              Hiển thị {filteredTemplates.length} /{" "}
              {templates.length} mẫu tuần kiểm
            </p>

            <div className="inspection-template-list">
              {filteredTemplates.map((template) => {
                const taskCount = template.tasks?.length ?? 0;

                const criteriaCount = (template.tasks ?? [])
                  .reduce(
                    (total, task) =>
                      total + (task.criteria?.length ?? 0),
                    0
                  );

                return (
                  <div
                    key={template.id}
                    className={`inspection-template-card ${template.isActive ? "" : "is-inactive"}`}
                  >
                    <div className="inspection-template-card-header">
                      <h3>
                        {template.name}
                      </h3>

                      <span className={`inspection-template-status ${template.isActive ? "is-active" : "is-inactive"}`}>
                        {template.isActive
                          ? "Đang hoạt động"
                          : "Ngừng hoạt động"}
                      </span>
                    </div>

                    {template.description && <p className="inspection-template-description">{template.description}</p>}
                    <div className="inspection-template-meta">
                      <div><span>Công việc kiểm tra</span><strong>{taskCount}</strong></div>
                      <div><span>Tiêu chuẩn đánh giá</span><strong>{criteriaCount}</strong></div>
                      <div><span>Phiên bản</span><strong>V{template.version ?? 1}</strong></div>
                    </div>
                    <div className="inspection-template-actions">
                      {canManageTemplate(template) ? (
                        <><ActionIconButton
                          icon="edit" label={`Xem và sửa mẫu ${template.name}`}
                          type="button"
                          disabled={Boolean(savingTemplateId)}
                          onClick={() => navigate(`/inspections/templates/${encodeURIComponent(template.id)}`)}
                        /><ActionIconButton
                          icon={template.isActive ? "deactivate" : "activate"} variant={template.isActive ? "danger" : "default"} label={`${template.isActive ? "Ngừng sử dụng" : "Khôi phục"} mẫu ${template.name}`}
                          type="button"
                          disabled={Boolean(savingTemplateId)}
                          onClick={() => void toggleTemplateStatus(template)}
                        />
                        {isAdmin(appUser) && !template.isActive && (
                          <ActionIconButton
                            icon="delete" variant="danger" label={`Xóa vĩnh viễn mẫu ${template.name}`}
                            type="button"
                            disabled={Boolean(savingTemplateId)}
                            onClick={() => void permanentlyDeleteTemplate(template)}
                          />
                        )}</>
                      ) : (
                        <span className="inspection-template-readonly">Chỉ xem</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {filteredTemplates.length === 0 && (
              <p className="inspection-template-empty">
                {templates.length === 0
                  ? "Chưa có mẫu tuần kiểm. Hãy tạo mẫu đầu tiên."
                  : "Không tìm thấy mẫu phù hợp với bộ lọc."}
              </p>
            )}
          </>
        )}</div>
      </section>
    </main>
  );
}
