import { useEffect, useMemo, useState } from "react";
import {
  addDoc,
  collection,
  doc,
  getDoc,
  getDocs,
  serverTimestamp,
} from "firebase/firestore";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import ActionIconButton from "../components/ActionIconButton";
import { canAccessArea, type AppUser } from "../types/user";

import { db } from "../config/firebase";

// [MỚI] 1. Kiểu nhóm bảo trì
type Category = "PLANNED" | "CORRECTIVE";

interface Device {
  code?: string;
  name?: string;
  areaId?: string;
}

interface MaintenanceType {
  id: string;
  code?: string;
  name?: string;
  isActive?: boolean;
  tasks?: string[];
  areaIds?: string[];
  category?: Category;
}

interface ChecklistItem {
  name: string;
  done: boolean;
}

export default function MaintenanceCreate({ appUser }: { appUser: AppUser }) {
  const navigate = useNavigate();
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const inspectionSource = {
    recordId: searchParams.get("inspectionRecordId") ?? "",
    taskId: searchParams.get("inspectionTaskId") ?? "",
    criterionId: searchParams.get("inspectionCriterionId") ?? "",
  };
  const isInspectionMaintenance = Object.values(inspectionSource).every(Boolean);

  const [device, setDevice] = useState<Device | null>(null);
  const [types, setTypes] = useState<MaintenanceType[]>([]);
  const [typesLoaded, setTypesLoaded] = useState(false);

  // [MỚI] 2. Nhóm bảo trì: luồng tuần kiểm (hoặc ?mode=corrective) là CORRECTIVE
  const [category, setCategory] = useState<Category>(
    isInspectionMaintenance || searchParams.get("mode") === "corrective"
      ? "CORRECTIVE"
      : "PLANNED",
  );

  const [title, setTitle] = useState("");
  const [selectedTypeId, setSelectedTypeId] = useState("");
  const [checklist, setChecklist] = useState<ChecklistItem[]>([]);
  const [description, setDescription] = useState("");
  const [performedBy, setPerformedBy] = useState(appUser.displayName ?? "");
  const [result, setResult] = useState("");

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadDevice() {
      if (!id) return;

      try {
        const snapshot = await getDoc(doc(db, "devices", id));

        if (!snapshot.exists()) {
          setError("Không tìm thấy thiết bị.");
          return;
        }

        const deviceData = snapshot.data() as Device;
        if (!canAccessArea(appUser, deviceData.areaId ?? "")) {
          setError("Bạn không có quyền ghi nhận bảo trì cho thiết bị ngoài khu vực được phân quyền.");
          return;
        }
        setDevice(deviceData);
      } catch (err) {
        console.error(err);
        setError("Không thể tải thông tin thiết bị.");
      }
    }

    loadDevice();
  }, [appUser, id]);

  useEffect(() => {
    async function loadTypes() {
      try {
        const snapshot = await getDocs(collection(db, "maintenanceTypes"));
        setTypes(
          snapshot.docs.map((item) => ({
            id: item.id,
            ...item.data(),
          })) as MaintenanceType[],
        );
      } catch (err) {
        console.error("LỖI LOAD LOẠI BẢO TRÌ:", err);
        setError("Không thể tải danh sách loại bảo trì.");
      } finally {
        setTypesLoaded(true);
      }
    }

    loadTypes();
  }, []);

  // [ĐỔI] 3. Lọc cứng theo nhóm + khu vực của thiết bị (loại không có areaIds = dùng chung)
  const typeOptions = useMemo(() => {
    if (!device) return [];
    const areaId = device.areaId ?? "";

    return types
      .filter(
        (t) =>
          t.isActive !== false &&
          (t.category ?? "PLANNED") === category &&
          (!t.areaIds || t.areaIds.length === 0 || t.areaIds.includes(areaId)),
      )
      .sort((a, b) => (a.name ?? "").localeCompare(b.name ?? "", "vi"));
  }, [types, device, category]);

  const selectedType = typeOptions.find((t) => t.id === selectedTypeId);

  // [MỚI] 4. Đổi nhóm thì xóa loại đang chọn, effect bên dưới sẽ tự chọn loại đầu của nhóm mới
  function changeCategory(next: Category) {
    setCategory(next);
    setSelectedTypeId("");
  }

  // Tự chọn loại đầu tiên khi danh sách sẵn sàng.
  useEffect(() => {
    if (!selectedTypeId && typeOptions.length > 0) {
      setSelectedTypeId(typeOptions[0].id);
    }
  }, [typeOptions, selectedTypeId]);

  // Đổi loại thì nạp lại checklist từ loại đó.
  useEffect(() => {
    setChecklist(
      (selectedType?.tasks ?? []).map((name) => ({ name, done: false })),
    );
  }, [selectedTypeId]); // eslint-disable-line react-hooks/exhaustive-deps

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (!id || !device) {
      setError("Không xác định được thiết bị.");
      return;
    }

    if (!title.trim()) {
      setError("Vui lòng nhập nội dung bảo trì.");
      return;
    }

    if (!selectedType) {
      setError("Vui lòng chọn loại bảo trì.");
      return;
    }

    try {
      setSaving(true);
      setError("");

      await addDoc(collection(db, "maintenances"), {
        deviceId: id,
        deviceCode: device.code || "",
        deviceName: device.name || "",

        title: title.trim(),

        maintenanceType: selectedType.code || "",
        maintenanceTypeId: selectedType.id,
        maintenanceTypeName: selectedType.name || "",
        maintenanceTypeCategory: category, // [ĐỔI] lấy theo nhóm đang chọn
        tasksSnapshot: checklist,

        description: description.trim(),
        performedBy: performedBy.trim(),
        result: result.trim(),

        status: "PENDING_APPROVAL",

        performedAt: serverTimestamp(),
        createdAt: serverTimestamp(),
        ...(isInspectionMaintenance ? { inspectionSource } : {}),
      });

      navigate(`/devices/${id}`);
    } catch (err) {
      console.error(err);
      const code = typeof err === "object" && err !== null && "code" in err
        ? String(err.code)
        : "unknown";
      setError(`Không thể lưu thông tin bảo trì (${code}).`);
    } finally {
      setSaving(false);
    }
  }

  const noTypeAvailable = typesLoaded && device && typeOptions.length === 0;

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <ActionIconButton
            icon="back"
            label="Quay lại chi tiết thiết bị"
            onClick={() => navigate(`/devices/${id}`)}
          />

          <h1>Ghi nhận bảo trì</h1>

          <p className="page-subtitle">
            {isInspectionMaintenance
              ? "Ghi nhận bảo trì cho tiêu chí tuần kiểm chưa đạt. Sau khi bảo trì, hãy kiểm tra bổ sung và ghi nhận kết quả đạt để hoàn tất xử lý."
              : "Ghi nhận hoạt động bảo trì của thiết bị"}
          </p>
        </div>
      </div>

      <div className="form-card">
        <div className="device-summary">
          <strong>{device?.code ?? "Đang tải..."}</strong>
          <span>{device?.name ?? ""}</span>
        </div>

        {error && <div className="form-error">{error}</div>}

        {/* [ĐỔI] thông báo nói rõ nhóm nào đang thiếu loại */}
        {noTypeAvailable && (
          <div className="form-error">
            Chưa có loại bảo trì nhóm{" "}
            {category === "CORRECTIVE" ? "Khắc phục" : "Có kế hoạch"} áp dụng cho
            khu vực của thiết bị này. Vui lòng liên hệ quản lý để tạo loại.
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>
              Nội dung bảo trì <span>*</span>
            </label>

            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="VD: Vệ sinh và kiểm tra camera"
            />
          </div>

          {/* [MỚI] 5. Ô chọn nhóm; luồng tuần kiểm thì khóa */}
          <div className="form-group">
            <label>Nhóm bảo trì</label>
            {isInspectionMaintenance ? (
              <div>Khắc phục (từ tuần kiểm không đạt)</div>
            ) : (
              <select
                value={category}
                onChange={(e) => changeCategory(e.target.value as Category)}
              >
                <option value="PLANNED">Có kế hoạch (định kỳ)</option>
                <option value="CORRECTIVE">Khắc phục (sửa chữa, thay thế)</option>
              </select>
            )}
          </div>

          <div className="form-group">
            <label>
              Loại bảo trì <span>*</span>
            </label>

            <select
              value={selectedTypeId}
              onChange={(e) => setSelectedTypeId(e.target.value)}
              disabled={!typesLoaded || typeOptions.length === 0}
            >
              {typeOptions.length === 0 && (
                <option value="">
                  {typesLoaded ? "Không có loại phù hợp" : "Đang tải..."}
                </option>
              )}
              {typeOptions.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name || t.code}
                </option>
              ))}
            </select>
          </div>

          {checklist.length > 0 && (
            <div className="form-group">
              <label>Checklist công việc</label>
              {checklist.map((item, index) => (
                <label key={index} className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={item.done}
                    disabled={saving}
                    onChange={(e) =>
                      setChecklist(
                        checklist.map((c, i) =>
                          i === index ? { ...c, done: e.target.checked } : c,
                        ),
                      )
                    }
                  />
                  {item.name}
                </label>
              ))}
            </div>
          )}

          <div className="form-group">
            <label>Nội dung thực hiện</label>

            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="VD: Vệ sinh lens, kiểm tra nguồn, dây mạng, jack kết nối..."
              rows={4}
            />
          </div>

          <div className="form-group">
            <label>Người thực hiện</label>

            <input
              type="text"
              value={performedBy}
              onChange={(e) => setPerformedBy(e.target.value)}
              placeholder="VD: Nguyễn Văn A"
            />
          </div>

          <div className="form-group">
            <label>Kết quả</label>

            <textarea
              value={result}
              onChange={(e) => setResult(e.target.value)}
              placeholder="VD: Thiết bị hoạt động bình thường sau bảo trì"
              rows={3}
            />
          </div>

          <div className="form-actions">
            <button
              type="button"
              className="btn-secondary"
              onClick={() => navigate(`/devices/${id}`)}
            >
              Hủy
            </button>

            <button
              type="submit"
              className="btn-primary"
              disabled={saving || !selectedType}
            >
              {saving ? "Đang lưu..." : "Lưu bảo trì"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}