
// import { useEffect, useState, type FormEvent } from "react";
// import {
//   collection,
//   doc,
//   deleteField,
//   getDoc,
//   getDocs,
//   runTransaction,
//   serverTimestamp,
//   query,
//   where,
// } from "firebase/firestore";
// import { useNavigate, useParams } from "react-router-dom";

// import { db } from "../config/firebase";
// import { invalidateAppCollection } from "../services/sharedCollectionCache";
// import { isAdmin, type AppUser } from "../types/user";

// // ======================================================
// // 1. ĐỊNH NGHĨA DỮ LIỆU
// // ======================================================

// interface Area {
//   id: string;
//   code?: string;
//   name?: string;
//   status?: string;
// }

// interface SubArea { id: string; factoryId: string; code: string; name: string; status?: string }

// interface DeviceCategory {
//   id: string;
//   name: string;
//   status: string;
// }

// interface DeviceType {
//   id: string;
//   code?: string;
//   name: string;
//   categoryId: string;
//   isActive: boolean;
//   areaIds: string[];
// }

// interface Device {
//   code?: string;
//   name?: string;
//   areaId?: string;
//   subAreaId?: string;
//   deviceTypeId?: string;
//   manufacturer?: string;
//   model?: string;
//   serialNumber?: string;
//   ipAddress?: string;
//   macAddress?: string;
//   status?: string;
//   description?: string;
//   isActive?: boolean;
// }

// // ======================================================
// // 2. HÀM KIỂM TRA IP VÀ MAC
// // ======================================================

// function isValidIPv4(ip: string) {
//   if (!ip) return true;

//   const parts = ip.split(".");
//   if (parts.length !== 4) return false;

//   return parts.every(
//     (part) =>
//       /^\d{1,3}$/.test(part) &&
//       Number(part) >= 0 &&
//       Number(part) <= 255
//   );
// }

// function isValidMac(mac: string) {
//   if (!mac) return true;

//   return /^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/.test(mac);
// }

// // ======================================================
// // 3. COMPONENT CHỈNH SỬA THIẾT BỊ
// // ======================================================

// export default function DeviceEdit({ appUser }: { appUser: AppUser }) {
//   const { id } = useParams<{ id: string }>();
//   const navigate = useNavigate();

//   // Danh mục lấy từ Firestore
//   const [areas, setAreas] = useState<Area[]>([]);
//   const [subAreas, setSubAreas] = useState<SubArea[]>([]);
//   const [categories, setCategories] = useState<DeviceCategory[]>([]);
//   const [deviceTypes, setDeviceTypes] = useState<DeviceType[]>([]);

//   // Thông tin thiết bị
//   const [code, setCode] = useState("");
//   const [name, setName] = useState("");

//   const [areaId, setAreaId] = useState("");
//   const [subAreaId, setSubAreaId] = useState("");
//   const [categoryId, setCategoryId] = useState("");
//   const [deviceTypeId, setDeviceTypeId] = useState("");

//   // Lưu tham chiếu ban đầu để xử lý danh mục INACTIVE
//   const [, setOriginalAreaId] = useState("");
//   const [originalTypeId, setOriginalTypeId] = useState("");

//   const [manufacturer, setManufacturer] = useState("");
//   const [model, setModel] = useState("");
//   const [serialNumber, setSerialNumber] = useState("");
//   const [ipAddress, setIpAddress] = useState("");
//   const [macAddress, setMacAddress] = useState("");

//   const [status, setStatus] = useState("ACTIVE");
//   const [description, setDescription] = useState("");

//   // Trạng thái xử lý
//   const [loading, setLoading] = useState(true);
//   const [saving, setSaving] = useState(false);
//   const [error, setError] = useState("");
//   const [deviceFound, setDeviceFound] = useState(false);

//   // ====================================================
//   // 4. TẢI THIẾT BỊ VÀ DANH MỤC
//   // ====================================================

//   useEffect(() => {
//     let cancelled = false;

//     async function loadData() {
//       if (!id) {
//         setError("Không xác định được thiết bị.");
//         setLoading(false);
//         return;
//       }

//       try {
//         setLoading(true);
//         setError("");

//         const areaPromise = isAdmin(appUser)
//           ? getDocs(collection(db, "areas")).then((snapshot) => snapshot.docs)
//           : Promise.all(appUser.areaIds.map((area) => getDoc(doc(db, "areas", area))))
//               .then((snapshots) => snapshots.filter((snapshot) => snapshot.exists()));
//         const subAreaPromise = isAdmin(appUser)
//           ? getDocs(collection(db, "subAreas")).then((snapshot) => snapshot.docs)
//           : Promise.all(appUser.areaIds.map((factoryId) => getDocs(query(
//               collection(db, "subAreas"), where("factoryId", "==", factoryId),
//             )))).then((snapshots) => snapshots.flatMap((snapshot) => snapshot.docs));
//         const [
//           deviceSnapshot,
//           areaDocuments,
//           categorySnapshot,
//           typeSnapshot,
//           subAreaSnapshot,
//         ] = await Promise.all([
//           getDoc(doc(db, "devices", id)),
//           areaPromise,
//           getDocs(collection(db, "deviceCategories")),
//           getDocs(collection(db, "deviceTypes")),
//           subAreaPromise,
//         ]);

//         if (cancelled) return;

//         if (!deviceSnapshot.exists()) {
//           setError("Không tìm thấy thiết bị.");
//           setDeviceFound(false);
//           return;
//         }

//         const data = deviceSnapshot.data() as Device;
//         setDeviceFound(true);

//         // Đổ thông tin thiết bị vào biểu mẫu
//         setCode(data.code || deviceSnapshot.id);
//         setName(data.name || "");

//         setAreaId(data.areaId || "");
//         setSubAreaId(data.subAreaId || "");
//         setDeviceTypeId(data.deviceTypeId || "");

//         setOriginalAreaId(data.areaId || "");
//         setOriginalTypeId(data.deviceTypeId || "");

//         setManufacturer(data.manufacturer || "");
//         setModel(data.model || "");
//         setSerialNumber(data.serialNumber || "");
//         setIpAddress(data.ipAddress || "");
//         setMacAddress(data.macAddress || "");

//         setStatus(data.status || "ACTIVE");
//         setDescription(data.description || "");

//         // Danh sách khu vực: giữ cả khu vực cũ đã INACTIVE
//         const areaData: Area[] = areaDocuments.map(
//           (item) => ({
//             ...(item.data() as Omit<Area, "id">),
//             id: item.id,
//           })
//         );

//         setAreas(
//           areaData
//             .filter(
//               (area) =>
//                 area.status !== "INACTIVE" ||
//                 area.id === data.areaId
//             )
//             .sort((a, b) =>
//               (a.code || "").localeCompare(b.code || "")
//             )
//         );
//         setSubAreas(subAreaSnapshot.map((item) => ({ id: item.id, ...(item.data() as Omit<SubArea, "id">) })));

//         // Danh sách lĩnh vực
//         const categoryData: DeviceCategory[] =
//           categorySnapshot.docs.map((item) => ({
//             id: item.id,
//             name: String(item.data().name || item.id),
//             status: String(
//               item.data().status || "ACTIVE"
//             ),
//           }));

//         setCategories(
//           categoryData.sort((a, b) =>
//             a.name.localeCompare(b.name, "vi")
//           )
//         );

//         // Danh sách loại thiết bị
//         const typeData: DeviceType[] = typeSnapshot.docs.map(
//           (item) => ({
//             id: item.id,
//             code: String(item.data().code || ""),
//             name: String(item.data().name || item.id),
//             categoryId: String(item.data().categoryId || ""),
//             isActive: item.data().isActive !== false,
//             areaIds: Array.isArray(item.data().areaIds)
//               ? item.data().areaIds.filter((value: unknown): value is string => typeof value === "string")
//               : [],
//           })
//         );

//         setDeviceTypes(
//           typeData.sort((a, b) =>
//             a.name.localeCompare(b.name, "vi")
//           )
//         );

//         // Tự nhận diện lĩnh vực từ loại thiết bị đã lưu
//         const currentType = typeData.find(
//           (item) => item.id === data.deviceTypeId
//         );

//         setCategoryId(currentType?.categoryId || "");
//       } catch (err) {
//         console.error("Lỗi tải thiết bị:", err);

//         if (!cancelled) {
//           setError("Không thể tải thông tin thiết bị.");
//           setDeviceFound(false);
//         }
//       } finally {
//         if (!cancelled) setLoading(false);
//       }
//     }

//     void loadData();

//     return () => {
//       cancelled = true;
//     };
//   }, [appUser, id]);

//   // ====================================================
//   // 5. LỌC DANH MỤC THEO LĨNH VỰC
//   // ====================================================

//   const originalType = deviceTypes.find(
//     (item) => item.id === originalTypeId
//   );

//   const originalCategoryId = originalType?.categoryId || "";

//   const selectableCategories = categories.filter(
//     (item) =>
//       item.status === "ACTIVE" ||
//       item.id === originalCategoryId
//   );

//   const filteredTypes = deviceTypes.filter(
//     (item) =>
//       item.categoryId === categoryId &&
//       (
//         item.isActive ||
//         item.id === originalTypeId
//       ) && (
//         item.id === originalTypeId ||
//         item.areaIds.length === 0 ||
//         item.areaIds.includes(areaId)
//       )
//   );

//   const selectedArea = areas.find(
//     (item) => item.id === areaId
//   );

//   const selectedCategory = categories.find(
//     (item) => item.id === categoryId
//   );

//   const selectedType = deviceTypes.find(
//     (item) => item.id === deviceTypeId
//   );

//   // Khi đổi lĩnh vực, bỏ lựa chọn loại thiết bị cũ.
//   function handleCategoryChange(value: string) {
//     setCategoryId(value);
//     setDeviceTypeId("");
//     setError("");
//   }

//   // ====================================================
//   // 6. LƯU THAY ĐỔI
//   // ====================================================

//   async function handleSubmit(e: FormEvent<HTMLFormElement>) {
//     e.preventDefault();

//     if (!id || saving || !deviceFound) return;

//     setError("");

//     const normalizedName = name.trim();
//     const normalizedIp = ipAddress.trim();
//     const normalizedMac = macAddress.trim().toUpperCase();

//     if (
//       !normalizedName ||
//       !areaId ||
//       !categoryId ||
//       !deviceTypeId
//     ) {
//       setError("Vui lòng nhập đầy đủ các trường bắt buộc.");
//       return;
//     }

//     if (!isValidIPv4(normalizedIp)) {
//       setError(
//         "Địa chỉ IP không hợp lệ. Ví dụ: 10.192.1.101"
//       );
//       return;
//     }

//     if (!isValidMac(normalizedMac)) {
//       setError(
//         "MAC Address không hợp lệ. Ví dụ: AA:BB:CC:DD:EE:FF"
//       );
//       return;
//     }

//     try {
//       setSaving(true);

//       const deviceRef = doc(db, "devices", id);
//       const areaRef = doc(db, "areas", areaId);
//       const categoryRef = doc(
//         db,
//         "deviceCategories",
//         categoryId
//       );
//       const typeRef = doc(db, "deviceTypes", deviceTypeId);
//       const subAreaRef = subAreaId ? doc(db, "subAreas", subAreaId) : null;

//       // Transaction kiểm tra danh mục mới nhất
//       // trước khi cập nhật hồ sơ thiết bị.
//       await runTransaction(db, async (transaction) => {
//         const [
//           deviceSnap,
//           areaSnap,
//           categorySnap,
//           typeSnap,
//           subAreaSnap,
//         ] = await Promise.all([
//           transaction.get(deviceRef),
//           transaction.get(areaRef),
//           transaction.get(categoryRef),
//           transaction.get(typeRef),
//           subAreaRef ? transaction.get(subAreaRef) : Promise.resolve(null),
//         ]);

//         if (!deviceSnap.exists()) {
//           throw new Error("Thiết bị không còn tồn tại.");
//         }

//         if (!areaSnap.exists()) {
//           throw new Error("Khu vực không còn tồn tại.");
//         }

//         if (!categorySnap.exists()) {
//           throw new Error("Lĩnh vực không còn tồn tại.");
//         }

//         if (!typeSnap.exists()) {
//           throw new Error("Loại thiết bị không còn tồn tại.");
//         }

//         const currentDevice = deviceSnap.data() as Device;
//         const areaData = areaSnap.data();
//         const categoryData = categorySnap.data();
//         const typeData = typeSnap.data();
//         if (subAreaId && (!subAreaSnap?.exists() || subAreaSnap.data().factoryId !== areaId || (subAreaSnap.data().status === "INACTIVE" && currentDevice.subAreaId !== subAreaId))) {
//           throw new Error("Khu vực con không hợp lệ hoặc không thuộc nhà máy đã chọn.");
//         }

//         // Chỉ giữ được khu vực INACTIVE nếu đó là khu vực
//         // đang lưu trong hồ sơ thiết bị tại thời điểm cập nhật.
//         if (
//           areaData.status === "INACTIVE" &&
//           currentDevice.areaId !== areaId
//         ) {
//           throw new Error(
//             "Không thể chuyển thiết bị vào khu vực đã ngừng sử dụng."
//           );
//         }

//         // Tương tự: không được chuyển sang loại INACTIVE.
//         if (
//           typeData.isActive === false &&
//           currentDevice.deviceTypeId !== deviceTypeId
//         ) {
//           throw new Error(
//             "Không thể chuyển sang loại thiết bị đã ngừng sử dụng."
//           );
//         }

//         // Loại thiết bị phải thuộc đúng lĩnh vực đã chọn.
//         if (typeData.categoryId !== categoryId) {
//           throw new Error(
//             "Loại thiết bị không thuộc lĩnh vực đã chọn."
//           );
//         }

//         // Không được chuyển sang lĩnh vực đã ngừng sử dụng.
//         // Chỉ chấp nhận lĩnh vực cũ nếu loại thiết bị không đổi.
//         if (
//           categoryData.status !== "ACTIVE" &&
//           currentDevice.deviceTypeId !== deviceTypeId
//         ) {
//           throw new Error(
//             "Không thể chuyển sang lĩnh vực đã ngừng sử dụng."
//           );
//         }

//         // Chỉ cập nhật thông tin cho phép chỉnh sửa.
//         // Không thay đổi code, isActive, createdAt,
//         // lịch sử sự cố, bảo trì hoặc liên kết QR.
//         transaction.update(deviceRef, {
//           name: normalizedName,
//           areaId,
//           ...(subAreaId ? { subAreaId } : { subAreaId: deleteField() }),
//           deviceTypeId,

//           manufacturer: manufacturer.trim(),
//           model: model.trim(),
//           serialNumber: serialNumber.trim(),

//           ipAddress: normalizedIp,
//           macAddress: normalizedMac,

//           status,
//           description: description.trim(),

//           updatedAt: serverTimestamp(),
//         });
//       });

//       invalidateAppCollection("devices");

//       navigate(`/devices/${id}`);
//     } catch (err) {
//       console.error("Lỗi cập nhật thiết bị:", err);

//       setError(
//         err instanceof Error
//           ? err.message
//           : "Không thể cập nhật thiết bị."
//       );
//     } finally {
//       setSaving(false);
//     }
//   }

//   // ====================================================
//   // 7. TRẠNG THÁI ĐANG TẢI
//   // ====================================================

//   if (loading) {
//     return <p>Đang tải thông tin thiết bị...</p>;
//   }

//   if (!deviceFound) {
//     return (
//       <div>
//         <div className="error-message">
//           {error || "Không tìm thấy thiết bị."}
//         </div>

//         <button
//           type="button"
//           className="secondary-button"
//           onClick={() => navigate("/devices")}
//         >
//           Quay lại danh sách
//         </button>
//       </div>
//     );
//   }

//   // ====================================================
//   // 8. GIAO DIỆN CHỈNH SỬA
//   // ====================================================

//   return (
//     <>
//       <div className="page-header">
//         <div>
//           <h1>Chỉnh sửa thiết bị</h1>
//           <p className="page-subtitle">
//             Cập nhật thông tin thiết bị {code}
//           </p>
//         </div>
//       </div>

//       <form
//         className="device-form"
//         onSubmit={handleSubmit}
//       >
//         {error && (
//           <div className="error-message">
//             {error}
//           </div>
//         )}

//         <div className="form-grid">
//           {/* MÃ THIẾT BỊ */}
//           <label>
//             Mã thiết bị *
//             <input
//               value={code}
//               disabled
//               className="readonly-input"
//             />

//             <small className="form-help-text">
//               Mã thiết bị không thể thay đổi.
//             </small>
//           </label>

//           {/* TÊN THIẾT BỊ */}
//           <label>
//             Tên thiết bị *
//             <input
//               value={name}
//               onChange={(e) => setName(e.target.value)}
//               required
//             />
//           </label>

//           {/* KHU VỰC */}
//           <label>
//             Khu vực *
//             <select
//               value={areaId}
//               onChange={(e) => {
//                 setAreaId(e.target.value);
//                 setSubAreaId("");
//                 setDeviceTypeId("");
//               }}
//               required
//             >
//               <option value="">
//                 -- Chọn khu vực --
//               </option>

//               {areas.map((area) => (
//                 <option
//                   key={area.id}
//                   value={area.id}
//                 >
//                   {area.code} - {area.name}
//                   {area.status === "INACTIVE"
//                     ? " (Ngừng sử dụng)"
//                     : ""}
//                 </option>
//               ))}
//             </select>

//             {selectedArea?.status === "INACTIVE" && (
//               <small style={{ color: "#b45309" }}>
//                 Khu vực hiện tại đã ngừng sử dụng.
//                 Nên chuyển thiết bị sang khu vực hoạt động.
//               </small>
//             )}
//           </label>

//           <label>
//             Khu vực con
//             <select value={subAreaId} onChange={(e) => setSubAreaId(e.target.value)} disabled={!areaId}>
//               <option value="">-- Chưa xác định --</option>
//               {subAreas.filter((item) => item.factoryId === areaId && (item.status !== "INACTIVE" || item.id === subAreaId)).map((item) => (
//                 <option key={item.id} value={item.id}>{item.code} - {item.name}{item.status === "INACTIVE" ? " (Ngừng sử dụng)" : ""}</option>
//               ))}
//             </select>
//           </label>

//           {/* LĨNH VỰC */}
//           <label>
//             Lĩnh vực *
//             <select
//               value={categoryId}
//               onChange={(e) =>
//                 handleCategoryChange(e.target.value)
//               }
//               required
//             >
//               <option value="">
//                 -- Chọn lĩnh vực --
//               </option>

//               {selectableCategories.map((category) => (
//                 <option
//                   key={category.id}
//                   value={category.id}
//                   disabled={
//                     category.status !== "ACTIVE" &&
//                     category.id !== originalCategoryId
//                   }
//                 >
//                   {category.name}
//                   {category.status !== "ACTIVE"
//                     ? " (Ngừng sử dụng)"
//                     : ""}
//                 </option>
//               ))}
//             </select>

//             {selectedCategory?.status !== "ACTIVE" &&
//               selectedCategory && (
//                 <small style={{ color: "#b45309" }}>
//                   Lĩnh vực này đã ngừng sử dụng.
//                 </small>
//               )}
//           </label>

//           {/* LOẠI THIẾT BỊ */}
//           <label>
//             Loại thiết bị *
//             <select
//               value={deviceTypeId}
//               onChange={(e) =>
//                 setDeviceTypeId(e.target.value)
//               }
//               disabled={!categoryId}
//               required
//             >
//               <option value="">
//                 -- Chọn loại thiết bị --
//               </option>

//               {filteredTypes.map((type) => (
//                 <option
//                   key={type.id}
//                   value={type.id}
//                   disabled={
//                     !type.isActive &&
//                     type.id !== originalTypeId
//                   }
//                 >
//                   {type.name || type.code}
//                   {!type.isActive
//                     ? " (Ngừng sử dụng)"
//                     : ""}
//                 </option>
//               ))}
//             </select>

//             {selectedType && !selectedType.isActive && (
//               <small style={{ color: "#b45309" }}>
//                 Loại thiết bị hiện tại đã ngừng sử dụng.
//                 Bạn có thể giữ nguyên hoặc chọn loại khác
//                 đang hoạt động.
//               </small>
//             )}

//             {categoryId && filteredTypes.length === 0 && (
//               <small className="form-help-text">
//                 Lĩnh vực này chưa có loại thiết bị.
//                 Bạn có thể thêm tại Quản trị → Loại thiết bị.
//               </small>
//             )}
//           </label>

//           {/* LIÊN KẾT QUẢN LÝ LOẠI THIẾT BỊ */}
//           <div
//             style={{
//               display: "flex",
//               alignItems: "flex-end",
//             }}
//           >
//             <button
//               type="button"
//               className="secondary-button"
//               onClick={() =>
//                 navigate("/admin/device-types")
//               }
//             >
//               Quản lý loại thiết bị
//             </button>
//           </div>

//           {/* HÃNG SẢN XUẤT */}
//           <label>
//             Hãng sản xuất
//             <input
//               value={manufacturer}
//               onChange={(e) =>
//                 setManufacturer(e.target.value)
//               }
//             />
//           </label>

//           {/* MODEL */}
//           <label>
//             Model
//             <input
//               value={model}
//               onChange={(e) => setModel(e.target.value)}
//             />
//           </label>

//           {/* SERIAL */}
//           <label>
//             Serial Number
//             <input
//               value={serialNumber}
//               onChange={(e) =>
//                 setSerialNumber(e.target.value)
//               }
//             />
//           </label>

//           {/* IP */}
//           <label>
//             Địa chỉ IP
//             <input
//               value={ipAddress}
//               onChange={(e) =>
//                 setIpAddress(e.target.value)
//               }
//               placeholder="10.192.x.x"
//             />
//           </label>

//           {/* MAC */}
//           <label>
//             MAC Address
//             <input
//               value={macAddress}
//               onChange={(e) =>
//                 setMacAddress(e.target.value)
//               }
//               placeholder="AA:BB:CC:DD:EE:FF"
//             />
//           </label>

//           {/* TRẠNG THÁI */}
//           <label>
//             Trạng thái
//             <select
//               value={status}
//               onChange={(e) => setStatus(e.target.value)}
//             >
//               <option value="ACTIVE">Hoạt động</option>
//               <option value="WARNING">Cảnh báo</option>
//               <option value="OFFLINE">Mất kết nối</option>
//               <option value="MAINTENANCE">Bảo trì</option>
//             </select>
//           </label>
//         </div>

//         {/* GHI CHÚ */}
//         <label className="full-field">
//           Ghi chú
//           <textarea
//             value={description}
//             onChange={(e) =>
//               setDescription(e.target.value)
//             }
//             rows={4}
//           />
//         </label>

//         {/* NÚT THAO TÁC */}
//         <div className="form-actions">
//           <button
//             type="button"
//             className="secondary-button"
//             disabled={saving}
//             onClick={() => navigate(`/devices/${id}`)}
//           >
//             Hủy
//           </button>

//           <button
//             type="submit"
//             className="primary-button"
//             disabled={saving}
//           >
//             {saving ? "Đang lưu..." : "Lưu thay đổi"}
//           </button>
//         </div>
//       </form>
//     </>
//   );
// }
import { useEffect, useState, type FormEvent } from "react";
import {
  collection,
  doc,
  deleteField,
  getDoc,
  getDocs,
  runTransaction,
  serverTimestamp,
  query,
  where,
} from "firebase/firestore";
import { useNavigate, useParams } from "react-router-dom";

import { db } from "../config/firebase";
import { invalidateAppCollection } from "../services/sharedCollectionCache";
import { isAdmin, type AppUser } from "../types/user";

// ======================================================
// 1. ĐỊNH NGHĨA DỮ LIỆU
// ======================================================

interface Area {
  id: string;
  code?: string;
  name?: string;
  status?: string;
}

interface SubArea { id: string; factoryId: string; code: string; name: string; status?: string }

interface DeviceCategory {
  id: string;
  name: string;
  status: string;
}

interface DeviceType {
  id: string;
  code?: string;
  name: string;
  categoryId: string;
  isActive: boolean;
  areaIds: string[];
}

interface Device {
  code?: string;
  materialCode?: string;
  locationCode?: string;
  name?: string;
  areaId?: string;
  subAreaId?: string;
  deviceTypeId?: string;
  manufacturer?: string;
  model?: string;
  serialNumber?: string;
  ipAddress?: string;
  macAddress?: string;
  status?: string;
  description?: string;
  isActive?: boolean;
}

// ======================================================
// 2. HÀM KIỂM TRA IP VÀ MAC
// ======================================================

function isValidIPv4(ip: string) {
  if (!ip) return true;

  const parts = ip.split(".");
  if (parts.length !== 4) return false;

  return parts.every(
    (part) =>
      /^\d{1,3}$/.test(part) &&
      Number(part) >= 0 &&
      Number(part) <= 255
  );
}

function isValidMac(mac: string) {
  if (!mac) return true;

  return /^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/.test(mac);
}

// Mã vật tư và mã vị trí: chữ hoa, số và . _ - (cùng quy tắc với trang Thêm thiết bị)
const FREE_CODE_PATTERN = /^[A-Z0-9._-]*$/;

// ======================================================
// 3. COMPONENT CHỈNH SỬA THIẾT BỊ
// ======================================================

export default function DeviceEdit({ appUser }: { appUser: AppUser }) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  // Danh mục lấy từ Firestore
  const [areas, setAreas] = useState<Area[]>([]);
  const [subAreas, setSubAreas] = useState<SubArea[]>([]);
  const [categories, setCategories] = useState<DeviceCategory[]>([]);
  const [deviceTypes, setDeviceTypes] = useState<DeviceType[]>([]);

  // Thông tin thiết bị
  const [code, setCode] = useState("");
  const [materialCode, setMaterialCode] = useState("");
  const [locationCode, setLocationCode] = useState("");
  const [name, setName] = useState("");

  const [areaId, setAreaId] = useState("");
  const [subAreaId, setSubAreaId] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [deviceTypeId, setDeviceTypeId] = useState("");

  // Lưu tham chiếu ban đầu để xử lý danh mục INACTIVE
  const [originalAreaId, setOriginalAreaId] = useState("");
  const [originalTypeId, setOriginalTypeId] = useState("");
  // Serial/IP ban đầu: chỉ kiểm tra trùng khi người dùng thay đổi giá trị
  const [original, setOriginal] = useState({ serial: "", ip: "" });

  const [manufacturer, setManufacturer] = useState("");
  const [model, setModel] = useState("");
  const [serialNumber, setSerialNumber] = useState("");
  const [ipAddress, setIpAddress] = useState("");
  const [macAddress, setMacAddress] = useState("");

  const [status, setStatus] = useState("ACTIVE");
  const [description, setDescription] = useState("");

  // Trạng thái xử lý
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [deviceFound, setDeviceFound] = useState(false);

  // ====================================================
  // 4. TẢI THIẾT BỊ VÀ DANH MỤC
  // ====================================================

  useEffect(() => {
    let cancelled = false;

    async function loadData() {
      if (!id) {
        setError("Không xác định được thiết bị.");
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError("");

        const areaPromise = isAdmin(appUser)
          ? getDocs(collection(db, "areas")).then((snapshot) => snapshot.docs)
          : Promise.all(appUser.areaIds.map((area) => getDoc(doc(db, "areas", area))))
              .then((snapshots) => snapshots.filter((snapshot) => snapshot.exists()));
        const subAreaPromise = isAdmin(appUser)
          ? getDocs(collection(db, "subAreas")).then((snapshot) => snapshot.docs)
          : Promise.all(appUser.areaIds.map((factoryId) => getDocs(query(
              collection(db, "subAreas"), where("factoryId", "==", factoryId),
            )))).then((snapshots) => snapshots.flatMap((snapshot) => snapshot.docs));
        const [
          deviceSnapshot,
          areaDocuments,
          categorySnapshot,
          typeSnapshot,
          subAreaSnapshot,
        ] = await Promise.all([
          getDoc(doc(db, "devices", id)),
          areaPromise,
          getDocs(collection(db, "deviceCategories")),
          getDocs(collection(db, "deviceTypes")),
          subAreaPromise,
        ]);

        if (cancelled) return;

        if (!deviceSnapshot.exists()) {
          setError("Không tìm thấy thiết bị.");
          setDeviceFound(false);
          return;
        }

        const data = deviceSnapshot.data() as Device;
        setDeviceFound(true);

        // Đổ thông tin thiết bị vào biểu mẫu
        setCode(data.code || deviceSnapshot.id);
        setMaterialCode(data.materialCode || "");
        setLocationCode(data.locationCode || "");
        setName(data.name || "");

        setAreaId(data.areaId || "");
        setSubAreaId(data.subAreaId || "");
        setDeviceTypeId(data.deviceTypeId || "");

        setOriginalAreaId(data.areaId || "");
        setOriginalTypeId(data.deviceTypeId || "");

        setManufacturer(data.manufacturer || "");
        setModel(data.model || "");
        setSerialNumber(data.serialNumber || "");
        setIpAddress(data.ipAddress || "");
        setMacAddress(data.macAddress || "");
        setOriginal({
          serial: (data.serialNumber || "").trim(),
          ip: (data.ipAddress || "").trim(),
        });

        setStatus(data.status || "ACTIVE");
        setDescription(data.description || "");

        // Danh sách khu vực: giữ cả khu vực cũ đã INACTIVE
        const areaData: Area[] = areaDocuments.map(
          (item) => ({
            ...(item.data() as Omit<Area, "id">),
            id: item.id,
          })
        );

        setAreas(
          areaData
            .filter(
              (area) =>
                area.status !== "INACTIVE" ||
                area.id === data.areaId
            )
            .sort((a, b) =>
              (a.code || "").localeCompare(b.code || "")
            )
        );
        setSubAreas(subAreaSnapshot.map((item) => ({ id: item.id, ...(item.data() as Omit<SubArea, "id">) })));

        // Danh sách lĩnh vực
        const categoryData: DeviceCategory[] =
          categorySnapshot.docs.map((item) => ({
            id: item.id,
            name: String(item.data().name || item.id),
            status: String(
              item.data().status || "ACTIVE"
            ),
          }));

        setCategories(
          categoryData.sort((a, b) =>
            a.name.localeCompare(b.name, "vi")
          )
        );

        // Danh sách loại thiết bị
        const typeData: DeviceType[] = typeSnapshot.docs.map(
          (item) => ({
            id: item.id,
            code: String(item.data().code || ""),
            name: String(item.data().name || item.id),
            categoryId: String(item.data().categoryId || ""),
            isActive: item.data().isActive !== false,
            areaIds: Array.isArray(item.data().areaIds)
              ? item.data().areaIds.filter((value: unknown): value is string => typeof value === "string")
              : [],
          })
        );

        setDeviceTypes(
          typeData.sort((a, b) =>
            a.name.localeCompare(b.name, "vi")
          )
        );

        // Tự nhận diện lĩnh vực từ loại thiết bị đã lưu
        const currentType = typeData.find(
          (item) => item.id === data.deviceTypeId
        );

        setCategoryId(currentType?.categoryId || "");
      } catch (err) {
        console.error("Lỗi tải thiết bị:", err);

        if (!cancelled) {
          setError("Không thể tải thông tin thiết bị.");
          setDeviceFound(false);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    void loadData();

    return () => {
      cancelled = true;
    };
  }, [appUser, id]);

  // ====================================================
  // 5. LỌC DANH MỤC THEO LĨNH VỰC
  // ====================================================

  const originalType = deviceTypes.find(
    (item) => item.id === originalTypeId
  );

  const originalCategoryId = originalType?.categoryId || "";

  const selectableCategories = categories.filter(
    (item) =>
      item.status === "ACTIVE" ||
      item.id === originalCategoryId
  );

  const filteredTypes = deviceTypes.filter(
    (item) =>
      item.categoryId === categoryId &&
      (
        item.isActive ||
        item.id === originalTypeId
      ) && (
        item.id === originalTypeId ||
        item.areaIds.length === 0 ||
        item.areaIds.includes(areaId)
      )
  );

  const selectedArea = areas.find(
    (item) => item.id === areaId
  );

  const selectedCategory = categories.find(
    (item) => item.id === categoryId
  );

  const selectedType = deviceTypes.find(
    (item) => item.id === deviceTypeId
  );

  // Khi đổi lĩnh vực, bỏ lựa chọn loại thiết bị cũ.
  function handleCategoryChange(value: string) {
    setCategoryId(value);
    setDeviceTypeId("");
    setError("");
  }

  // ====================================================
  // 6. LƯU THAY ĐỔI
  // ====================================================

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();

    if (!id || saving || !deviceFound) return;

    setError("");

    const normalizedName = name.trim();
    const normalizedIp = ipAddress.trim();
    const normalizedMac = macAddress.trim().toUpperCase();
    const normalizedSerial = serialNumber.trim();
    const normalizedMaterial = materialCode.trim().toUpperCase();
    const normalizedLocation = locationCode.trim().toUpperCase();

    if (
      !normalizedName ||
      !areaId ||
      !categoryId ||
      !deviceTypeId
    ) {
      setError("Vui lòng nhập đầy đủ các trường bắt buộc.");
      return;
    }

    if (
      !FREE_CODE_PATTERN.test(normalizedMaterial) ||
      !FREE_CODE_PATTERN.test(normalizedLocation)
    ) {
      setError("Mã vật tư và mã vị trí chỉ gồm chữ, số và các ký tự . _ -");
      return;
    }

    if (!isValidIPv4(normalizedIp)) {
      setError(
        "Địa chỉ IP không hợp lệ. Ví dụ: 10.192.1.101"
      );
      return;
    }

    if (!isValidMac(normalizedMac)) {
      setError(
        "MAC Address không hợp lệ. Ví dụ: AA:BB:CC:DD:EE:FF"
      );
      return;
    }

    try {
      setSaving(true);

      // Kiểm tra trùng serial / IP trong nhà máy đang chọn (bỏ qua chính thiết bị này).
      // Chỉ kiểm tra khi giá trị thay đổi hoặc thiết bị được chuyển sang nhà máy khác.
      const areaChanged = areaId !== originalAreaId;
      const findOtherDevice = async (field: string, value: string) => {
        const snap = await getDocs(
          query(
            collection(db, "devices"),
            where("areaId", "==", areaId),
            where(field, "==", value),
          ),
        );
        return snap.docs.find((item) => item.id !== id);
      };

      if (normalizedSerial && (areaChanged || normalizedSerial !== original.serial)) {
        const other = await findOtherDevice("serialNumber", normalizedSerial);
        if (other) {
          throw new Error(
            `Serial "${normalizedSerial}" đã được dùng cho thiết bị ${other.id}.`
          );
        }
      }

      if (normalizedIp && (areaChanged || normalizedIp !== original.ip)) {
        const other = await findOtherDevice("ipAddress", normalizedIp);
        if (other) {
          throw new Error(
            `Địa chỉ IP ${normalizedIp} đã được dùng cho thiết bị ${other.id}.`
          );
        }
      }

      const deviceRef = doc(db, "devices", id);
      const areaRef = doc(db, "areas", areaId);
      const categoryRef = doc(
        db,
        "deviceCategories",
        categoryId
      );
      const typeRef = doc(db, "deviceTypes", deviceTypeId);
      const subAreaRef = subAreaId ? doc(db, "subAreas", subAreaId) : null;

      // Transaction kiểm tra danh mục mới nhất
      // trước khi cập nhật hồ sơ thiết bị.
      await runTransaction(db, async (transaction) => {
        const [
          deviceSnap,
          areaSnap,
          categorySnap,
          typeSnap,
          subAreaSnap,
        ] = await Promise.all([
          transaction.get(deviceRef),
          transaction.get(areaRef),
          transaction.get(categoryRef),
          transaction.get(typeRef),
          subAreaRef ? transaction.get(subAreaRef) : Promise.resolve(null),
        ]);

        if (!deviceSnap.exists()) {
          throw new Error("Thiết bị không còn tồn tại.");
        }

        if (!areaSnap.exists()) {
          throw new Error("Khu vực không còn tồn tại.");
        }

        if (!categorySnap.exists()) {
          throw new Error("Lĩnh vực không còn tồn tại.");
        }

        if (!typeSnap.exists()) {
          throw new Error("Loại thiết bị không còn tồn tại.");
        }

        const currentDevice = deviceSnap.data() as Device;
        const areaData = areaSnap.data();
        const categoryData = categorySnap.data();
        const typeData = typeSnap.data();
        if (subAreaId && (!subAreaSnap?.exists() || subAreaSnap.data().factoryId !== areaId || (subAreaSnap.data().status === "INACTIVE" && currentDevice.subAreaId !== subAreaId))) {
          throw new Error("Khu vực con không hợp lệ hoặc không thuộc nhà máy đã chọn.");
        }

        // Chỉ giữ được khu vực INACTIVE nếu đó là khu vực
        // đang lưu trong hồ sơ thiết bị tại thời điểm cập nhật.
        if (
          areaData.status === "INACTIVE" &&
          currentDevice.areaId !== areaId
        ) {
          throw new Error(
            "Không thể chuyển thiết bị vào khu vực đã ngừng sử dụng."
          );
        }

        // Tương tự: không được chuyển sang loại INACTIVE.
        if (
          typeData.isActive === false &&
          currentDevice.deviceTypeId !== deviceTypeId
        ) {
          throw new Error(
            "Không thể chuyển sang loại thiết bị đã ngừng sử dụng."
          );
        }

        // Loại thiết bị phải thuộc đúng lĩnh vực đã chọn.
        if (typeData.categoryId !== categoryId) {
          throw new Error(
            "Loại thiết bị không thuộc lĩnh vực đã chọn."
          );
        }

        // Không được chuyển sang lĩnh vực đã ngừng sử dụng.
        // Chỉ chấp nhận lĩnh vực cũ nếu loại thiết bị không đổi.
        if (
          categoryData.status !== "ACTIVE" &&
          currentDevice.deviceTypeId !== deviceTypeId
        ) {
          throw new Error(
            "Không thể chuyển sang lĩnh vực đã ngừng sử dụng."
          );
        }

        // Chỉ cập nhật thông tin cho phép chỉnh sửa.
        // Không thay đổi code, isActive, createdAt,
        // lịch sử sự cố, bảo trì hoặc liên kết QR.
        transaction.update(deviceRef, {
          materialCode: normalizedMaterial,
          locationCode: normalizedLocation,
          name: normalizedName,
          areaId,
          ...(subAreaId ? { subAreaId } : { subAreaId: deleteField() }),
          deviceTypeId,

          manufacturer: manufacturer.trim(),
          model: model.trim(),
          serialNumber: normalizedSerial,

          ipAddress: normalizedIp,
          macAddress: normalizedMac,

          status,
          description: description.trim(),

          updatedAt: serverTimestamp(),
        });
      });

      invalidateAppCollection("devices");

      navigate(`/devices/${id}`);
    } catch (err) {
      console.error("Lỗi cập nhật thiết bị:", err);

      setError(
        err instanceof Error
          ? err.message
          : "Không thể cập nhật thiết bị."
      );
    } finally {
      setSaving(false);
    }
  }

  // ====================================================
  // 7. TRẠNG THÁI ĐANG TẢI
  // ====================================================

  if (loading) {
    return <p>Đang tải thông tin thiết bị...</p>;
  }

  if (!deviceFound) {
    return (
      <div>
        <div className="error-message">
          {error || "Không tìm thấy thiết bị."}
        </div>

        <button
          type="button"
          className="secondary-button"
          onClick={() => navigate("/devices")}
        >
          Quay lại danh sách
        </button>
      </div>
    );
  }

  // ====================================================
  // 8. GIAO DIỆN CHỈNH SỬA
  // ====================================================

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Chỉnh sửa thiết bị</h1>
          <p className="page-subtitle">
            Cập nhật thông tin thiết bị {code}
          </p>
        </div>
      </div>

      <form
        className="device-form"
        onSubmit={handleSubmit}
      >
        {error && (
          <div className="error-message">
            {error}
          </div>
        )}

        <div className="form-grid">
          {/* MÃ THIẾT BỊ */}
          <label>
            Mã thiết bị *
            <input
              value={code}
              disabled
              className="readonly-input"
            />

            <small className="form-help-text">
              Mã do hệ thống tự cấp (nội dung mã QR), không thể thay đổi.
            </small>
          </label>

          {/* MÃ VẬT TƯ (có thể trùng giữa nhiều thiết bị) */}
          <label>
            Mã vật tư
            <input
              value={materialCode}
              onChange={(e) =>
                setMaterialCode(e.target.value.toUpperCase())
              }
              placeholder="VD: 1060080701333"
            />
          </label>

          {/* MÃ VỊ TRÍ */}
          <label>
            Mã vị trí
            <input
              value={locationCode}
              onChange={(e) =>
                setLocationCode(e.target.value.toUpperCase())
              }
              placeholder="VD: 1-06-LC1-1"
            />
          </label>

          {/* TÊN THIẾT BỊ */}
          <label>
            Tên thiết bị *
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </label>

          {/* KHU VỰC */}
          <label>
            Khu vực *
            <select
              value={areaId}
              onChange={(e) => {
                setAreaId(e.target.value);
                setSubAreaId("");
                setDeviceTypeId("");
              }}
              required
            >
              <option value="">
                -- Chọn khu vực --
              </option>

              {areas.map((area) => (
                <option
                  key={area.id}
                  value={area.id}
                >
                  {area.code} - {area.name}
                  {area.status === "INACTIVE"
                    ? " (Ngừng sử dụng)"
                    : ""}
                </option>
              ))}
            </select>

            {selectedArea?.status === "INACTIVE" && (
              <small style={{ color: "#b45309" }}>
                Khu vực hiện tại đã ngừng sử dụng.
                Nên chuyển thiết bị sang khu vực hoạt động.
              </small>
            )}
          </label>

          <label>
            Khu vực con
            <select value={subAreaId} onChange={(e) => setSubAreaId(e.target.value)} disabled={!areaId}>
              <option value="">-- Chưa xác định --</option>
              {subAreas.filter((item) => item.factoryId === areaId && (item.status !== "INACTIVE" || item.id === subAreaId)).map((item) => (
                <option key={item.id} value={item.id}>{item.code} - {item.name}{item.status === "INACTIVE" ? " (Ngừng sử dụng)" : ""}</option>
              ))}
            </select>
          </label>

          {/* LĨNH VỰC */}
          <label>
            Lĩnh vực *
            <select
              value={categoryId}
              onChange={(e) =>
                handleCategoryChange(e.target.value)
              }
              required
            >
              <option value="">
                -- Chọn lĩnh vực --
              </option>

              {selectableCategories.map((category) => (
                <option
                  key={category.id}
                  value={category.id}
                  disabled={
                    category.status !== "ACTIVE" &&
                    category.id !== originalCategoryId
                  }
                >
                  {category.name}
                  {category.status !== "ACTIVE"
                    ? " (Ngừng sử dụng)"
                    : ""}
                </option>
              ))}
            </select>

            {selectedCategory?.status !== "ACTIVE" &&
              selectedCategory && (
                <small style={{ color: "#b45309" }}>
                  Lĩnh vực này đã ngừng sử dụng.
                </small>
              )}
          </label>

          {/* LOẠI THIẾT BỊ */}
          <label>
            Loại thiết bị *
            <select
              value={deviceTypeId}
              onChange={(e) =>
                setDeviceTypeId(e.target.value)
              }
              disabled={!categoryId}
              required
            >
              <option value="">
                -- Chọn loại thiết bị --
              </option>

              {filteredTypes.map((type) => (
                <option
                  key={type.id}
                  value={type.id}
                  disabled={
                    !type.isActive &&
                    type.id !== originalTypeId
                  }
                >
                  {type.name || type.code}
                  {!type.isActive
                    ? " (Ngừng sử dụng)"
                    : ""}
                </option>
              ))}
            </select>

            {selectedType && !selectedType.isActive && (
              <small style={{ color: "#b45309" }}>
                Loại thiết bị hiện tại đã ngừng sử dụng.
                Bạn có thể giữ nguyên hoặc chọn loại khác
                đang hoạt động.
              </small>
            )}

            {categoryId && filteredTypes.length === 0 && (
              <small className="form-help-text">
                Lĩnh vực này chưa có loại thiết bị.
                Bạn có thể thêm tại Quản trị → Loại thiết bị.
              </small>
            )}
          </label>

          {/* LIÊN KẾT QUẢN LÝ LOẠI THIẾT BỊ */}
          <div
            style={{
              display: "flex",
              alignItems: "flex-end",
            }}
          >
            <button
              type="button"
              className="secondary-button"
              onClick={() =>
                navigate("/admin/device-types")
              }
            >
              Quản lý loại thiết bị
            </button>
          </div>

          {/* HÃNG SẢN XUẤT */}
          <label>
            Hãng sản xuất
            <input
              value={manufacturer}
              onChange={(e) =>
                setManufacturer(e.target.value)
              }
            />
          </label>

          {/* MODEL */}
          <label>
            Model
            <input
              value={model}
              onChange={(e) => setModel(e.target.value)}
            />
          </label>

          {/* SERIAL */}
          <label>
            Serial Number
            <input
              value={serialNumber}
              onChange={(e) =>
                setSerialNumber(e.target.value)
              }
            />
          </label>

          {/* IP */}
          <label>
            Địa chỉ IP
            <input
              value={ipAddress}
              onChange={(e) =>
                setIpAddress(e.target.value)
              }
              placeholder="10.192.x.x"
            />
          </label>

          {/* MAC */}
          <label>
            MAC Address
            <input
              value={macAddress}
              onChange={(e) =>
                setMacAddress(e.target.value)
              }
              placeholder="AA:BB:CC:DD:EE:FF"
            />
          </label>

          {/* TRẠNG THÁI */}
          <label>
            Trạng thái
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              <option value="ACTIVE">Hoạt động</option>
              <option value="WARNING">Cảnh báo</option>
              <option value="OFFLINE">Mất kết nối</option>
              <option value="MAINTENANCE">Bảo trì</option>
            </select>
          </label>
        </div>

        {/* GHI CHÚ */}
        <label className="full-field">
          Ghi chú
          <textarea
            value={description}
            onChange={(e) =>
              setDescription(e.target.value)
            }
            rows={4}
          />
        </label>

        {/* NÚT THAO TÁC */}
        <div className="form-actions">
          <button
            type="button"
            className="secondary-button"
            disabled={saving}
            onClick={() => navigate(`/devices/${id}`)}
          >
            Hủy
          </button>

          <button
            type="submit"
            className="primary-button"
            disabled={saving}
          >
            {saving ? "Đang lưu..." : "Lưu thay đổi"}
          </button>
        </div>
      </form>
    </>
  );
}