
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { doc, getDoc } from "firebase/firestore";

import { auth, db } from "../config/firebase";
import { getDeviceInspectionPlan } from "../services/deviceInspectionPlanService";
import { createInspectionResult, getInspectionResult } from "../services/inspectionResultService";
import { showAppAlert } from "../services/appDialog";
import { canAccessArea, type AppUser } from "../types/user";

import type {
  DeviceInspectionPlan,
  InspectionCriterion,
  InspectionCriterionResult,
  InspectionResultStatus,
  InspectionTask,
  InspectionTaskResult,
} from "../types/inspection";

type InspectionType = "SCHEDULED" | "EXTRA";

interface DeviceInfo {
  id: string;
  code?: string;
  name?: string;
  isActive?: boolean;
}

interface DeviceInspectionExecuteProps {
  appUser: AppUser | null;
}

const STATUS_OPTIONS: InspectionResultStatus[] = [
  "PASS",
  "WARNING",
  "FAIL",
];

const STATUS_LABELS: Record<InspectionResultStatus, string> = {
  PASS: "Đạt",
  WARNING: "Cảnh báo",
  FAIL: "Không đạt",
  NOT_CHECKED: "Chưa kiểm tra",
};

function vietnamDate(): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Ho_Chi_Minh",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

function vietnamWeekday(): number {
  const shortDay = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Ho_Chi_Minh",
    weekday: "short",
  }).format(new Date());

  const map: Record<string, number> = {
    Mon: 1,
    Tue: 2,
    Wed: 3,
    Thu: 4,
    Fri: 5,
    Sat: 6,
    Sun: 7,
  };

  return map[shortDay];
}

function aggregateStatus(
  statuses: InspectionResultStatus[]
): InspectionResultStatus {
  if (statuses.includes("FAIL")) return "FAIL";
  if (statuses.includes("WARNING")) return "WARNING";
  if (statuses.includes("NOT_CHECKED")) return "NOT_CHECKED";
  return statuses.length > 0 ? "PASS" : "NOT_CHECKED";
}

function numericStatus(
  criterion: InspectionCriterion,
  value: number
): InspectionResultStatus | null {
  const hasMin = criterion.minValue != null;
  const hasMax = criterion.maxValue != null;

  if (!hasMin && !hasMax) return null;

  if (hasMin && value < criterion.minValue!) return "FAIL";
  if (hasMax && value > criterion.maxValue!) return "FAIL";

  return "PASS";
}

function initialResult(task: InspectionTask): InspectionTaskResult {
  return {
    taskId: task.id,
    status: "NOT_CHECKED",
    criteriaResults: task.criteria.map((criterion) => ({
      criterionId: criterion.id,
      status: "NOT_CHECKED",
      numericValue: null,
      textValue: "",
      note: "",
    })),
    note: "",
  };
}

export default function DeviceInspectionExecute({
  appUser,
}: DeviceInspectionExecuteProps) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const sourceInspectionRecordId = searchParams.get("sourceInspectionRecordId");
  const sourceInspectionTaskId = searchParams.get("sourceInspectionTaskId");
  const sourceInspectionCriterionId = searchParams.get("sourceInspectionCriterionId");
  const isRemediationRetest = Boolean(
    sourceInspectionRecordId && sourceInspectionTaskId && sourceInspectionCriterionId,
  );

  const [device, setDevice] = useState<DeviceInfo | null>(null);
  const [plan, setPlan] = useState<DeviceInspectionPlan | null>(null);

  const [inspectionType, setInspectionType] =
    useState<InspectionType>(() =>
      searchParams.get("inspectionType") === "EXTRA" ? "EXTRA" : "SCHEDULED",
    );

  const [inspectorName, setInspectorName] = useState(
    auth.currentUser?.displayName ||
    auth.currentUser?.email ||
    ""
  );

  const [results, setResults] = useState<InspectionTaskResult[]>([]);
  const [note, setNote] = useState(() => isRemediationRetest
    ? `Kiểm tra bổ sung sau bảo trì từ phiếu ${sourceInspectionRecordId}, công việc ${sourceInspectionTaskId}, tiêu chí ${sourceInspectionCriterionId}.`
    : "");

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [saveError, setSaveError] = useState("");

  const today = vietnamDate();
  const weekday = vietnamWeekday();

  useEffect(() => {
    let cancelled = false;

    async function loadData() {
      if (!id) {
        setError("Không xác định được thiết bị.");
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError("");
        setSaveError("");
        setDevice(null);
        setPlan(null);
        setResults([]);

        const deviceSnapshot = await getDoc(
          doc(db, "devices", id)
        );

        if (cancelled) return;

        if (!deviceSnapshot.exists()) {
          throw new Error("Không tìm thấy thiết bị.");
        }

        const deviceData = deviceSnapshot.data();

        if (
          !canAccessArea(
            appUser,
            typeof deviceData.areaId === "string" ? deviceData.areaId : ""
          )
        ) {
          throw new Error("Bạn không có quyền truy cập thiết bị này.");
        }

        const planData = await getDeviceInspectionPlan(id);

        if (!planData) {
          throw new Error(
            "Thiết bị chưa được gán kế hoạch tuần kiểm."
          );
        }

        if (planData.deviceId !== id) {
          throw new Error("Kế hoạch tuần kiểm không thuộc thiết bị này.");
        }

        if (cancelled) return;

        setDevice({
          id,
          code: deviceData.code,
          name: deviceData.name,
          isActive: deviceData.isActive,
        });

        setPlan(planData);
      } catch (err: unknown) {
        if (!cancelled) {
          setError(
            err instanceof Error
              ? err.message
              : "Không thể tải dữ liệu tuần kiểm."
          );
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    void loadData();

    return () => {
      cancelled = true;
    };
  }, [appUser, id]);

  const visibleTasks = useMemo(() => {
    if (!plan) return [];

    return plan.tasks
      .filter((task) => {
        if (!task.isActive) return false;

        if (inspectionType === "EXTRA") return true;

        return task.weekdays.includes(weekday);
      })
      .sort((a, b) => a.order - b.order);
  }, [plan, inspectionType, weekday]);

  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      setResults(visibleTasks.map(initialResult));
    });

    return () => window.cancelAnimationFrame(frame);
  }, [visibleTasks]);

  function updateCriterion(
    taskId: string,
    criterionId: string,
    changes: Partial<InspectionCriterionResult>
  ) {
    setResults((current) =>
      current.map((taskResult) => {
        if (taskResult.taskId !== taskId) return taskResult;

        const criteriaResults = taskResult.criteriaResults.map(
          (criterionResult) =>
            criterionResult.criterionId === criterionId
              ? { ...criterionResult, ...changes }
              : criterionResult
        );

        return {
          ...taskResult,
          criteriaResults,
          status: aggregateStatus(
            criteriaResults.map((item) => item.status)
          ),
        };
      })
    );
  }

  function updateTaskNote(taskId: string, value: string) {
    setResults((current) =>
      current.map((item) =>
        item.taskId === taskId
          ? { ...item, note: value }
          : item
      )
    );
  }

  function findCriterionResult(
    taskId: string,
    criterionId: string
  ): InspectionCriterionResult | undefined {
    return results
      .find((item) => item.taskId === taskId)
      ?.criteriaResults.find(
        (item) => item.criterionId === criterionId
      );
  }

  async function handleSave() {
    if (!id || !plan || !device || saving) return;

    if (device.isActive === false || !plan.isActive) {
      setSaveError("Thiết bị hoặc kế hoạch đang ngừng hoạt động.");
      return;
    }

    if (visibleTasks.length === 0) {
      setSaveError("Không có công việc cần kiểm tra.");
      return;
    }

    setSaving(true);
    setSaveError("");

    try {
      if (isRemediationRetest) {
        const sourceRecord = await getInspectionResult(sourceInspectionRecordId!);
        const sourceTask = sourceRecord?.results.find((task) => task.taskId === sourceInspectionTaskId);
        const sourceCriterion = sourceTask?.criteriaResults.find((criterion) => criterion.criterionId === sourceInspectionCriterionId);
        const planTask = plan.tasks.find((task) => task.id === sourceInspectionTaskId);
        if (!sourceRecord || sourceRecord.deviceId !== id || !sourceCriterion || !planTask?.criteria.some((criterion) => criterion.id === sourceInspectionCriterionId)) {
          throw new Error("Không tìm thấy tiêu chí tuần kiểm nguồn hợp lệ để kiểm tra lại.");
        }
        if (sourceCriterion.status !== "WARNING" && sourceCriterion.status !== "FAIL") {
          throw new Error("Tiêu chí nguồn không ở trạng thái cần xử lý.");
        }
      }
      // Chỉ lưu kết quả các công việc đang hiển thị.
      const inspectionResults = visibleTasks.map((task) => {
        if (isRemediationRetest && task.id !== sourceInspectionTaskId) return null;
        if (isRemediationRetest && task.id === sourceInspectionTaskId) {
          const sourceValue = results.find((item) => item.taskId === task.id)?.criteriaResults
            .find((item) => item.criterionId === sourceInspectionCriterionId);
          if (!sourceValue || sourceValue.status === "NOT_CHECKED") {
            throw new Error("Vui lòng kiểm tra lại tiêu chí tuần kiểm chưa đạt.");
          }
          return {
            taskId: task.id,
            status: sourceValue.status,
            note: "",
            criteriaResults: [sourceValue],
          };
        }
        const result = results.find(
          (item) => item.taskId === task.id
        );

        if (!result) {
          throw new Error(`Thiếu kết quả công việc: ${task.name}`);
        }

        for (const criterion of task.criteria) {
          const item = result.criteriaResults.find(
            (value) => value.criterionId === criterion.id
          );

          if (!item) {
            throw new Error(
              `Thiếu tiêu chuẩn: ${criterion.standard}`
            );
          }

          if (criterion.isRequired && item.status === "NOT_CHECKED") {
            throw new Error(
              `Chưa hoàn thành: ${criterion.standard}`
            );
          }

          if (
            (item.status === "WARNING" || item.status === "FAIL") &&
            !item.note?.trim()
          ) {
            throw new Error(
              `Vui lòng mô tả bất thường: ${criterion.standard}`
            );
          }
        }

        return result;
      }).filter((result): result is InspectionTaskResult => result !== null);

      await createInspectionResult({
        deviceId: id,
        planId: plan.id,
        planVersion: plan.version,
        inspectionDate: vietnamDate(),
        inspectionType,
        inspectorName: inspectorName.trim(),
        results: inspectionResults,
        note,
        ...(isRemediationRetest ? {
          remediationSource: {
            recordId: sourceInspectionRecordId!,
            taskId: sourceInspectionTaskId!,
            criterionId: sourceInspectionCriterionId!,
          },
        } : {}),
      });

      await showAppAlert("Đã lưu kết quả tuần kiểm thành công!", { tone: "success" });
      navigate(`/devices/${id}`);
    } catch (err: unknown) {
      setSaveError(
        err instanceof Error
          ? err.message
          : "Không thể lưu kết quả tuần kiểm."
      );
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <p>Đang tải kế hoạch tuần kiểm...</p>;

  if (error) {
    return (
      <div style={{ padding: 24 }}>
        <h2>Không thể thực hiện tuần kiểm</h2>
        <p role="alert" style={{ color: "#b91c1c" }}>{error}</p>
        <button onClick={() => navigate("/devices")}>
          Quay về danh sách thiết bị
        </button>
      </div>
    );
  }

  if (!device || !plan) return null;

  const disabled = device.isActive === false || !plan.isActive;

  return (
    <div style={{ padding: 24, maxWidth: 1000, margin: "0 auto" }}>
      <header style={{ marginBottom: 24 }}>
        <h1>Thực hiện tuần kiểm</h1>
        <p>
          <strong>{device.name || "Thiết bị"}</strong>
          {" — "}
          {device.code || device.id}
        </p>
        <p>
          Kế hoạch: {plan.name} (V{plan.version})
        </p>
        <button
          type="button"
          onClick={() => navigate(`/devices/${device.id}`)}
        >
          Quay lại thiết bị
        </button>
      </header>

      {disabled && (
        <p role="alert" style={{ color: "#b91c1c" }}>
          Thiết bị hoặc kế hoạch ngừng hoạt động.
        </p>
      )}

      <section style={cardStyle}>
        <h2>Thông tin lần kiểm tra</h2>

        <label style={labelStyle}>Ngày kiểm tra</label>
        <input value={today} readOnly style={inputStyle} />

        <label style={labelStyle}>Người kiểm tra</label>
        <input
          value={inspectorName}
          disabled={disabled}
          onChange={(e) => setInspectorName(e.target.value)}
          style={inputStyle}
        />

        <label style={labelStyle}>Hình thức kiểm tra</label>
        <select
          value={inspectionType}
          disabled={disabled}
          onChange={(e) =>
            setInspectionType(e.target.value as InspectionType)
          }
          style={inputStyle}
        >
          {!isRemediationRetest && <option value="SCHEDULED">Theo lịch</option>}
          <option value="EXTRA">Kiểm tra bổ sung</option>
        </select>
      </section>

      {isRemediationRetest && (
        <div className="inspection-history-result-note" role="status">
          Đây là lượt kiểm tra bổ sung sau bảo trì. Chỉ tiêu chí nguồn được yêu cầu kiểm tra; khi đạt, luồng tuần kiểm được xem là đã xử lý.
        </div>
      )}

      {visibleTasks.length === 0 && (
        <section style={cardStyle}>
          <p>
            Hôm nay không có công việc theo lịch.
            Bạn có thể chọn "Kiểm tra bổ sung".
          </p>
        </section>
      )}

      {visibleTasks.map((task, taskIndex) => (
        (isRemediationRetest && task.id !== sourceInspectionTaskId) ? null : (
        <section key={task.id} style={cardStyle}>
          <h2>
            {taskIndex + 1}. {task.name}
          </h2>

          {task.description && <p>{task.description}</p>}

          {task.criteria.filter((criterion) => !isRemediationRetest || criterion.id === sourceInspectionCriterionId).map((criterion, criterionIndex) => {
            const value = findCriterionResult(
              task.id,
              criterion.id
            );

            if (!value) return null;

            const hasThreshold =
              criterion.minValue != null ||
              criterion.maxValue != null;

            return (
              <div
                key={criterion.id}
                style={{
                  borderTop: "1px solid #e5e7eb",
                  paddingTop: 16,
                  marginTop: 16,
                }}
              >
                <h3>
                  {criterionIndex + 1}. {criterion.standard}
                  {criterion.isRequired ? " *" : ""}
                </h3>

                {criterion.inputType === "NUMBER" && (
                  <>
                    <label style={labelStyle}>
                      Giá trị đo {criterion.unit ? `(${criterion.unit})` : ""}
                    </label>
                    <input
                      type="number"
                      value={value.numericValue ?? ""}
                      disabled={disabled}
                      onChange={(e) => {
                        const raw = e.target.value;
                        const numberValue =
                          raw === "" ? null : Number(raw);

                        updateCriterion(task.id, criterion.id, {
                          numericValue: numberValue,
                          status:
                            numberValue === null
                              ? "NOT_CHECKED"
                              : numericStatus(criterion, numberValue) ??
                                "NOT_CHECKED",
                        });
                      }}
                      style={inputStyle}
                    />
                    {hasThreshold && (
                      <p style={{ fontSize: 13 }}>
                        Giới hạn:{" "}
                        {criterion.minValue ?? "Không giới hạn"}
                        {" → "}
                        {criterion.maxValue ?? "Không giới hạn"}
                        {criterion.unit ? ` ${criterion.unit}` : ""}
                      </p>
                    )}
                  </>
                )}

                {criterion.inputType === "TEXT" && (
                  <>
                    <label style={labelStyle}>Nội dung kiểm tra</label>
                    <textarea
                      value={value.textValue ?? ""}
                      disabled={disabled}
                      onChange={(e) =>
                        updateCriterion(task.id, criterion.id, {
                          textValue: e.target.value,
                          status: e.target.value.trim()
                            ? value.status
                            : "NOT_CHECKED",
                        })
                      }
                      style={inputStyle}
                      rows={3}
                    />
                  </>
                )}

                {(criterion.inputType !== "NUMBER" || !hasThreshold) && (
                  <>
                    <label style={labelStyle}>Đánh giá</label>
                    <select
                      value={value.status}
                      disabled={disabled}
                      onChange={(e) =>
                        updateCriterion(task.id, criterion.id, {
                          status: e.target.value as InspectionResultStatus,
                        })
                      }
                      style={inputStyle}
                    >
                      <option value="NOT_CHECKED">
                        Chưa kiểm tra
                      </option>
                      {STATUS_OPTIONS.map((status) => (
                        <option key={status} value={status}>
                          {STATUS_LABELS[status]}
                        </option>
                      ))}
                    </select>
                  </>
                )}

                <p>
                  Kết quả:{" "}
                  <strong>{STATUS_LABELS[value.status]}</strong>
                </p>

                <label style={labelStyle}>
                  Ghi chú / Mô tả bất thường
                </label>
                <textarea
                  value={value.note ?? ""}
                  disabled={disabled}
                  onChange={(e) =>
                    updateCriterion(task.id, criterion.id, {
                      note: e.target.value,
                    })
                  }
                  style={inputStyle}
                  rows={2}
                  placeholder="Mô tả hiện tượng, nguyên nhân dự kiến..."
                />
              </div>
            );
          })}

          <label style={labelStyle}>Ghi chú công việc</label>
          <textarea
            value={results.find((item) => item.taskId === task.id)?.note ?? ""}
            disabled={disabled}
            onChange={(e) => updateTaskNote(task.id, e.target.value)}
            style={inputStyle}
            rows={2}
          />
        </section>
        )
      ))}

      <section style={cardStyle}>
        <h2>Ghi chú chung</h2>
        <textarea
          value={note}
          disabled={disabled}
          onChange={(e) => setNote(e.target.value)}
          style={inputStyle}
          rows={3}
        />

        {saveError && (
          <p role="alert" style={{ color: "#b91c1c" }}>
            {saveError}
          </p>
        )}

        <button
          type="button"
          disabled={disabled || saving || visibleTasks.length === 0}
          onClick={() => void handleSave()}
          style={{
            marginTop: 16,
            padding: "12px 20px",
            background: "#2563eb",
            color: "white",
            border: 0,
            borderRadius: 8,
            cursor: "pointer",
          }}
        >
          {saving ? "Đang lưu..." : "Lưu kết quả tuần kiểm"}
        </button>
      </section>
    </div>
  );
}

const cardStyle: React.CSSProperties = {
  padding: 20,
  border: "1px solid #e5e7eb",
  borderRadius: 12,
  marginBottom: 20,
};

const labelStyle: React.CSSProperties = {
  display: "block",
  fontWeight: 600,
  marginTop: 12,
  marginBottom: 6,
};

const inputStyle: React.CSSProperties = {
  display: "block",
  width: "100%",
  padding: 10,
  border: "1px solid #d1d5db",
  borderRadius: 8,
  boxSizing: "border-box",
};
