import { useEffect, useMemo, useState } from "react";
import {
  collection,
  documentId,
  getDocs,
  query,
  where,
} from "firebase/firestore";
import { useNavigate } from "react-router-dom";

import { db } from "../config/firebase";
import PaginationControls, { DEFAULT_PAGE_SIZE } from "../components/PaginationControls";
import ActionIconButton from "../components/ActionIconButton";
import type { InspectionScheduleStatus } from "../services/inspectionScheduleStatus";
import { loadInspectionScheduleStatuses } from "../services/inspectionScheduleReader";
import { beginAppCollectionRead } from "../services/sharedCollectionCache";
import { isPermissionDenied } from "../services/sharedRamCache";
import { isAdmin, isManager, type AppUser } from "../types/user";
import "../styles/inspection-hub.css";

const FIRESTORE_IN_LIMIT = 30;

interface Device {
  id: string;
  code?: string;
  name?: string;
  areaId?: string;
  isActive?: boolean;
}

interface Area {
  id: string;
  code?: string;
  name?: string;
}

interface InspectionHubProps {
  appUser: AppUser;
}

function chunkIds(ids: string[]): string[][] {
  const chunks: string[][] = [];
  for (let index = 0; index < ids.length; index += FIRESTORE_IN_LIMIT) {
    chunks.push(ids.slice(index, index + FIRESTORE_IN_LIMIT));
  }
  return chunks;
}

async function getDevicesForAreas(areaIds: string[]) {
  const snapshots = await Promise.all(
    chunkIds(areaIds).map((areaIdsChunk) =>
      getDocs(
        query(
          collection(db, "devices"),
          where("areaId", "in", areaIdsChunk),
        ),
      ),
    ),
  );

  return snapshots.flatMap((snapshot) => snapshot.docs);
}

async function getAreasByIds(areaIds: string[]) {
  const snapshots = await Promise.all(
    chunkIds(areaIds).map((areaIdsChunk) =>
      getDocs(
        query(
          collection(db, "areas"),
          where(documentId(), "in", areaIdsChunk),
        ),
      ),
    ),
  );

  return snapshots.flatMap((snapshot) => snapshot.docs);
}

function scheduleStatusPresentation(status: InspectionScheduleStatus) {
  let presentation: { label: string; className: string };
  switch (status.state) {
    case "OVERDUE":
      presentation = { label: `Quá hạn (${status.overdueTaskCount})`, className: "is-overdue" };
      break;
    case "DUE_TODAY":
      presentation = { label: `Đến hạn hôm nay (${status.dueTaskCount - status.completedTodayCount})`, className: "is-due" };
      break;
    case "COMPLETED_TODAY":
      presentation = { label: "Đã kiểm tra hôm nay", className: "is-completed" };
      break;
    case "INACTIVE_PLAN":
      presentation = { label: "Lịch đã ngừng", className: "is-neutral" };
      break;
    case "NO_PLAN":
      presentation = { label: "Chưa lập lịch", className: "is-neutral" };
      break;
    default:
      presentation = { label: "Không có lịch hôm nay", className: "is-neutral" };
  }

  const outcomeLabels = { PASS: "Đạt", WARNING: "Cảnh báo", FAIL: "Không đạt", NOT_CHECKED: "Chưa kiểm tra đủ" };
  const outcomeClass = status.todayResultStatus === "FAIL"
    ? "is-result-fail"
    : status.todayResultStatus === "WARNING"
      ? "is-result-warning"
      : status.todayResultStatus === "PASS"
        ? "is-result-pass"
        : "";
  return status.todayResultStatus
    ? { ...presentation, label: `${presentation.label} · ${outcomeLabels[status.todayResultStatus]}`, className: `${presentation.className} ${outcomeClass}`.trim() }
    : presentation;
}

export default function InspectionHub({ appUser }: InspectionHubProps) {
  const navigate = useNavigate();
  const isAdminUser = isAdmin(appUser);
  const isManagerUser = isManager(appUser);
  const [devices, setDevices] = useState<Device[]>([]);
  const [areas, setAreas] = useState<Area[]>([]);
  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [scheduleStatuses, setScheduleStatuses] = useState<Map<string, InspectionScheduleStatus>>(new Map());
  const [scheduleLoading, setScheduleLoading] = useState(false);
  const [scheduleError, setScheduleError] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function loadInspectionDevices() {
      try {
        setLoading(true);
        setError("");

        if (!isAdminUser && appUser.areaIds.length === 0) {
          if (!cancelled) {
            setDevices([]);
            setAreas([]);
          }
          return;
        }

        const loadDevices = async (): Promise<Device[]> => {
          const documents = isAdminUser
            ? await getDocs(collection(db, "devices")).then(
                (snapshot) => snapshot.docs,
              )
            : await getDevicesForAreas(appUser.areaIds);
          return documents.map((item) => ({
            ...(item.data() as Omit<Device, "id">),
            id: item.id,
          }));
        };
        const loadAreas = async (): Promise<Area[]> => {
          const documents = isAdminUser
            ? await getDocs(collection(db, "areas")).then(
                (snapshot) => snapshot.docs,
              )
            : await getAreasByIds(appUser.areaIds);
          return documents.map((item) => ({
            ...(item.data() as Omit<Area, "id">),
            id: item.id,
          }));
        };

        const deviceRead = beginAppCollectionRead(
          appUser,
          "devices",
          loadDevices,
        );
        const areaRead = beginAppCollectionRead(appUser, "areas", loadAreas);
        if (!deviceRead || !areaRead) {
          throw new Error("Cache scope is not available for verified profile.");
        }

        if (!cancelled && deviceRead.snapshot.data && areaRead.snapshot.data) {
          setDevices(deviceRead.snapshot.data);
          setAreas(areaRead.snapshot.data);
          setLoading(false);
        }

        const [deviceResult, areaResult] = await Promise.all([
          deviceRead.request,
          areaRead.request,
        ]);
        if (cancelled) return;
        if (deviceResult?.committed) setDevices(deviceResult.data);
        if (areaResult?.committed) setAreas(areaResult.data);
      } catch (loadError) {
        console.error("Unable to load inspection devices:", loadError);
        if (!cancelled) {
          if (isPermissionDenied(loadError)) {
            setDevices([]);
            setAreas([]);
          }
          setError("Không thể tải danh sách thiết bị tuần kiểm.");
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    void loadInspectionDevices();

    return () => {
      cancelled = true;
    };
  }, [appUser, isAdminUser]);

  useEffect(() => {
    let cancelled = false;

    async function loadScheduleStatuses() {
      if (devices.length === 0) {
        setScheduleStatuses(new Map());
        setScheduleError("");
        return;
      }

      try {
        setScheduleLoading(true);
        setScheduleError("");
        const nextStatuses = await loadInspectionScheduleStatuses(
          devices.map((device) => device.id),
        );

        if (!cancelled) setScheduleStatuses(nextStatuses);
      } catch (loadError) {
        console.error("Unable to load inspection schedule statuses:", loadError);
        if (!cancelled) {
          setScheduleStatuses(new Map());
          setScheduleError(
            isPermissionDenied(loadError)
              ? "Không có quyền đọc lịch hoặc kết quả tuần kiểm trong phạm vi hiện tại."
              : "Không thể xác định trạng thái lịch tuần kiểm. Vui lòng thử tải lại.",
          );
        }
      } finally {
        if (!cancelled) setScheduleLoading(false);
      }
    }

    void loadScheduleStatuses();
    return () => { cancelled = true; };
  }, [devices]);

  const areaMap = useMemo(
    () => new Map(areas.map((area) => [area.id, area])),
    [areas],
  );

  const filteredDevices = useMemo(() => {
    const keyword = search.trim().toLocaleLowerCase("vi");

    return devices
      .filter((device) => {
        if (!keyword) return true;
        return [device.code, device.name]
          .filter(Boolean)
          .join(" ")
          .toLocaleLowerCase("vi")
          .includes(keyword);
      })
      .sort((first, second) =>
        (first.code || first.name || first.id).localeCompare(
          second.code || second.name || second.id,
          "vi",
        ),
      );
  }, [devices, search]);
  const totalInspectionPages = Math.max(1, Math.ceil(filteredDevices.length / DEFAULT_PAGE_SIZE));
  const safeInspectionPage = Math.min(currentPage, totalInspectionPages);
  const paginatedDevices = filteredDevices.slice(
    (safeInspectionPage - 1) * DEFAULT_PAGE_SIZE,
    safeInspectionPage * DEFAULT_PAGE_SIZE,
  );

  const scheduleSummary = useMemo(() => {
    const values = [...scheduleStatuses.values()];
    return {
      overdue: values.filter((status) => status.state === "OVERDUE").length,
      dueToday: values.filter((status) => status.state === "DUE_TODAY").length,
      completedToday: values.filter((status) => status.state === "COMPLETED_TODAY").length,
      failedToday: values.filter((status) => status.todayResultStatus === "FAIL").length,
      warningToday: values.filter((status) => status.todayResultStatus === "WARNING").length,
      withoutPlan: values.filter((status) => status.state === "NO_PLAN").length,
    };
  }, [scheduleStatuses]);

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Tuần kiểm thiết bị</h1>
          <p className="page-subtitle">
            Chọn thiết bị để thực hiện tuần kiểm hoặc xem lịch sử.
          </p>
        </div>
        {isManagerUser && <div className="device-header-actions">
          <button type="button" className="secondary-button" onClick={() => navigate("/inspections/templates")}>Mẫu tuần kiểm</button>
        </div>}
      </div>

      <section className="panel">
        <input
          className="search-input"
          type="search"
          value={search}
          onChange={(event) => { setSearch(event.target.value); setCurrentPage(1); }}
          placeholder="Tìm mã hoặc tên thiết bị..."
        />

        {!loading && devices.length > 0 && (
          <div className="inspection-status-summary" aria-label="Tổng hợp trạng thái tuần kiểm">
            <div className="is-overdue"><span>Quá hạn</span><strong>{scheduleSummary.overdue}</strong></div>
            <div className="is-due"><span>Đến hạn hôm nay</span><strong>{scheduleSummary.dueToday}</strong></div>
            <div className="is-completed"><span>Đã kiểm tra hôm nay</span><strong>{scheduleSummary.completedToday}</strong></div>
            <div className="is-result-fail"><span>Không đạt hôm nay</span><strong>{scheduleSummary.failedToday}</strong></div>
            <div className="is-result-warning"><span>Cảnh báo hôm nay</span><strong>{scheduleSummary.warningToday}</strong></div>
            <div><span>Chưa lập lịch</span><strong>{scheduleSummary.withoutPlan}</strong></div>
          </div>
        )}

        {scheduleSummary.overdue > 0 && (
          <div className="inspection-overdue-alert" role="alert">
            Có {scheduleSummary.overdue} thiết bị quá hạn tuần kiểm cần xử lý.
          </div>
        )}
        {scheduleError && <div className="error-message inspection-status-error">{scheduleError}</div>}

        {loading && <p>Đang tải thiết bị tuần kiểm...</p>}
        {error && <div className="error-message">{error}</div>}

        {!loading && !error && filteredDevices.length === 0 && (
          <p className="empty-history">
            Không có thiết bị tuần kiểm trong phạm vi được phân công.
          </p>
        )}

        {!loading && !error && filteredDevices.length > 0 && (
          <><div className="table-wrapper" style={{ marginTop: 16 }}>
            <table className="device-table">
              <thead>
                <tr>
                  <th>Mã thiết bị</th>
                  <th>Tên thiết bị</th>
                  <th>Khu vực</th>
                  <th>Trạng thái</th>
                  <th>Lịch tuần kiểm</th>
                  <th>Thao tác</th>
                </tr>
              </thead>
              <tbody>
                {paginatedDevices.map((device) => {
                  const area = device.areaId
                    ? areaMap.get(device.areaId)
                    : undefined;
                  const inactive = device.isActive === false;
                  const scheduleStatus = scheduleStatuses.get(device.id);
                  const schedulePresentation = scheduleStatus
                    ? scheduleStatusPresentation(scheduleStatus)
                    : null;

                  return (
                    <tr key={device.id}>
                      <td><strong>{device.code || device.id}</strong></td>
                      <td>{device.name || "-"}</td>
                      <td>{area?.name || area?.code || "-"}</td>
                      <td>{inactive ? "Ngừng sử dụng" : "Đang sử dụng"}</td>
                      <td>
                        <span className={`inspection-schedule-badge ${schedulePresentation?.className ?? "is-loading"}`}>
                          {schedulePresentation?.label ?? (scheduleLoading ? "Đang kiểm tra..." : "Chưa xác định")}
                        </span>
                      </td>
                      <td>
                        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                          <ActionIconButton
                            icon="inspect" variant="primary" label={`Thực hiện tuần kiểm ${device.code || device.id}`}
                            type="button"
                            disabled={inactive}
                            onClick={() =>
                              navigate(`/devices/${device.id}/inspection`)
                            }
                          />
                          {isManagerUser && <ActionIconButton
                            icon="schedule" label={`Lập lịch tuần kiểm ${device.code || device.id}`}
                            type="button"
                            disabled={inactive}
                            onClick={() => navigate(`/devices/${device.id}/inspection-plan`)}
                          />}
                          <ActionIconButton
                            icon="history" label={`Lịch sử tuần kiểm ${device.code || device.id}`}
                            type="button"
                            onClick={() =>
                              navigate(`/devices/${device.id}/inspection-history`)
                            }
                          />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <PaginationControls currentPage={safeInspectionPage} totalItems={filteredDevices.length} onPageChange={setCurrentPage} /></>
        )}
      </section>
    </div>
  );
}
