import { useState } from "react";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../config/firebase";
import { useNavigate, useSearchParams } from "react-router-dom";
import "../styles/login.css";

interface LoginProps {
  onLogin: () => void;
}

export default function Login({ onLogin }: LoginProps) {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    setError("");
    setLoading(true);

    try {
      await signInWithEmailAndPassword(auth, email, password);
      onLogin();
      const requestedPath = searchParams.get("returnTo") || "/";
      navigate(requestedPath.startsWith("/") && !requestedPath.startsWith("//") ? requestedPath : "/", { replace: true });
    } catch (err) {
      console.error(err);
      setError("Email hoặc mật khẩu không đúng.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="login-page">
      <div className="login-decoration login-decoration-one" aria-hidden="true" />
      <div className="login-decoration login-decoration-two" aria-hidden="true" />
      <form onSubmit={handleLogin} className="login-card">
        <div className="login-brand" aria-hidden="true">▣</div>
        <div className="login-heading">
          <h1>Quản lý thiết bị</h1>
          <p>Đăng nhập để tiếp tục quản lý hệ thống</p>
        </div>

        <label className="login-field">
          <span>Email đăng nhập</span>
          <input
            type="email"
            placeholder="name@company.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            autoComplete="username"
            autoFocus
          />
        </label>

        <label className="login-field">
          <span>Mật khẩu</span>
          <div className="login-password-control">
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Nhập mật khẩu"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="current-password"
            />
            <button
              type="button"
              className="login-password-toggle"
              onClick={() => setShowPassword((current) => !current)}
              aria-label={showPassword ? "Ẩn mật khẩu" : "Hiện mật khẩu"}
              aria-pressed={showPassword}
            >
              {showPassword ? (
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l18 18M10.6 10.6a2 2 0 002.8 2.8M9.9 4.2A10.7 10.7 0 0112 4c5 0 9 4.5 9 8a8.6 8.6 0 01-2 4.8M6.6 6.6C4.4 8 3 10.2 3 12c0 3.5 4 8 9 8a9.8 9.8 0 004.1-.9" /></svg>
              ) : (
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12c0-3.5 4-8 9-8s9 4.5 9 8-4 8-9 8-9-4.5-9-8z" /><circle cx="12" cy="12" r="3" /></svg>
              )}
            </button>
          </div>
        </label>

        {error && (
          <div className="login-error" role="alert">{error}</div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="login-submit"
        >
          {loading && <span className="login-spinner" aria-hidden="true" />}
          {loading ? "Đang đăng nhập..." : "Đăng nhập"}
        </button>

        <div className="login-divider"><span>hoặc</span></div>

        <button type="button" onClick={() => navigate("/")} className="login-guest">
          Tiếp tục xem với tư cách khách
        </button>

        <p className="login-security-note">Thông tin đăng nhập được bảo vệ bởi Firebase Authentication.</p>
      </form>
    </main>
  );
}
