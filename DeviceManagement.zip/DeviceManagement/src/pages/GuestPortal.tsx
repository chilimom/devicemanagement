import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

import { loadPublicPortalData, type PublicPortalData } from "../services/publicPortalService";
import ActionIconButton, { type ActionIcon } from "../components/ActionIconButton";
import "../styles/guest-portal.css";
import "../styles/inspection-hub.css";

type GuestPage = "dashboard" | "devices" | "areas" | "incidents" | "maintenances" | "inspections";
const EMPTY: PublicPortalData = { areas: [], devices: [], incidents: [], maintenances: [] };

function GuestAction({ label, icon, primary = false }: { label: string; icon: ActionIcon; primary?: boolean }) {
  const location = useLocation();
  return <ActionIconButton icon={icon} label={label} variant={primary ? "primary" : "default"} onClick={() => {
    window.dispatchEvent(new CustomEvent("app:login-required", { detail: {
      message: "Bạn cần đăng nhập để thực hiện chức năng này.",
      returnTo: location.pathname,
    } }));
  }} />;
}

function inspectionLabel(state: string, count: number) {
  if (state === "OVERDUE") return `Quá hạn (${count})`;
  if (state === "DUE_TODAY") return `Đến hạn hôm nay (${count})`;
  if (state === "COMPLETED_TODAY") return "Đã hoàn thành hôm nay";
  if (state === "NO_PLAN") return "Chưa lập lịch";
  if (state === "INACTIVE_PLAN") return "Lịch đã ngừng";
  return "Không có lịch hôm nay";
}

export default function GuestPortal({ page }: { page: GuestPage }) {
  const navigate = useNavigate();
  const [data, setData] = useState(EMPTY);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [categoryFilter, setCategoryFilter] = useState("ALL");
  const [typeFilter, setTypeFilter] = useState("ALL");
  const [areaFilter, setAreaFilter] = useState("ALL");
  const [lifecycleFilter, setLifecycleFilter] = useState("ACTIVE");

  useEffect(() => {
    let cancelled = false;
    loadPublicPortalData().then((result) => { if (!cancelled) setData(result); })
      .catch(() => { if (!cancelled) setError("Không thể tải dữ liệu xem công khai."); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, []);

  const inspection = useMemo(() => ({
    overdue: data.devices.filter((item) => item.inspectionState === "OVERDUE").length,
    due: data.devices.filter((item) => item.inspectionState === "DUE_TODAY").length,
    completed: data.devices.filter((item) => item.inspectionState === "COMPLETED_TODAY").length,
    noPlan: data.devices.filter((item) => item.inspectionState === "NO_PLAN").length,
  }), [data.devices]);
  const currentPageCount = page === "areas" ? data.areas.length
    : page === "incidents" ? data.incidents.length
      : page === "maintenances" ? data.maintenances.length
        : data.devices.length;
  const activeDevices = data.devices.filter((item) => item.isActive !== false);
  const categoryStats = [...new Set(activeDevices.map((item) => item.categoryName || "Chưa phân loại"))]
    .map((name) => ({
      name,
      total: activeDevices.filter((item) => (item.categoryName || "Chưa phân loại") === name).length,
      active: activeDevices.filter((item) => (item.categoryName || "Chưa phân loại") === name && item.status === "ACTIVE").length,
      warning: activeDevices.filter((item) => (item.categoryName || "Chưa phân loại") === name && item.status === "WARNING").length,
      offline: activeDevices.filter((item) => (item.categoryName || "Chưa phân loại") === name && item.status === "OFFLINE").length,
    }));
  const keyword = search.trim().toLocaleLowerCase("vi");
  const visibleDevices = data.devices.filter((item) =>
    (!keyword || `${item.code} ${item.name} ${item.categoryName} ${item.deviceTypeName} ${item.areaName}`.toLocaleLowerCase("vi").includes(keyword))
    && (statusFilter === "ALL" || item.status === statusFilter)
    && (categoryFilter === "ALL" || item.categoryName === categoryFilter)
    && (typeFilter === "ALL" || item.deviceTypeName === typeFilter)
    && (areaFilter === "ALL" || item.areaId === areaFilter)
    && (lifecycleFilter === "ALL" || (lifecycleFilter === "ACTIVE" ? item.isActive : !item.isActive)),
  );
  const visibleIncidents = data.incidents.filter((item) =>
    (!keyword || `${item.deviceCode} ${item.deviceName}`.toLocaleLowerCase("vi").includes(keyword))
    && (statusFilter === "ALL" || item.status === statusFilter),
  );

  if (loading) return <p>Đang tải dữ liệu công khai...</p>;
  if (error) return <div className="error-message">{error}</div>;

  if (page === "dashboard") return <div className="guest-page dashboard-page">
    <div className="page-header"><div><h1>Tổng quan hệ thống</h1><p className="page-subtitle">Theo dõi tình trạng thiết bị, sự cố và hoạt động bảo trì.</p></div><div className="dashboard-header-actions"><GuestAction label="Quét QR" icon="scan" /><GuestAction label="Thêm thiết bị" icon="add" primary /></div></div>
    <section className="dashboard-kpi-grid">
      <button className="dashboard-kpi-card" onClick={() => navigate("/devices")}><span>Tổng thiết bị</span><strong>{activeDevices.length}</strong><small>Thiết bị đang sử dụng</small></button>
      <button className="dashboard-kpi-card dashboard-kpi-active" onClick={() => navigate("/devices")}><span>Hoạt động</span><strong>{activeDevices.filter((item) => item.status === "ACTIVE").length}</strong><small>Hoạt động bình thường</small></button>
      <button className="dashboard-kpi-card dashboard-kpi-warning" onClick={() => navigate("/devices")}><span>Cảnh báo</span><strong>{activeDevices.filter((item) => item.status === "WARNING").length}</strong><small>Thiết bị cần chú ý</small></button>
      <button className="dashboard-kpi-card dashboard-kpi-offline" onClick={() => navigate("/devices")}><span>Mất kết nối</span><strong>{activeDevices.filter((item) => item.status === "OFFLINE").length}</strong><small>Thiết bị offline</small></button>
    </section>
    <section className="dashboard-secondary-grid">
      <button className="dashboard-summary-card" onClick={() => navigate("/areas")}><span>Khu vực</span><strong>{data.areas.filter((item) => item.status !== "INACTIVE").length}</strong><small>Khu vực đang sử dụng</small></button>
      <button className="dashboard-summary-card" onClick={() => navigate("/incidents")}><span>Sự cố đang mở</span><strong>{data.incidents.filter((item) => item.status === "OPEN").length}</strong><small>Cần tiếp tục xử lý</small></button>
      <button className="dashboard-summary-card" onClick={() => navigate("/incidents")}><span>Sự cố nghiêm trọng</span><strong>{data.incidents.filter((item) => item.status === "OPEN" && item.severity === "CRITICAL").length}</strong><small>Ưu tiên xử lý</small></button>
      <button className="dashboard-summary-card" onClick={() => navigate("/maintenances")}><span>Lượt bảo trì</span><strong>{data.maintenances.length}</strong><small>Tổng lịch sử bảo trì</small></button>
    </section>
    <section className="dashboard-inspection-section"><div className="dashboard-inspection-heading"><div><h2>Trạng thái tuần kiểm</h2><p>Số liệu công khai toàn hệ thống.</p></div><ActionIconButton icon="view" label="Xem tuần kiểm" onClick={() => navigate("/inspections")} /></div><div className="dashboard-inspection-kpis">
      <button className="dashboard-inspection-card is-overdue" onClick={() => navigate("/inspections")}><span>Quá hạn</span><strong>{inspection.overdue}</strong></button>
      <button className="dashboard-inspection-card is-due" onClick={() => navigate("/inspections")}><span>Đến hạn hôm nay</span><strong>{inspection.due}</strong></button>
      <button className="dashboard-inspection-card is-completed" onClick={() => navigate("/inspections")}><span>Đã hoàn thành hôm nay</span><strong>{inspection.completed}</strong></button>
      <button className="dashboard-inspection-card" onClick={() => navigate("/inspections")}><span>Chưa lập lịch</span><strong>{inspection.noPlan}</strong></button>
    </div>{inspection.overdue > 0 && <button className="dashboard-inspection-alert" onClick={() => navigate("/inspections")}>Có {inspection.overdue} thiết bị quá hạn tuần kiểm cần xử lý.</button>}</section>
    <section className="panel dashboard-panel"><div className="dashboard-panel-header"><div><h2>Thiết bị theo lĩnh vực</h2><p>Phân bố thiết bị đang sử dụng theo lĩnh vực.</p></div></div><div className="guest-category-grid">{categoryStats.map((item) => <div key={item.name}><strong>{item.name}</strong><b>{item.total}</b><span>Hoạt động: {item.active}</span><span>Cảnh báo: {item.warning}</span><span>Offline: {item.offline}</span></div>)}</div></section>
    <section className="panel dashboard-panel"><div className="dashboard-panel-header"><div><h2>Sự cố cần xử lý</h2><p>Các sự cố đang mở được ưu tiên theo mức độ.</p></div><ActionIconButton icon="view" label="Xem tất cả sự cố" onClick={() => navigate("/incidents")} /></div>{data.incidents.filter((item) => item.status === "OPEN").length === 0 ? <div className="dashboard-success-box">Không có sự cố đang chờ xử lý.</div> : <div className="dashboard-incident-list">{data.incidents.filter((item) => item.status === "OPEN").slice(0, 5).map((item) => <div className="dashboard-incident-row" key={item.id} onClick={() => window.dispatchEvent(new CustomEvent("app:login-required", { detail: { message: "Bạn cần đăng nhập để xem chi tiết sự cố.", returnTo: "/incidents" } }))}><div className="dashboard-incident-main"><strong>{item.severity}</strong><span>{item.deviceCode} - {item.deviceName}</span></div></div>)}</div>}</section>
  </div>;

  const titles = { devices: "Thiết bị", areas: "Khu vực", incidents: "Sự cố", maintenances: "Bảo trì", inspections: "Tuần kiểm thiết bị", dashboard: "" };
  if (page === "areas") {
    const activeAreas = data.areas.filter((item) => item.status !== "INACTIVE").length;
    const filteredAreas = data.areas.filter((item) => !keyword || `${item.code} ${item.name}`.toLocaleLowerCase("vi").includes(keyword));
    return <div className="guest-page"><div className="page-header"><div><h1>Quản lý khu vực</h1><p className="page-subtitle">Theo dõi thiết bị theo từng nhà máy, xưởng và khu vực.</p></div></div>
      <div className="area-kpi-grid"><div className="area-kpi-card"><span>Tổng khu vực</span><strong>{data.areas.length}</strong></div><div className="area-kpi-card"><span>Tổng thiết bị</span><strong>{data.devices.length}</strong></div><div className="area-kpi-card kpi-active"><span>Đang hoạt động</span><strong>{activeAreas}</strong></div><div className="area-kpi-card kpi-attention"><span>Thiết bị cần chú ý</span><strong>{data.devices.filter((item) => ["WARNING", "OFFLINE"].includes(item.status)).length}</strong></div></div>
      <div className="area-filters"><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Tìm mã khu vực, tên khu vực..." /></div>
      <section className="panel">{filteredAreas.length === 0 ? <div className="empty-history">Không có khu vực phù hợp.</div> : <div className="area-list-table-wrap"><table className="area-list-table"><thead><tr><th>Khu vực</th><th>Trạng thái</th><th>Thiết bị</th><th>Hoạt động</th><th>Cảnh báo</th><th>Offline</th><th>Thao tác</th></tr></thead><tbody>{filteredAreas.map((item) => {
        const areaDevices = data.devices.filter((device) => device.areaId === item.id);
        const isInactive = item.status === "INACTIVE";
        return <tr key={item.id} className={`area-list-row ${isInactive ? "is-inactive" : ""}`}>
          <td data-label="Khu vực"><div className="area-list-identity"><span className="area-code">{item.code || "Chưa có mã"}</span><strong>{item.name || "Chưa có tên"}</strong></div></td>
          <td data-label="Trạng thái"><span className={isInactive ? "area-status inactive" : "area-status active"}>{isInactive ? "Ngừng sử dụng" : "Hoạt động"}</span></td>
          <td data-label="Thiết bị"><strong className="area-list-number">{areaDevices.length}</strong></td>
          <td data-label="Hoạt động"><strong className="area-list-number is-active">{areaDevices.filter((device) => device.status === "ACTIVE").length}</strong></td>
          <td data-label="Cảnh báo"><strong className="area-list-number is-warning">{areaDevices.filter((device) => device.status === "WARNING").length}</strong></td>
          <td data-label="Offline"><strong className="area-list-number is-offline">{areaDevices.filter((device) => device.status === "OFFLINE").length}</strong></td>
          <td data-label="Thao tác"><div className="area-list-actions"><ActionIconButton icon="view" label={`Xem thiết bị tại ${item.name}`} onClick={() => navigate(`/devices?area=${item.id}`)} /></div></td>
        </tr>;
      })}</tbody></table></div>}</section>
    </div>;
  }

  return <div className="guest-page"><div className="page-header"><div><h1>{titles[page]}</h1><p className="page-subtitle">Bạn đang xem ở chế độ khách. Đăng nhập để xem chi tiết và thực hiện nghiệp vụ.</p></div>{page === "inspections" && <GuestAction label="Mẫu tuần kiểm" icon="schedule" />}{page === "devices" && <div className="device-header-actions"><GuestAction label="Xuất Excel" icon="export" /><GuestAction label="Thêm thiết bị" icon="add" primary /></div>}</div>
    {page === "incidents" && <><div className="incident-kpi-grid"><div className="incident-kpi-card"><span>Tổng sự cố</span><strong>{data.incidents.length}</strong></div><div className="incident-kpi-card kpi-open"><span>Đang mở</span><strong>{data.incidents.filter((item) => item.status === "OPEN").length}</strong></div><div className="incident-kpi-card kpi-resolved"><span>Đã xử lý</span><strong>{data.incidents.filter((item) => item.status === "RESOLVED").length}</strong></div><div className="incident-kpi-card kpi-critical"><span>Nghiêm trọng</span><strong>{data.incidents.filter((item) => item.status === "OPEN" && item.severity === "CRITICAL").length}</strong></div></div><div className="incident-filters"><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Tìm mã hoặc tên thiết bị..." /><select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}><option value="ALL">Tất cả trạng thái</option><option value="OPEN">Đang mở</option><option value="RESOLVED">Đã xử lý</option><option value="CLOSED">Đã đóng</option></select></div></>}
    {page === "maintenances" && <><div className="maintenance-kpi-grid"><div className="maintenance-kpi-card"><span>Tổng bảo trì</span><strong>{data.maintenances.length}</strong></div><div className="maintenance-kpi-card kpi-preventive"><span>Định kỳ</span><strong>{data.maintenances.filter((item) => item.maintenanceType === "PREVENTIVE").length}</strong></div><div className="maintenance-kpi-card kpi-corrective"><span>Khắc phục</span><strong>{data.maintenances.filter((item) => item.maintenanceType === "CORRECTIVE").length}</strong></div><div className="maintenance-kpi-card kpi-replacement"><span>Thay thế</span><strong>{data.maintenances.filter((item) => item.maintenanceType === "REPLACEMENT").length}</strong></div></div></>}
    {page === "inspections" && <><div className="inspection-status-summary"><div className="is-overdue"><span>Quá hạn</span><strong>{inspection.overdue}</strong></div><div className="is-due"><span>Đến hạn hôm nay</span><strong>{inspection.due}</strong></div><div className="is-completed"><span>Đã hoàn thành hôm nay</span><strong>{inspection.completed}</strong></div><div><span>Chưa lập lịch</span><strong>{inspection.noPlan}</strong></div></div>{inspection.overdue > 0 && <div className="inspection-overdue-alert">Có {inspection.overdue} thiết bị quá hạn tuần kiểm cần xử lý.</div>}</>}
    {page === "inspections" && <input className="search-input guest-inspection-search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Tìm mã hoặc tên thiết bị..." />}
    <section className="panel">{page === "devices" && <><div className="device-filters">
      <input className="search-input" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Tìm mã, tên, loại, khu vực..." />
      <select value={categoryFilter} onChange={(event) => { setCategoryFilter(event.target.value); setTypeFilter("ALL"); }}><option value="ALL">Tất cả lĩnh vực</option>{[...new Set(data.devices.map((item) => item.categoryName).filter(Boolean))].map((name) => <option key={name} value={name}>{name}</option>)}</select>
      <select value={typeFilter} onChange={(event) => setTypeFilter(event.target.value)}><option value="ALL">Tất cả loại thiết bị</option>{[...new Set(data.devices.filter((item) => categoryFilter === "ALL" || item.categoryName === categoryFilter).map((item) => item.deviceTypeName).filter(Boolean))].map((name) => <option key={name} value={name}>{name}</option>)}</select>
      <select value={areaFilter} onChange={(event) => setAreaFilter(event.target.value)}><option value="ALL">Tất cả khu vực</option>{data.areas.map((area) => <option key={area.id} value={area.id}>{area.name}</option>)}</select>
      <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}><option value="ALL">Tất cả trạng thái</option><option value="ACTIVE">Hoạt động</option><option value="WARNING">Cảnh báo</option><option value="OFFLINE">Mất kết nối</option><option value="MAINTENANCE">Bảo trì</option></select>
      <select value={lifecycleFilter} onChange={(event) => setLifecycleFilter(event.target.value)}><option value="ACTIVE">Đang sử dụng</option><option value="INACTIVE">Ngừng sử dụng</option><option value="ALL">Tất cả thiết bị</option></select>
    </div><div className="result-summary guest-device-summary"><div>Hiển thị <strong>{visibleDevices.length}</strong> / {data.devices.length} thiết bị <span>Đang sử dụng: <strong>{data.devices.filter((item) => item.isActive).length}</strong> | Ngừng sử dụng: <strong>{data.devices.filter((item) => !item.isActive).length}</strong></span></div><ActionIconButton icon="clear" label="Xóa bộ lọc" onClick={() => { setSearch(""); setStatusFilter("ALL"); setCategoryFilter("ALL"); setTypeFilter("ALL"); setAreaFilter("ALL"); setLifecycleFilter("ACTIVE"); }} /></div></>}
    <div className="table-wrapper"><table className="device-table"><thead><tr>
      {page === "incidents" ? <><th>Thiết bị</th><th>Mức độ</th><th>Trạng thái</th><th>Thao tác</th></> : page === "maintenances" ? <><th>Thiết bị</th><th>Loại bảo trì</th><th>Trạng thái</th><th>Thao tác</th></> : page === "devices" ? <><th>Mã thiết bị</th><th>Tên thiết bị</th><th>Lĩnh vực</th><th>Loại thiết bị</th><th>Khu vực</th><th>Trạng thái</th><th>Thao tác</th></> : <><th>Mã thiết bị</th><th>Tên thiết bị</th><th>Khu vực</th><th>Trạng thái</th><th>Lịch tuần kiểm</th><th>Thao tác</th></>}
    </tr></thead><tbody>
      {(page === "devices" || page === "inspections") && visibleDevices.map((item) => <tr key={item.id} className={!item.isActive ? "device-row-inactive" : ""}><td><strong>{item.code}</strong></td><td>{item.name}</td>{page === "devices" && <><td>{item.categoryName || "-"}</td><td>{item.deviceTypeName || "-"}</td></>}<td>{item.areaName}</td><td>{!item.isActive ? <span className="status status-inactive">Ngừng sử dụng</span> : <span className={`status status-${item.status.toLowerCase()}`}>{item.status === "ACTIVE" ? "Hoạt động" : item.status === "WARNING" ? "Cảnh báo" : item.status === "OFFLINE" ? "Mất kết nối" : item.status === "MAINTENANCE" ? "Bảo trì" : item.status}</span>}</td>{page === "inspections" && <td><span className={`inspection-schedule-badge ${item.inspectionState === "OVERDUE" ? "is-overdue" : item.inspectionState === "DUE_TODAY" ? "is-due" : item.inspectionState === "COMPLETED_TODAY" ? "is-completed" : "is-neutral"}`}>{inspectionLabel(item.inspectionState, item.inspectionCount)}</span></td>}<td><div className="guest-actions">{page === "inspections" ? <><GuestAction label="Thực hiện tuần kiểm" icon="inspect" primary /><GuestAction label="Lập lịch" icon="schedule" /><GuestAction label="Lịch sử" icon="history" /></> : <GuestAction label="Xem" icon="view" />}</div></td></tr>)}
      {page === "incidents" && visibleIncidents.map((item) => <tr key={item.id}><td>{item.deviceCode} {item.deviceName}</td><td>{item.severity}</td><td><span className={`incident-badge ${item.status === "CLOSED" ? "closed" : item.status === "RESOLVED" ? "resolved" : "open"}`}>{item.status}</span></td><td><GuestAction label={item.status === "OPEN" ? "Xử lý" : item.status === "RESOLVED" ? "Xác minh" : "Xem thiết bị"} icon={item.status === "OPEN" ? "resolve" : item.status === "RESOLVED" ? "verify" : "view"} primary={item.status !== "CLOSED"} /></td></tr>)}
      {page === "maintenances" && data.maintenances.map((item) => <tr key={item.id}><td>{item.deviceCode} {item.deviceName}</td><td>{item.maintenanceType}</td><td>{item.status}</td><td><GuestAction label="Xem chi tiết" icon="view" /></td></tr>)}
    </tbody></table></div>{currentPageCount === 0 && <p className="empty-history">Chưa có dữ liệu công khai. ADMIN cần cập nhật dữ liệu khách.</p>}</section>
  </div>;
}
