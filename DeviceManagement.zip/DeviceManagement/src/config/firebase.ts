import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

export const firebaseConfig = {
  apiKey: "AIzaSyDGN3EyHYJw-WnhFQl_2NA0SkHm9rxHTNs",
  authDomain: "quanly-tasklist.firebaseapp.com",
  projectId: "quanly-tasklist",
  storageBucket: "quanly-tasklist.firebasestorage.app",
  messagingSenderId: "581135835940",
  appId: "1:581135835940:web:8844fe5ffc2583932a89b1"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
if (import.meta.env.DEV) { (window as any).__auth = auth; }
export const db = getFirestore(app);

export default app;
