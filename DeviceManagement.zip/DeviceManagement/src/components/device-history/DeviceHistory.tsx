

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import ActionIconButton from "../ActionIconButton";
import "../../styles/device-history.css";

interface FirestoreTimestamp {
  toDate(): Date;
  toMillis(): number;
}
/* =========================================================
   KIỂU DỮ LIỆU LỊCH SỬ THIẾT BỊ

   Phản ánh dữ liệu sự cố và bảo trì đang được sử dụng
   tại DeviceDetail.tsx. Không thay đổi Firestore.
========================================================= */


interface Incident {
  id: string;
  deviceId?: string;
  deviceCode?: string;
  deviceName?: string;
  title?: string;
  description?: string;
  severity?: string;
  status?: string;
  reportedAt?: FirestoreTimestamp;
  resolvedAt?: FirestoreTimestamp;
  resolution?: string;

  // Thông tin bổ sung khi đóng sự cố
  resolvedByUid?: string;
  resolutionCount?: number;
  closedAt?: FirestoreTimestamp;
  lastVerifiedByName?: string;
  lastVerifiedAt?: FirestoreTimestamp;
}


interface Maintenance {
  id: string;
  deviceId?: string;
  deviceCode?: string;
  deviceName?: string;
  title?: string;
  description?: string;
  maintenanceType?: string;
  performedBy?: string;
  performedAt?: FirestoreTimestamp;
  result?: string;
  status?: string;
  createdAt?: FirestoreTimestamp;
}

export type HistoryItem =
  | {
      type: "INCIDENT";
      timestamp?: FirestoreTimestamp;
      data: Incident;
    }
  | {
      type: "MAINTENANCE";
      timestamp?: FirestoreTimestamp;
      data: Maintenance;
    };


interface IncidentResolution {
  id: string;
  incidentId: string;
  deviceId: string;
  resolution: string;
  attemptNumber: number;
  resolvedByUid: string;
  resolvedByName: string;
  resolvedByEmail: string;
  resolvedAt: FirestoreTimestamp;
  outcome?: "OPEN" | "RESOLVED";
}

interface DeviceHistoryProps {
  deviceId: string;
  historyItems: HistoryItem[];
  incidentResolutions: IncidentResolution[];
  canCreateMaintenance: boolean;
  historyVisible: boolean;
  historyLoading: boolean;
  historyError: string;
  onShowHistory: () => void;
  standalone?: boolean;
}

/* =========================================================
   HÀM HỖ TRỢ HIỂN THỊ

   Chuyển các mã trạng thái sang tiếng Việt.
   Giữ nguyên quy tắc từ DeviceDetail.tsx.
========================================================= */

function getSeverityLabel(severity?: string) {
  switch (severity) {
    case "LOW":
      return "Thấp";
    case "MEDIUM":
      return "Trung bình";
    case "HIGH":
      return "Cao";
    case "CRITICAL":
      return "Nghiêm trọng";
    default:
      return severity || "-";
  }
}

function getIncidentStatusLabel(status?: string) {
  switch (status) {
    case "OPEN":
      return "Đang mở";
    case "IN_PROGRESS":
      return "Đang xử lý";
    case "RESOLVED":
      return "Đã xử lý";
    case "CLOSED":
      return "Đã đóng";
    default:
      return status || "-";
  }
}

function getMaintenanceTypeLabel(type?: string) {
  switch (type) {
    case "PREVENTIVE":
      return "Bảo trì định kỳ";
    case "CORRECTIVE":
      return "Bảo trì sửa chữa";
    case "INSPECTION":
      return "Kiểm tra";
    case "REPLACEMENT":
      return "Thay thế";
    default:
      return type || "-";
  }
}

function formatDate(timestamp?: FirestoreTimestamp | null) {
  if (!timestamp?.toDate) {
    return "-";
  }

  return timestamp.toDate().toLocaleString("vi-VN");
}

/* =========================================================
   COMPONENT LỊCH SỬ THIẾT BỊ

   - Nhận dữ liệu đã được sắp xếp từ trang cha.
   - Hiển thị sự cố và bảo trì.
   - Điều hướng đến các chức năng hiện có.
   - Không đọc hoặc ghi dữ liệu Firestore.
========================================================= */

export default function DeviceHistory({
  deviceId,
  historyItems,
  incidentResolutions,
  canCreateMaintenance,
  historyVisible,
  historyLoading,
  historyError,
  onShowHistory,
  standalone = false,
}: DeviceHistoryProps) {

  const navigate = useNavigate();
 /* =========================================================
   TRẠNG THÁI MỞ / ĐÓNG CHI TIẾT LỊCH SỬ

   - Mặc định tất cả bản ghi đều thu gọn.
   - Chỉ cho phép mở một bản ghi tại một thời điểm.
   - Nhấn lại bản ghi đang mở để thu gọn.
========================================================= */
const [expandedId, setExpandedId] = useState<string | null>(null);

function toggleHistoryItem(itemId: string) {
  setExpandedId((currentId) =>
    currentId === itemId ? null : itemId
  );
}
  return (
    <section className={`panel detail-card${standalone ? " device-history-standalone" : ""}`}>
      {/* Tiêu đề và các thao tác thêm mới */}
      <div className="history-header">
        <div>
          <h2>Lịch sử thiết bị</h2>
          <p>
            Theo dõi sự cố, bảo trì và thay thế trong suốt
            vòng đời thiết bị.
          </p>
        </div>

        <div className="history-actions">
          <ActionIconButton
            icon="incident" label="Ghi nhận sự cố"
            onClick={() =>
              navigate(`/devices/${deviceId}/incidents/new`)
            }
          />

          <ActionIconButton
            icon="repair" variant="primary" label="Tạo bản ghi bảo trì"
            hidden={!canCreateMaintenance}
            onClick={() =>
              navigate(`/devices/${deviceId}/maintenance/new`)
            }
          />

          {!standalone && <ActionIconButton
            icon="history" label="Mở trang lịch sử thiết bị"
            onClick={onShowHistory}
            disabled={historyLoading}
          />}
        </div>
      </div>

{/* =========================================================
    DANH SÁCH LỊCH SỬ THIẾT BỊ

    - Mặc định tất cả bản ghi thu gọn.
    - Nhấn vào dòng tiêu đề để mở/đóng chi tiết.
    - Chỉ mở một bản ghi tại một thời điểm.
    - Giữ nguyên các chức năng xử lý sự cố.
========================================================= */}
{!historyVisible ? null : historyLoading ? (
  <div className="empty-history">Đang tải lịch sử thiết bị...</div>
) : historyError ? (
  <div className="empty-history" role="alert">
    <p>{historyError}</p>
    {standalone && <button type="button" className="table-action" onClick={onShowHistory} disabled={historyLoading}>Thử tải lại</button>}
  </div>
) : historyItems.length === 0 ? (
  <div className="empty-history">
    Chưa có lịch sử hoạt động của thiết bị.
  </div>
) : (
  <div className="device-history-list">
    {historyItems.map((item) => {
      /* =====================================================
         BẢN GHI SỰ CỐ
      ===================================================== */
      if (item.type === "INCIDENT") {
        const incident = item.data;
        const itemId = `incident-${incident.id}`;
        const isExpanded = expandedId === itemId;

        const isResolved =
          incident.status === "RESOLVED" ||
          incident.status === "CLOSED";

        return (
          <div
            key={itemId}
            className="device-history-row"
          >
            {/* Dòng tóm tắt có thể nhấn để mở chi tiết */}
            <button
              type="button"
              className="device-history-row-toggle"
              onClick={() => toggleHistoryItem(itemId)}
              aria-expanded={isExpanded}
            >
              <span className="device-history-row-main">
                <strong>
                  {incident.title || "Sự cố"}
                </strong>
                <span className="device-history-row-meta">
                  Sự cố · {formatDate(incident.reportedAt)}
                </span>
              </span>

              <span
                className={`incident-status ${
                  isResolved
                    ? "incident-status-resolved"
                    : "incident-status-open"
                }`}
              >
                {getIncidentStatusLabel(incident.status)}
              </span>

              <span
                className="device-history-chevron"
                aria-hidden="true"
              >
                {isExpanded ? "▲" : "▼"}
              </span>
            </button>

            {/* Chi tiết sự cố chỉ xuất hiện khi mở */}
            {isExpanded && (
              <div className="device-history-details">
                <div className="incident-info">
                  <div>
                    <span>Mức độ</span>
                    <strong>
                      {getSeverityLabel(incident.severity)}
                    </strong>
                  </div>

                  <div>
                    <span>Mô tả</span>
                    <strong>
                      {incident.description || "-"}
                    </strong>
                  </div>
                </div>

                {/* Sự cố đã hoàn thành */}
                {isResolved &&
                    !incidentResolutions.some(
                      (resolution) => resolution.incidentId === incident.id
                    ) && (
                  <div className="resolution-box">
                    <div className="resolution-title">
                      Kết quả xử lý
                    </div>

                    <p>
                      {incident.resolution ||
                        "Chưa có nội dung xử lý."}
                    </p>

                    <div className="resolved-date">
                      Hoàn thành:{" "}
                      <strong>
                        {formatDate(incident.resolvedAt)}
                      </strong>
                    </div>
                  </div>
                )}
                                
                    {/* Lịch sử khắc phục lấy từ incidentResolutions */}
                    {incidentResolutions
                        .filter((item) => item.incidentId === incident.id)
                        .sort((a, b) => a.attemptNumber - b.attemptNumber)
                  .map((resolution) => (
                    <div
                      key={resolution.id}
                      className="resolution-box"
                      style={{ marginTop: "12px" }}
                    >
                      <div className="resolution-title">
                        Lịch sử khắc phục - Lần {resolution.attemptNumber}
                      </div>

                      <div>
                        <strong>Nội dung khắc phục:</strong>
                        <p>{resolution.resolution}</p>
                      </div>

                      <div>
                        <strong>Kết quả:</strong>{" "}
                        {resolution.outcome === "OPEN"
                          ? "Chưa đạt — sự cố tiếp tục mở"
                          : resolution.outcome === "RESOLVED"
                            ? "Đạt — chờ xác minh"
                            : "Không xác định (bản ghi lịch sử cũ)"}
                      </div>

                      <div>
                        <strong>Người xử lý:</strong>{" "}
                        {resolution.resolvedByName ||
                          resolution.resolvedByEmail ||
                          resolution.resolvedByUid}
                      </div>

                      <div className="resolved-date">
                        <strong>Thời gian hoàn thành:</strong>{" "}
                        {formatDate(resolution.resolvedAt)}
                      </div>
                    </div>
                  ))}

                {/* Sự cố chưa hoàn thành */}
                {incident.status === "OPEN" && (
                  <div className="incident-actions">
                    <ActionIconButton
                      icon="resolve" variant="primary" label={`Xử lý sự cố ${incident.deviceCode || ""}`}
                      type="button"
                      onClick={() =>
                        navigate(
                          `/incidents/${incident.id}/resolve`
                        )
                      }
                    />
                  </div>
                )}

                {incident.status === "RESOLVED" && (
                  <div className="incident-actions">
                    <ActionIconButton
                      icon="verify" variant="primary" label={`Xác minh sự cố ${incident.deviceCode || ""}`}
                      type="button"
                      onClick={() =>
                        navigate(`/incidents/${incident.id}/verify`)
                      }
                    />
                  </div>
                )}

                {incident.status === "CLOSED" && (
                  <div className="resolution-box" style={{ marginTop: "12px" }}>
                    <div className="resolution-title">Thông tin xác minh</div>
                    <div>
                      <strong>Người xác minh:</strong>{" "}
                      {incident.lastVerifiedByName || "-"}
                    </div>
                    <div className="resolved-date">
                      <strong>Thời gian xác minh:</strong>{" "}
                      {formatDate(incident.lastVerifiedAt || incident.closedAt)}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        );
      }

      /* =====================================================
         BẢN GHI BẢO TRÌ
      ===================================================== */
      const maintenance = item.data;
      const itemId = `maintenance-${maintenance.id}`;
      const isExpanded = expandedId === itemId;

      return (
        <div
          key={itemId}
          className="device-history-row"
        >
          {/* Dòng tóm tắt bảo trì */}
          <button
            type="button"
            className="device-history-row-toggle"
            onClick={() => toggleHistoryItem(itemId)}
            aria-expanded={isExpanded}
          >
            <span className="device-history-row-main">
              <strong>
                {maintenance.title || "Bảo trì thiết bị"}
              </strong>

              <span className="device-history-row-meta">
                Bảo trì ·{" "}
                {formatDate(
                  maintenance.performedAt ||
                    maintenance.createdAt
                )}
              </span>
            </span>

            <span className="maintenance-status">
              Hoàn thành
            </span>

            <span
              className="device-history-chevron"
              aria-hidden="true"
            >
              {isExpanded ? "▲" : "▼"}
            </span>
          </button>

          {/* Chi tiết bảo trì chỉ xuất hiện khi mở */}
          {isExpanded && (
            <div className="device-history-details">
              <div className="maintenance-info-grid">
                <div>
                  <span>Loại bảo trì</span>
                  <strong>
                    {getMaintenanceTypeLabel(
                      maintenance.maintenanceType
                    )}
                  </strong>
                </div>

                <div>
                  <span>Người thực hiện</span>
                  <strong>
                    {maintenance.performedBy || "-"}
                  </strong>
                </div>
              </div>

              <div className="maintenance-description">
                <span>Nội dung thực hiện</span>
                <p>{maintenance.description || "-"}</p>
              </div>

              {maintenance.result && (
                <div className="maintenance-result">
                  <div className="resolution-title">
                    Kết quả bảo trì
                  </div>
                  <p>{maintenance.result}</p>
                </div>
              )}
            </div>
          )}
        </div>
      );
    })}
  </div>
)}

    </section>
  );
}
