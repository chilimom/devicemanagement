import "../styles/login-required-dialog.css";

interface LoginRequiredDialogProps {
  message: string;
  onClose: () => void;
  onLogin: () => void;
}

export default function LoginRequiredDialog({ message, onClose, onLogin }: LoginRequiredDialogProps) {
  return (
    <div className="login-required-overlay" role="presentation" onMouseDown={(event) => {
      if (event.target === event.currentTarget) onClose();
    }}>
      <section className="login-required-dialog" role="dialog" aria-modal="true" aria-labelledby="login-required-title">
        <button type="button" className="login-required-close" onClick={onClose} aria-label="Đóng">×</button>
        <div className="login-required-icon" aria-hidden="true">!</div>
        <h2 id="login-required-title">Yêu cầu đăng nhập</h2>
        <p>{message}</p>
        <div className="login-required-actions">
          <button type="button" className="secondary-button" onClick={onClose}>Để sau</button>
          <button type="button" className="primary-button" onClick={onLogin}>Đăng nhập</button>
        </div>
      </section>
    </div>
  );
}
