
import { useEffect, useState, type ReactNode } from "react";
import { signOut } from "firebase/auth";
import {
  NavLink,
  useLocation,
  useNavigate,
} from "react-router-dom";

import { auth } from "../config/firebase";
import { appSharedRamCacheLifecycle } from "../services/appSharedRamCache";
import type { AppUser } from "../types/user";
import { isManager } from "../types/user";
import LoginRequiredDialog from "./LoginRequiredDialog";
import AppDialog from "./AppDialog";
import type { AppDialogRequest } from "../services/appDialog";
interface AppLayoutProps {
  children: ReactNode;
  userDisplayName?: string | null;
  appUser?: AppUser | null;
  guestMode?: boolean;
}


const navigation = [
  { path: "/", label: "Tổng quan", icon: "⌂", end: true },
  { path: "/devices", label: "Thiết bị", icon: "▣" },
  { path: "/areas", label: "Khu vực", icon: "▤" },
  { path: "/scan", label: "Quét QR", icon: "▦" },
  { path: "/incidents", label: "Sự cố", icon: "⚠" },
  { path: "/maintenances", label: "Bảo trì", icon: "⚙" },

 
];

export default function AppLayout({
  children,
  userDisplayName,
  appUser,
  guestMode = false,
}: AppLayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const isManagerUser = isManager(appUser ?? null);

  const isAdminPage =
    location.pathname === "/admin" ||
    location.pathname.startsWith("/admin/");

  const [adminExpanded, setAdminExpanded] =
    useState(isAdminPage);

  const [mobileMenuOpen, setMobileMenuOpen] =useState(false);
  const [accountMenuOpen, setAccountMenuOpen] =useState(false);
  const [loginPrompt, setLoginPrompt] = useState<{ message: string; returnTo: string } | null>(null);
  const [appDialog, setAppDialog] = useState<AppDialogRequest | null>(null);

  useEffect(() => {
    const showLoginPrompt = (event: Event) => {
      const detail = (event as CustomEvent<{ message?: string; returnTo?: string }>).detail;
      setLoginPrompt({
        message: detail?.message || "Bạn cần đăng nhập để thực hiện chức năng này.",
        returnTo: detail?.returnTo || location.pathname,
      });
    };
    window.addEventListener("app:login-required", showLoginPrompt);
    return () => window.removeEventListener("app:login-required", showLoginPrompt);
  }, [location.pathname]);

  useEffect(() => {
    const showDialog = (event: Event) => setAppDialog((event as CustomEvent<AppDialogRequest>).detail);
    window.addEventListener("app:dialog", showDialog);
    return () => window.removeEventListener("app:dialog", showDialog);
  }, []);

  const resolveAppDialog = (accepted: boolean) => {
    if (!appDialog) return;
    appDialog.resolve(accepted);
    setAppDialog(null);
  };
  // Đóng menu khi chuyển trang.
  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      setMobileMenuOpen(false);
      setAccountMenuOpen(false);

      if (isAdminPage) {
        setAdminExpanded(true);
      }
    });

    return () => window.cancelAnimationFrame(frame);
  }, [location.pathname, isAdminPage]);

  // Khóa cuộn nền khi menu điện thoại mở.
  useEffect(() => {
    if (!mobileMenuOpen) return;

    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      document.body.style.overflow = oldOverflow;
    };
  }, [mobileMenuOpen]);

  async function handleLogout() {
    appSharedRamCacheLifecycle.logout();

    try {
      await signOut(auth);
    } catch (error) {
      if (appUser && auth.currentUser?.uid === appUser.uid) {
        const profileVerificationEpoch =
          appSharedRamCacheLifecycle.resolveAuth(appUser.uid);
        appSharedRamCacheLifecycle.activateProfile(
          appUser,
          profileVerificationEpoch,
        );
      }
      console.error("Không thể đăng xuất:", error);
      window.dispatchEvent(new CustomEvent<AppDialogRequest>("app:dialog", { detail: {
        kind: "alert", message: "Đăng xuất thất bại. Vui lòng thử lại.", tone: "error", resolve: () => undefined,
      } }));
    }
  }

  const menuClass = ({ isActive }: { isActive: boolean }) =>
    `menu-item ${isActive ? "active" : ""}`;

  return (
    <div className="app-layout">
      {/* SIDEBAR DESKTOP */}
      <aside className="sidebar">
        <div className="brand">
          <div>
            <strong>Quản Lý Thiết Bị</strong>
            <small>Device Management</small>
          </div>
        </div>

        <nav className="menu" aria-label="Menu chính">
          {navigation.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.end}
              className={menuClass}
              onClick={(event) => {
                if (guestMode && item.path === "/scan") {
                  event.preventDefault();
                  setLoginPrompt({ message: "Bạn cần đăng nhập để sử dụng chức năng Quét QR.", returnTo: item.path });
                }
              }}
            >
              {item.label}
            </NavLink>
          ))}
          
          <NavLink
            to="/inspections"
            className={menuClass}
          >
            Tuần kiểm
          </NavLink>

          
{isManagerUser && (
  <>
    <button
      type="button"
      className={`menu-item admin-menu-toggle ${
        isAdminPage ? "active" : ""
      }`}
      onClick={() =>
        setAdminExpanded((previous) => !previous)
      }
      aria-expanded={adminExpanded}
      aria-controls="admin-submenu"
    >
      <span>Quản trị</span>
      <span className="admin-menu-arrow">
        {adminExpanded ? "▾" : "▸"}
      </span>
    </button>

    {adminExpanded && (
      <div id="admin-submenu" className="admin-submenu">
        <NavLink
          to="/admin/device-types"
          className={menuClass}
        >
          Loại thiết bị
        </NavLink>

        <NavLink
          to="/admin/users"
          className={menuClass}
        >
          Quản lý người dùng
        </NavLink>

        {/* <span className="menu-item admin-submenu-item disabled">
          Phân quyền
        </span> */}
      </div>
    )}
  </>
)}

        </nav>
      </aside>

      {/* NỘI DUNG CHÍNH */}
      <div className="main-area">
        
<header className="topbar">
  {/* HEADER DESKTOP */}
  <strong className="desktop-title">
    HỆ THỐNG QUẢN LÝ THIẾT BỊ
  </strong>

  <div className="user-area desktop-user-area">
    <span>{userDisplayName}</span>

    {guestMode ? (
      <button type="button" className="logout-button" onClick={() => navigate(`/login?returnTo=${encodeURIComponent(location.pathname)}`)}>Đăng nhập</button>
    ) : (
      <button type="button" className="logout-button" onClick={handleLogout}>Đăng xuất</button>
    )}
  </div>

  {/* HEADER MOBILE */}
  <div className="mobile-header-brand">
    <span className="mobile-header-logo">▣</span>

    <div>
      <strong>Quản lý thiết bị</strong>
      <small>Device Management</small>
    </div>
  </div>

  {/* MENU TÀI KHOẢN MOBILE */}
  <div className="mobile-account">
    <button
      type="button"
      className="mobile-account-button"
      onClick={() =>
        setAccountMenuOpen((previous) => !previous)
      }
      aria-label="Mở menu tài khoản"
      aria-expanded={accountMenuOpen}
      aria-controls="mobile-account-dropdown"
    >
      ☻
    </button>

    {accountMenuOpen && (
      <div
        id="mobile-account-dropdown"
        className="mobile-account-dropdown"
      >
        <div className="mobile-account-info">
          <strong>Tài khoản đăng nhập</strong>
          <span>{userDisplayName}</span>
        </div>

        {guestMode ? (
          <button type="button" className="mobile-account-logout" onClick={() => navigate(`/login?returnTo=${encodeURIComponent(location.pathname)}`)}>Đăng nhập</button>
        ) : (
          <button type="button" className="mobile-account-logout" onClick={handleLogout}>Đăng xuất</button>
        )}
      </div>
    )}
  </div>
</header>


        <main className="content">{children}</main>
      </div>

      {/* THANH ĐIỀU HƯỚNG MOBILE */}
      <nav
        className="mobile-bottom-nav"
        aria-label="Điều hướng điện thoại"
      >
        <NavLink to="/" end className={menuClass}>
          <span className="mobile-nav-icon">⌂</span>
          <span>Trang chủ</span>
        </NavLink>

        <NavLink to="/devices" className={menuClass}>
          <span className="mobile-nav-icon">▣</span>
          <span>Thiết bị</span>
        </NavLink>

        <NavLink to="/scan" className={menuClass} onClick={(event) => {
          if (guestMode) {
            event.preventDefault();
            setLoginPrompt({ message: "Bạn cần đăng nhập để sử dụng chức năng Quét QR.", returnTo: "/scan" });
          }
        }}>
          <span className="mobile-nav-icon">▦</span>
          <span>Quét QR</span>
        </NavLink>

        <button
          type="button"
          className={`menu-item ${
            mobileMenuOpen ? "active" : ""
          }`}
          onClick={() => setMobileMenuOpen(true)}
          aria-label="Mở menu chức năng"
          aria-expanded={mobileMenuOpen}
          aria-controls="mobile-menu-panel"
        >
          <span className="mobile-nav-icon">☰</span>
          <span>Menu</span>
        </button>
      </nav>

      {/* MENU MỞ RỘNG MOBILE */}
      {mobileMenuOpen && (
        <div className="mobile-menu-overlay">
          <button
            type="button"
            className="mobile-menu-backdrop"
            onClick={() => setMobileMenuOpen(false)}
            aria-label="Đóng menu"
          />

          <aside
            id="mobile-menu-panel"
            className="mobile-menu-panel"
            role="dialog"
            aria-modal="true"
            aria-label="Menu chức năng"
          >
            <div className="mobile-menu-heading">
              <div>
                <strong>Menu chức năng</strong>
                <small>Quản lý thiết bị</small>
              </div>

              <button
                type="button"
                className="mobile-menu-close"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Đóng menu"
              >
                ✕
              </button>
            </div>

            <nav className="mobile-menu-links">
              {navigation.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.end}
                  className={menuClass}
                  onClick={() => setMobileMenuOpen(false)}
                  onClickCapture={(event) => {
                    if (guestMode && item.path === "/scan") {
                      event.preventDefault();
                      setMobileMenuOpen(false);
                      setLoginPrompt({ message: "Bạn cần đăng nhập để sử dụng chức năng Quét QR.", returnTo: "/scan" });
                    }
                  }}
                >
                  <span className="mobile-drawer-icon">
                    {item.icon}
                  </span>
                  {item.label}
                </NavLink>
              ))}
              
                <NavLink
                  to="/inspections"
                  className={menuClass}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span className="mobile-drawer-icon">☑</span>
                  Tuần kiểm
                </NavLink>

              {isManagerUser && (
              <>
              <div className="mobile-menu-section-title">
                QUẢN TRỊ HỆ THỐNG
              </div>

              <NavLink
                to="/admin/device-types"
                className={menuClass}
                onClick={() => setMobileMenuOpen(false)}
              >
                <span className="mobile-drawer-icon">⚙</span>
                Loại thiết bị
              </NavLink>
              
                <NavLink
                  to="/admin/users"
                  className={menuClass}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span className="mobile-drawer-icon">👤</span>
                  Quản lý người dùng
                </NavLink>
              </>
              )}
            </nav>

            <div className="mobile-menu-footer">
              <span>{userDisplayName}</span>
              {guestMode ? (
                <button type="button" onClick={() => navigate(`/login?returnTo=${encodeURIComponent(location.pathname)}`)}>Đăng nhập</button>
              ) : (
                <button type="button" onClick={handleLogout}>Đăng xuất</button>
              )}
            </div>
          </aside>
        </div>
      )}
      {loginPrompt && <LoginRequiredDialog
        message={loginPrompt.message}
        onClose={() => setLoginPrompt(null)}
        onLogin={() => navigate(`/login?returnTo=${encodeURIComponent(loginPrompt.returnTo)}`)}
      />}
      {appDialog && <AppDialog request={appDialog} onResolve={resolveAppDialog} />}
    </div>
  );
}
