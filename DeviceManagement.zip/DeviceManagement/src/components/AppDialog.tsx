import { useState } from "react";
import type { AppDialogRequest } from "../services/appDialog";
import "../styles/login-required-dialog.css";

export default function AppDialog({ request, onResolve }: {
  request: AppDialogRequest;
  onResolve: (accepted: boolean) => void;
}) {
  const isConfirm = request.kind === "confirm";
  const [verificationValue, setVerificationValue] = useState("");
  const verificationMatches = !request.verificationText
    || verificationValue.trim() === request.verificationText;
  const title = request.title || (isConfirm ? "Xác nhận thao tác" : request.tone === "error" ? "Không thể thực hiện" : "Thông báo");
  return <div className="login-required-overlay" role="presentation" onMouseDown={(event) => {
    if (event.target === event.currentTarget) onResolve(false);
  }}>
    <section className="login-required-dialog" role="dialog" aria-modal="true" aria-labelledby="app-dialog-title">
      <button type="button" className="login-required-close" onClick={() => onResolve(false)} aria-label="Đóng">×</button>
      <div className={`login-required-icon dialog-${request.tone || "info"}`} aria-hidden="true">
        {request.tone === "success" ? "✓" : request.tone === "error" ? "×" : request.tone === "warning" || isConfirm ? "!" : "i"}
      </div>
      <h2 id="app-dialog-title">{title}</h2>
      <p>{request.message}</p>
      {request.verificationText && <label className="app-dialog-verification">
        <span>{request.verificationLabel || `Nhập “${request.verificationText}” để xác nhận`}</span>
        <input value={verificationValue} onChange={(event) => setVerificationValue(event.target.value)} autoComplete="off" />
      </label>}
      <div className="login-required-actions">
        {isConfirm && <button type="button" className="secondary-button" onClick={() => onResolve(false)}>{request.cancelLabel || "Hủy"}</button>}
        <button type="button" className="primary-button" onClick={() => onResolve(true)} disabled={!verificationMatches} autoFocus={!request.verificationText}>{request.confirmLabel || (isConfirm ? "Xác nhận" : "Đóng")}</button>
      </div>
    </section>
  </div>;
}
