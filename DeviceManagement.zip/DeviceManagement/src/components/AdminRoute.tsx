
import type { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import type { AppUser } from "../types/user";
import { isAdmin, isManager } from "../types/user";

interface AdminRouteProps {
  user: AppUser;
  children: ReactNode;
  allowAreaAdmin?: boolean;
}

export default function AdminRoute({
  user,
  children,
  allowAreaAdmin = false,
}: AdminRouteProps) {
  if (!(allowAreaAdmin ? isManager(user) : isAdmin(user))) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}
