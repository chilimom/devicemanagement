import type { ButtonHTMLAttributes, ReactNode } from "react";
import "../styles/action-icon-button.css";

export type ActionIcon =
  | "view" | "edit" | "delete" | "activate" | "deactivate"
  | "history" | "schedule" | "inspect" | "resolve" | "verify"
  | "subareas" | "export" | "clear" | "print" | "back"
  | "add" | "close" | "incident" | "repair" | "scan";

const paths: Record<ActionIcon, ReactNode> = {
  view: <><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6Z"/><circle cx="12" cy="12" r="2.5"/></>,
  edit: <><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"/></>,
  delete: <><path d="M3 6h18"/><path d="M8 6V4h8v2m3 0-1 14H6L5 6"/><path d="M10 11v5m4-5v5"/></>,
  activate: <><path d="m5 12 4 4L19 6"/><path d="M21 12a9 9 0 1 1-3-6.7"/></>,
  deactivate: <><circle cx="12" cy="12" r="9"/><path d="M8 12h8"/></>,
  history: <><path d="M3 12a9 9 0 1 0 2.6-6.4L3 8"/><path d="M3 3v5h5m4-1v5l3 2"/></>,
  schedule: <><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M16 2v4M8 2v4M3 10h18M8 14h3m-3 3h7"/></>,
  inspect: <><path d="m3 12 6 6L21 6"/><circle cx="12" cy="12" r="10"/></>,
  resolve: <><path d="m4 12 5 5L20 6"/><path d="M21 12a9 9 0 1 1-3-6.7"/></>,
  verify: <><path d="m4 12 5 5L20 6"/><path d="M12 2a10 10 0 1 0 10 10"/></>,
  subareas: <><rect x="3" y="4" width="8" height="6" rx="1"/><rect x="13" y="14" width="8" height="6" rx="1"/><path d="M7 10v4h10v-0"/></>,
  export: <><path d="M12 3v12m-4-4 4 4 4-4"/><path d="M5 17v4h14v-4"/></>,
  clear: <><path d="m5 5 14 14M19 5 5 19"/></>,
  print: <><path d="M6 9V3h12v6M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v7H6z"/></>,
  back: <><path d="m15 18-6-6 6-6"/><path d="M9 12h12"/></>,
  add: <><path d="M12 5v14M5 12h14"/></>,
  close: <><path d="m6 6 12 12M18 6 6 18"/></>,
  incident: <><path d="M12 3 2.8 19h18.4L12 3Z"/><path d="M12 9v4m0 3h.01"/></>,
  repair: <><path d="M14.7 6.3a5 5 0 0 0-6.4 6.4L3 18l3 3 5.3-5.3a5 5 0 0 0 6.4-6.4l-3 3-3-3 3-3Z"/></>,
  scan: <><path d="M4 8V4h4m8 0h4v4m0 8v4h-4m-8 0H4v-4"/><path d="M8 12h8m-4-4v8"/></>,
};

type Props = Omit<ButtonHTMLAttributes<HTMLButtonElement>, "children"> & {
  icon: ActionIcon;
  label: string;
  variant?: "default" | "primary" | "danger";
};

export default function ActionIconButton({ icon, label, variant = "default", className = "", ...props }: Props) {
  return <button {...props} type={props.type ?? "button"} className={`action-icon-button is-${variant} ${className}`.trim()} aria-label={props["aria-label"] ?? label} title={props.title ?? label}>
    <svg viewBox="0 0 24 24" aria-hidden="true">{paths[icon]}</svg>
  </button>;
}
