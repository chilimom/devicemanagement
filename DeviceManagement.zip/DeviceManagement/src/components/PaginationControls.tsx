import "../styles/pagination.css";

interface PaginationControlsProps {
  currentPage: number;
  totalItems: number;
  pageSize?: number;
  onPageChange: (page: number) => void;
}

export const DEFAULT_PAGE_SIZE = 25;

export default function PaginationControls({
  currentPage,
  totalItems,
  pageSize = DEFAULT_PAGE_SIZE,
  onPageChange,
}: PaginationControlsProps) {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  if (totalItems <= pageSize) return null;

  const safePage = Math.min(Math.max(currentPage, 1), totalPages);
  const pages = [...new Set([1, safePage - 1, safePage, safePage + 1, totalPages])]
    .filter((page) => page >= 1 && page <= totalPages)
    .sort((first, second) => first - second);

  return <nav className="pagination" aria-label="Phân trang">
    <div className="pagination-summary">
      Trang <strong>{safePage}</strong> / {totalPages}
      <span>{totalItems} mục</span>
    </div>
    <div className="pagination-actions">
      <button type="button" onClick={() => onPageChange(safePage - 1)} disabled={safePage === 1} aria-label="Trang trước">‹</button>
      {pages.map((page, index) => <span key={page} className="pagination-page-group">
        {index > 0 && page - pages[index - 1] > 1 && <i aria-hidden="true">…</i>}
        <button type="button" className={page === safePage ? "is-active" : ""} onClick={() => onPageChange(page)} aria-current={page === safePage ? "page" : undefined}>{page}</button>
      </span>)}
      <button type="button" onClick={() => onPageChange(safePage + 1)} disabled={safePage === totalPages} aria-label="Trang sau">›</button>
    </div>
  </nav>;
}
