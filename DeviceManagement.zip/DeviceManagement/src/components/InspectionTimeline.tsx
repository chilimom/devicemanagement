import type { ReactNode } from "react";
import { Timestamp } from "firebase/firestore";
import "../styles/inspection-timeline.css";
import type {
  InspectionCriterion,
  InspectionResultStatus,
} from "../types/inspection";

/* =========================================================
   INSPECTION TIMELINE
   Hiển thị chuỗi xử lý của MỘT tiêu chí:
   Lần 1 → Bảo trì → Lần 2 (sau khắc phục)
   Component chỉ hiển thị, không đọc/ghi Firestore.
========================================================= */

export type Tone = "ok" | "fail" | "warn" | "info" | "idle";

export const STATUS_TONE: Record<InspectionResultStatus, Tone> = {
  PASS: "ok",
  WARNING: "warn",
  FAIL: "fail",
  NOT_CHECKED: "idle",
};

const STATUS_TEXT: Record<InspectionResultStatus, string> = {
  PASS: "Đạt",
  WARNING: "Cảnh báo",
  FAIL: "Không đạt",
  NOT_CHECKED: "Chưa kiểm tra",
};

const TONE_ICON: Record<Tone, string> = {
  ok: "✓",
  fail: "✕",
  warn: "!",
  info: "↻",
  idle: "○",
};

export interface TimelineInitial {
  inspectionDate: string;
  inspectorName: string;
  createdAt?: unknown;
  status: InspectionResultStatus;
  numericValue?: number | null;
  textValue?: string;
  note?: string;
}

export interface TimelineRetest {
  id: string;
  inspectionDate: string;
  inspectorName: string;
  createdAt?: unknown;
  status: InspectionResultStatus;
  numericValue?: number | null;
  textValue?: string;
  note?: string;
}

export interface TimelineMaintenance {
  id: string;
  title?: string;
  result?: string;
  performedBy?: string;
  performedAt?: unknown;
  status?: string;
  canApprove?: boolean;
  isApproving?: boolean;
  onApprove?: () => void;
}

interface InspectionTimelineProps {
  title: string;
  initial: TimelineInitial;
  criterion?: InspectionCriterion;
  /** Trạng thái hiện tại đã tính qua lần kiểm lại / sự cố. */
  currentStatus: InspectionResultStatus;
  retests: TimelineRetest[];
  maintenances: TimelineMaintenance[];
  maintenanceResolution?: string;
  /** Các nút thao tác do trang cha quyết định (điều hướng, quyền...). */
  actions?: ReactNode;
}

type StepKind =
  | "initial"
  | "maintenance"
  | "retest"
  | "pending";

interface Step {
  key: string;
  kind: StepKind;
  at: number;
  tone: Tone;
  title: string;
  badge?: { label: string; tone: Tone };
  meta?: string;
  value?: string;
  limit?: string;
  note?: string;
  action?: ReactNode;
  elapsed?: string;
}

const KIND_RANK: Record<StepKind, number> = {
  initial: 0,
  maintenance: 1,
  retest: 2,
  pending: 4,
};

function toMillis(value: unknown): number {
  return value instanceof Timestamp ? value.toMillis() : 0;
}

function formatTime(value: unknown): string {
  return value instanceof Timestamp
    ? value.toDate().toLocaleString("vi-VN", { timeZone: "Asia/Ho_Chi_Minh" })
    : "";
}

function formatLimit(criterion?: InspectionCriterion): string {
  if (!criterion) return "";
  const unit = criterion.unit ? ` ${criterion.unit}` : "";
  const { minValue: min, maxValue: max } = criterion;
  if (min != null && max != null) return `ngưỡng ${min} – ${max}${unit}`;
  if (max != null) return `ngưỡng ≤ ${max}${unit}`;
  if (min != null) return `ngưỡng ≥ ${min}${unit}`;
  return "";
}

function formatValue(
  numericValue: number | null | undefined,
  textValue: string | undefined,
  criterion?: InspectionCriterion,
): string {
  if (numericValue != null) {
    return `${numericValue}${criterion?.unit ? ` ${criterion.unit}` : ""}`;
  }
  return textValue?.trim() ?? "";
}

function formatDuration(ms: number): string {
  const minutes = Math.round(ms / 60000);
  if (minutes < 1) return "dưới 1 phút";
  if (minutes < 60) return `${minutes} phút`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h${String(minutes % 60).padStart(2, "0")}`;
  return `${Math.floor(hours / 24)} ngày ${hours % 24}h`;
}

function buildSteps(props: InspectionTimelineProps): Step[] {
  const { initial, criterion, currentStatus, maintenances } = props;
  const limit = formatLimit(criterion);
  const abnormal = initial.status === "WARNING" || initial.status === "FAIL";
  const steps: Step[] = [];

  const initialAt = toMillis(initial.createdAt);
  steps.push({
    key: "initial",
    kind: "initial",
    at: initialAt,
    tone: STATUS_TONE[initial.status],
    title: "Lần 1 — Kiểm tra ban đầu",
    badge: { label: STATUS_TEXT[initial.status], tone: STATUS_TONE[initial.status] },
    meta: `${formatTime(initial.createdAt) || initial.inspectionDate} · ${initial.inspectorName}`,
    value: formatValue(initial.numericValue, initial.textValue, criterion),
    limit,
    note: initial.note?.trim() || undefined,
  });

  for (const item of maintenances) {
    steps.push({
      key: `m-${item.id}`,
      kind: "maintenance",
      at: toMillis(item.performedAt),
      tone: item.status === "COMPLETED" ? "ok" : item.status === "PENDING_APPROVAL" ? "warn" : "info",
      title: `Bảo trì — ${item.title || "Đã ghi nhận"}`,
      badge: { label: item.status === "COMPLETED" ? "Quản lý khu vực đã xác nhận" : item.status === "PENDING_APPROVAL" ? "Chờ quản lý khu vực xác nhận" : "Đã ghi nhận", tone: item.status === "COMPLETED" ? "ok" : item.status === "PENDING_APPROVAL" ? "warn" : "info" },
      meta: [item.performedBy, formatTime(item.performedAt)]
        .filter(Boolean)
        .join(" · "),
      note: item.result ? `Kết quả bảo trì: ${item.result}` : undefined,
      action: item.status === "PENDING_APPROVAL" && item.canApprove ? (
        <button type="button" className="ct-btn ct-btn-primary" disabled={item.isApproving} onClick={item.onApprove}>
          {item.isApproving ? "Đang xác nhận..." : "Xác nhận kết quả bảo trì"}
        </button>
      ) : undefined,
    });
  }

  const sortedRetests = [...props.retests].sort((a, b) => {
    const x = toMillis(a.createdAt);
    const y = toMillis(b.createdAt);
    return x && y ? x - y : 0;
  });

  sortedRetests.forEach((retest, index) => {
    steps.push({
      key: `r-${retest.id}`,
      kind: "retest",
      at: toMillis(retest.createdAt),
      tone: STATUS_TONE[retest.status],
      title: `Lần ${index + 2} — Kiểm tra sau khắc phục`,
      badge: { label: STATUS_TEXT[retest.status], tone: STATUS_TONE[retest.status] },
      meta: `${formatTime(retest.createdAt) || retest.inspectionDate} · ${retest.inspectorName}`,
      value: formatValue(retest.numericValue, retest.textValue, criterion),
      limit,
      note: retest.note?.trim() || undefined,
    });
  });

  steps.sort((a, b) => {
    if (a.kind === "initial") return -1;
    if (b.kind === "initial") return 1;
    return a.at && b.at ? a.at - b.at : KIND_RANK[a.kind] - KIND_RANK[b.kind];
  });

  /* Thời gian xử lý: từ lần 1 đến mốc cuối cùng xác nhận đạt */
  if (abnormal && currentStatus === "PASS" && initialAt > 0) {
    const closing = [...steps]
      .reverse()
      .find((s) => s.kind === "retest" && s.tone === "ok" && s.at > 0);
    if (closing) closing.elapsed = `Xử lý trong ${formatDuration(closing.at - initialAt)}`;
  }

  /* Bước tiếp theo còn thiếu */
  if (abnormal && currentStatus !== "PASS") {
    const last = steps[steps.length - 1];
    steps.push({
      key: "pending",
      kind: "pending",
      at: 0,
      tone: "idle",
      title: last.kind === "maintenance" ? "Chờ quản lý khu vực xác nhận kết quả bảo trì" : "Chờ ghi nhận bảo trì",
    });
  }

  return steps;
}

function summarize(props: InspectionTimelineProps): { label: string; tone: Tone } {
  const { initial, currentStatus, retests, maintenances } = props;
  const abnormal = initial.status === "WARNING" || initial.status === "FAIL";

  if (currentStatus === "PASS") {
    return abnormal
      ? { label: "Đã khắc phục", tone: "info" }
      : { label: "Đạt", tone: "ok" };
  }
  if (currentStatus === "NOT_CHECKED") return { label: "Chưa kiểm tra", tone: "idle" };
  if (maintenances.some((item) => item.status === "COMPLETED")) return { label: "Đã xác nhận đạt", tone: "ok" };
  if (maintenances.some((item) => item.status === "PENDING_APPROVAL")) return { label: "Chờ quản lý khu vực xác nhận", tone: "warn" };
  if (retests.length === 0 && maintenances.length > 0) {
    return { label: "Đang xử lý", tone: "warn" };
  }
  return { label: STATUS_TEXT[currentStatus], tone: STATUS_TONE[currentStatus] };
}

export default function InspectionTimeline(props: InspectionTimelineProps) {
  const { title, initial, criterion, actions } = props;
  const summary = summarize(props);
  const steps = buildSteps(props);
  const compact =
    steps.length === 1 && initial.status === "PASS" && !initial.note?.trim();

  return (
    <div className={`ct-criterion ct-criterion-${summary.tone}`}>
      <div className="ct-head">
        <div className="ct-title">{title}</div>
        <span className={`ct-badge ct-badge-${summary.tone}`}>
          <span aria-hidden="true">{TONE_ICON[summary.tone]}</span>
          {summary.label}
        </span>
      </div>

      {compact ? (
        <div className="ct-compact">
          {formatValue(initial.numericValue, initial.textValue, criterion) && (
            <span className="ct-value-text">
              {formatValue(initial.numericValue, initial.textValue, criterion)}
            </span>
          )}
          {formatLimit(criterion) && <small>{formatLimit(criterion)}</small>}
          <small>
            {formatTime(initial.createdAt) || initial.inspectionDate} · {initial.inspectorName}
          </small>
        </div>
      ) : (
        <ol className="ct-steps">
          {steps.map((step) => (
            <li key={step.key} className={`ct-step ct-step-${step.tone}`}>
              <span className="ct-rail" aria-hidden="true">
                <span className="ct-dot">{TONE_ICON[step.tone]}</span>
              </span>
              <div className="ct-body">
                <div className="ct-line">
                  <strong>{step.title}</strong>
                  {step.badge && (
                    <span className={`ct-badge ct-badge-${step.badge.tone}`}>
                      {step.badge.label}
                    </span>
                  )}
                </div>
                {step.meta && <div className="ct-meta">{step.meta}</div>}
                {(step.value || step.limit) && (
                  <div className="ct-value">
                    {step.value && <span className="ct-value-text">{step.value}</span>}
                    {step.limit && <small>{step.limit}</small>}
                  </div>
                )}
                {step.note && <div className="ct-note">{step.note}</div>}
                {step.action && <div className="ct-actions">{step.action}</div>}
                {step.action && <div className="ct-actions">{step.action}</div>}
                {step.elapsed && <div className="ct-elapsed">{step.elapsed}</div>}
              </div>
            </li>
          ))}
        </ol>
      )}

      {actions && <div className="ct-actions">{actions}</div>}
    </div>
  );
}
