# 05 â€” TÃ­nh nÄƒng vÃ  route

Má»i route nghiá»‡p vá»¥ náº±m sau Ä‘Äƒng nháº­p/profile active. â€œADMINâ€ dÆ°á»›i Ä‘Ã¢y nghÄ©a lÃ  cÃ³ `AdminRoute`; cÃ¡c route cÃ²n láº¡i váº«n bá»‹ Rules vÃ  kiá»ƒm tra area chi phá»‘i.

Khi chÆ°a Ä‘Äƒng nháº­p, á»©ng dá»¥ng cháº¡y á»Ÿ cháº¿ Ä‘á»™ GUEST: xem Tá»•ng quan vÃ  cÃ¡c danh sÃ¡ch public summary táº¡i `/devices`, `/areas`, `/incidents`, `/maintenances`, `/inspections`. Route chi tiáº¿t, QR vÃ  quáº£n trá»‹ chuyá»ƒn Ä‘áº¿n Ä‘Äƒng nháº­p; GUEST khÃ´ng pháº£i role Firestore.

| Route | Page | Chá»©c nÄƒng | Service/chÃ­nh | Quyá»n UI |
|---|---|---|---|---|
| `/` | `Dashboard` | KPI thiáº¿t bá»‹, váº­n hÃ nh, tuáº§n kiá»ƒm vÃ  dá»¯ liá»‡u tá»•ng há»£p | Ä‘á»c trá»±c tiáº¿p Firestore | ADMIN/AREA_ADMIN/USER scoped |
| `/devices` | `Devices` | danh sÃ¡ch, lá»c, phÃ¢n trang 25 dÃ²ng, xuáº¥t Excel toÃ n bá»™ | Excel reader/transform/dynamic workbook | ADMIN/USER scoped |
| `/devices/new` | `AddDevice` | táº¡o device/type nhanh | transaction trá»±c tiáº¿p | ADMIN |
| `/devices/:id` | `DeviceDetail` | Device details and lifecycle; history opens in a separate page | Firestore | ADMIN/USER scoped |
| `/devices/:id/history` | `DeviceDetail` | Separate incident and maintenance history page with expandable records | `DeviceHistory` + Firestore | ADMIN/USER scoped by Rules |
| `/devices/:id/edit` | `DeviceEdit` | sá»­a há»“ sÆ¡ | transaction trá»±c tiáº¿p | ADMIN |
| `/devices/:id/qr` | `DeviceQrPrint` | in QR | Firestore + `qrcode.react` | ADMIN/USER scoped |
| `/scan` | `QrScanner` | quÃ©t/upload QR | `html5-qrcode` | ngÆ°á»i dÃ¹ng Ä‘Ã£ Ä‘Äƒng nháº­p |
| `/q/:deviceCode` | `QrDeviceRedirect` | tra code vÃ  chuyá»ƒn chi tiáº¿t | query devices scoped | ADMIN/USER scoped |
| `/areas` | `Areas` | danh sÃ¡ch/KPI; ADMIN xÃ³a vÄ©nh viá»…n area ngá»«ng dÃ¹ng khi khÃ´ng cÃ²n tham chiáº¿u | Firestore | ADMIN/USER scoped |
| `/areas/new` | `AreaCreate` | táº¡o area | Firestore | ADMIN |
| `/areas/:areaId/edit` | `AreaEdit` | sá»­a/khÃ³a area | Firestore | ADMIN |
| `/areas/:areaId/subareas` | `SubAreas` | quản lý khu vực con trong nhà máy | Firestore | ADMIN/AREA_ADMIN theo nhà máy |
| `/areas/:areaId/subareas` | `SubAreas` | quản lý khu vực con trong nhà máy | Firestore | ADMIN/AREA_ADMIN theo nhà máy |
| `/areas/:areaId/subareas` | `SubAreas` | quáº£n lÃ½ khu vá»±c con cá»§a nhÃ  mÃ¡y | Firestore | ADMIN/AREA_ADMIN theo nhÃ  mÃ¡y |
| `/areas/:areaId/subareas` | `SubAreas` | quáº£n lÃ½ khu vá»±c con trong nhÃ  mÃ¡y; ngÄƒn ngá»«ng má»¥c cÃ²n gÃ¡n cho thiáº¿t bá»‹ | Firestore | ADMIN/AREA_ADMIN theo nhÃ  mÃ¡y |
| `/incidents` | `Incidents` | danh sÃ¡ch/lá»c, phÃ¢n trang 25 dÃ²ng vÃ  thÃ´ng bÃ¡o tráº¡ng thÃ¡i cáº§n xá»­ lÃ½/xÃ¡c minh | Firestore | ADMIN/AREA_ADMIN/USER scoped |
| `/devices/:id/incidents/new` | `IncidentCreate` | táº¡o thá»§ cÃ´ng/tá»« inspection | transaction hoáº·c addDoc | ADMIN/USER scoped |
| `/incidents/:incidentId/resolve` | `IncidentResolve` | ghi láº§n kháº¯c phá»¥c | resolution service | ADMIN/USER scoped |
| `/incidents/:incidentId/verify` | `IncidentVerify` | xÃ¡c minh/Ä‘Ã³ng | verification service | ADMIN/AREA_ADMIN/USER scoped |
| `/maintenances` | `Maintenances` | danh sÃ¡ch báº£o trÃ¬, phÃ¢n trang 25 dÃ²ng | Firestore | ADMIN/USER scoped read |
| `/devices/:id/maintenance/new` | `MaintenanceCreate` | táº¡o báº£o trÃ¬ | Firestore | ADMIN/AREA_ADMIN scoped |
| `/admin/device-types` | `DeviceTypes` | quáº£n lÃ½ type; ADMIN xÃ³a vÄ©nh viá»…n type ngá»«ng dÃ¹ng khi khÃ´ng cÃ²n tham chiáº¿u | Firestore | ADMIN, AREA_ADMIN theo scope |
| `/admin/users` | `UserManagement` | táº¡o/sá»­a/khÃ³a; ADMIN nháº­p máº­t kháº©u má»›i trong form Sá»­a qua service local khi cháº¡y giao diá»‡n Vite dev | Firestore + Firebase Auth + local admin service | ADMIN, AREA_ADMIN theo scope; Ä‘á»•i máº­t kháº©u chá»‰ ADMIN/local |
| `/admin` | redirect | Ä‘áº¿n device types | Router | ADMIN area UI |
| `/inspections` | `InspectionHub` | trang chÃ­nh Tuáº§n kiá»ƒm: tráº¡ng thÃ¡i lá»‹ch vÃ  danh sÃ¡ch thiáº¿t bá»‹ phÃ¢n trang 25 dÃ²ng | Firestore | ADMIN/AREA_ADMIN/USER scoped |
| `/inspections/templates` | `InspectionTemplates` | danh sÃ¡ch, xem/sá»­a, ngá»«ng/khÃ´i phá»¥c; ADMIN xÃ³a vÄ©nh viá»…n máº«u khÃ´ng cÃ²n plan tham chiáº¿u | inspection service | ADMIN, AREA_ADMIN theo scope |
| `/inspections/templates/new` | `InspectionTemplateForm` | táº¡o máº«u theo xÆ°á»Ÿng | inspection service | ADMIN, AREA_ADMIN theo scope |
| `/inspections/templates/:templateId` | `InspectionTemplateForm` | xem/sá»­a máº«u; cáº­p nháº­t version, khÃ´ng ghi láº¡i plan hoáº·c lá»‹ch sá»­ Ä‘Ã£ táº¡o | inspection service | ADMIN, AREA_ADMIN theo scope |
| `/devices/:id/inspection-plan` | `DeviceInspectionPlan` | táº¡o vÃ  sá»­a lá»‹ch/plan theo thiáº¿t bá»‹; ADMIN má»i khu vá»±c, AREA_ADMIN trong `areaIds` | plan/template services | ADMIN, AREA_ADMIN theo scope |
| `/devices/:id/inspection` | `DeviceInspectionExecute` | thá»±c hiá»‡n phiáº¿u | plan/result services | ADMIN/USER scoped |
| `/devices/:id/inspection-history` | `DeviceInspectionHistory` | lá»‹ch sá»­ má»›i nháº¥t trÆ°á»›c vÃ  tá»± má»Ÿ lÆ°á»£t má»›i nháº¥t; báº¥t thÆ°á»ng chÆ°a liÃªn káº¿t cho chá»n kiá»ƒm tra bá»• sung sau kháº¯c phá»¥c hoáº·c chuyá»ƒn thÃ nh sá»± cá»‘ | result service | ADMIN/USER scoped |
| `*` | `Navigate` | fallback `/` | Router | Ä‘Ã£ Ä‘Äƒng nháº­p |

## ChÆ°a hoÃ n thiá»‡n/Cáº¦N XÃC MINH

- KhÃ´ng cÃ³ UI/service quáº£n trá»‹ `deviceCategories`; `DeviceTypes` chá»‰ Ä‘á»c category active Ä‘á»ƒ quáº£n lÃ½ type.
- KhÃ´ng cÃ³ sá»­a/xÃ³a maintenance vÃ  Rules test Ä‘áº§y Ä‘á»§ chÆ°a cháº¡y Emulator.
- Port 55000 khÃ´ng pháº£i port máº·c Ä‘á»‹nh hiá»‡n hÃ nh, nhÆ°ng Ä‘Ã£ xÃ¡c minh cháº¡y Ä‘Æ°á»£c báº±ng CLI override.
