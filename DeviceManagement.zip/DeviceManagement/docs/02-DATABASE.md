# 02 — Firestore Database

Nguồn: write/query trong `src/`, kiểu trong `src/types/`, và `firestore.rules`. `Timestamp` là Firestore server timestamp khi source dùng `serverTimestamp()`.

## Collection và ID

| Collection | Document ID | Quan hệ |
|---|---|---|
| `users` | Firebase Auth UID | `areaIds[]` → `areas` |
| `areas` | auto ID | `devices.areaId` |
| `subAreas` | auto ID | `factoryId` → `areas`; `devices.subAreaId` (optional) |
| `deviceCategories` | CẦN XÁC MINH cơ chế tạo | `deviceTypes.categoryId` |
| `deviceTypes` | auto ID | `devices.deviceTypeId` |
| `devices` | mã thiết bị chuẩn hóa | cha logic của lịch sử |
| `incidents` | auto ID hoặc ID từ tuần kiểm | `deviceId` |
| `incidentResolutions` | `{incidentId}_{attemptNumber}` | incident, device |
| `incidentVerifications` | `incidentId` | một verification/incident |
| `maintenances` | auto ID | `deviceId` |
| `inspectionTemplates` | auto ID | mẫu để tạo plan |
| `deviceInspectionPlans` | `deviceId` | một plan/thiết bị |
| `inspectionResults` | auto ID | device, plan, snapshot |
| `publicPortal` | `current` | generation snapshot công khai hiện hành |
| `publicAreas`, `publicDevices`, `publicIncidents`, `publicMaintenances` | ID nguồn | bản tóm tắt chỉ đọc cho GUEST |

## Schema

### `users`

`displayName: string`, `email: string`, `role: "ADMIN" | "USER"`, `isActive: boolean`, `areaIds?: string[]`. ID là Auth UID. Source hiện chỉ đọc profile; không có lệnh tạo Firebase Auth user hoặc ghi `users/{uid}`. Vì vậy quy trình cấp tài khoản/profile thực tế là thao tác Console hoặc quy trình quản trị bên ngoài và vẫn **CẦN XÁC MINH** với người vận hành.

### `areas`

`code`, `name`, `description`: string; `status: "ACTIVE" | "INACTIVE"`; `createdAt`, `updatedAt`: Timestamp. Tạo/sửa tại `AreaCreate.tsx`, `AreaEdit.tsx`; client kiểm tra trùng code.

Trong mô hình hiện tại `areas` đại diện **nhà máy** (giữ nguyên document ID và cách cấp `users.areaIds`). `subAreas` là danh mục khu vực con thuộc một nhà máy, gồm `factoryId`, `code`, `name`, `description?`, `status`, timestamps. Mã khu vực con duy nhất trong phạm vi một nhà máy do client kiểm tra. Thiết bị có `subAreaId?`; trường này tùy chọn để giữ thiết bị legacy hợp lệ. Nếu có giá trị, Rules buộc khu vực con tồn tại và thuộc đúng `devices.areaId`; phân quyền và dữ liệu lịch sử vẫn dựa trên `areaId` nhà máy.

### `deviceCategories`

Source chỉ xác nhận các field được đọc là `code`, `name`, `status`; `deviceTypes.categoryId` tham chiếu document category. Không có UI/service ghi collection này; trang `DeviceTypes` chỉ quản lý type và chọn category active. Do không đọc production database trong bước tài liệu, các field khác, field bắt buộc, timestamp, quy tắc duy nhất và cơ chế tạo Document ID vẫn **CẦN XÁC MINH**.

### `deviceTypes`

`code`, `name`, `description`, `categoryId`: string; `isActive: boolean`; `areaIds?: string[]`; `createdAt`, `updatedAt`. `areaIds` rỗng hoặc không tồn tại là loại thiết bị toàn hệ thống và chỉ ADMIN được quản lý. Loại có `areaIds` được AREA_ADMIN quản lý khi toàn bộ phạm vi là tập con quyền của họ. UI sinh code từ danh sách hiện tại, không phải counter duy nhất phía server.

### `devices`

ID = `code` chuẩn hóa và không đổi khi sửa. Field tạo: `code`, `name`, `areaId`, `subAreaId?`, `deviceTypeId`, `manufacturer`, `model`, `serialNumber`, `ipAddress`, `macAddress`, `status`, `description`, `isActive`, `createdAt`, `updatedAt`. Lifecycle thêm `inactiveReason`, `inactiveAt`, `reactivatedAt`.

Trạng thái giao diện: `ACTIVE`, `WARNING`, `OFFLINE`, `MAINTENANCE`; ngừng dùng ghi `status="INACTIVE"`, `isActive=false`. Rules cấm delete.

### `incidents`

Field cốt lõi: `deviceId`, `deviceCode`, `deviceName`, `title`, `description`, `severity`, `status`, `reportedAt`, `resolvedAt`, `resolution`.

- Severity: `LOW | MEDIUM | HIGH | CRITICAL`.
- Status: `OPEN | RESOLVED | CLOSED`.
- Khắc phục: `resolutionAttemptCount`, `lastResolutionAttemptAt`, `lastResolutionAttemptByUid`; khi đạt có `resolvedByUid`, `resolutionCount`.
- Xác minh: `verificationCount`, `lastVerifiedByUid`, `lastVerifiedByName`, `lastVerifiedAt`, `closedAt`.
- Nguồn tuần kiểm: `sourceType="INSPECTION"`, `inspectionRecordId`, `inspectionTaskId`, `inspectionCriterionId`; ID `inspection_{recordId}_{taskId}_{criterionId}`. Tạo thủ công dùng auto ID.

### `incidentResolutions`

Rules yêu cầu đúng các field: `incidentId`, `deviceId`, `resolution`, `attemptNumber`, `resolvedByUid`, `resolvedByName`, `resolvedByEmail`, `resolvedAt`, `outcome`. Outcome là `OPEN | RESOLVED`. Mỗi lần khắc phục một document; update/delete bị cấm.

### `incidentVerifications`

Rules yêu cầu `incidentId`, `deviceId`, `note`, `attemptNumber=1`, `verifiedByUid`, `verifiedByName`, `verifiedByEmail`, `verifiedAt`. ID bằng incident ID; workflow hiện chỉ cho một verification; update/delete bị cấm.

### `maintenances`

`deviceId`, `deviceCode`, `deviceName`, `title`, `maintenanceType`, `description`, `performedBy`, `result`, `status`, `performedAt`, `createdAt`. Type: `PREVENTIVE | CORRECTIVE | REPLACEMENT`; tạo mới ghi `COMPLETED`. Bảo trì bắt đầu từ tiêu chí tuần kiểm có thêm `inspectionSource: {recordId, taskId, criterionId}`; field tùy chọn để giữ tương thích hồ sơ cũ. Lịch sử tuần kiểm hiển thị maintenance liên kết, còn trạng thái hoàn tất chỉ được tính khi lượt `EXTRA` liên kết cùng nguồn có kết quả `PASS`.

### `inspectionTemplates`

`name`, `description?`, `deviceTypeId?`, `categoryId?`, `areaIds[]`, `tasks[]`, `isActive`, `version`, `createdAt`, `updatedAt`. Mẫu mới bắt buộc có ít nhất một xưởng. ADMIN chọn mọi xưởng; AREA_ADMIN chỉ chọn tập con `areaIds` được giao. Mẫu legacy thiếu `areaIds` chỉ ADMIN quản lý.

Sửa nội dung giữ nguyên Document ID, tăng `version` trong transaction và cập nhật `updatedAt`. Thay đổi không ghi ngược vào `deviceInspectionPlans` hay `inspectionResults.planSnapshot` đã lưu.

### `deviceInspectionPlans`

ID = device ID. Field: `deviceId`, `templateId?`, `name`, `tasks[]`, `isActive`, `version`, `createdAt`, `updatedAt`. Tạo lần đầu bằng transaction, version 1. Khi ADMIN hoặc AREA_ADMIN đúng scope sửa lịch, transaction tăng version một đơn vị và chỉ cập nhật `name`, `tasks`, `version`, `updatedAt`; không đổi ID, template gốc hoặc trạng thái active.

Task: `id`, `name`, `description?`, `order`, `frequency`, `weekdays[]`, `criteria[]`, `isActive`. Criterion: `id`, `category`, `standard`, `inputType`, `unit?`, `minValue?`, `maxValue?`, `isRequired`.

### `inspectionResults`

Rules yêu cầu `deviceId`, `planId`, `planVersion`, `inspectionDate` (`YYYY-MM-DD`), `inspectionType`, `inspectorName`, `recordedByUid`, `results[]`, `note`, `planSnapshot`, `createdAt`.

- Type: `SCHEDULED | EXTRA`.
- Status task/criterion: `PASS | WARNING | FAIL | NOT_CHECKED`.
- Criterion có thể có `numericValue`, `textValue`, `note`.
- `planSnapshot`: `name`, `version`, `tasks` tại thời điểm kiểm tra.
- Create-only; lịch sử query theo device và `createdAt desc`.

### Public summary cho GUEST

`publicPortal/current` giữ `generation`, `publishedAt`. Bốn collection `public*` chỉ chứa field hiển thị danh sách công khai và cùng `generation`. Khách chỉ query generation hiện hành; không được đọc collection nghiệp vụ. Chỉ ADMIN được phát hành snapshot bằng nút “Cập nhật dữ liệu khách”; đây là thao tác chủ động, không phải đồng bộ realtime.

## Quy tắc timestamp/schema

- Dùng `serverTimestamp()` cho thời điểm nghiệp vụ/created/updated; `inspectionDate` là chuỗi ngày địa phương.
- Không đổi/xóa `deviceId`: Rules lịch sử và query USER phụ thuộc field này.
- Ứng dụng không hard-delete `devices`. Hard-delete chỉ áp dụng cho `areas`, `deviceTypes` và `inspectionTemplates` đã inactive, chỉ bởi ADMIN và sau kiểm tra tham chiếu.
- Không đổi ID plan/verification/resolution nếu chưa cập nhật transaction và Rules `getAfter()`.
- Không loại `planSnapshot`; không thay snapshot lịch sử bằng plan hiện hành.
- Dữ liệu legacy có thể thiếu field; migration cần kế hoạch và test riêng.

### Quan hệ kiểm tra khắc phục

Lượt EXTRA khởi tạo từ nút khắc phục lưu `remediationSource: {recordId, taskId, criterionId}` để liên kết tới tiêu chí gốc cùng thiết bị. Document kiểm tra lại vẫn create-only riêng biệt; UI gom nó vào cùng luồng/KPI mà không ghi đè `planSnapshot` hoặc kết quả lịch sử ban đầu.
