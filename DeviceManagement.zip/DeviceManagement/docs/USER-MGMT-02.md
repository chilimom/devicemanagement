# USER-MGMT-02 — Khảo sát RBAC và quản lý người dùng theo xưởng

## Trạng thái

**IMPLEMENTED — CHỜ NGHIỆM THU VÀ CHƯA DEPLOY.**

Khảo sát phát hiện hai quyết định schema/nghiệp vụ chưa thể suy ra an toàn từ repository:

1. Source chỉ có `areas` và `devices.areaId`; không có thực thể hoặc field liên kết xưởng–khu vực. Vì vậy `areaIds` giới hạn được một tập khu vực nhưng không chứng minh tập đó thuộc cùng một xưởng và không cung cấp tên xưởng.
2. Quy trình lời mời cần một collection/schema mới và chính sách đối chiếu email Firebase Auth với email lời mời. Repository hiện không có collection, Rules hoặc workflow này.

Ngoài ra, các danh mục `deviceCategories`, `deviceTypes` và `inspectionTemplates` hiện là dữ liệu toàn cục, không có `areaId`/`workshopId`. Chưa thể tự quyết định AREA_ADMIN được sửa dữ liệu dùng chung toàn hệ thống hay chỉ được đọc.

Các quyết định đã được phê duyệt: mỗi `areas` là một xưởng; giữ `ADMIN` toàn cục; thêm `AREA_ADMIN`; dùng `areaIds` làm phạm vi. Các phần dưới giữ lại kết quả khảo sát và bổ sung kết quả triển khai ở mục 11.

## 1. Kiến trúc RBAC thực tế đã xác nhận

### Auth và profile

- Firebase Email/Password xác thực Auth user.
- `App.tsx` theo dõi `onAuthStateChanged`, sau đó mở listener `users/{uid}` bằng `onSnapshot`.
- Thiếu profile, profile sai schema, inactive hoặc không đọc được đều fail-closed; route nghiệp vụ không được mount.
- Profile hiện có `uid`, `displayName`, `email`, `role`, `isActive`, `areaIds`.
- Role hợp lệ hiện chỉ là `ADMIN | USER`. `ADMIN` có quyền toàn hệ thống; `USER` bị giới hạn bởi `areaIds`.
- User Management hiện chỉ list profile. Không có create/update/lock/invite trong source.

Bằng chứng: `src/App.tsx:61-151`, `src/types/user.ts:5-49`, `src/services/userService.ts:15-170`, `src/pages/UserManagement.tsx`.

### Firestore Rules

- `isAdminProfile` coi mọi active `ADMIN` là quản trị toàn hệ thống.
- `canAccessAreaForProfile` bỏ qua `areaIds` với ADMIN; chỉ USER bị giới hạn.
- ADMIN hiện có thể list và sửa mọi `users/{uid}` hợp lệ, kể cả admin khác và chính mình.
- Ghi `areas`, `devices`, maintenance, template và inspection plan đều dùng `isAdmin()` toàn cục.
- Device history được phân quyền theo `devices/{deviceId}.areaId` hiện tại.
- Rules chưa có `SUPER_ADMIN`, `AREA_ADMIN`, invite, email verified hoặc giới hạn admin theo phạm vi.

Bằng chứng: `firestore.rules:46-61`, `firestore.rules:94-98`, `firestore.rules:285-315`, `firestore.rules:343-356`.

### Route và CRUD

- `AdminRoute` và menu chỉ nhận role `ADMIN`.
- Các route tạo/sửa area, device, type, maintenance, inspection template/plan và quản lý user đều dùng guard ADMIN hiện tại.
- Nhiều trang quản trị không nhận `appUser`; chúng dựa vào Rules toàn cục. Để hỗ trợ AREA_ADMIN, cả query, validation đích và Rules của từng write đều phải đổi đồng bộ.
- Các workflow incident/inspection của USER đã kiểm tra quyền dựa trên device/area và có thể tái sử dụng cho AREA_ADMIN sau khi helper Rules được mở rộng đúng cách.

Bằng chứng: `src/App.tsx:201-345`, `src/components/AdminRoute.tsx`, `src/components/AppLayout.tsx:33-38`.

### Shared RAM Cache

- Scope key đã chứa UID, role và chữ ký `areaIds` chuẩn hóa.
- Khi role/areaIds/active thay đổi, lifecycle xóa scope cũ và request cũ không được commit.
- Cơ chế hiện tại phù hợp với AREA_ADMIN nếu `areaIds` tiếp tục là phạm vi quyền chuẩn. Chỉ cần mở rộng union role và tests; không cần đổi TTL.

Bằng chứng: `src/services/sharedRamCache.ts:81-130`, `src/services/sharedRamCache.ts:162-174`, `src/services/sharedRamCacheLifecycle.ts:43-101`.

## 2. Quan hệ xưởng–khu vực

### Đã xác nhận

- `users.areaIds[]` tham chiếu trực tiếp document `areas`.
- `devices.areaId` tham chiếu một area.
- `areas` chỉ có code, name, description, status và timestamp.
- Không tìm thấy `workshop`, `workshopId`, `factory` hoặc collection tương đương trong schema/source/Rules.

### Kết luận

`areaIds` **đủ để thực thi quyền theo danh sách khu vực**, nhưng **không đủ để mô hình hóa xưởng là một cấp riêng**. Cần xác nhận một trong hai mô hình:

1. **Khuyến nghị tối thiểu nếu mỗi area chính là một xưởng:** giữ nguyên schema, dùng `areaIds` làm phạm vi AREA_ADMIN và đổi nhãn UI theo thuật ngữ đã xác nhận. Không có cấp “khu vực con”.
2. **Nếu một xưởng gồm nhiều area:** cần quan hệ rõ ràng. Phương án nhỏ nhất là bổ sung `workshopId` vào `areas` và collection danh mục xưởng; đây là thay đổi schema và cần kế hoạch tương thích dữ liệu legacy. Không được triển khai khi chưa có danh sách xưởng và mapping area hiện hữu.

Không nên chỉ lưu một danh sách `areaIds` tùy ý rồi gọi đó là xưởng nếu nghiệp vụ yêu cầu kiểm tra “cùng xưởng”, vì Rules không thể suy ra quan hệ không tồn tại.

## 3. Thiết kế RBAC đề xuất

### Tương thích role hiện hữu

Phương án an toàn được khuyến nghị:

- Giữ giá trị lưu trữ `ADMIN` hiện hữu là quyền quản trị tổng, không tự động chuyển đổi.
- Thêm `AREA_ADMIN` cho quản trị theo phạm vi.
- Giữ `USER` như hiện tại.
- UI có thể hiển thị `ADMIN` hiện hữu là “Quản trị tổng”. Nếu bắt buộc lưu literal `SUPER_ADMIN`, cần một đợt xác minh/migration thủ công riêng; không tự đổi role production.

Như vậy không làm mất quyền ADMIN tổng hiện hữu và không cần migration chỉ để bắt đầu hỗ trợ AREA_ADMIN.

### Nguyên tắc Rules

- `isSuperAdmin`: active và role `ADMIN` (legacy global admin).
- `isAreaAdmin`: active, role `AREA_ADMIN`, `areaIds` là danh sách không rỗng hợp lệ.
- `canAccessArea`: ADMIN toàn cục; AREA_ADMIN/USER chỉ area nằm trong profile.
- Mọi create/update device phải kiểm tra cả area trước và area sau. AREA_ADMIN chỉ được tạo/chuyển device khi area đích thuộc quyền.
- Update record có liên kết device phải kiểm tra device trước/sau hoặc deviceId bất biến, không chỉ kiểm tra dữ liệu cũ.
- AREA_ADMIN chỉ được list user bằng query có constraint Rules có thể chứng minh; không list toàn `users` rồi lọc client.
- AREA_ADMIN chỉ được tạo/sửa USER hoặc AREA_ADMIN có `areaIds` là tập con của chính caller; không được ghi role ADMIN.
- AREA_ADMIN không được sửa profile role ADMIN, không được sửa chính mình để tăng quyền/mở rộng scope/tự mở khóa.
- Với thay đổi profile mục tiêu, Rules kiểm tra cả `resource.data` và `request.resource.data` để ngăn đưa user từ ngoài phạm vi vào rồi chiếm quyền quản lý.
- Delete profile nên tiếp tục bị cấm trong UI; khóa bằng `isActive=false` bảo toàn audit/profile.

### Dữ liệu toàn cục chưa có phạm vi

Cần phê duyệt chính sách cho `deviceCategories`, `deviceTypes`, `inspectionTemplates`:

- Khuyến nghị ban đầu: AREA_ADMIN được đọc nhưng không sửa danh mục/template toàn cục; ADMIN tổng tiếp tục quản lý.
- AREA_ADMIN vẫn được quản lý device, maintenance và plan gắn với device trong phạm vi nếu Rules kiểm tra device area.
- Nếu AREA_ADMIN phải quản lý type/template riêng theo xưởng, bắt buộc bổ sung ownership/scope vào schema; không thể bảo vệ bằng Rules hiện tại.

## 4. Quy trình lời mời khả thi trên Firebase Spark

Không cần Admin SDK/Cloud Functions để người dùng tự đăng ký, xác minh email và nhận profile, nhưng cần schema + Rules mới.

Luồng đề xuất:

1. Admin có quyền tạo invite với email canonical, role được phép, areaIds hợp lệ, trạng thái pending, người tạo và thời hạn.
2. Người được mời tạo/đăng nhập Firebase Auth và hoàn tất `sendEmailVerification`.
3. Client buộc refresh ID token; Rules yêu cầu `request.auth.token.email_verified == true` và email token khớp invite.
4. Một transaction/batch duy nhất tạo `users/{uid}` và chuyển invite từ pending sang accepted, lưu `acceptedByUid`/thời điểm server.
5. Rules yêu cầu profile mới khớp chính xác role/areaIds từ invite, invite chưa dùng/chưa hết hạn và `users/{uid}` chưa tồn tại.
6. `getAfter()` kiểm tra invite đã được consume trong cùng atomic write; invite không thể tái sử dụng.
7. Trước khi profile tồn tại, user chỉ được đọc invite dành cho chính email và tự nhận invite; mọi collection nghiệp vụ vẫn bị từ chối.

Các điểm phải chốt trước triển khai:

- Tên collection và schema invite.
- Chuẩn hóa email. Firestore Rules không có hàm lowercase tùy ý, vì vậy format lưu và phép so sánh với Auth token phải được thiết kế/test bằng Emulator, không chỉ normalize ở client.
- Cách tạo Auth account/mật khẩu và nội dung email vận hành. Firebase client có thể gửi email xác minh, nhưng ứng dụng Spark không tự có dịch vụ gửi “email mời” tùy biến phía server.
- TTL/hủy invite và quyền xem metadata invite để tránh lộ danh sách email.

Khóa user trên Spark trong mô hình này là `users/{uid}.isActive=false`; nó chặn dữ liệu bằng Rules nhưng không disable Firebase Auth account ở cấp Auth. Disable Auth account yêu cầu môi trường đặc quyền (Admin SDK/Console), nằm ngoài giới hạn hiện tại.

## 5. Ma trận kiểm thử Rules bắt buộc sau khi phê duyệt

| Actor/ca | Kỳ vọng |
|---|---|
| ADMIN legacy | Giữ toàn quyền hiện tại |
| AREA_ADMIN A/B | Chỉ read/write device và dữ liệu liên kết trong areaIds của mình |
| AREA_ADMIN A đọc/list dữ liệu B | Denied, kể cả query không constraint |
| AREA_ADMIN A tạo user có area B | Denied |
| AREA_ADMIN tự đổi role ADMIN | Denied |
| AREA_ADMIN sửa/khóa ADMIN | Denied |
| AREA_ADMIN chuyển device A → B | Denied; A → area khác trong scope được phép |
| USER | Không tạo invite, không sửa profile |
| Invite email chưa verify/sai email/hết hạn/đã dùng | Denied |
| Claim invite hợp lệ | Profile + consume invite cùng commit |
| Inactive profile | Chỉ đọc profile chính để hiển thị trạng thái; nghiệp vụ denied |
| Role/areaIds đổi realtime | UI fail-closed, cache scope cũ bị xóa |

Rules Emulator hiện được cấu hình ở port 8085 và có script `npm run rules:test:emulator`. Khi Rules thay đổi phải bổ sung tests cho toàn bộ ma trận trên rồi chạy Emulator trước nghiệm thu.

## 6. File đã sửa

- `docs/USER-MGMT-02.md` — báo cáo khảo sát và thiết kế này.

Không sửa source, Firebase Auth, Firestore Rules, indexes, database, schema hoặc dependency. Không deploy.

## 7. Chức năng hoàn thành

- Hoàn thành khảo sát Auth/Profile, role hiện tại, user management, route guard, Rules và cache scope.
- Xác định ranh giới có thể tái sử dụng và các lỗ hổng nếu chỉ mở UI cho AREA_ADMIN.
- Đề xuất mô hình tương thích ADMIN hiện hữu và quy trình invite trên Spark.

Chưa triển khai chức năng người dùng hoặc AREA_ADMIN vì thiếu quyết định schema/phạm vi nêu trên.

## 8. Kiểm thử

- Không chạy test/build vì chỉ thêm tài liệu và chủ động dừng trước thay đổi code/Rules.
- Rules Emulator: **PENDING**, chưa có Rules mới để kiểm thử.
- Kiểm thử production/Console: không thực hiện.

## 9. Vấn đề cần phê duyệt

1. Mỗi document `areas` có phải chính là một xưởng không, hay một xưởng gồm nhiều area?
2. Nếu có cấp xưởng riêng, phê duyệt schema/mapping xưởng–area và chiến lược legacy.
3. Giữ role lưu trữ `ADMIN` làm quản trị tổng (khuyến nghị) hay migration sang literal `SUPER_ADMIN`?
4. AREA_ADMIN có được sửa danh mục/type/template toàn cục không? Khuyến nghị không.
5. Phê duyệt collection/schema invite và quy tắc canonical email.
6. “Khóa tài khoản” chỉ là chặn profile/Rules hay phải disable cả Firebase Auth account?

## 10. Rollback

Trước deploy, rollback bằng cách hoàn nguyên các file liệt kê tại mục 11. Sau deploy, phải rollback `firestore.rules` và Hosting về cùng phiên bản để tránh UI/Rules lệch nhau. Không có migration tự động; role ADMIN/USER legacy không bị đổi.

## 11. Kết quả triển khai

### File thay đổi

- `firestore.rules`: role AREA_ADMIN, scoped business writes, user/invite authorization và atomic invite acceptance.
- `src/types/user.ts`, `src/services/userService.ts`: kiểu role và parser/helper RBAC.
- `src/components/AdminRoute.tsx`, `src/components/AppLayout.tsx`, `src/App.tsx`: route/menu quản trị theo scope và trạng thái Auth chưa có profile.
- `src/services/userManagementService.ts`: tạo/list lời mời, quản lý profile và nhận lời mời bằng transaction.
- `src/pages/UserManagement.tsx`: danh sách, invite, sửa role/areaIds, khóa/mở và tên xưởng.
- `src/pages/InviteActivation.tsx`: xác minh email và nhận lời mời khi Auth user chưa có profile.
- `src/pages/AddDevice.tsx`, `DeviceEdit.tsx`, `DeviceDetail.tsx`, `AreaEdit.tsx`, `Areas.tsx`, `Devices.tsx`, `Dashboard.tsx`: mở thao tác AREA_ADMIN trong phạm vi và giữ query scoped.
- `tests/firestore.rules.test.mjs`: ca AREA_ADMIN, chuyển xưởng, nâng quyền và invite.
- `tests/sharedRamCache.test.ts`: phân biệt scope ADMIN/AREA_ADMIN/USER.

### Chức năng hoàn thành

- ADMIN giữ nguyên quyền toàn hệ thống và có thể mời/quản lý mọi role.
- AREA_ADMIN đọc dữ liệu theo cùng query `areaIds` an toàn như USER, nhưng được tạo/sửa device, sửa area được giao, tạo maintenance và tạo inspection plan trong phạm vi.
- AREA_ADMIN không được tạo area mới, sửa danh mục/type/template toàn cục, đổi code xưởng, xóa dữ liệu không có workflow UI, chuyển device ra ngoài scope hoặc sửa ADMIN.
- User Management hiển thị tên xưởng, trạng thái profile và lời mời; hỗ trợ invite, sửa role/areaIds và khóa/mở.
- Auth user chưa có profile chỉ thấy màn hình nhận lời mời; chưa nhận thành công không mount dữ liệu nghiệp vụ.
- Nhận lời mời yêu cầu token `email_verified`, email trùng chính xác invite, tạo `users/{uid}` và consume invite trong cùng transaction.
- Cache key hiện có đã chứa role và area signature; thêm test chứng minh AREA_ADMIN không dùng scope ADMIN/USER. TTL không đổi.

### Quy tắc phân quyền đáng chú ý

- Device update kiểm tra cả `resource.data.areaId` và `request.resource.data.areaId`.
- Maintenance/plan create suy phạm vi từ device liên kết. Update/delete không có workflow AREA_ADMIN nên không được mở mặc định.
- AREA_ADMIN chỉ update target user khác mình, role USER/AREA_ADMIN, với areaIds trước và sau đều là tập con scope caller; email bất biến.
- AREA_ADMIN không được list collection `users`. UI chỉ khám phá các account đã nhận invite do chính AREA_ADMIN đó tạo, rồi `get` từng UID. Đây là giới hạn chủ động vì Firestore Rules không thể bảo vệ phép list theo quan hệ tập-con `areaIds`.
- Danh mục/type toàn cục: active user đọc theo hành vi hiện hữu; chỉ ADMIN ghi. Template: AREA_ADMIN đọc để lập plan; chỉ ADMIN ghi.

### Kết quả kiểm thử

| Lệnh | Kết quả |
|---|---|
| `npm run cache` | PASS — 34/34 |
| `npx tsc --noEmit` | PASS |
| `npm run lint` | PASS |
| `npm run build` | PASS |
| `npm run rules:test:emulator` | PENDING — Firestore Emulator không thể khởi động vì Java chưa có trên PATH (`spawn java ENOENT`) |
| `npm run rules:test` | PASS command, nhưng 9 integration tests SKIP vì repository chưa có `@firebase/rules-unit-testing` |
| `npm run excel` | PASS — 26/26 |

Build còn cảnh báo chunk trên 500 kB như trước, không phải lỗi RBAC.

### Giới hạn còn lại

- AREA_ADMIN không thể liệt kê các profile legacy được gán area thủ công hoặc được admin khác mời; cần ADMIN quản lý các tài khoản đó. Không mở `users` list để tránh rò rỉ profile ngoài scope.
- Email invite phải ở dạng `trim + lowercase`. Auth email mixed-case bị fail-closed vì Firestore Rules không có phép lowercase tổng quát.
- `isActive=false` chặn dữ liệu qua Rules nhưng không disable Firebase Auth account; disable Auth cần Console/Admin SDK.
- Không có dịch vụ gửi email mời tùy biến. Firebase client chỉ gửi email xác minh địa chỉ.
- Rules mới chưa được xác nhận bằng Emulator cho tới khi cài Java và chạy suite thành công. Không deploy Rules trước bước này.

### Kiểm thử thủ công

1. Tạo ADMIN, AREA_ADMIN xưởng A/B và USER A trong Emulator/UAT riêng.
2. Kiểm tra Dashboard/Devices/Detail/Areas/Incidents/Maintenance/Inspection của AREA_ADMIN chỉ có areaIds được giao.
3. Thử URL trực tiếp tới device/area B, chuyển device A → B và chỉnh request bằng DevTools; phải permission-denied.
4. ADMIN tạo invite USER/AREA_ADMIN; đăng ký/đăng nhập đúng email, xác minh email, nhận invite và kiểm tra lần nhận thứ hai bị từ chối.
5. Thử email chưa verify, email sai, không có invite và invite đã dùng.
6. Thử AREA_ADMIN cấp area B, role ADMIN, sửa ADMIN tổng, sửa chính mình; tất cả phải bị từ chối.
7. Khóa user đang đăng nhập; profile listener phải unmount app và cache scope phải bị xóa.
8. Logout/login tài khoản khác và kiểm tra không có dữ liệu cache scope cũ.

### Triển khai sau phê duyệt

1. Cài Java tương thích Firebase Emulator và dependency test `@firebase/rules-unit-testing` sau phê duyệt; bảo đảm `java -version` chạy được.
2. Chạy `npm run rules:test:emulator`; chỉ tiếp tục khi 9 integration tests thực sự chạy và toàn bộ PASS, không chấp nhận SKIP.
3. Kiểm thử thủ công trên project Emulator/UAT, không dùng dữ liệu production.
4. Review riêng diff `firestore.rules` và phê duyệt cửa sổ rollback.
5. Deploy Rules trước bằng lệnh Firebase CLI được phê duyệt; xác minh deny/allow trọng yếu.
6. Sau đó mới build và deploy Hosting bằng quy trình đã phê duyệt.
7. Nếu lỗi, rollback Rules về bản trước và rollback các file source nêu trên; không cần migration vì `ADMIN`/`USER` legacy vẫn tương thích và chưa có ghi production tự động.

## 12. USER-MGMT-03 — Firestore Rules Security Test

### Môi trường ngày 06/11/2026

- `java -version`: không tìm thấy lệnh.
- `where.exe java`: không có kết quả.
- `JAVA_HOME`: trống.
- Không tìm thấy Java/JDK/JBR trong các thư mục Program Files, user profile hoặc registry phổ biến.
- Firebase CLI: `15.33.0` (xác nhận bằng `firebase.cmd --version`; PowerShell shim `.ps1` bị ExecutionPolicy chặn).
- Node.js: `20.19.6`.
- Firestore Emulator cấu hình `127.0.0.1:8085`.
- Không tìm thấy cache JAR tại `%USERPROFILE%\.cache\firebase\emulators`; lần chạy đầu có thể cần artifact Emulator từ mạng hoặc nguồn nội bộ.

Tài liệu Firebase hiện yêu cầu JDK 11 trở lên và cảnh báo Firestore Emulator sẽ chuyển sang yêu cầu Java 21. Chọn **JDK 21 LTS x64** để tránh phải nâng lại:

- <https://firebase.google.com/docs/emulator-suite/install_and_configure>
- <https://firebase.google.com/docs/emulator-suite/connect_firestore>

### Cài JDK offline, không đổi PATH hệ thống

1. Lấy gói JDK 21 LTS x64 ZIP/MSI từ kho phần mềm nội bộ đã phê duyệt; kèm checksum SHA-256 và thông tin nhà phát hành.
2. Nếu dùng ZIP, giải nén vào thư mục công cụ được phép, ví dụ `C:\Tools\jdk-21`. Không cần ghi System PATH.
3. Trong đúng PowerShell dùng để test, đặt biến chỉ cho process hiện tại:

   ```powershell
   $env:JAVA_HOME = 'C:\Tools\jdk-21'
   $env:Path = "$env:JAVA_HOME\bin;$env:Path"
   java -version
   npm run rules:test
   ```

4. Nếu máy kiểm thử không có Internet, cung cấp thêm cache/binary Firestore Emulator tương ứng Firebase CLI 15.33.0 từ kho nội bộ theo quy trình của tổ chức. Không sao chép artifact không có checksum.

### Dependency và test runner

- Đã thêm dev dependency `@firebase/rules-unit-testing@5.0.2`; không thay đổi runtime dependencies.
- `package.json` và `package-lock.json` đã cập nhật.
- `npm run rules:test` nay tự chạy `firebase emulators:exec --only firestore`; không còn chạy test trực tiếp khi không có Emulator.
- Test dùng import bắt buộc, không còn optional import hoặc chuyển integration test thành SKIP khi thiếu package.
- Mỗi test clear và seed lại Firestore Emulator để không rò trạng thái giữa các ca.
- Bộ Rules hiện có **16 integration tests**, bao phủ ADMIN, AREA_ADMIN A/B, USER, inactive, chuyển device, user management, verified/unverified/mismatched email, reuse invite, atomic profile+invite và các collection liên kết.

### Kết quả

| Lệnh | PASS | FAIL | SKIP | Ghi chú |
|---|---:|---:|---:|---|
| `npm run cache` | 34 | 0 | 0 | PASS |
| `npm run excel` | 26 | 0 | 0 | PASS |
| `npx tsc --noEmit` | 1 command | 0 | 0 | PASS |
| `npm run lint` | 1 command | 0 | 0 | PASS |
| `npm run build` | 1 command | 0 | 0 | PASS; còn cảnh báo chunk size như trước |
| `npm run rules:test` | 0 | 1 môi trường | 0 | BLOCKED trước khi chạy test: `spawn java ENOENT` |

Sau khi dependency được cài, chạy file test trực tiếp không còn SKIP mà fail ở hook do không có Emulator host. Runner đã được sửa để luôn khởi động Emulator, vì vậy kết quả hợp lệ tiếp theo phải là 16 test thực thi thật.

`npm install` báo 19 vulnerability gián tiếp (12 moderate, 7 high). Không chạy `npm audit fix` vì có thể thay đổi dependency ngoài phạm vi; cần đánh giá riêng trước deploy.

### Lỗi đã sửa trong hạ tầng test

- Bỏ optional import khiến test bị SKIP khi thiếu dependency.
- Sửa script `rules:test` để luôn bao quanh test bằng Firestore Emulator.
- Cô lập fixture bằng `clearFirestore()` + seed trước mỗi test.
- Bổ sung các ca email mismatch, partial atomic write, inactive profile, USER tự sửa profile, AREA_ADMIN list/manage ngoài scope và access collection liên kết.

### Trạng thái deploy

**NOT READY FOR DEPLOY.** Chưa được phép deploy Hosting hoặc Rules cho tới khi:

1. JDK 21 LTS và Firestore Emulator binary/cache sẵn sàng.
2. `npm run rules:test` chạy đủ 16 test với PASS=16, FAIL=0, SKIP=0.
3. Chạy lại toàn bộ regression sau mọi sửa Rules phát sinh từ test failure.
