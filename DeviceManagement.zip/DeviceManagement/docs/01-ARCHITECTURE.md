# 01 — Kiến trúc

## Tổng thể

```mermaid
flowchart LR
  Browser[React + Vite SPA] --> Auth[Firebase Authentication]
  Browser --> Rules[Firestore Security Rules]
  Rules --> DB[(Cloud Firestore)]
  Browser --> XLSX[Transformer + ExcelJS]
  Hosting[Firebase Hosting] --> Browser
```

Ứng dụng không có backend riêng hoặc Cloud Functions. Browser dùng Firebase Web SDK, nên thao tác Firestore phải thỏa kiểm tra client và `firestore.rules`.

## Entry và module

- `index.html` → `src/main.tsx` → `src/App.tsx`.
- `App.tsx` theo dõi Firebase Auth và realtime profile `users/{uid}`, sau đó dựng layout/route.
- `pages/` chứa màn hình; một số page đọc Firestore trực tiếp.
- `services/` chứa workflow và transaction dùng lại.
- `types/` chứa kiểu user, tuần kiểm và biên đọc Excel.
- `firestore.rules` là lớp quyết định quyền phía server.

## Đăng nhập

```mermaid
sequenceDiagram
  participant U as Người dùng
  participant UI as Login/App
  participant A as Firebase Auth
  participant F as Firestore
  U->>UI: Email + mật khẩu
  UI->>A: signInWithEmailAndPassword
  A-->>UI: Firebase User
  UI->>F: onSnapshot users/{uid}
  F-->>UI: role, isActive, areaIds
  UI->>UI: parseAppUser
  alt profile hợp lệ và active
    UI-->>U: Ứng dụng
  else thiếu/sai/inactive
    UI-->>U: Khóa truy cập
  end
```

## Đọc và ghi dữ liệu

- ADMIN thường list toàn collection theo Rules.
- USER lấy thiết bị/khu vực bằng `areaId in areaIds` hoặc `documentId in areaIds`, sau đó lịch sử bằng `deviceId`.
- Write đơn giản dùng `addDoc`/`updateDoc`; write cần nhất quán dùng transaction.
- Khắc phục tạo resolution và cập nhật incident trong cùng transaction.
- Xác minh tạo verification và đóng incident trong cùng transaction.
- Phiếu tuần kiểm lưu `planSnapshot` để bảo toàn lịch sử.

## Xuất Excel

```mermaid
flowchart LR
  Button[Devices: Xuất Excel] --> Reader[loadExcelExportData]
  Reader --> Transform[transformExcelExportData]
  Transform --> Tables[6 sheet / 63 cột]
  Tables --> Dynamic[dynamic import workbook]
  Dynamic --> ExcelJS[ExcelJS]
  ExcelJS --> Download[XLSX]
```

Reader chỉ đọc và áp dụng phạm vi ADMIN/USER. Transformer không gọi Firestore. Workbook được dynamic import để ExcelJS không vào entry khi chưa dùng.

## Hosting và phụ thuộc

Vite tạo `dist/`; Firebase Hosting phục vụ `dist` và rewrite `**` về `/index.html`, phù hợp `BrowserRouter`.

- Pages → Firebase config, types, services.
- Workflow sự cố → Auth + transaction + `incidentWorkflow.ts`.
- Tuần kiểm → ba service inspection/plan/result.
- Excel → data reader → transformer → workbook.
- UI guard hỗ trợ trải nghiệm; Rules mới là lớp quyền quyết định.

