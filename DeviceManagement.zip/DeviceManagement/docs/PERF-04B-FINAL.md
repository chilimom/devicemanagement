# PERF-04B FINAL — Hoàn thiện Shared RAM Cache

Ngày hoàn thiện code: 06/11/2026. Phạm vi: shared RAM cache cho `devices`, `areas`, `deviceCategories`, `deviceTypes`; không bật Firestore Offline Persistence và không deploy.

## Kết quả

Shared cache đã được tích hợp vào Devices, DeviceDetail, Dashboard và hai consumer phù hợp là Areas/InspectionHub. Cache chỉ hoạt động sau Auth/profile barrier, chỉ giữ active scope trong RAM và không dùng cache làm căn cứ cấp quyền.

- Fresh: render ngay, không gọi loader Firestore.
- Stale: render dữ liệu cùng verified scope và chạy một background refresh deduplicated.
- Expired/miss: không trả dữ liệu cũ; foreground load.
- Permission denied: entry bị evict; các page list xóa dữ liệu đang hiển thị và báo lỗi.
- Scope/logout/profile change: lifecycle epoch + cache generation làm request cũ không commit.

## File tạo/sửa trong PERF-04B FINAL

| File | Nội dung |
| --- | --- |
| `src/services/sharedCollectionCache.ts` | Adapter collection dùng scope active, TTL, dedupe và invalidation. |
| `src/services/appSharedRamCache.ts` | Xác minh AppUser khớp exact active scope. |
| `src/pages/Devices.tsx` | Cache bốn collection; fresh hit, stale refresh nền, trạng thái refresh/error. |
| `src/pages/DeviceDetail.tsx` | Seed device/metadata từ cache đúng scope + area check, luôn revalidate document; invalidate lifecycle write. |
| `src/pages/Dashboard.tsx` | Cache phần dữ liệu chung; incidents/maintenances vẫn đọc trực tiếp và công thức KPI không đổi. |
| `src/pages/Areas.tsx` | Dùng cache areas/devices, giữ nguyên công thức thống kê. |
| `src/pages/InspectionHub.tsx` | Dùng cache devices/areas. |
| `src/pages/AddDevice.tsx` | Invalidate devices/deviceTypes sau write thành công. |
| `src/pages/DeviceEdit.tsx` | Invalidate devices sau transaction thành công, gồm chuyển area. |
| `src/pages/DeviceTypes.tsx` | Invalidate deviceTypes sau add/update/toggle thành công. |
| `src/pages/AreaCreate.tsx`, `src/pages/AreaEdit.tsx` | Invalidate areas sau write thành công. |
| `tests/sharedRamCache.test.ts` | Thêm test adapter fresh-hit và stale-background-refresh. |
| `tsconfig.cache-test.json` | Compile adapter/app singleton trong cache suite. |
| `docs/PERF-04B-FINAL.md` | Báo cáo nghiệm thu. |

Các file nền tảng/lifecycle từ PERF-04B.1/2A tiếp tục được sử dụng. Không đổi Firebase Auth persistence, Rules, indexes, database, schema, route, QR hoặc dependency.

## Cache hit/miss và refresh

`beginAppCollectionRead` chỉ trả cache khi `AppUser` tạo ra cùng exact scope key đang active. Adapter đọc snapshot đồng bộ:

- `fresh`: `request=null`, không gọi loader.
- `stale`/`refreshing`: trả data; `cache.load` refresh nền, dùng chung Promise cùng collection/scope.
- `missing`/`expired`/`loading`: không trả expired data; caller hiển thị loading và await request.

Devices hiển thị bốn dataset cached ngay khi cả bốn có data. Refresh failure do mạng giữ dữ liệu chưa expired và hiển thị thông báo; permission failure xóa UI data. Dashboard dùng cache cho bốn collection nhưng vẫn tải incidents/maintenances riêng để bảo toàn KPI. Không cache history hoặc inspection results.

DeviceDetail chỉ seed khi cached device thuộc exact current scope và USER vẫn qua `canAccessArea` với cached `areaId`; sau đó vẫn gọi `getDoc(devices/{id})`. Direct URL/cache miss giữ flow server hiện hành. Server trả not-found/permission/out-of-area sẽ xóa seed và block hồ sơ.

## Invalidation CRUD

| Write thành công | Invalidation |
| --- | --- |
| Add device | `devices` |
| Edit/move device | `devices` |
| Deactivate/reactivate device | `devices` |
| Add type từ AddDevice | `deviceTypes` |
| Add/edit/toggle type | `deviceTypes` |
| Add/edit area | `areas` |

Invalidation nằm sau `await` write/transaction. Write thất bại không thay cache. Không bổ sung delete device. Profile/logout/UID/role/areaIds/active vẫn do lifecycle fail-closed quản lý.

## Phạm vi không cache

- incidents, maintenances, incident history/resolution/verification.
- inspectionResults, plan history/snapshot.
- Excel export data.
- Profile/RBAC và validation/transaction precondition.

Các form Add/Edit/DeviceTypes tiếp tục đọc trực tiếp vì cần validation mới nhất và hiện không nhận AppUser; không thay route props chỉ để tối ưu form.

## Kiểm thử và nghiệm thu

Unit tests bao phủ scope, TTL, hit/miss, stale refresh, dedupe, invalidation, permission denied, logout/profile changes, StrictMode và late request. Các lệnh quality gate được chạy trên trạng thái cuối và ghi ở báo cáo bàn giao.

Các kiểm tra browser tương tác (throttle 4G/offline, nhiều tài khoản thật, deep-link, QR scan/print) cần smoke test trên preview được phê duyệt; không deploy trong công việc này. Source review xác nhận QR/history/KPI formula không bị sửa.

## Rủi ro còn lại

- Cache là per-tab, không đồng bộ mutation từ tab/thiết bị khác trước TTL; stale refresh giới hạn cửa sổ này.
- DeviceDetail USER có thể seed dữ liệu từng được phép xem trong stale window trước khi server revalidate; UI vẫn kiểm tra cached `areaId`, sau đó fail-closed nếu server từ chối. Máy dùng chung được bảo vệ bằng clear scope khi logout/account/profile change.
- Không có React browser test dependency; integration behavior cần UAT preview. Không thêm dependency theo yêu cầu.
- Build vẫn có cảnh báo chunk lớn đã biết, không liên quan logic cache.

## Rollback

1. Khôi phục direct loaders trong Devices/Dashboard/Areas/InspectionHub và bỏ seed trong DeviceDetail.
2. Gỡ các call invalidation khỏi CRUD pages.
3. Có thể giữ core/lifecycle chưa có consumer hoặc gỡ adapter/singleton imports.
4. Không cần migration/xóa browser storage vì cache chỉ RAM; không rollback Rules/database.

**PERF-04B FINAL — CODE COMPLETE.** Chờ smoke test/UAT và phê duyệt riêng trước deploy.
