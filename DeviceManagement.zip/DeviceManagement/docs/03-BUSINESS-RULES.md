# 03 — Quy tắc nghiệp vụ

## Khu vực và danh mục

- Area code được trim/uppercase và kiểm tra trùng ở client; trạng thái `ACTIVE/INACTIVE`.
- `areas` đại diện nhà máy; `subAreas.factoryId` liên kết khu vực con với nhà máy. Mã khu vực con duy nhất trong từng nhà máy; AREA_ADMIN chỉ quản lý con trong nhà máy được giao.
- Không ngừng khu vực con đang được thiết bị tham chiếu. Thiết bị legacy không có `subAreaId` vẫn hợp lệ; nếu có thì phải cùng nhà máy với `areaId`.
- Không cho chuyển area sang INACTIVE khi còn thiết bị đang sử dụng.
- Category là lĩnh vực; source hiện chỉ đọc `code`, `name`, `status`, chưa có màn hình/service quản trị category. Rules cho active user đọc và chỉ ADMIN ghi, nhưng không có workflow ghi trong ứng dụng. Thay đổi category từ công cụ bên ngoài có thể ảnh hưởng lựa chọn category/type; thiết bị hiện hữu vẫn liên kết gián tiếp qua `deviceTypeId`.
- Device type thuộc một category. Không được ngừng type khi còn thiết bị active; không chuyển thiết bị sang category/type inactive.
- Chỉ ADMIN được xóa vĩnh viễn khu vực hoặc loại thiết bị đã ngừng sử dụng. Trước khi xóa, client kiểm tra các tham chiếu đã biết và từ chối nếu còn thiết bị, tài khoản, phạm vi hoặc mẫu liên quan. AREA_ADMIN chỉ được ngừng sử dụng/khôi phục trong scope.

## Thiết bị

- Mã thiết bị bắt buộc, chuẩn hóa và dùng làm Firestore Document ID; không đổi khi sửa.
- Tạo bằng transaction xác minh area/category/type còn hợp lệ và không ghi đè ID đã có.
- IP/MAC được kiểm tra định dạng ở form; code/IP/MAC/serial được giữ dạng text trong Excel.
- Status hoạt động: `ACTIVE`, `WARNING`, `OFFLINE`, `MAINTENANCE`.
- Ngừng dùng yêu cầu lý do, ghi `isActive=false`, `status=INACTIVE`, timestamp. Kích hoạt lại ghi `isActive=true`, `status=ACTIVE`.
- Không xóa thiết bị vì quyền lịch sử dựa trên thiết bị hiện tại.

## Sự cố, khắc phục, xác minh

```mermaid
stateDiagram-v2
  [*] --> OPEN
  OPEN --> OPEN: khắc phục chưa đạt
  OPEN --> RESOLVED: khắc phục đạt
  RESOLVED --> CLOSED: xác minh
```

- Tạo incident luôn ở `OPEN`, `resolution=""`, `resolvedAt=null`.
- Mỗi lần khắc phục OPEN tăng attempt và tạo history bất biến.
- Outcome `OPEN`: giữ sự cố mở. Outcome `RESOLVED`: ghi nội dung/người/thời gian hoàn thành và chờ xác minh.
- Chỉ incident RESOLVED được xác minh. Verification ID cố định bằng incident ID, attempt 1; transaction chuyển sang CLOSED.
- Không tự coi CLOSED nếu không có verification hợp lệ. Không nhầm lần thử gần nhất với lần khắc phục đạt cuối.
- Severity: `LOW`, `MEDIUM`, `HIGH`, `CRITICAL`.
- USER và AREA_ADMIN được khắc phục/xác minh incident trong area hiện tại mình được cấp. Trạng thái sự cố chưa tạo từ phiếu tuần kiểm phải cho phép kiểm tra ID chưa tồn tại để UI hiển thị hành động chuyển thành sự cố.

Từ bất thường tuần kiểm, người có quyền có thể ghi nhận bảo trì liên kết bằng `inspectionSource`, sau đó thực hiện lượt `EXTRA` kiểm tra lại tiêu chí nguồn. Lượt kiểm tra lại chỉ lưu tiêu chí nguồn; chỉ trạng thái `PASS` hoàn tất bất thường và phản ánh trạng thái hiện tại cho KPI lịch sử. Nếu chưa đạt, bất thường vẫn mở để tiếp tục bảo trì và kiểm tra lại. Kết quả ban đầu bất biến. Lựa chọn chuyển thành incident hiện tạm ẩn ở giao diện lịch sử tuần kiểm.

## Sự cố từ tuần kiểm

Criterion `WARNING` hoặc `FAIL` trong lịch sử tuần kiểm có thể mở form tạo incident. Hệ thống xác minh result/device/task/criterion, tạo ID xác định `inspection_{result}_{task}_{criterion}` để một bất thường không tạo lặp theo luồng này, và lưu các ID nguồn. Dữ liệu kết quả gốc không đổi. Phần trạng thái tổng hợp/KPI của lịch sử quy đổi bất thường sang `PASS` khi incident liên kết đã `CLOSED` với verification hợp lệ; chi tiết vẫn ghi rõ kết quả ban đầu và trạng thái xử lý/xác minh để bảo toàn lịch sử.

## Bảo trì

- ADMIN, AREA_ADMIN và USER được gửi record bảo trì cho thiết bị trong area được cấp; record mới có `status=PENDING_APPROVAL`.
- Chỉ ADMIN xác nhận kết quả bảo trì để chuyển sang `COMPLETED`; thời điểm và UID xác nhận được lưu tại `approvedAt`, `approvedByUid`. Các record legacy đã `COMPLETED` tiếp tục đọc được.
- Source không có workflow sửa/xóa bảo trì ở giao diện: **CẦN XÁC MINH** nếu nghiệp vụ yêu cầu.

## Tuần kiểm

- Template là mẫu quản trị theo xưởng, gồm task và criteria. ADMIN sửa mọi mẫu; AREA_ADMIN chỉ sửa mẫu có toàn bộ `areaIds` trong scope được giao. Tạo đặt `version=1`; mỗi lần sửa nội dung tăng version một đơn vị. Ngừng/khôi phục không tăng version nội dung. Sửa mẫu không tự đồng bộ vào plan thiết bị đã tạo.
- Plan là bản gán riêng cho thiết bị, ID bằng device ID; transaction chỉ tạo khi thiết bị active và chưa có plan. ADMIN sửa được plan ở mọi khu vực; AREA_ADMIN chỉ sửa plan của thiết bị thuộc `areaIds` được giao. USER không sửa plan. Lưu thay đổi tăng version nguyên tử; không tự đồng bộ thay đổi template vào plan đã tạo.
- Task hiện yêu cầu frequency `WEEKLY`, weekday 1..7 và ít nhất một criterion.
- Phiếu chỉ tạo khi device/plan active và version đầu vào khớp.
- Criterion bắt buộc không được `NOT_CHECKED`; NUMBER cần số hữu hạn; TEXT bắt buộc cần nội dung.
- Status tổng hợp ưu tiên `FAIL`, rồi `WARNING`, `NOT_CHECKED`, cuối cùng `PASS`.
- Phiếu lưu `planSnapshot`; mọi hiển thị/export lịch sử dùng snapshot. Sửa template/plan về sau không được dùng để viết lại snapshot của phiếu cũ. Phiếu mới phải dùng version mới của plan.
- Mẫu tuần kiểm dùng xóa mềm qua `isActive`: ngừng sử dụng làm mẫu không còn được chọn cho kế hoạch mới; khôi phục cho phép sử dụng lại. Kế hoạch và `planSnapshot` lịch sử đã tạo không bị sửa hoặc xóa.
- Chỉ ADMIN được xóa vĩnh viễn mẫu đã ngừng sử dụng và không còn `deviceInspectionPlans` tham chiếu. Thiết bị không có hard-delete trong ứng dụng.
- Tab chính Tuần kiểm suy ra trạng thái lịch theo múi giờ Việt Nam từ plan hiện hành và `inspectionResults`: `Quá hạn`, `Đến hạn hôm nay`, `Đã kiểm tra hôm nay`, `Không có lịch hôm nay`, `Chưa lập lịch` hoặc `Lịch đã ngừng`. Trạng thái lịch thể hiện task đã được thực hiện; kết quả hiện tại được tính riêng từ lượt mới nhất trong ngày và hiển thị `Đạt`, `Cảnh báo` hoặc `Không đạt`. Một task quá hạn khi lần gần nhất trước hôm nay theo `weekdays` chưa có kết quả kiểm tra chứa task đó trong khoảng từ ngày đến hạn đến hôm nay; không xét lịch trước ngày tạo plan. Phiếu `EXTRA` hoàn thành task cũng được tính để xóa cảnh báo quá hạn và có thể hoàn tất lịch đến hạn hôm nay; trạng thái này không viết lại lịch sử và không thay Security Rules.

## QR

- QR chứa `${window.location.origin}/q/{deviceCode}`.
- Scanner chỉ nhận cùng origin và path `/q/`; sau đó query thiết bị theo code và phạm vi area USER.
- QR dựa trên mã thiết bị cố định, không dựa ID tạm hoặc managementCode chưa triển khai.

## Xuất Excel

- Đúng 6 sheet: `DM_ThietBi`, `DM_SuCo`, `LS_KhacPhuc`, `LS_XacMinh`, `DM_TuanKiem`, `KQ_TuanKiem`.
- Tổng 63 cột gồm STT đầu mỗi sheet. STT theo nhóm mã thiết bị, chỉ hiện dòng đầu nhóm, không merge.
- Không xuất Document ID/UID/email kỹ thuật; thiếu dữ liệu hợp lệ để trống.
- Mỗi resolution, verification và criterion là một dòng; không gộp mất lịch sử.
- Formula-like text được bảo vệ; ngày giờ, text identifiers và giới hạn 1.048.576 dòng/sheet được kiểm soát.
- Export toàn bộ dữ liệu trong quyền, không dùng dòng/bộ lọc đang hiển thị.
- Các danh sách Thiết bị, Tuần kiểm, Sự cố và Bảo trì phân trang giao diện 25 dòng. Đây là client-side pagination: giảm số DOM render nhưng chưa giảm Firestore reads; KPI và Excel vẫn dùng toàn bộ dữ liệu trong quyền.


### Kiểm tra khắc phục tuần kiểm

Lượt EXTRA kiểm tra lại được liên kết rõ tới phiếu/công việc/tiêu chí bất thường ban đầu. KPI tính theo trạng thái mới nhất của tiêu chí trong cùng luồng; lượt đạt xóa trạng thái chưa xử lý. Nếu lượt kiểm tra lại vẫn WARNING/FAIL, bất thường tiếp tục chưa xử lý. Phiếu gốc bất biến và các lượt kiểm tra lại hiển thị bên trong luồng gốc.
