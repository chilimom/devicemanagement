# USER-MGMT-06 — Firebase-only Account Management

## Trạng thái

**STOPPED BEFORE IMPLEMENTATION — SECURITY/OPERABILITY REQUIREMENTS ARE NOT FULLY SATISFIABLE WITH THE APPROVED ARCHITECTURE.**

Không sửa frontend, Auth flow, Firestore Rules hoặc quy trình `invites`. Không deploy và không ghi production.

Firebase Client SDK có thể dùng một secondary `FirebaseApp`/`Auth` để tạo email/password account mà không thay phiên ADMIN trên default Auth instance. Tuy nhiên đây chỉ là signup client thông thường, không phải privileged account provisioning. Nó không giải quyết được quản trị Auth, reconcile account mồ côi hoặc việc AREA_ADMIN liệt kê user an toàn.

## 1. Kiến trúc thực tế

- Default Firebase app dùng `getAuth(app)` và `getFirestore(app)`.
- `App.tsx` dùng `onAuthStateChanged` và realtime `users/{uid}` profile làm authorization barrier.
- Thiếu profile/inactive/profile lỗi đều không mount route nghiệp vụ; hiện thiếu profile đi vào màn nhận invite.
- Role: `ADMIN`, `AREA_ADMIN`, `USER`; quyền dữ liệu dựa trên profile hiện tại và `areaIds`.
- Shared RAM Cache key gồm project, database, UID, role và normalized area signature; profile thay đổi làm clear scope.
- User Management hiện dựa trên `invites`. ADMIN list toàn `users`; AREA_ADMIN chỉ khám phá các user đã nhận invite do chính mình tạo rồi `get` từng UID.
- Firestore Rules Emulator tests vẫn chưa chạy vì thiếu Java; `docs/USER-MGMT-02.md` đang ghi **NOT READY FOR DEPLOY**.

Bằng chứng chính: `src/config/firebase.ts`, `src/App.tsx:55-179`, `src/services/userManagementService.ts`, `src/services/sharedRamCache.ts:81-174`, `firestore.rules:414-439`.

## 2. Secondary Auth instance: phần khả thi

Luồng kỹ thuật có thể viết:

1. Khởi tạo secondary Firebase app bằng cùng public Firebase web config và tên app riêng.
2. Lấy Auth của secondary app.
3. Gọi `createUserWithEmailAndPassword(secondaryAuth, email, password)`.
4. User mới chỉ trở thành current user của **secondary Auth**; default Auth vẫn giữ ADMIN/AREA_ADMIN.
5. Lấy `credential.user.uid`.
6. Dùng **default Firestore instance** đang mang token caller quản trị để tạo `users/{uid}`. Không dùng Firestore gắn secondary app để tự ghi profile.
7. Sign out secondary Auth và xóa secondary app khi hoàn tất.

Firebase xác nhận signup/sign-in làm user trở thành current user của Auth instance, và mặc định end user được phép signup. Vì vậy tách Auth instance bảo vệ phiên UI hiện tại nhưng không biến thao tác thành quyền ADMIN.

Nguồn chính thức:

- <https://firebase.google.com/docs/auth/users/>
- <https://firebase.google.com/docs/reference/js/auth>
- <https://firebase.google.com/docs/auth/web/password-auth>

## 3. Firestore profile có thể được bảo vệ như thế nào

Rules có thể phân biệt caller đang ghi profile vì request tới default Firestore mang `request.auth.uid` của ADMIN/AREA_ADMIN, không phải UID mới của secondary Auth.

Rule create tối thiểu cần có hai nhánh, không có nhánh self-create:

- ADMIN active: tạo target role USER hoặc AREA_ADMIN với valid profile/areaIds.
- AREA_ADMIN active: target UID khác caller, target role **chỉ USER**, target areaIds không rỗng và là tập con caller areaIds.
- USER, account chưa có profile và secondary user: deny.

Rules phải validate exact/allowed keys, email/displayName/role/isActive/areaIds, không tin client-side form. Tài khoản tự signup ngoài UI sẽ có Auth account nhưng không thể tạo profile và do đó không truy cập business data.

Điểm này có thể bảo vệ quyền Firestore, nhưng chưa đủ để hoàn thành toàn bộ USER-MGMT-06.

## 4. Các trở ngại bắt buộc

### 4.1 Client Auth signup không có authorization ADMIN

Firebase Client SDK không có API “ADMIN creates another user”. Khi Email/Password signup được bật, người biết web config có thể gọi signup ngoài UI. UI guard, secondary app và Firestore Rules không thể ngăn tạo Auth account rác; chúng chỉ ngăn account đó có profile/quyền nghiệp vụ.

Firebase Admin user-management API mới có create/list/update/disable/reconcile đặc quyền và được thiết kế cho secure server environment/service account. Kiến trúc USER-MGMT-06 cấm thành phần đó.

Nguồn: <https://firebase.google.com/docs/auth/admin/manage-users>.

### 4.2 Auth create và profile create không atomic

Auth và Firestore không có transaction chung:

- Auth create thành công, profile write thất bại → Auth account mồ côi.
- Client SDK không list Auth users, không lookup arbitrary user như Admin SDK và không có durable reconcile queue mặc định.
- Trong phiên ngay sau create có thể giữ UID để retry profile, nhưng reload/crash/mất mạng làm mất context nếu không bổ sung schema provisioning riêng.
- Email đã bị chiếm nên thao tác create lại trả duplicate; UI không thể khôi phục UID từ Auth bằng quyền quản trị.
- Theo yêu cầu, không được tự động xóa account Auth khi profile fail. Sau khi secondary session mất, cleanup/reconcile thực tế cần Firebase Console hoặc Admin SDK.

Vì vậy UI chỉ có thể báo `AUTH_CREATED_PROFILE_FAILED` cùng email/UID ngay lúc đó; không thể cung cấp workflow phục hồi đáng tin cậy hoàn toàn trong app hiện tại.

### 4.3 AREA_ADMIN không thể list toàn bộ user thuộc scope an toàn

Current schema lưu `users.areaIds[]`. Firestore Rules không phải bộ lọc và client query không biểu đạt điều kiện “mọi phần tử target.areaIds là tập con caller.areaIds”. Vì vậy:

- `allow list` toàn collection rồi filter frontend sẽ rò profile ngoài scope.
- `array-contains` một area không chứng minh target không có area ngoài scope.
- Current implementation chủ động chỉ cho ADMIN list `users`; AREA_ADMIN dựa vào invite do chính mình tạo để khám phá accepted UID.
- USER-MGMT-06 cấm dùng `invites`, nên AREA_ADMIN không còn discovery index hiện hành.

Có thể thiết kế một management-assignment/index collection mới được duy trì atomically với profile, nhưng đây là schema/workflow mới chưa được phê duyệt và vẫn không giải quyết Auth orphan/reconcile. Không được âm thầm thêm collection chỉ để làm UI có vẻ hoạt động.

### 4.4 Client SDK không khóa/mở Firebase Auth account

Client có thể cập nhật `users/{uid}.isActive` nếu Rules cho phép và Rules sẽ chặn business data. Client không thể disable arbitrary Firebase Auth user hoặc revoke refresh tokens; các chức năng này thuộc Admin SDK/Console. Do đó “khóa” Firebase-only chỉ là khóa quyền ứng dụng, Auth account vẫn tồn tại và có thể authenticate.

### 4.5 Thiết lập mật khẩu lần đầu

`createUserWithEmailAndPassword` bắt buộc nhận password và đăng nhập secondary user. Phương án ít rủi ro nhất trong giới hạn client là:

- Sinh password ngẫu nhiên mạnh, duy nhất bằng Web Crypto, chỉ giữ trong memory và không hiển thị/log/email.
- Sau create, gửi password-reset email qua Firebase và/hoặc verification email.
- Sign out secondary Auth.
- Người nhận dùng email action để đặt password riêng.

Nhưng đây vẫn là signup client, chịu signup quota/abuse, và không tạo account disabled. Password reset không thay thế profile authorization. Không dùng password mặc định chung hoặc plaintext email.

## 5. Phát hiện bảo mật hiện hữu cần xử lý trước mọi deploy

`firestore.rules:143-149` hiện định nghĩa `targetWithinAreaAdminScope` với:

```text
data.role in ["ADMIN", "AREA_ADMIN", "USER"]
```

Điều này mâu thuẫn với chính sách. Với ADMIN có `areaIds=[]`, phép `hasOnly(caller.areaIds)` có thể đúng; `firestore.rules:414-422` có thể cho AREA_ADMIN đọc hoặc cập nhật ADMIN nếu before/after vượt qua helper. AREA_ADMIN thậm chí có thể gửi after role USER/AREA_ADMIN trong scope và demote target ADMIN nếu các điều kiện khác khớp.

Helper đúng cho chính sách USER-MGMT-06 phải chỉ coi target `USER` là manageable bởi AREA_ADMIN, cả trước và sau update. Đây là lỗi nghiêm trọng cần sửa và chứng minh bằng Emulator trước deploy. Không sửa trong USER-MGMT-06 vì task phải dừng trước implementation khi security chưa được xác nhận, và Rules Emulator hiện chưa chạy được.

## 6. Luồng đề xuất nếu các blocker được chấp nhận/giải quyết

### ADMIN

1. Validate form và xác nhận caller profile realtime vẫn là ADMIN.
2. Secondary Auth tạo USER/AREA_ADMIN bằng random one-time password.
3. Default Firestore ADMIN tạo exact profile theo Rules.
4. Chỉ báo thành công khi profile write thành công.
5. Gửi reset/verification email, sign out secondary.
6. Nếu profile fail: báo rõ Auth đã tạo nhưng chưa có quyền, hiển thị UID/email để vận hành xử lý; không báo success và không tự delete.

### AREA_ADMIN

Tương tự nhưng Rules chỉ cho target role USER và areaIds subset. Secondary Auth không quyết định quyền; default Firestore Rules là authority.

### Tự signup ngoài UI

Auth account có thể được tạo nhưng không có profile. `App.tsx` phải thay màn `InviteActivation` bằng thông báo “tài khoản chưa được cấp quyền”, không cung cấp self-claim. Mọi business collection vẫn deny.

## 7. Quy tắc bảo mật bắt buộc nếu triển khai sau này

- Không cho self-create `users/{uid}`.
- AREA_ADMIN create/update chỉ USER, target khác chính mình, before/after areaIds subset.
- AREA_ADMIN không get/list/update ADMIN hoặc AREA_ADMIN.
- ADMIN tạo USER/AREA_ADMIN; không làm mất ADMIN tổng hiện hữu.
- `isActive=false` chặn toàn business data và cache scope.
- Profile write luôn dùng default Firestore authenticated as manager.
- Secondary Auth không được dùng làm authorization source.
- Không lưu temp password trong state lâu dài, storage, log hoặc Firestore.
- Không coi reset email thành bằng chứng RBAC.
- Không xóa Rules/data `invites` cũ khi chưa có migration plan; chỉ ngừng dùng UI sau cutover được duyệt.

## 8. File đã sửa

- Tạo `docs/USER-MGMT-06.md`.

Không sửa source, `firestore.rules`, Auth configuration, dependencies hoặc tests. Không xóa `invites` cũ.

## 9. Kết quả kiểm thử

Không chạy build/regression vì chỉ thêm tài liệu và chủ động dừng trước code/Rules changes.

Security validation hiện tại:

- Firestore Rules suite đã chuẩn bị 16 integration tests nhưng chưa chạy được do thiếu Java/Firestore Emulator.
- Trạng thái kế thừa từ USER-MGMT-03: **NOT READY FOR DEPLOY**.
- Phát hiện helper target scope nêu tại mục 5 chưa có kết quả Emulator.

## 10. Giới hạn Firebase Spark/Firebase-only

- Có thể giữ phiên ADMIN bằng secondary Auth instance.
- Có thể dùng Rules bảo vệ profile và business data.
- Không thể giới hạn client Auth signup chỉ cho ADMIN.
- Không thể list/update/disable arbitrary Auth users bằng Client SDK.
- Không thể revoke refresh tokens.
- Không có atomicity Auth–Firestore hoặc privileged reconcile.
- Không thể đáp ứng AREA_ADMIN user discovery an toàn với schema `users.areaIds[]` hiện tại khi bỏ `invites`.
- App lock bằng `isActive` không đồng nghĩa Firebase Auth disabled.

## 11. Hướng dẫn test localhost nếu thiết kế được phê duyệt lại

Chỉ thực hiện sau khi có Java 21/Emulator và sửa Rules:

1. Chạy `npm run rules:test`; yêu cầu toàn bộ test thật PASS, không SKIP.
2. Dùng Firebase Auth Emulator hoặc project test riêng; tuyệt đối không production.
3. Đăng nhập default Auth bằng ADMIN, tạo user qua secondary Auth và xác nhận default UID/session không đổi.
4. Xác nhận secondary Auth được sign out/xóa sau mọi success/failure.
5. Giả lập profile write permission-denied/network fail; UI phải báo incomplete, không báo success.
6. Tự gọi Client Auth signup ngoài UI; account không profile phải bị deny mọi business data.
7. AREA_ADMIN thử tạo AREA_ADMIN/ADMIN, area ngoài scope, sửa ADMIN/AREA_ADMIN/self; tất cả deny.
8. Đổi role/areaIds/isActive realtime; app unmount scope cũ và cache clear.
9. Refresh sau Auth-created/profile-failed để xác nhận quy trình vận hành orphan đã được phê duyệt.

## 12. Điều kiện để tiếp tục

Ít nhất một trong các hướng sau cần được phê duyệt:

1. Giữ `invites` cho discovery/claim và không dùng direct client provisioning; hoặc
2. Phê duyệt schema management/provisioning index mới cùng quy trình Console reconcile orphan; chấp nhận client signup không thể giới hạn; hoặc
3. Cho phép privileged backend/Admin SDK như thiết kế USER-MGMT-05.

Trước mọi hướng, phải sửa lỗi Rules ở mục 5 và chạy Firestore Emulator suite PASS. Với các quyết định bắt buộc hiện tại (không backend, không invites, direct create, AREA_ADMIN quản lý user), chưa thể bàn giao một chức năng đầy đủ và an toàn.
