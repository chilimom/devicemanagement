# PERF-04B.0 — Thiết kế shared memory cache

Ngày thiết kế: 06/11/2026. Mục tiêu ưu tiên: tăng tốc luồng `Devices → DeviceDetail → Devices`. Phạm vi chỉ thiết kế; không sửa source, Firebase Auth, Firestore Rules, indexes, database, schema hoặc KPI; không thêm dependency và không deploy.

## 1. Kết luận và quyết định đề xuất

Đề xuất thử nghiệm **phương án A: shared memory cache theo scope bảo mật, TTL và stale-while-revalidate**, triển khai đầu tiên chỉ cho bốn dataset của Devices: `devices`, `areas`, `deviceCategories`, `deviceTypes`. Cache chỉ sống trong RAM của SPA, không dùng IndexedDB/localStorage/sessionStorage và không thay cache nội bộ của Firestore.

Điều kiện bắt buộc:

- Chỉ tạo/đọc cache sau khi Firebase Auth và profile `users/{uid}` đã được xác nhận active.
- Scope cache gồm project/database, UID, role và chữ ký `areaIds` đã chuẩn hóa. Khi scope đổi phải hủy hiệu lực đồng bộ trước khi render route nghiệp vụ.
- Cache không quyết định quyền. Mọi server request vẫn qua Security Rules; UI vẫn kiểm tra `isAdmin`/`canAccessArea`; write nhạy cảm vẫn dùng document read/transaction hiện hành.
- Kết quả request của scope/generation cũ không được ghi vào cache hoặc React state, dù request đó hoàn tất sau khi logout/đổi quyền.
- `permission-denied` phải evict dataset liên quan và hiển thị lỗi; không fallback sang stale data.

Phương án B — chỉ giữ state Devices trong provider gần route — phù hợp làm đối chứng nhỏ, nhưng không được chọn làm kiến trúc đích vì khó chia sẻ với Dashboard/Inspection và dễ tạo nhiều nguồn dữ liệu không đồng bộ.

## 2. Hiện trạng và dữ liệu đọc lại

### Luồng ưu tiên

`Devices` giữ bốn mảng trong state cục bộ và gọi lại Firestore khi component mount (`src/pages/Devices.tsx:161-176, 215-316`). Khi chọn thiết bị, route đổi sang `/devices/:id` (`src/pages/Devices.tsx:870-874`), làm state của Devices mất. `DeviceDetail` đọc lại device bằng ID, sau đó area/type/category (`src/pages/DeviceDetail.tsx:201-340`). Khi quay lại `/devices` (`src/pages/DeviceDetail.tsx:699, 726`), Devices mount lại và chạy lại bốn query.

Dashboard cũng đọc lại `devices`, `areas`, `deviceCategories`, `deviceTypes` và thêm incidents/maintenances (`src/pages/Dashboard.tsx:249-377`). Inspection Hub và Areas tiếp tục dùng devices/areas. Đây là phần trùng lặp phù hợp nhất để cache RAM.

### Phân loại dataset

| Dataset | Nơi dùng lại chính | Cache RAM? | Chính sách đề xuất | Lý do/giới hạn |
| --- | --- | --- | --- | --- |
| `devices` theo scope | Devices, Dashboard, Areas, Incidents, Maintenances, InspectionHub, DeviceDetail | Có, ưu tiên pha 1 | Fresh 30 giây; stale đến 2 phút; expired sau 2 phút | Thay đổi nghiệp vụ thường xuyên và chứa `areaId`; phải invalidate chặt khi device CRUD/lifecycle/scope đổi. |
| `areas` theo scope | Devices, Dashboard, Areas, InspectionHub, DeviceDetail | Có | Fresh 5 phút; stale đến 15 phút | Tương đối ổn định nhưng trực tiếp liên quan `areaIds`; scope change xóa ngay. |
| `deviceCategories` | Devices, Dashboard, Add/Edit Device, DeviceTypes | Có | Fresh 10 phút; stale đến 30 phút | Danh mục read-only trong UI hiện tại; vẫn scope theo user để tránh cross-account. |
| `deviceTypes` | Devices, Dashboard, Add/Edit Device, DeviceTypes, DeviceDetail | Có | Fresh 5 phút; stale đến 15 phút | Có CRUD ADMIN; invalidate ngay sau write thành công. |
| Device detail cơ bản | DeviceDetail, Devices list | Có thể lấy từ cache `devices`, không tạo bản sao độc lập ở pha 1 | Seed tức thời rồi revalidate theo freshness | Tránh hai cache entry cho cùng device. Nếu device không thuộc cached list thì đọc server. |
| Incidents/maintenances | Dashboard, list riêng, DeviceDetail history | Chưa ở pha 1; ứng viên pha sau | TTL ngắn 30–60 giây nếu được duyệt | Fan-out theo device và workflow write phức tạp; cần invalidation theo device/dashboard. |
| Inspection templates/plans/results | Inspection pages | Chưa ở pha 1 | Chỉ thiết kế sau khi Devices ổn định | Plan/result ảnh hưởng thực thi; lịch sử dùng `planSnapshot`; freshness và invalidation riêng. |
| `users/{uid}` profile | App/RBAC | Không cache nghiệp vụ | Giữ listener realtime hiện tại | Đây là nguồn quyền và cache scope, không phải consumer của cache. |
| User list ADMIN | UserManagement | Không ở pha 1 | Nếu cần, cache riêng TTL ngắn | Dữ liệu quyền nhạy cảm. |
| Excel export dataset | Export | Không | Luôn dùng reader hiện tại | Export cần snapshot đầy đủ trong scope, không lấy từ UI cache (`src/services/excelExportDataService.ts`). |
| Duplicate/validation reads | Area/device/type validation | Không dùng để quyết định | Đọc mới/transaction | Cache không bảo đảm uniqueness hoặc precondition. |

### Dữ liệu bắt buộc đọc mới hoặc transaction

- Profile active, role và `areaIds`: listener `users/{uid}` trong `src/App.tsx:58-125`.
- Document và profile được transaction đọc trong create/edit device, incident resolution/verification và plan creation.
- Device/area/type hiện hành trước write; duplicate check; quyền area hiện tại của device.
- Dữ liệu export; dữ liệu dùng để quyết định có cho phép workflow/write.
- Sau `permission-denied`, không dùng cache cũ làm fallback.

## 3. Kiến trúc cache đề xuất

```mermaid
flowchart TD
  Auth[onAuthStateChanged] --> Profile[Realtime users/uid]
  Profile -->|active + parsed| Scope[Build CacheScope]
  Profile -->|logout/inactive/error/scope change| Barrier[Advance generation + clear cache]
  Scope --> Provider[SessionDataCacheProvider]
  Provider --> Store[(RAM Map only)]
  Devices[Devices] --> Hook[useScopedDataset]
  Detail[DeviceDetail] --> Hook
  Dashboard[Dashboard - phase later] --> Hook
  Hook --> Guard{Profile confirmed and scope matches?}
  Guard -->|no| Block[Render no business data]
  Guard -->|yes| Store
  Store -->|fresh| Render[Render immediately]
  Store -->|stale| Render
  Store -->|stale| Refresh[Background Firestore read]
  Store -->|expired/miss| Loading[Block dataset + Firestore read]
  Refresh --> Commit{request generation == active generation?}
  Loading --> Commit
  Commit -->|yes| Store
  Commit -->|no| Drop[Discard result]
  Store --> Filter[Defensive area filter for USER]
  Filter --> UI[UI only; Rules remain authoritative]
  CRUD[Successful CRUD] --> Invalidate[Patch/evict affected datasets]
  Invalidate --> Store
```

### Thành phần logic

Không cần dependency mới. Có thể triển khai sau phê duyệt bằng React Context + hook và module TypeScript thuần:

- `SessionDataCacheProvider`: nằm bên trong nhánh đã có `user` + `appUser`, bên ngoài các route nghiệp vụ; nhận một `CacheScope` đã xác nhận.
- Store RAM: `Map<scopeKey, Map<datasetKey, CacheEntry>>`. Để giảm rủi ro, chỉ giữ active scope; scope cũ được xóa, không giữ LRU nhiều tài khoản.
- `useScopedDataset(datasetKey, loader, policy)`: trả dữ liệu + trạng thái + `refresh()`; dedupe request cùng key.
- API mutation nội bộ: `invalidate`, `invalidateMany`, `patchDevice`, `clearActiveScope`, `advanceGeneration`.
- Không export raw store để page tùy ý bỏ qua scope guard.

Tên file/module cụ thể chỉ là đề xuất và chưa được phê duyệt; không phải thay đổi source trong bước này.

## 4. Cache key và vòng đời

### Chuẩn hóa scope

```text
normalizedAreaIds = unique(areaIds.map(trim).filter(nonEmpty)).sort()
areaSignature     = normalizedAreaIds.join("\u001f")
scopeKey          = projectId + "|" + databaseId + "|" + uid + "|" + role + "|" + areaSignature
```

- Không cần hash mật mã; chữ ký chỉ là key RAM, không phải token. Không log toàn bộ key nếu UID/area được coi là dữ liệu vận hành nhạy cảm.
- Với ADMIN vẫn đưa role và `areaSignature` vào key. Thay đổi profile luôn tạo scope mới, dù query ADMIN hiện đọc rộng.
- `databaseId` dùng `(default)` nếu ứng dụng không chỉ định database khác.
- Dataset key ví dụ: `devices:list`, `areas:list`, `deviceCategories:list`, `deviceTypes:list`. Scope nằm ngoài dataset key để không thể vô tình dùng chung cross-user.

### Cache entry

```text
CacheEntry<T> = {
  data?: T
  state: empty | loading | fresh | refreshing | stale | expired | error
  fetchedAt?: number
  staleAt?: number
  expiresAt?: number
  generation: number
  requestId?: number
  error?: classified error
}
```

Quy tắc trạng thái:

| Trạng thái | Có hiển thị data? | Hành động |
| --- | --- | --- |
| `empty` | Không | Bắt đầu foreground load. |
| `loading` | Không | Dedupe request; hiển thị loading hiện hành. |
| `fresh` | Có | Không query lại khi mount trong fresh TTL, trừ manual refresh/invalidation. |
| `refreshing` | Có | Giữ UI ổn định, hiển thị chỉ báo refresh không chặn; một request nền duy nhất. |
| `stale` | Có, chỉ khi scope vẫn khớp và không có lỗi quyền | Chuyển ngay sang `refreshing`. |
| `expired` | Không dùng làm dữ liệu nghiệp vụ | Foreground reload. Có thể giữ object nội bộ để debug nhưng không render. |
| `error` | Chỉ giữ data cũ với lỗi mạng tạm thời khi chưa expired; tuyệt đối không với `permission-denied` | Cho retry; permission error evict data. |

TTL là điểm khởi đầu để thử nghiệm, không phải KPI cố định. Phải đo trước/sau và có thể điều chỉnh bằng hằng số nội bộ, không remote config trong pha đầu.

### Vòng đời route ưu tiên

1. Devices mount, cache miss → tải bốn dataset và lưu theo active scope.
2. Chọn DeviceDetail → lấy device từ `devices:list` nếu key/scope khớp; kiểm tra `canAccessArea` trước khi render. Nếu entry fresh, có thể dùng ngay và revalidate detail theo chính sách; nếu stale thì render seed + background `getDoc`; nếu expired/miss thì không render cache và đọc server.
3. Quay lại Devices → bốn entry fresh được render trong cùng tick/provider; giữ filter trong URL hiện có. Nếu devices stale, danh sách hiện ngay và refresh nền.
4. Refresh browser → provider/store mất hoàn toàn; flow hiện tại xác nhận Auth/profile rồi tải lại Firestore.

## 5. Bảo vệ RBAC và xử lý race

### Security barrier

`App` hiện xóa `user`/`appUser` khi auth đổi và chỉ render route sau khi profile hợp lệ (`src/App.tsx:58-163`). Provider phải đặt sau barrier này. Trình tự khi logout/đổi account/profile:

1. Đánh dấu active scope unavailable và tăng `generation` đồng bộ.
2. Xóa Map, subscriber data và error của scope cũ.
3. Không render route nghiệp vụ trong thời gian profile chưa xác nhận.
4. Chỉ tạo scope mới sau `parseAppUser` thành công và `isActive === true`.
5. Mọi promise resolve kiểm tra cả `generation`, `requestId` và exact `scopeKey`; sai bất kỳ điều kiện nào thì drop, không set React state.

Firestore `getDoc/getDocs` không có cơ chế abort chuẩn đang được source dùng. Vì vậy “hủy request” trong thiết kế nghĩa là hủy quyền commit kết quả; network request có thể vẫn hoàn tất.

### Quy tắc USER

- Loader USER tiếp tục query theo `areaIds`, không list toàn collection rồi lọc client.
- Trước render cached device, áp dụng `canAccessArea(appUser, device.areaId)` như defense-in-depth. Đây không thay Security Rules.
- Nếu device chuyển area và USER có thể mất quyền, evict toàn `devices:list` ngay khi biết mutation/scope change; không optimistic-patch sang dữ liệu ngoài scope.
- Cache không được trả dữ liệu khi profile listener lỗi, inactive hoặc chưa có profile.

### Error policy

| Lỗi | Cache action | UI action |
| --- | --- | --- |
| `permission-denied` | Evict dataset; nếu liên quan scope/profile thì clear toàn cache | Hiển thị lỗi quyền; không stale fallback. |
| `unauthenticated` | Advance generation + clear toàn cache | Trở về auth flow. |
| Mất mạng/timeout tương đương | Giữ fresh/stale data cùng scope tới `expiresAt`; không kéo dài TTL tự động | Báo offline/refresh failed; retry thủ công hoặc khi online. |
| Query/index lỗi | Không ghi cache; giữ data cũ chỉ nếu còn trong stale window và không phải lỗi quyền | Hiển thị lỗi kỹ thuật, log mã lỗi an toàn. |
| Parse/data shape lỗi | Evict entry | Không render record lỗi; báo lỗi. |

## 6. Ma trận invalidation

| Sự kiện/write thực tế | Bằng chứng source | Cache action tối thiểu sau server success | Ghi chú RBAC |
| --- | --- | --- | --- |
| Logout | `src/components/AppLayout.tsx:73-81` | Advance generation; clear toàn cache trước/đồng thời auth transition | Không chờ route unmount mới clear. |
| Đổi UID | `src/App.tsx:58-78` | Clear toàn cache; drop in-flight scope cũ | Không giữ cache nhiều account. |
| Role/`areaIds`/active đổi | Profile `onSnapshot`, `src/App.tsx:78-118` | Clear toàn cache và tạo scope mới sau xác nhận | Kể cả ADMIN→ADMIN với area signature đổi. |
| Tạo device | `src/pages/AddDevice.tsx:387-450` | Invalidate `devices:list`; có thể insert server-confirmed device vào ADMIN/current USER scope nếu area hợp lệ, nhưng pha đầu nên evict + refresh | Document ID là normalized code; không đổi schema. |
| Sửa device/chuyển area/type | `src/pages/DeviceEdit.tsx:354-449` | Evict `devices:list` và cached detail seed; refresh devices/areas-dependent views | USER mất quyền do chuyển area: không optimistic render. |
| Deactivate/reactivate | `src/pages/DeviceDetail.tsx:523-666` | Patch đúng device sau `updateDoc` success, đồng thời mark `devices:list` stale; invalidate Dashboard-derived data | Không patch trước server success. |
| Xóa device | Không có write path; Rules/tài liệu hiện không cho delete | Không có event hiện tại. Nếu nghiệp vụ bổ sung sau này: remove device + invalidate all device-derived datasets | Test bắt buộc hiện phải xác nhận “không có chức năng xóa”, không giả lập workflow không tồn tại. |
| Tạo/sửa area | `AreaCreate.tsx:53-72`; `AreaEdit.tsx:162-194` | Invalidate `areas:list`; nếu area status/quan hệ ảnh hưởng view thì mark devices stale | USER scope vẫn do profile `areaIds`; Rules quyết định. |
| Tạo/sửa/toggle device type | `AddDevice.tsx:294`; `DeviceTypes.tsx:213-230, 280` | Invalidate `deviceTypes:list`; mark `devices:list` stale vì label/filter phụ thuộc type | ADMIN-only write. |
| Tạo incident | `IncidentCreate.tsx:355-421` | Khi cache history được triển khai: invalidate incidents của device + Dashboard; devices list không cần evict nếu không có derived incident KPI | Workflow có transaction/inspection source. |
| Resolve/verify incident | `incidentResolutionService.ts:66-153`; `incidentVerificationService.ts:49-130` | Invalidate incident/detail history + Dashboard | Không optimistic workflow state trước transaction success. |
| Tạo maintenance | `MaintenanceCreate.tsx:73` | Invalidate maintenance history + Dashboard | Device cache chỉ stale nếu list có derived maintenance state trong tương lai. |
| Tạo/update template | `inspectionService.ts:58-105` | Invalidate templates | ADMIN-only; chưa cache pha 1. |
| Tạo inspection plan | `deviceInspectionPlanService.ts:153-195` | Invalidate plan của device | Không viết lại `planSnapshot` lịch sử. |
| Tạo inspection result | `inspectionResultService.ts:165-231` | Invalidate result history của device + Dashboard nếu có derived KPI | Không cache precondition. |
| Manual refresh | UI mới nếu được phê duyệt | Mark chosen entries stale và force refresh, vẫn dedupe | Không thay scope. |

## 7. So sánh phương án A/B

### A. Shared memory cache + TTL + background refresh

Provider/store giữ dữ liệu chuẩn hóa theo dataset và scope. Devices/Detail cùng đọc cache; về sau Dashboard có thể dùng lại.

### B. Giữ state Devices ở provider phù hợp

Đưa state và loader hiện tại của Devices lên một `DevicesStateProvider` đặt quanh route `/devices*`, giữ list khi chuyển sang detail. Provider có thể lưu cả UI filter hoặc chỉ data. Nếu provider bị unmount khi rời route subtree, lợi ích mất; nếu đặt ở AppLayout, thực tế nó tiến gần phương án A nhưng chỉ chuyên biệt Devices.

| Tiêu chí | A — shared TTL/SWR | B — lifted Devices state |
| --- | --- | --- |
| Độ phức tạp ban đầu | Trung bình: scope, state machine, generation, invalidation | Thấp–trung bình nếu chỉ giữ list; tăng nhanh khi thêm TTL/RBAC/invalidation |
| Quay lại Devices | Tức thời khi fresh/stale hợp lệ | Tức thời miễn provider còn mounted |
| Query Firestore | Có thể bỏ query trong fresh TTL; một background refresh khi stale; dedupe consumer | Bỏ query khi state còn sống; thường thiếu freshness contract hoặc vẫn query lại |
| Tính mới | Rõ bằng `fresh/stale/expired`; refresh nền/manual | Dễ trở thành state vô thời hạn hoặc cần tự xây TTL, lúc đó trùng A |
| Chia sẻ Dashboard/Inspection | Có, theo từng dataset | Kém; dễ tạo provider lồng/nhiều bản sao |
| RBAC | Thiết kế scope/generation tập trung | Có thể an toàn nếu provider nhận scope, nhưng dễ sót reset khi profile đổi |
| CRUD invalidation | API tập trung, test được | Mutation phải biết và sửa state provider; khó mở rộng cross-feature |
| Rollback | Feature flag/module consumer fallback về loader cũ | Đưa state xuống Devices lại tương đối dễ nhưng có thể chạm routing/provider tree |
| Rủi ro | Cache state machine sai, stale data, race scope | State sống quá lâu, nhiều nguồn truth, provider placement sai |

Khuyến nghị: dùng B làm baseline/prototype đo UX nếu cần patch cực nhỏ, nhưng triển khai chính thức theo A từng dataset. Không chạy đồng thời hai nguồn cache trong production; A/B là hai build/flag thử nghiệm độc lập.

## 8. Kế hoạch triển khai theo bước nhỏ

Mọi bước dưới đây cần phê duyệt riêng trước khi sửa code.

1. **Đo baseline:** instrument development-only hoặc DevTools thủ công cho số query và thời gian Devices → Detail → Devices; không log dữ liệu/UID/token.
2. **Cache core thuần:** scope normalization, cache state machine, generation/request commit guard; unit test không cần Firebase.
3. **Provider auth barrier:** đặt provider sau profile active; test logout/account/role/area transitions bằng loader giả.
4. **Devices dictionaries:** cache `areas`, categories, types trước vì invalidation đơn giản; fallback loader cũ qua feature flag nội bộ.
5. **Devices list:** thêm TTL/SWR và permission error policy; giữ query ADMIN/USER y nguyên.
6. **DeviceDetail seed:** tìm device từ same-scope list, defense filter, sau đó revalidate; không cache history ở bước này.
7. **CRUD invalidation:** nối create/edit/lifecycle/type/area success paths; không thay transaction/schema.
8. **So sánh B:** build thử provider state chuyên Devices nếu cần số liệu A/B; không merge hai kiến trúc cùng lúc.
9. **Mở rộng có điều kiện:** chỉ sau nghiệm thu Devices mới cân nhắc Dashboard/Inspection; incidents/maintenances là work item riêng.
10. **Xóa flag/fallback:** chỉ sau khi metrics, RBAC tests và rollback drill đạt.

Patch nên tách commit/change-set theo bước, không refactor ngoài phạm vi. Vì thay đổi code, khi triển khai phải chạy `npm run excel`, `npx tsc --noEmit`, `npm run lint`, `npm run build`; Rules không đổi nhưng query shape phải giữ nguyên ở pha đầu. Nếu sau này đổi query gom `deviceId`, phải chạy Rules Emulator suite.

## 9. Kế hoạch kiểm thử bắt buộc

| Ca | Thiết lập/hành động | Kết quả bắt buộc |
| --- | --- | --- |
| ADMIN → logout → USER | ADMIN tải devices, logout khi có/không có request nền, USER đăng nhập | Cache clear trước render; không một row/label/count ADMIN xuất hiện; promise ADMIN bị drop. |
| Hai USER area khác nhau | USER A tải area A; đổi sang USER B area B | Scope key khác; không reuse data; query B đúng `areaIds`; DevTools không thấy UI A. |
| Role/`areaIds` đổi realtime | Profile listener đổi khi đang ở Devices/Detail và có refresh chạy | Generation tăng, route data bị block/clear, request cũ drop, query lại đúng scope mới. Nếu mất quyền detail, không render cached device. |
| Tạo device | ADMIN create thành công rồi về Devices | Không hiện list cũ như fresh; device mới xuất hiện sau invalidate/refresh; write fail không patch cache. |
| Sửa/chuyển area | Sửa device, kể cả USER mất quyền sau chuyển area | Cache list/detail invalid; USER ngoài area không thấy device. ADMIN thấy dữ liệu mới. |
| Xóa device | Đối chiếu source/Rules hiện hành | Ghi nhận không có delete workflow; không tạo test giả. Nếu delete được bổ sung sau phê duyệt, thêm test removal/invalidation trước release. |
| Lifecycle | Deactivate/reactivate từ Detail | Sau server success, Detail và list thống nhất; Dashboard được stale/invalidate theo thiết kế. |
| Devices → Detail → Devices | Lần đầu và lần quay lại trong fresh/stale/expired window | Fresh: 0 query list mới; stale: render ngay + đúng 1 refresh; expired: không render expired data và foreground load. |
| Điều hướng nhanh | Chuyển route/scope trước khi request hoàn tất | Không set state sau unmount; không commit requestId/generation cũ; không duplicate request cùng key. |
| 4G chậm | Throttle network | Cached fresh/stale same-scope render nhanh; chỉ báo refresh không khóa UI; dedupe giữ đúng. |
| Mất kết nối | Offline khi fresh, stale và expired | Fresh/stale hiển thị tới expiry với trạng thái offline; expired không giả là fresh; retry khi online. |
| `permission-denied` | Loader trả lỗi quyền | Evict affected entry, không stale fallback, hiển thị lỗi và giữ route guard. |
| Refresh browser | Refresh từ Devices/Detail | RAM cache mất; Auth/profile xác nhận trước; Firestore load lại; không có persistence nghiệp vụ. |
| Multi-tab | Hai tab cùng account và khác account | Cache không chia sẻ giữa tab; mỗi tab tự scope; logout cross-tab do Auth không được giả định thay cho cache test. |

Kiểm thử cần bao phủ cả exact cache state transitions và UI integration. Không dùng production writes để test.

## 10. Tiêu chí nghiệm thu

### Chức năng và RBAC

- 100% ca bắt buộc ở mục 9 PASS cho ADMIN, USER một area, USER nhiều area và USER không area.
- Không render business data trước khi profile active được xác nhận.
- Không có cache hit cross-UID/cross-role/cross-area signature; request scope cũ không commit.
- Query Firestore và Security Rules behavior không đổi ở pha Devices; cache không list rộng rồi lọc client.
- CRUD thành công invalidates đúng; CRUD thất bại không làm cache báo dữ liệu đã lưu.

### Hiệu năng đề xuất để phê duyệt KPI sau đo baseline

- Quay lại Devices trong fresh TTL: dữ liệu list render từ RAM, không phát lại bốn read group của Devices.
- Stale window: tối đa một refresh in-flight cho mỗi dataset/scope dù nhiều consumer mount.
- Không tăng số query lần tải đầu so với baseline.
- Thu thập median/p95 thời gian route revisit và số request/document reads trên profile dữ liệu đại diện. Ngưỡng số ms cụ thể **CẦN XÁC MINH sau baseline**, không tự đặt KPI trong tài liệu này.

### Chất lượng

- Unit test scope normalization, state transitions, TTL boundary, dedupe, invalidation và generation race.
- Integration test navigation/CRUD/error; bốn quality gates của repository PASS.
- Không có IndexedDB/localStorage/sessionStorage cho business cache; refresh browser chứng minh cache mất.

## 11. Rollback

Thiết kế rollback theo consumer, không migration dữ liệu:

1. Feature flag build-time mặc định `false` trong giai đoạn thử; khi off, Devices/Detail dùng loader hiện tại.
2. Cache chỉ RAM nên rollback không cần xóa browser storage, database hay migration.
3. Mỗi phase có fallback về direct `getDoc/getDocs`; không xóa loader cũ trước nghiệm thu cuối.
4. Nếu phát hiện RBAC leak, ưu tiên kill switch cache, clear active store và redeploy bản direct-read đã kiểm chứng; không sửa Rules để che lỗi client.
5. Rollback phải smoke test ADMIN/USER, route deep-link, CRUD và export. Deploy/rollback chỉ thực hiện sau phê duyệt riêng.

## 12. Rủi ro và mục cần xác minh

| Rủi ro/CẦN XÁC MINH | Kiểm soát đề xuất |
| --- | --- |
| Device list lớn làm RAM tăng | Đo số document/kích thước thực tế; chỉ active scope; không cache nhiều account; cân nhắc cap sau số liệu. |
| TTL quá dài gây stale UX | TTL ngắn cho devices, manual refresh, invalidation sau write, đo production-like preview. |
| Mutation từ client/tab khác | Background refresh theo stale window; không hứa realtime. Nếu yêu cầu realtime xuất hiện, đánh giá listener riêng. |
| Auth persistence mặc định và multi-tab | Cache vẫn per-tab RAM; profile listener là barrier; test auth event thực tế sau triển khai. |
| `DeviceDetail` seed khác server | Gắn trạng thái refreshing; server result thay thế; permission error xóa ngay. |
| Query fan-out history | Ngoài pha Devices; không trộn với cache rollout. Query batching cần PERF riêng + Rules Emulator/index review. |
| Firebase Console/Rules deployed drift | Không suy đoán; kiểm tra read-only và Emulator theo phê duyệt trước UAT. |

## 13. Trạng thái bàn giao

- Sơ đồ kiến trúc cache: **HOÀN TẤT**.
- Danh sách dữ liệu cache/server-fresh: **HOÀN TẤT**.
- Cache key, state và vòng đời: **HOÀN TẤT**.
- Ma trận invalidation: **HOÀN TẤT**.
- Phương án bảo vệ RBAC/race: **HOÀN TẤT**.
- So sánh A/B: **HOÀN TẤT**.
- Kế hoạch triển khai, kiểm thử, nghiệm thu và rollback: **HOÀN TẤT**.
- Thay đổi source/config/Firebase/dependency/deploy: **KHÔNG THỰC HIỆN**.
- Baseline runtime, TTL/KPI cuối cùng và Firebase deployed state: **PENDING — CẦN XÁC MINH sau phê duyệt**.

**Điểm dừng:** thiết kế hoàn tất; chờ phê duyệt trước khi tạo source, test hoặc chạy thử nghiệm.
