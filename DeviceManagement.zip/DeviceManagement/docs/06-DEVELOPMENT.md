# 06 — Phát triển

## Yêu cầu

- Node.js 20.x (đã xác minh với 20.19.6) và npm.
- Dependency đúng `package-lock.json`.
- Truy cập Firebase project được cấp phép; Firebase CLI nếu chạy Emulator/deploy.
- Java/JDK và Emulator binary nếu kiểm thử Firestore Rules.

## Cài và chạy

```powershell
npm install
npm run dev
```

Port mặc định thực tế là `8000`, bind LAN (`host: true`), strict port. Yêu cầu nội bộ port 55000 chạy bằng:

```powershell
npm run dev -- --port 55000 --strictPort
```

Đã chạy thử thành công cả port mặc định `8000` và override `55000` ngày 05/11/2026. `host: true` bind các interface và Vite công bố địa chỉ Ethernet; không tự đổi `vite.config.ts`. Truy cập từ điện thoại cần cùng LAN và còn phụ thuộc Windows Firewall, Domain policy, VLAN/client isolation nên phải smoke test tại môi trường công ty.

### Service quản trị tài khoản local

Reset mật khẩu ADMIN chỉ gọi service trên cùng máy, qua Vite proxy cùng origin `/__account-admin` tới `http://127.0.0.1:9000`. Chạy service trong `D:\Authen-Tuankiem` và giao diện bằng `npm run dev` trong repository này. Không mở API service ra LAN/Internet và không gọi trực tiếp `127.0.0.1` từ trình duyệt. Bản build/Hosting không tích hợp service local; thao tác reset tại đó sẽ báo cần mở giao diện local. Vite dev server phải giữ trên máy quản trị; khi dùng qua LAN, client gửi yêu cầu qua Vite trên máy này.

## Môi trường

Repository hiện không có `.env` và không dùng `VITE_*`. Firebase Web config nằm ở `src/config/firebase.ts`. Nếu sau này chuyển sang env, chỉ tài liệu hóa tên biến như `VITE_FIREBASE_PROJECT_ID`; không commit giá trị nhạy cảm. Firebase Web API key là client identifier, nhưng private key/token/service account tuyệt đối không đưa vào source.

## Lệnh

| Lệnh | Mục đích |
|---|---|
| `npm run dev` | Vite dev server |
| `npm run preview` | preview build, mặc định port 8000 |
| `npm run excel` / `npm run excel:test` | compile và chạy 26 Excel tests |
| `npx tsc --noEmit` | typecheck |
| `npm run lint` | ESLint toàn workspace |
| `npm run build` | TypeScript build + Vite production |
| `npm run rules:test` | chạy test file; integration sẽ skip nếu thiếu tooling |
| `npm run rules:test:emulator` | chạy Rules suite qua Emulator |

## Quy trình sửa lỗi an toàn

1. Tái hiện và ghi bằng chứng; đọc docs/source/Rules liên quan.
2. Xác định collection, field, quyền, route và test bị ảnh hưởng.
3. Chụp/lưu trữ file quan trọng nếu thay đổi có rủi ro; không lưu secret.
4. Sửa nhỏ nhất có thể; không mở rộng scope.
5. Chạy Excel, TypeScript, lint, build; chạy Rules Emulator nếu liên quan quyền/Rules.
6. Smoke test ADMIN và USER theo area; kiểm tra history/QR/Excel nếu liên quan.
7. Cập nhật docs và báo cáo PASS/FAIL/PENDING.

## Quy ước dữ liệu

- Không đổi Document ID hoặc field quan hệ mà không có migration/RBAC plan.
- Dùng transaction cho workflow nhiều document.
- Không lọc dữ liệu trái quyền sau khi list toàn collection cho USER.
- Không sửa lịch sử từ dữ liệu hiện hành; dùng snapshot.
- Không thêm dependency hoặc deploy nếu chưa phê duyệt.

