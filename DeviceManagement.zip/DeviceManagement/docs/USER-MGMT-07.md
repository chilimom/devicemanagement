# USER-MGMT-07 — Firebase-only User Management

## Trạng thái

**CODE COMPLETE FOR THE APPROVED CLIENT-ONLY DESIGN — RULES TEST BLOCKED — NOT READY FOR DEPLOY.**

Không deploy Hosting/Rules, không ghi production, không xóa dữ liệu `invites` cũ và không thay Firebase plan.

## 1. File thay đổi

- `src/config/firebase.ts`: export public `firebaseConfig` để khởi tạo secondary Firebase app.
- `src/services/directAccountProvisioning.ts`: secondary Auth, provisioning state, profile batch, retry an toàn và danh sách account quản lý được.
- `src/pages/UserManagement.tsx`: thay UI lời mời bằng tạo tài khoản trực tiếp; hiển thị trạng thái provisioning và phân biệt khóa quyền ứng dụng.
- `src/App.tsx`: account không profile chỉ thấy thông báo chưa được cấp quyền; không còn self-claim invite trong luồng hoạt động.
- `firestore.rules`: direct profile create theo role/scope và bảo vệ `accountProvisioningAttempts`.
- `tests/firestore.rules.test.mjs`: test direct create và atomic provisioning.
- `docs/USER-MGMT-07.md`.

Không sửa module thiết bị, Dashboard, QR, KPI, TTL/cache hoặc port Vite.

## 2. Luồng tạo tài khoản

1. ADMIN/AREA_ADMIN nhập họ tên, email, role và ít nhất một xưởng.
2. Client normalize email `trim + lowercase`, loại area trùng và kiểm tra scope defense-in-depth.
3. Default Firestore tạo `accountProvisioningAttempts/{email}` trạng thái `PENDING_AUTH`. Rules kiểm tra caller role/scope.
4. Tạo secondary Firebase app có tên riêng và Auth dùng `inMemoryPersistence`.
5. Sinh mật khẩu tạm thời mạnh, duy nhất bằng Web Crypto; không hiển thị, không log, không lưu Firestore/localStorage.
6. `createUserWithEmailAndPassword` tạo Auth account trên secondary Auth. Default ADMIN session không đổi.
7. Một Firestore batch bằng default authenticated Firestore:
   - tạo `users/{uid}`;
   - chuyển provisioning attempt sang `ACTIVE` và lưu UID.
8. Gửi Firebase verification email và password-reset email. Người dùng tự đặt mật khẩu; không có password chung/plaintext email.
9. Sign out secondary Auth và delete secondary app trong `finally`.

Service lưu UID và kiểm tra default Auth UID trước/sau. Secondary Auth không được dùng để ghi profile hoặc quyết định quyền.

## 3. Khả năng phục hồi

State machine:

```text
PENDING_AUTH -> AUTH_CREATED_PROFILE_PENDING -> ACTIVE
            \-------------------------------> ACTIVE
```

- Profile và trạng thái `ACTIVE` phải commit trong cùng Firestore batch.
- Nếu Auth create thành công nhưng batch profile thất bại, service cố ghi `AUTH_CREATED_PROFILE_PENDING` cùng UID và báo lỗi rõ ràng; không báo tạo thành công và không tự xóa Auth account.
- Submit lại đúng email khi trạng thái có UID chỉ retry batch profile, không gọi Auth create lần nữa.
- Nếu Auth create fail, attempt giữ `PENDING_AUTH` và error code; UI yêu cầu review, không tự retry tạo Auth.
- Trường hợp không thể phục hồi bằng Client SDK: browser crash/mất mạng ngay sau Auth create nhưng trước khi UID được lưu. Attempt có thể còn `PENDING_AUTH`, email đã tồn tại và Client SDK không lookup/list Auth users. Phải đối chiếu/xử lý thủ công trong Firebase Console, sau đó quyết định tạo profile hoặc xóa Auth account.

Không có atomic transaction giữa Firebase Auth và Firestore; tài liệu/UI không tuyên bố điều ngược lại.

## 4. Phân quyền Firestore

### ADMIN

- Direct-create profile role USER hoặc AREA_ADMIN.
- Không direct-create ADMIN qua workflow này.
- List và quản lý profile theo quyền tổng hiện hữu.
- Đọc mọi provisioning attempt.

### AREA_ADMIN

- Direct-create profile chỉ role USER.
- `areaIds` phải không rỗng và là tập con caller scope.
- Chỉ đọc provisioning attempts do chính mình tạo.
- Chỉ get/update target có before-role và after-role đều là USER, before/after areaIds đều trong scope.
- Không sửa chính mình, ADMIN hoặc AREA_ADMIN; không nâng USER.

### USER/account không profile

- Không tạo provisioning attempt hoặc profile có quyền.
- Account tự signup có Auth nhưng không có `users/{uid}`; App không mount dữ liệu nghiệp vụ và Rules tiếp tục deny.

SECURITY-FIX-01 được giữ nguyên cho get/update. USER-MGMT-07 chỉ mở `create users/{uid}` theo exact role/scope và thêm provisioning collection được bảo vệ.

## 5. Giao diện

- Tiêu đề “Thêm tài khoản”, nút “Tạo tài khoản”.
- ADMIN chọn USER hoặc AREA_ADMIN; AREA_ADMIN chỉ thấy USER.
- Checkbox hiển thị tên xưởng.
- Danh sách: họ tên, email, role, xưởng, trạng thái quyền ứng dụng, sửa và khóa/mở.
- Không hiển thị disable Firebase Authentication. `isActive=false` được ghi rõ là “khóa quyền ứng dụng”.
- Bảng trạng thái provisioning thay bảng lời mời.
- Không xóa collection/data/Rules `invites` legacy; chỉ bỏ nó khỏi active UI/Auth flow.

## 6. Kiểm thử

| Kiểm tra | Kết quả |
|---|---|
| `npx tsc --noEmit` | PASS |
| `npm run lint` | PASS |
| `npm run build` | PASS |
| `npm run cache` | PASS — 34/34 |
| `npm run excel` | PASS — 26/26 |
| `node --check tests/firestore.rules.test.mjs` | PASS |
| Rules integration suite | 25 tests đã chuẩn bị |
| `npm run rules:test` | **BLOCKED** — `spawn java ENOENT` |

Rules tests mới bao phủ:

- ADMIN direct-create USER/AREA_ADMIN nhưng không ADMIN.
- AREA_ADMIN direct-create USER đúng scope.
- AREA_ADMIN không tạo AREA_ADMIN hoặc USER ngoài scope.
- Provisioning chỉ chuyển ACTIVE khi matching profile được tạo trong cùng batch.
- Standalone activation không có profile bị deny.
- Các test SECURITY-FIX-01 về get/update/lock/demote/nâng quyền vẫn giữ nguyên.

Không báo Rules PASS. Cần chạy thật 25 PASS, 0 FAIL, 0 SKIP sau khi Java/Firestore Emulator sẵn sàng.

## 7. Hạn chế còn lại

- Client Auth signup không thể giới hạn chỉ cho ADMIN; security boundary là Firestore profile/Rules.
- Client SDK không disable arbitrary Firebase Auth account hoặc revoke refresh token. Khóa trong UI chỉ là `users.isActive=false`.
- AREA_ADMIN chỉ khám phá USER được tạo qua provisioning attempts của chính mình; không list toàn `users` và không quản lý profile legacy không có assignment an toàn.
- Email reset/verification có thể bị quota/delivery failure. Account/profile vẫn có thể ACTIVE; UI cảnh báo cần gửi lại thủ công qua Firebase Console nếu email action thất bại.
- `PENDING_AUTH` sau crash ở cửa sổ không lưu được UID cần Firebase Console reconcile; UI không tự tạo lại để tránh duplicate Auth account.
- Rules mới chưa được Emulator xác nhận, nên chưa sẵn sàng deploy.

## 8. Test giao diện localhost

Chỉ dùng Firebase project test/Emulator phù hợp, không production:

```powershell
npm run dev -- --port 55000 --strictPort
```

Không thay đổi cấu hình port trong source.

Checklist:

1. Đăng nhập ADMIN, ghi lại default Auth UID; tạo USER và AREA_ADMIN; UID phiên ADMIN phải không đổi.
2. Xác nhận user mới nhận verification/reset email và đăng nhập sau khi đặt mật khẩu.
3. Đăng nhập AREA_ADMIN A; UI chỉ cho role USER và chỉ hiện xưởng trong scope A.
4. Chỉnh request trực tiếp để gửi AREA_ADMIN hoặc area B; Firestore phải permission-denied.
5. USER gọi thẳng provisioning/profile write; phải denied.
6. Tự signup ngoài UI; account không profile phải chỉ thấy “chưa được cấp quyền”.
7. Giả lập profile batch fail; UI phải hiển thị UID/incomplete, không báo thành công. Submit lại đúng email chỉ retry profile.
8. Refresh ở trạng thái `PENDING_AUTH` không UID; UI phải yêu cầu Console review, không tạo Auth lần hai.
9. Sửa role/areaIds/isActive của user đang đăng nhập; profile listener phải fail-closed và cache scope cũ bị xóa.
10. Khóa user và xác nhận đây là khóa ứng dụng; Firebase Auth account không bị quảng cáo là disabled.

## 9. Điều kiện deploy

1. Cài/cấu hình Java và chạy `npm run rules:test` đạt 25/25.
2. Smoke test bằng Firebase project test, bao gồm secondary/default session và failure recovery.
3. Review riêng Rules, collection `accountProvisioningAttempts` và quy trình Console reconcile.
4. Chỉ deploy Rules/Hosting sau phê duyệt; USER-MGMT-07 không tự deploy.
