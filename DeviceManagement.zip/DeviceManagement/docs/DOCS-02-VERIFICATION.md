# DOCS-02 — Xác minh tài liệu bàn giao

Ngày xác minh: 05/11/2026. Phạm vi chỉ đọc source/cấu hình và cập nhật Markdown; không sửa source, cấu hình, Rules, Auth, Firestore hoặc Hosting.

## Điểm đã xác minh

| Chủ đề | Kết quả | Bằng chứng |
|---|---|---|
| Vite | Port mặc định `8000`, `strictPort: true`, `host: true`; override `55000` hoạt động | `vite.config.ts`; chạy `npm run dev` và `npm run dev -- --port 55000 --strictPort` |
| LAN | Vite công bố Network URL trên Ethernet ở cả hai port | Output Vite; truy cập từ thiết bị khác còn phụ thuộc firewall/mạng công ty |
| `deviceCategories` | Source chỉ đọc `code`, `name`, `status`; type tham chiếu bằng `categoryId`; không có UI/service ghi | `AddDevice.tsx`, `DeviceTypes.tsx`, các query trong `src/`, `firestore.rules` |
| Quản lý user | UI/service chỉ đọc; không có source tạo Auth user hoặc ghi/cập nhật `users/{uid}` | `UserManagement.tsx`, `userService.ts`, Auth flow và `firestore.rules` |
| Auth thiếu profile | Bị từ chối quyền nghiệp vụ và hiển thị trạng thái thiếu hồ sơ | Luồng Auth/profile trong ứng dụng |
| Template | ADMIN-only; có list/create; update service không có caller và không tăng version | inspection services/pages/routes, `firestore.rules` |
| Plan | Một plan/device, tạo transaction version 1; chưa có update/sync template | inspection plan service/page, Rules |
| Lịch sử tuần kiểm | `inspectionResults.planSnapshot` là nguồn lịch sử; không thay bằng plan/template hiện hành | result service, history/export transformer, Rules |
| Rules tests | 5 integration test còn PENDING; không coi skip/exit 0 là PASS | `tests/firestore.rules.test.mjs`, `tests/README.md`, `package.json` |
| UI tests | Không có UI automated tests | `tests/`, npm scripts |
| Hosting live | Release `1793846686317000`, version `2346f8b34230a116`, `FINALIZED`, 05/11/2026 09:44:46 UTC+7 | `firebase.cmd hosting:channel:list --site quanly-tasklist --project quanly-tasklist --json` |

## Chi tiết quyền và workflow

- `deviceCategories`: active user được đọc; chỉ ADMIN được Rules cho ghi. Tuy nhiên ứng dụng không cung cấp workflow thêm/sửa/ngừng sử dụng category. `DeviceTypes` chỉ chọn category active và quản lý type. Thiết bị giữ `deviceTypeId`, không giữ `categoryId` trực tiếp.
- `users/{uid}`: profile dùng `displayName`, `email`, `role`, `isActive`, `areaIds`; ID phải khớp Firebase Auth UID. Rules cho ADMIN quản lý profile, nhưng Firebase Auth account là tài nguyên độc lập và source không triển khai cấp tài khoản.
- Template/plan: template không tự cập nhật plan đã tạo; source không có update plan. Kết quả tuần kiểm lưu snapshot tại thời điểm phát sinh, nên lịch sử và Excel tiếp tục dùng snapshot.

## Môi trường Rules Emulator

Cần Java/JDK tương thích, Firebase CLI, Firestore Emulator binary và `@firebase/rules-unit-testing`. Emulator được cấu hình `127.0.0.1:8085`; chạy bằng `npm run rules:test:emulator`. Không chuyển test sang production khi thiếu tooling.

Năm ca integration vẫn **PENDING**: current-area access; USER tạo ngoài area; resolution transaction; verification transaction; revoke/transfer area. Repository chưa có UI automated tests; kiểm thử giao diện phải thực hiện thủ công theo checklist ADMIN/USER trong `08-TESTING.md`.

## Tài liệu đã cập nhật

- `README.md`
- `docs/02-DATABASE.md`
- `docs/03-BUSINESS-RULES.md`
- `docs/04-AUTHORIZATION.md`
- `docs/05-FEATURES.md`
- `docs/06-DEVELOPMENT.md`
- `docs/07-DEPLOYMENT.md`
- `docs/08-TESTING.md`
- `docs/09-TROUBLESHOOTING.md`
- `docs/10-CHANGELOG.md`

`AGENTS.md` và `docs/01-ARCHITECTURE.md` không sửa vì nội dung hiện tại không mâu thuẫn với kết quả xác minh.

## Còn PENDING / CẦN XÁC MINH

1. Truy cập điện thoại trên mạng công ty: cần thử cùng LAN và xác nhận Firewall/Domain/VLAN/client isolation với IT.
2. Schema đầy đủ, Document ID, uniqueness, timestamp và quy trình vận hành thật của `deviceCategories`: không có writer trong source và không đọc production database ở bước này.
3. Quy trình chính thức tạo Firebase Auth user, tạo profile, phân công người chịu trách nhiệm và thu hồi tài khoản.
4. Nghiệp vụ sửa/version template và nhu cầu cập nhật plan; source hiện chưa tạo thành workflow hoàn chỉnh.
5. Năm Rules integration test chưa chạy trong Emulator; không đánh dấu PASS.
6. Commit SHA tương ứng Hosting release: CLI metadata không cung cấp, cần đối chiếu Git/CI hoặc hồ sơ deploy.

## Cần người dùng quyết định

- Phê duyệt quy trình vận hành tài khoản Auth/profile và kiểm soát role/`areaIds`.
- Xác định có cần xây dựng UI quản trị category và workflow sửa/version template/plan trong giai đoạn riêng hay không.
- Bố trí môi trường Emulator/tooling để hoàn tất 5 Rules test và cân nhắc chiến lược UI automated tests.
- Chỉ định nguồn Git/CI chuẩn để gắn commit SHA với mỗi Hosting release.
