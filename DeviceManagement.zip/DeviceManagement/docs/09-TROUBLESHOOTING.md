# 09 — Troubleshooting

## Không đăng nhập được

1. Kiểm tra mạng, project/auth domain và Email/Password provider trong Console.
2. Xác nhận Auth user tồn tại và `users/{uid}` tồn tại.
3. Kiểm tra `role`, `isActive`, `areaIds` đúng type.
4. Không ghi mật khẩu/token vào log hoặc ảnh chụp.

## ADMIN đổi mật khẩu không kết nối service local

- Chỉ ADMIN được đổi mật khẩu trong phần **Sửa tài khoản**. Nhập mật khẩu mới và xác nhận; thao tác thu hồi các phiên đăng nhập đang tồn tại.
- Chạy lại service quản trị trên máy Vite tại `127.0.0.1:9000` để nạp route vừa cập nhật, sau đó dùng giao diện qua `npm run dev` (mặc định `http://localhost:8000`). Vite proxy `/__account-admin` sẽ chuyển tiếp cùng origin; không cấu hình trình duyệt gọi API HTTP localhost trực tiếp.
- Nếu báo service không kết nối, kiểm tra service đang lắng nghe cổng 9000 và terminal của Vite có lỗi proxy không. Không gửi token hoặc mật khẩu vào log.
- Reset từ Firebase Hosting/HTTPS không được hỗ trợ vì service chỉ local. Mở giao diện local trên máy quản trị để thao tác; không bật service ra Internet.

Ứng dụng hiện không có workflow tạo Auth user/profile. Nếu Auth có nhưng thiếu `users/{uid}`, cần chuyển cho ADMIN vận hành theo quy trình cấp tài khoản đã phê duyệt; không tự tạo profile hoặc đoán role/area.

## Không truy cập được dev server từ điện thoại

- Xác nhận Vite hiển thị Network URL và điện thoại cùng LAN; dùng địa chỉ Ethernet thật, không dùng adapter VMware/vEthernet.
- Mặc định là port `8000`; môi trường công ty dùng `npm run dev -- --port 55000 --strictPort` khi được yêu cầu.
- Kiểm tra Windows Firewall, Domain policy, VLAN/client isolation với IT; không tự tắt firewall hoặc vượt chính sách.

## `permission-denied` / không đọc Firestore

- Ghi collection, loại thao tác, route và role/area (không ghi token).
- Kiểm tra query có constraint phù hợp Rules; USER không được list toàn collection.
- Xác nhận history có `deviceId` hợp lệ và device hiện thuộc area được cấp.
- Đối chiếu Rules đang deploy với file local; không tự deploy để thử.
- Dùng Emulator test khi có tooling.

## Không lưu thiết bị

- Code có trùng ID không; area/category/type còn tồn tại/active và đúng quan hệ không.
- Kiểm tra IP/MAC, field bắt buộc và transaction error.
- Khi sửa, code không được đổi; không chuyển sang area/type inactive.

## QR

- Camera cần HTTPS/localhost và quyền trình duyệt.
- QR phải cùng origin, path `/q/`, code URL-encoded.
- Kiểm tra device code và areaIds. Thử upload ảnh để tách lỗi camera khỏi lỗi decode.

## Xuất Excel

- Xác nhận user active và dữ liệu đọc không bị permission-denied.
- Không dùng dữ liệu bảng UI để đối chiếu vì export đọc toàn scope.
- Kiểm tra dynamic chunk `excelExportWorkbook-*.js` tải được.
- Nếu workbook lỗi, ghi sheet/số dòng/kiểu dữ liệu; không tải file thiếu.
- ExcelJS chunk lớn có thể chậm trên mạng yếu; đây là cảnh báo đã biết.

## Route refresh

Nếu route sâu trả 404, kiểm tra Hosting public=`dist` và rewrite `**` về `/index.html`. Nếu route vào app rồi redirect, kiểm tra Auth/profile và route trong `App.tsx`.

## Build/deploy

- Chạy bốn cổng chất lượng; xem lỗi đầu tiên thay vì deploy lại nhiều lần.
- PowerShell có thể chặn `firebase.ps1`; dùng `firebase.cmd` được cấu hình hiện tại.
- Luôn chỉ rõ `--only hosting --project quanly-tasklist` khi deploy Hosting.
- Kiểm tra `dist` không chứa tài liệu/log/secret.

## Thu thập log an toàn

- Thu thập timestamp, route, browser, role, mã lỗi Firebase, request collection/query shape và bước tái hiện.
- Che email nếu không cần; không ghi API token, access/refresh token, password, private key, cookie hoặc nội dung dữ liệu nhạy cảm.
- Phân biệt lỗi đã xác nhận bằng log/test với giả thuyết xử lý tham khảo. Những đề xuất chưa tái hiện phải ghi **CẦN XÁC MINH**.

