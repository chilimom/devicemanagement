# 08 — Kiểm thử

## Bộ test hiện có

| Bộ test | File | Lệnh | Trạng thái gần nhất |
|---|---|---|---|
| Excel transformer | `tests/excelExportTransform.test.ts` | `npm run excel` | PASS |
| Excel workbook | `tests/excelExportWorkbook.test.ts` | `npm run excel` | PASS |
| Firestore Rules | `tests/firestore.rules.test.mjs` | `npm run rules:test:emulator` | **PENDING** integration |

`npm run excel` hiện có 26 test và đã PASS 26/26 trong lần kiểm tra tài liệu. Nó kiểm 6 sheet/63 cột, STT/group, giữ số dòng, snapshot, dữ liệu thiếu, tiếng Việt, Date, sheet rỗng, giới hạn dòng và formula injection.

`npm run rules:test` có thể exit 0 nhưng skip 5 integration test khi thiếu `@firebase/rules-unit-testing`/Emulator; không được diễn giải thành Rules PASS.

## Rules Emulator

Theo `tests/README.md`, môi trường được phê duyệt cần Firebase CLI, Firestore Emulator binary, Java/JDK và `@firebase/rules-unit-testing`. `firebase.json` cấu hình Emulator tại `127.0.0.1:8085`. Khi đủ thành phần, chạy:

```powershell
npm run rules:test:emulator
```

Không tự cài tooling hoặc chuyển test sang production. Năm integration test vẫn **PENDING**, gồm current-area access, tạo ngoài area, resolution transaction, verification transaction và revoke/transfer; lệnh skip/exit 0 không phải PASS.

## Smoke test chức năng

- **Auth/RBAC:** active/inactive, ADMIN, USER không area, một/nhiều area, truy cập URL trực tiếp.
- **Thiết bị/area/type:** tạo, sửa, inactive/reactivate, trùng code, chuyển area/type inactive.
- **Sự cố:** thủ công; nhiều lần khắc phục OPEN; RESOLVED; verification; history đúng người/thời gian.
- **Sự cố từ tuần kiểm:** USER/AREA_ADMIN được đọc ID chưa có incident để hiện nút chuyển thành sự cố; AREA_ADMIN có thể đọc ID verification cố định chưa tồn tại chỉ trong area được giao; tạo/resolution/verification trong area được giao; ngoài area và GUEST bị Rules từ chối.
- **Bảo trì:** ADMIN/AREA_ADMIN/USER gửi trong area được cấp ở trạng thái `PENDING_APPROVAL`; chỉ ADMIN chuyển sang `COMPLETED` và xác nhận; USER ngoài area bị Rules từ chối.
- **Tuần kiểm:** template/plan; scheduled/extra; required criteria; snapshot; chọn tạo incident hoặc mở lượt EXTRA kiểm tra lại từ WARNING/FAIL; lượt EXTRA không sửa kết quả inspection gốc và được tính xóa cảnh báo trễ lịch.
- **Sửa plan tuần kiểm:** ADMIN sửa plan ở mọi area; AREA_ADMIN chỉ sửa plan trong `areaIds`; USER và AREA_ADMIN ngoài scope bị Rules từ chối; version tăng đúng một; không đổi `isActive`/`templateId`; snapshot phiếu cũ không đổi.
- **Cảnh báo lịch tuần kiểm:** đúng ngày Việt Nam; đến hạn/hoàn thành hôm nay; quá hạn sau khi bỏ lịch; không cảnh báo trước ngày tạo plan; `EXTRA` không xóa quá hạn; ADMIN/AREA_ADMIN/USER chỉ thấy trạng thái thiết bị trong scope.
- **QR:** tạo/in, scan camera/upload, sai origin/path/code, USER ngoài area.
- **Excel:** ADMIN/USER, dữ liệu rỗng/lớn, 6 sheet/63 cột, XLSX mở được.

## Checklist UAT

1. Test trên domain HTTPS đã authorize.
2. Dùng tài khoản UAT, không dùng production admin ngoài phạm vi.
3. Đối chiếu số liệu theo area và history.
4. Kiểm tra refresh mọi route chính.
5. Kiểm tra desktop/mobile và camera thật.
6. Ghi PASS/FAIL/PENDING cùng bằng chứng, browser và tài khoản vai trò.
7. Không đánh dấu PASS cho ca chưa chạy.

### Checklist thủ công theo vai trò

- **ADMIN:** đăng nhập/profile; CRUD area/type/device; lifecycle device; tạo/resolve/verify incident; maintenance; template/plan/inspection; Excel 6 sheet/63 cột; QR và refresh route sâu.
- **USER trong area:** chỉ thấy area/device/history được cấp; tạo/resolve/verify incident và thực hiện tuần kiểm đúng thiết bị; Excel không vượt scope.
- **USER ngoài area/không area:** URL trực tiếp, query, QR và export đều không lộ dữ liệu; thao tác ghi ngoài area bị từ chối.
- **Auth/profile bất thường:** Auth thiếu `users/{uid}`, profile inactive, role/`areaIds` sai kiểu phải bị chặn hoặc báo rõ; không dùng tài khoản hiện tại thay người lịch sử.
- **GUEST:** chưa đăng nhập chỉ đọc public summary generation hiện hành; không đọc collection nghiệp vụ, không ghi public summary, không thấy Quản trị/QR; route chi tiết chuyển đăng nhập và quay lại đúng `returnTo` sau đăng nhập.

## Cổng chất lượng

```powershell
npm run excel
npx tsc --noEmit
npm run lint
npm run build
```

Không có UI automated test trong repository. Chiến lược bổ sung browser regression vẫn **CẦN XÁC MINH**; hiện phải dùng checklist thủ công và không được ghi PASS khi chưa chạy.


- **Kiểm tra khắc phục tuần kiểm:** xác nhận lượt EXTRA được gom cùng luồng/KPI theo kết quả mới nhất, giữ phiếu gốc bất biến và Rules chặn liên kết tới phiếu khác thiết bị.

