# PERF-04B.2A — Tích hợp cache lifecycle với Auth/Profile

Ngày thực hiện: 06/11/2026. Phạm vi: lifecycle của shared RAM cache; chưa tích hợp cache data vào Dashboard, Devices, DeviceDetail hoặc page nghiệp vụ.

## Kết quả

- Tạo một `SharedRamCache` singleton cho mỗi application tab.
- Chỉ tầng Auth/profile trong `App` được kích hoạt scope sau khi Auth UID và profile active đã khớp.
- Auth loading, profile loading, logout, profile missing/inactive/error và effect cleanup đều giữ cache inactive hoặc vô hiệu scope hiện hành.
- Đổi UID, role hoặc normalized `areaIds` tạo scope key khác, làm clear data/in-flight của scope cũ. `active` không nằm trong key; inactive tạo `null` scope và được clear tường minh.
- Snapshot profile lặp lại cùng scope là no-op, không tăng generation hoặc clear cache.
- Thêm verification epoch để callback profile cũ, kể cả cùng UID, không thể activate/invalidate một verification mới.
- Không đổi Auth persistence, Firestore query, Rules, index, database, schema, UI hoặc route.

## File tạo/sửa

| File | Nội dung |
| --- | --- |
| `src/services/sharedRamCacheLifecycle.ts` | Auth/profile lifecycle controller và verification epoch. |
| `src/services/appSharedRamCache.ts` | Singleton cache + lifecycle, lấy project ID từ Firebase app options. |
| `src/App.tsx` | Auth/profile barrier kích hoạt/vô hiệu scope; cleanup StrictMode. |
| `src/components/AppLayout.tsx` | Clear cache đồng bộ trước logout; khôi phục scope nếu signOut thất bại và user vẫn khớp. |
| `tests/sharedRamCacheLifecycle.test.ts` | Unit tests lifecycle/race. |
| `tsconfig.cache-test.json` | Thêm lifecycle source/test vào cache test compile. |
| `package.json` | Thêm lệnh `npm run cache`; `cache:test` chạy cả core và lifecycle tests. |
| `docs/PERF-04B.2A.md` | Báo cáo này. |

## Cơ chế lifecycle

1. Effect Auth bắt đầu: `beginAuthVerification()` vô hiệu scope.
2. `onAuthStateChanged` trả UID: `resolveAuth(uid)` tăng verification epoch, clear scope và bắt đầu profile loading.
3. `onSnapshot users/{uid}` hợp lệ: parse profile, xác nhận active, rồi `activateProfile(profile, epoch)`.
4. Profile snapshot chỉ được chấp nhận nếu epoch hiện hành, UID profile khớp UID Auth và active=true.
5. Role/areaIds đổi: scope key đổi; `SharedRamCache.activateScope` tăng generation, clear entry và in-flight.
6. Snapshot cùng UID/role/normalized areas: key không đổi nên không clear.
7. Missing/inactive/parse error/read error: `invalidateProfile(epoch)` clear scope nếu callback vẫn thuộc epoch hiện hành.
8. Logout: `logout()` tăng epoch và clear scope trước khi await Firebase `signOut`.
9. Effect cleanup/StrictMode: `dispose()` tăng epoch và clear; remount xác minh lại từ đầu.

App vẫn dùng profile realtime và Rules làm nguồn quyền. Cache lifecycle không đọc cache để quyết định route/RBAC.

## Chống race

Hai lớp guard được dùng:

- Lifecycle verification epoch loại callback profile cũ sau Auth callback mới, logout hoặc StrictMode cleanup.
- Cache generation + requestId + exact scope key ngăn loader cũ commit sau scope transition.

Firestore request đã phát có thể hoàn tất, nhưng kết quả trả `committed: false`. Không có dữ liệu nghiệp vụ nào được lưu trong localStorage, sessionStorage hoặc IndexedDB.

## Kiểm thử

`npm run cache` hiện chạy 31 tests: 17 core tests và 14 lifecycle tests. Lifecycle bao phủ Auth loading, profile loading, valid profile, logout, UID/role/areaIds/active changes, deleted/error profile, late request, replay snapshot, StrictMode và stale same-UID callback.

Kết quả cuối cùng được ghi trong bàn giao sau khi chạy đủ quality gates.

## Rủi ro còn lại

- Chưa có React DOM integration test vì repository không có test dependency/harness tương ứng và yêu cầu cấm thêm dependency. Lifecycle được tách thuần TypeScript để unit test đầy đủ; smoke test runtime vẫn cần ở bước tích hợp/UAT được phê duyệt.
- Singleton đã vào main bundle nhưng chưa có dataset consumer; hiện chỉ giữ scope metadata, không giữ dữ liệu nghiệp vụ.
- Nếu signOut thất bại, `AppLayout` chỉ khôi phục scope khi `auth.currentUser.uid` vẫn khớp profile đang render; trường hợp khác tiếp tục giữ cache inactive.
- Profile permission error callback không phân biệt chi tiết mã lỗi vì mọi lỗi đọc profile đều phải fail closed và clear scope.

## Rollback

Gỡ import/call lifecycle khỏi `App.tsx` và `AppLayout.tsx`, xóa hai module lifecycle/singleton cùng test/config script liên quan. Core cache PERF-04B.1 có thể giữ độc lập. Không có persisted storage, migration hay dữ liệu cần dọn; không cần thay Rules/Auth/database.

**Điểm dừng:** lifecycle integration hoàn tất; chưa tích hợp page. Chờ phê duyệt trước PERF-04B.2 tiếp theo.
