# USER-MGMT-05 — Direct Account Provisioning API

## Trạng thái

**DESIGN ONLY — BLOCKED PENDING INFRASTRUCTURE CONFIRMATION.**

Chưa triển khai backend, frontend integration hoặc thay thế quy trình `invites`. Repository không cung cấp bằng chứng về nơi chạy API, DNS/TLS, firewall, CORS, secret store, email delivery hoặc khả năng client ngoài mạng công ty gọi API nội bộ. Tự chọn một môi trường sẽ tạo kiến trúc giả định và có nguy cơ làm lộ Firebase Admin credentials.

Không deploy, không ghi production, không tạo service-account key và không thay đổi Firebase plan.

## 1. Hạ tầng hiện có đã xác nhận

| Thành phần | Trạng thái xác nhận | Bằng chứng |
|---|---|---|
| Frontend | React 19 + TypeScript + Vite SPA | `package.json`, `src/`, `vite.config.ts` |
| Hosting | Firebase Hosting, `quanly-tasklist.web.app` | `.firebaserc`, `firebase.json`, `docs/07-DEPLOYMENT.md` |
| Auth/Data | Firebase Web SDK gọi Auth và Firestore trực tiếp | `src/config/firebase.ts`, `src/App.tsx` |
| Backend/API | Không có | Không có server project, route API, Express/Fastify, ASP.NET hoặc Cloud Functions |
| Node server | Chỉ có Node tooling cho build/test; không có runtime server | `package.json` |
| .NET/IIS | Không có project/config hoặc tài liệu vận hành | Không có `.sln`, `.csproj`, `web.config` |
| Environment | Không có `.env`, không dùng `VITE_*` | README và source |
| API proxy | Không có Vite/Hosting rewrite tới API | `vite.config.ts`, `firebase.json` |
| CORS | Chưa có | Không có backend/config CORS |
| DNS/TLS API | Chưa xác định | Không có hostname/certificate/reverse proxy trong repository |
| Mạng nội bộ | Chưa xác minh firewall, VLAN, client isolation và truy cập ngoài mạng | README, `docs/06-DEVELOPMENT.md`, `docs/09-TROUBLESHOOTING.md` |
| Credentials | Không có Admin credential trong repo, đúng yêu cầu bảo mật | `.gitignore`, source scan |
| RBAC | `ADMIN`, `AREA_ADMIN`, `USER`; Rules/profile theo `areaIds` | `firestore.rules`, `src/types/user.ts` |
| User workflow | Hiện dùng `invites` và client transaction nhận invite | `src/services/userManagementService.ts`, `UserManagement.tsx`, `InviteActivation.tsx` |

Firebase Web config hiện ở frontend là client config, không phải service-account credential và không thể dùng thay Firebase Admin SDK credential.

## 2. Đánh giá phương án vận hành

### A. Node.js API trên máy chủ nội bộ

Phù hợp nhất về stack vì repository đang dùng TypeScript/Node, nhưng chỉ nên chọn nếu tổ chức xác nhận:

- Có máy chủ luôn hoạt động, được vá bảo mật và có owner vận hành.
- Có DNS ổn định, ví dụ `device-api.company.example`.
- Có HTTPS với certificate được mọi thiết bị client tin cậy.
- Reverse proxy/process manager và logging/monitoring được quản trị.
- Outbound HTTPS từ server tới Google/Firebase được firewall cho phép.
- Browser người dùng có route mạng tới API. Người dùng ngoài công ty cần VPN/ZTNA hoặc API gateway được duyệt.
- Service identity/credential được giữ trong secret store hoặc protected machine credential, không trong repo/config frontend.

Firebase Hosting không “nối” được API nội bộ thay cho browser. JavaScript chạy trong browser sẽ gọi API trực tiếp; máy client phải phân giải DNS và kết nối được tới endpoint. Nếu trang HTTPS gọi API HTTP, trình duyệt sẽ chặn mixed content.

### B. ASP.NET Core API trên IIS nội bộ

Có thể phù hợp nếu đội vận hành chuẩn hóa Windows/IIS/.NET, nhưng repository không có dấu hiệu hạ tầng này. Cần xác nhận:

- Phiên bản .NET LTS, IIS hosting bundle và application pool identity.
- TLS binding/certificate lifecycle.
- Secret store/DPAPI/Windows service identity.
- Outbound Google API access, proxy doanh nghiệp và log retention.
- Quy trình build/deploy/rollback riêng cho API.

Không có lợi thế bảo mật tự động so với Node; chất lượng phụ thuộc vào IAM, TLS, secret management và vận hành thực tế.

### C. Backend cloud

Giải quyết tốt hơn khả năng truy cập ngoài mạng và TLS/DNS, đồng thời có thể dùng workload identity thay key file. Tuy nhiên Cloud Functions/Cloud Run hoặc dịch vụ tương đương có thể cần billing/plan và chính sách cloud được phê duyệt. USER-MGMT-05 cấm tự nâng Firebase plan, nên phương án này chưa được phép mặc định.

### Khuyến nghị có điều kiện

- Nếu toàn bộ người dùng ở LAN/VPN và tổ chức đã có Node operations: chọn A.
- Nếu tổ chức bắt buộc IIS/.NET và có đội vận hành: chọn B.
- Nếu cần truy cập Internet không qua VPN: đánh giá C qua quy trình kiến trúc, bảo mật và chi phí riêng.

Chưa có đủ dữ liệu để chọn một phương án cuối cùng.

## 3. Kiến trúc đề xuất

```text
Firebase Hosting SPA
  -> HTTPS API (CORS allowlist)
      -> verify Firebase ID token / expected project
      -> load caller users/{uid} from Firestore
      -> authorize current role, areaIds, isActive
      -> Firebase Admin Auth + Admin Firestore
      -> audit log (no token/password/credential)
```

API không tin custom payload `role`, `areaIds` hoặc UI state của caller. Mỗi request phải đọc lại profile caller. Mỗi update target phải đọc target hiện tại và kiểm tra cả phạm vi trước/sau; AREA_ADMIN không được dựa vào “createdBy” để bỏ qua phạm vi hiện tại.

### Authentication middleware

1. Chỉ nhận HTTPS.
2. Parse `Authorization: Bearer <Firebase ID Token>`; giới hạn header/payload.
3. `verifyIdToken(token, true)` bằng Admin SDK nếu chính sách yêu cầu kiểm tra revoked token.
4. Kiểm tra `aud`/project thuộc `quanly-tasklist` thông qua Admin app cấu hình đúng project.
5. Đọc `users/{uid}` server-side; thiếu/sai schema/inactive → 403.
6. Không log bearer token hoặc decoded token đầy đủ.

App Check có thể thêm defense-in-depth để giảm abuse từ client không chính thức, nhưng không thay ID Token, RBAC, CORS hoặc rate limiting.

## 4. API endpoints

### `POST /api/users`

Input đề xuất:

```json
{
  "email": "user@example.com",
  "displayName": "Nguyen Van A",
  "role": "USER",
  "areaIds": ["area-id"]
}
```

- ADMIN tạo USER hoặc AREA_ADMIN; không tạo ADMIN qua endpoint thông thường.
- AREA_ADMIN chỉ tạo USER và `areaIds` phải là tập con scope caller, không rỗng theo chính sách.
- Normalize email `trim + lowercase`; validate độ dài/format; kiểm tra duplicate qua Admin Auth.
- Không nhận password mặc định từ UI.
- Response chỉ trả UID, email, displayName, role, areaIds, active/provisioning status; không trả password/reset token.

### `GET /api/users`

- ADMIN: danh sách toàn hệ thống có pagination.
- AREA_ADMIN: backend đọc/filter bằng Admin SDK và chỉ trả target role USER có `areaIds` hoàn toàn nằm trong scope caller.
- Phải có pagination, search giới hạn, maximum page size; không dựa Firestore client Rules vì Admin SDK bypass Rules.

### `PATCH /api/users/:uid`

- Đọc lại caller và target hiện tại.
- Validate role/areaIds sau update.
- ADMIN sửa USER/AREA_ADMIN theo chính sách; bảo vệ ADMIN tổng.
- AREA_ADMIN chỉ sửa USER đang và sẽ hoàn toàn trong scope; không sửa mình, ADMIN hoặc AREA_ADMIN.
- Email thay đổi nên là workflow riêng vì liên quan xác minh; endpoint này mặc định không đổi email.

### `POST /api/users/:uid/disable`

- Kiểm tra target hiện tại và scope.
- Không cho AREA_ADMIN khóa ADMIN/AREA_ADMIN/out-of-scope/self.
- Không cho ADMIN vô tình khóa ADMIN active cuối cùng. Kiểm tra cần transaction/lock ứng dụng hoặc singleton guard để tránh hai request đồng thời cùng khóa hai admin cuối.
- Disable Firebase Auth, revoke refresh tokens và đặt Firestore `isActive=false` theo state machine/reconcile dưới đây.

### `POST /api/users/:uid/enable`

- Kiểm tra target hiện tại và scope như disable.
- Enable Auth và đặt `isActive=true`; xử lý partial failure.

### HTTP status

- `400`: payload/schema sai.
- `401`: thiếu/sai/hết hạn ID Token.
- `403`: caller inactive hoặc không đủ role/scope.
- `404`: target không tồn tại hoặc dùng concealment policy đã phê duyệt.
- `409`: email trùng, state conflict, provisioning đang xử lý.
- `429`: rate limit.
- `500/503`: lỗi nội bộ/phụ thuộc; trả correlation ID, không trả stack/credential.

## 5. RBAC backend

| Hành động | ADMIN | AREA_ADMIN | USER |
|---|---|---|---|
| Tạo USER | Mọi area hợp lệ | Chỉ subset areaIds caller | Deny |
| Tạo AREA_ADMIN | Có | Deny | Deny |
| Tạo ADMIN | Không qua endpoint thường; quy trình break-glass riêng | Deny | Deny |
| List | Toàn hệ thống | Chỉ USER hoàn toàn trong scope | Deny |
| Sửa USER | Có | Target trước/sau trong scope | Deny |
| Sửa AREA_ADMIN | Có | Deny | Deny |
| Sửa/khóa ADMIN | Chỉ policy đặc quyền, bảo vệ admin cuối | Deny | Deny |
| Tự sửa quyền | Không qua API quản trị | Deny | Deny |

Backend Admin SDK bypass Firestore Rules, nên kiểm tra RBAC trong API là bắt buộc và phải có unit/integration test riêng. Rules vẫn cần giữ fail-closed cho mọi frontend/client request.

## 6. Provisioning không atomic giữa Auth và Firestore

Firebase Auth và Firestore không có transaction chung. Không được báo thành công sau bước Auth nếu profile/audit chưa hoàn tất.

State machine đề xuất:

```text
REQUESTED -> AUTH_CREATED -> PROFILE_CREATED -> ACTIVE
                     \-> COMPENSATION_PENDING
                     \-> FAILED_REQUIRES_RECONCILE
```

Cần nơi lưu trạng thái provisioning bền vững và idempotency key. Đây là schema backend mới, phải được phê duyệt trước triển khai. Có thể dùng collection bảo vệ hoàn toàn khỏi client, ví dụ `accountProvisioningOperations/{operationId}`.

Luồng:

1. Tạo operation với idempotency key, actor, payload hash và `REQUESTED`.
2. Tạo Auth user disabled hoặc chưa active business profile.
3. Ghi UID và `AUTH_CREATED`.
4. Tạo `users/{uid}` với `isActive` theo policy, metadata creator nếu schema được duyệt.
5. Ghi audit và chuyển `ACTIVE`.
6. Nếu Firestore thất bại sau Auth create: thử delete Auth user mới nếu chắc chắn operation sở hữu user và chưa được sử dụng; nếu compensation thất bại, giữ `COMPENSATION_PENDING`, cảnh báo vận hành và retry idempotent.
7. Reconcile job/manual command so sánh operation/Auth/profile; không tự xóa account không chứng minh ownership.

Không log password, reset link đầy đủ, ID token, refresh token hoặc service credential.

## 7. Thiết lập mật khẩu lần đầu

Khuyến nghị:

- Backend tạo Auth account không dùng mật khẩu mặc định chung và không tự đặt `emailVerified=true`.
- Tạo password-reset/action link bằng Admin SDK hoặc dùng luồng Firebase reset được kiểm soát.
- Gửi link qua dịch vụ email doanh nghiệp được phê duyệt; link có hạn, HTTPS và continue URL allowlist.
- Không trả action link cho frontend ADMIN nếu không có chính sách phân phối an toàn; không ghi link vào audit/log.
- Người dùng xác lập mật khẩu và xác minh quyền sở hữu email trước khi truy cập nghiệp vụ theo policy đã duyệt.

Repository chưa có SMTP/email provider. Đây là blocker vận hành cần xác nhận.

## 8. Disable/enable và nhất quán

Disable đề xuất theo hướng fail-closed:

1. Ghi operation/audit intent.
2. Đặt Firestore `isActive=false` trước để Rules chặn business data đối với token còn hiệu lực.
3. Disable Auth user và revoke refresh tokens.
4. Hoàn tất operation; retry/reconcile nếu Admin Auth thất bại.

ID Token đã cấp không nhất thiết mất hiệu lực ngay chỉ vì disable Auth. Firestore Rules hiện đọc `users/{uid}.isActive`, nên lớp dữ liệu vẫn fail-closed. API cũng phải đọc profile ở mỗi request, không chỉ tin token.

Enable cần xử lý thứ tự/state cẩn thận để không tạo khoảng thời gian profile active trong khi Auth vẫn disabled; có thể enable Auth trước, sau đó active profile, với operation/reconcile nếu bước sau lỗi.

## 9. Audit log

Schema cần phê duyệt, tối thiểu:

- `operationId`, `correlationId`.
- actor UID/role/scope snapshot.
- target UID và email đã mask/hash theo policy.
- action, outcome, timestamps server-side.
- before/after role, areaIds, isActive đã lọc field.
- failure category, compensation/reconcile state.
- source IP/user-agent chỉ khi chính sách privacy/retention cho phép.

Client không được đọc/ghi audit collection trực tiếp. Retention, export và quyền điều tra phải được phê duyệt.

## 10. Bảo mật triển khai API

- HTTPS bắt buộc; HSTS/reverse proxy theo chuẩn tổ chức.
- CORS exact allowlist, tối thiểu `https://quanly-tasklist.web.app` và custom domain được phê duyệt; không dùng `*` với Authorization.
- Dev origin chỉ bật ở dev config, không ở production.
- Rate limit theo IP + actor UID + endpoint; giới hạn body, content type và timeout.
- Validate JSON schema, reject unknown fields.
- Secret không dùng biến `VITE_*`, không vào bundle frontend, repo, log hoặc image layer.
- Ưu tiên workload identity/managed service identity. Nếu internal server bắt buộc key file, lưu trong secret store/OS protected location, ACL tối thiểu, rotate và audit; không commit.
- Service account dùng quyền tối thiểu cần cho Firebase Auth, profile/provisioning/audit; cần security review IAM cụ thể.
- Central log phải redact Authorization, reset link và credentials.
- Có health/readiness endpoint không tiết lộ cấu hình.
- Dependency scanning, patch cadence, backup/restore và incident response phải có owner.

## 11. Frontend sau khi API được xác nhận

File dự kiến sửa:

- `src/services/userManagementService.ts`: thay Firestore invite calls bằng API client có Bearer ID Token.
- `src/pages/UserManagement.tsx`: “Thêm tài khoản”, API list/create/update/disable/enable và thông báo lỗi 401/403/409/500.
- `src/App.tsx`, `src/pages/InviteActivation.tsx`: chỉ loại luồng nhận invite sau khi API production/UAT đã xác nhận và có kế hoạch chuyển đổi.
- Cấu hình runtime/build cho API base URL không chứa secret.
- Tests frontend/API contract.

Không xóa `invites`, Rules hoặc dữ liệu production trong lần chuyển đầu. Nên dùng feature flag/cutover có rollback; dừng tạo invite mới sau khi API hoạt động, giữ read/claim trong một thời gian được phê duyệt nếu còn invite pending.

## 12. Kế hoạch kiểm thử

### Unit backend, mock Admin SDK

- ADMIN tạo USER/AREA_ADMIN.
- AREA_ADMIN chỉ tạo USER trong scope.
- USER, inactive actor, token thiếu/sai/revoked bị từ chối.
- Duplicate email → 409.
- Target đổi xưởng sau khi được tạo: quyền được kiểm tra lại, không dựa creator.
- Không tự nâng quyền, không sửa ngoài scope, không khóa ADMIN.
- Guard ADMIN active cuối cùng và race đồng thời.
- Firestore fail sau Auth create → compensation/reconcile.
- Auth fail sau profile inactive/active transition → reconcile.
- Log redaction: không có token/password/key/reset link.
- CORS/rate limit/payload limit/error mapping.

### Integration

- Verify ID Token đúng/sai project.
- Admin Auth Emulator/Firestore Emulator nếu khả dụng, nhưng mock test không thay Rules test.
- Gọi API trực tiếp không qua UI.
- HTTPS/CORS từ Firebase Hosting UAT và từ origin không được phép.
- Network test từ LAN, VPN và ngoài công ty theo mô hình đã chọn.

### Regression frontend

- `npm run cache`
- `npm run excel`
- `npx tsc --noEmit`
- `npm run lint`
- `npm run build`
- `npm run rules:test` sau khi Java/Emulator sẵn sàng.

## 13. Thông tin cần xác nhận trước lập trình

1. Chọn A, B hay C; hostname và owner vận hành cụ thể.
2. Người dùng có truy cập ngoài mạng không; nếu có, dùng VPN/ZTNA hay cloud/public gateway?
3. DNS, certificate authority, TLS termination và firewall inbound/outbound.
4. Production/UAT API origins và CORS allowlist.
5. Cơ chế service identity/secret store; tuyệt đối không gửi key qua chat/repo.
6. Dịch vụ email gửi password setup/reset link và allowed continue URL.
7. Phê duyệt schema provisioning operation và audit log, retention/reader roles.
8. Policy tạo ADMIN mới và cơ chế bảo vệ “ADMIN active cuối cùng”.
9. Rate limits, payload limits, log/monitoring/alerting và on-call owner.
10. Quy trình CI/CD, backup, deploy, rollback và credential rotation của API.
11. Nếu chọn cloud: billing/project/IAM/region đã được phê duyệt hay chưa.

## 14. File đã sửa và rollback

Đã tạo duy nhất `docs/USER-MGMT-05.md`.

Không sửa source, Rules, Auth workflow, dependencies hoặc dữ liệu. Rollback bằng cách xóa tài liệu này; không có runtime artifact cần phục hồi.
