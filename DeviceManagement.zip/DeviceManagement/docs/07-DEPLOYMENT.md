# 07 — Firebase Hosting Deployment

## Đích triển khai

- Project ID: `quanly-tasklist`.
- Hosting site ID: `quanly-tasklist`.
- URL: <https://quanly-tasklist.web.app>.
- `firebase.json`: public `dist`, rewrite `**` → `/index.html`.

## Điều kiện trước deploy

```powershell
npm run excel
npx tsc --noEmit
npm run lint
npm run build
```

Kiểm tra `dist/` không có `.env`, log, report, backup, source map hoặc credential. Xác nhận `.firebaserc` và Firebase client cùng project. Xác nhận Authorized domains/Email-Password trong Console và, nếu thay đổi quyền, Rules Emulator suite phải PASS hoặc rủi ro được phê duyệt.

## Deploy chỉ Hosting

```powershell
npm run build
firebase.cmd deploy --only hosting --project quanly-tasklist
```

Máy hiện tại dùng `firebase.cmd` vì PowerShell Execution Policy có thể chặn `firebase.ps1`. Không bỏ `--only hosting`, nếu không có nguy cơ triển khai thêm cấu hình ngoài phạm vi.

## Kiểm tra sau deploy

- Mở root và refresh trực tiếp một route sâu như `/devices` hoặc `/q/<code-hợp-lệ>`.
- Đăng nhập tài khoản ADMIN và USER; xác nhận area scope.
- Kiểm tra dashboard, thiết bị, incident workflow, maintenance, inspection history.
- Xuất XLSX và kiểm tra 6 sheet/63 cột.
- Quét QR trên thiết bị HTTPS và cấp quyền camera.
- Kiểm tra Console/Network không có lỗi chunk hoặc permission-denied bất thường.

## Xác định phiên bản

- Release `live` được Firebase CLI 15.33.0 xác minh ngày 05/11/2026: release ID `1793846686317000`, version ID `2346f8b34230a116`, trạng thái `FINALIZED`, release time `2026-11-05 09:44:46` (UTC+7), URL <https://quanly-tasklist.web.app>.
- Metadata xác nhận deployment tool là Firebase CLI và SPA rewrite về `/index.html`.
- Firebase Console → Hosting → Release history cho biết thời gian, người deploy và release.
- Có thể dùng Firebase CLI/Console đọc release; không dựa chỉ vào tên hash bundle vì hash đổi theo build.
- Firebase Hosting metadata trả về không có commit SHA và source chưa hiển thị app version/commit trong UI. Commit tương ứng release trên vẫn **CẦN XÁC MINH** từ lịch sử Git/CI; không suy đoán theo thời gian deploy.

## Rollback

Rollback Hosting phải được phê duyệt. Trong Firebase Console, chọn release tốt trước đó và dùng chức năng rollback/release lại của Hosting. Sau rollback chạy lại smoke test. Không rollback Rules/database theo Hosting một cách ngầm định; đây là các tài nguyên độc lập.

## Phê duyệt bắt buộc

- Deploy hoặc rollback production/UAT.
- Thay project/site/authorized domain.
- Deploy Rules, indexes, Functions hoặc thay Auth provider.
- Migration/database write và thay dependency/build config.

