# SECURITY-FIX-01 — Firestore RBAC Privilege Escalation

## Trạng thái

**CODE FIXED — RULES EMULATOR TEST BLOCKED — NOT READY FOR DEPLOY.**

Không deploy Firestore Rules, không ghi production và không thay đổi React/Auth/cache/schema.

## 1. Nguyên nhân lỗ hổng

Helper `targetWithinAreaAdminScope(data)` coi cả ba role `ADMIN`, `AREA_ADMIN`, `USER` là target mà AREA_ADMIN có thể quản lý, miễn `data.areaIds.hasOnly(caller.areaIds)`.

Đây là sai sót vì:

- ADMIN legacy thường có `areaIds=[]`; danh sách rỗng có thể thỏa điều kiện tập con.
- AREA_ADMIN khác cũng có thể thỏa nếu areaIds nằm trong caller scope.
- Helper được tái sử dụng cho cả `get` và `update`.
- Update kiểm tra helper trên cả `resource.data` và `request.resource.data`, nhưng do helper chấp nhận role đặc quyền nên before-state ADMIN/AREA_ADMIN không bị chặn.
- AREA_ADMIN có thể gửi after-state role USER trong scope và hạ quyền target đặc quyền.

Ngoài đường trực tiếp `users`, `validInviteCreate` cũng cho AREA_ADMIN tạo invite role AREA_ADMIN. Invitee sau đó có thể đi qua `validClaimedProfile`, tạo một AREA_ADMIN profile dù caller ban đầu không được phép cấp role đó.

## 2. Các nhánh Rules bị ảnh hưởng

Trong `match /users/{userId}`:

- `get`: self-get OR ADMIN OR AREA_ADMIN + `targetWithinAreaAdminScope(resource.data)`.
- `list`: chỉ ADMIN; không bị mở rộng.
- `create`: invite claim OR ADMIN; đường invite bị ảnh hưởng gián tiếp bởi `validInviteCreate`.
- `update`: ADMIN OR AREA_ADMIN + valid profile + `canAreaAdminUpdateUser`.
- `delete`: chỉ ADMIN; không bị mở rộng.

`canAreaAdminUpdateUser` đã có điều kiện target UID khác caller và kiểm tra cả before/after, nhưng hiệu quả phụ thuộc hoàn toàn vào helper target scope. Không có `allow` chồng lấn nào khác trong match `users` cấp quyền quản trị cho USER.

Self-profile `get` được giữ nguyên để Auth/Profile lifecycle đọc profile chính mình, kể cả tài khoản inactive cần hiển thị trạng thái khóa.

## 3. Điều kiện đã sửa

### Target profile

Trước:

```text
data.role in ["ADMIN", "AREA_ADMIN", "USER"]
```

Sau:

```text
data.role == "USER"
```

Kết quả:

- AREA_ADMIN chỉ có thể get/update target có before-role USER.
- Request after-update cũng phải tiếp tục là USER.
- Không thể sửa, khóa, demote ADMIN hoặc AREA_ADMIN.
- Không thể nâng USER thành AREA_ADMIN/ADMIN.
- Before và after `areaIds` đều phải là tập con caller scope.
- `userId != request.auth.uid` tiếp tục chặn AREA_ADMIN tự sửa.

### Invite create

Nhánh AREA_ADMIN trong `validInviteCreate` đổi từ “role khác ADMIN” thành exact `role == USER`. ADMIN vẫn có thể tạo invite role USER/AREA_ADMIN theo quyền hiện hành.

Không thay đổi schema, quyền ADMIN tổng, list users, delete users hoặc quyền self-get.

## 4. File thay đổi

- `firestore.rules`
- `tests/firestore.rules.test.mjs`
- `docs/SECURITY-FIX-01.md`

## 5. Kiểm thử bảo mật bổ sung

Suite hiện có 22 integration tests. Các ca mới/được củng cố:

- AREA_ADMIN không get ADMIN khác.
- AREA_ADMIN không update/đổi tên ADMIN.
- AREA_ADMIN không khóa ADMIN.
- AREA_ADMIN không demote ADMIN thành USER.
- AREA_ADMIN không get/update AREA_ADMIN khác.
- AREA_ADMIN không tự đổi role, mở rộng areaIds hoặc đổi active.
- AREA_ADMIN sửa USER đúng scope thành công.
- AREA_ADMIN không sửa USER ngoài scope.
- AREA_ADMIN không chuyển USER sang area ngoài scope.
- AREA_ADMIN không nâng USER thành AREA_ADMIN.
- AREA_ADMIN không tạo invite AREA_ADMIN nhưng vẫn tạo invite USER đúng scope.
- AREA_ADMIN vẫn get profile chính mình.
- AREA_ADMIN không direct-create hoặc delete user.
- USER không tự sửa role/areaIds/isActive.
- ADMIN vẫn get và quản lý profile USER/AREA_ADMIN hợp lệ.
- List toàn `users` vẫn chỉ ADMIN.

Mỗi integration test clear và seed lại Emulator, tránh mutation của test trước ảnh hưởng test sau.

## 6. Kết quả kiểm tra

| Kiểm tra | Kết quả |
|---|---|
| `node --check tests/firestore.rules.test.mjs` | PASS |
| Số integration tests | 22 |
| `npx tsc --noEmit` | PASS |
| `npm run lint` | PASS |
| `npm run build` | PASS |
| `npm run cache` | PASS — 34/34 |
| `npm run excel` | PASS — 26/26 |
| `npm run rules:test` | **BLOCKED** — Firestore Emulator không khởi động: `spawn java ENOENT` |

Build vẫn có cảnh báo chunk trên 500 kB như trước; không liên quan bản vá Rules.

Không có công cụ parser Rules độc lập trong repository. Vì Emulator không khởi động, chưa được tuyên bố Rules syntax/behavior PASS. JavaScript test syntax đã PASS nhưng không thay thế Rules Emulator.

## 7. Rủi ro còn lại

- Bản vá chưa được thực thi trên Firestore Emulator; không được deploy cho tới khi 22 tests chạy thật với PASS=22, FAIL=0, SKIP=0.
- Java/JDK vẫn thiếu trên PATH. Cần JDK 21 LTS hoặc môi trường Emulator đã phê duyệt theo `docs/USER-MGMT-02.md`.
- Workflow invite vẫn tồn tại; SECURITY-FIX-01 chỉ chặn AREA_ADMIN cấp role cao hơn USER, không thay đổi hoặc xóa dữ liệu invite.
- ADMIN giữ quyền quản trị tổng hiện hành, bao gồm update/delete profile theo Rules cũ. Chính sách bảo vệ “ADMIN cuối cùng” không thuộc phạm vi bản vá này.
- Client UI không phải lớp bảo mật; kết quả cuối cùng vẫn phụ thuộc Rules được deploy sau khi Emulator PASS.

## 8. Điều kiện nghiệm thu/deploy

1. Cài/cấu hình Java cho process test mà không cần thay đổi production.
2. Chạy `npm run rules:test`.
3. Xác nhận 22 PASS, 0 FAIL, 0 SKIP.
4. Nếu có failure, chỉ sửa Rules/test trong phạm vi RBAC và chạy lại toàn bộ regression.
5. Review diff Rules riêng trước deploy. SECURITY-FIX-01 không tự deploy.
