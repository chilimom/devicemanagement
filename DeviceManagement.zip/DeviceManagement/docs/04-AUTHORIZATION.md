# 04 — Authentication và phân quyền

## Authentication/profile

Đăng nhập bằng Firebase Email/Password. Auth user chưa đủ quyền: ứng dụng phải đọc `users/{uid}` và xác minh `role`, `isActive`, `areaIds`. Nếu Auth user tồn tại nhưng thiếu profile, ứng dụng báo tài khoản chưa có hồ sơ và không cấp quyền nghiệp vụ. Inactive user chỉ có thể đọc profile của chính mình để hiển thị trạng thái khóa.

`UserManagement` và `userService` hiện chỉ liệt kê/đọc profile. Source không tạo Auth user, không ghi `users/{uid}` và không cập nhật role/area. Rules cho ADMIN ghi profile hợp lệ, nhưng tạo/xóa Firebase Auth account là quy trình độc lập. Quy trình vận hành chính thức (Console hay công cụ ngoài ứng dụng) vẫn **CẦN XÁC MINH**; tuyệt đối không tạo profile với UID không khớp Auth user.

## Vai trò

- `ADMIN`: active, quản trị toàn hệ thống.
- `USER`: active, truy cập dữ liệu theo `users/{uid}.areaIds`.
- `GUEST`: trạng thái giao diện khi chưa đăng nhập, không phải role trong `users/{uid}`; chỉ đọc public summary generation hiện hành và không có quyền ghi.
- UI dùng `AdminRoute`, `isAdmin`, `canAccessArea`; Rules là nguồn quyết định cuối.
- Rủi ro trọng yếu: gán nhầm `ADMIN`, `areaIds` quá rộng, profile mồ côi hoặc Auth user thiếu profile. Mọi thay đổi phải đối chiếu cả Auth và `users/{uid}`.

## Ma trận Rules hiện hành

| Collection | ADMIN | AREA_ADMIN | USER active |
|---|---|---|
| `users` | get/list/create/update/delete profile hợp lệ | chỉ get profile chính mình |
| `areas` | read/write | đọc area có ID trong `areaIds` |
| `subAreas` | read/write theo `factoryId` | đọc khi `factoryId` thuộc `areaIds` |
| `deviceCategories`, `deviceTypes` | read/write | read danh mục |
| `devices` | get/list/create/update; không delete | get/list theo `areaIds`, tạo/cập nhật trong area được giao | get/list nếu `areaId` được cấp; không write |
| `incidents` | đọc; tạo; update chỉ transaction workflow; không delete | tương tự trong area hiện tại của device |
| resolution/verification | đọc theo device; create qua transaction; không update/delete | tương tự trong area hiện tại |
| `maintenances` | read/write | read/create trong area được giao; sửa/xóa ADMIN-only | read/create trong area được cấp; sửa/xóa ADMIN-only |
| `inspectionTemplates` | read/write | không read/write |
| `deviceInspectionPlans` | read/write | read; tạo/cập nhật trong area được giao, dùng template áp dụng đúng area | read theo device; không write |
| `inspectionResults` | read; create hợp lệ; không update/delete | read/create trong area được giao | read/create trong area device |

## Giới hạn theo khu vực

Rules lấy area hiện tại từ `devices/{deviceId}`; không tin `originAreaId` lịch sử. Vì vậy chuyển thiết bị sang area khác cũng chuyển quyền đọc lịch sử. Record lịch sử thiếu `deviceId` không được USER đọc theo helper hiện tại.

`areas` là nhà máy; `subAreas.factoryId` trỏ tới nhà máy. `AREA_ADMIN` chỉ đọc/ghi khu vực con trong nhà máy được giao. `devices.subAreaId` chỉ mô tả vị trí; Rules xác nhận nó thuộc cùng `devices.areaId`, còn mọi quyền thiết bị và lịch sử tiếp tục theo `areaId`.

Query client phải phù hợp Rules: USER và AREA_ADMIN lấy devices theo area, sau đó history theo device ID; không list toàn collection rồi lọc. Excel của hai role scoped này tuân theo cùng mô hình và không list `users`.

`AREA_ADMIN` được khắc phục và xác minh sự cố cho thiết bị trong area được giao. Transaction xác minh cần được đọc ID verification cố định chưa tồn tại trước khi tạo; Rules chỉ cho phép đọc thiếu-document này khi incident tương ứng có thiết bị trong area được cấp. Có thể kiểm tra ID incident chưa tồn tại để hiện/khởi tạo sự cố từ kết quả tuần kiểm; incident đã tồn tại vẫn chỉ đọc được theo area hiện tại của thiết bị. `AREA_ADMIN` được tạo, sửa và ngừng sử dụng `deviceTypes` khi document có `areaIds` không rỗng và toàn bộ ID nằm trong phạm vi được giao. Loại legacy/toàn hệ thống không có `areaIds` hoặc có danh sách rỗng chỉ ADMIN được sửa. Khi tạo thiết bị hoặc đổi xưởng/loại, Rules kiểm tra loại toàn hệ thống hoặc loại có chứa area đích.

Tạo thiết bị dùng transaction để kiểm tra mã thiết bị chưa tồn tại trước khi ghi. Vì vậy Rules cho ADMIN/AREA_ADMIN đọc ID thiết bị thiếu trong bước kiểm tra này; thiết bị đã tồn tại vẫn chỉ được đọc trong area hiện tại được cấp. Quyền tạo cuối cùng tiếp tục bị giới hạn bởi `canManageArea`, khu vực con hợp lệ và phạm vi `deviceType`.

AREA_ADMIN có thể mở trang lập lịch cho thiết bị trong `areaIds`. Trang cần đọc document plan theo ID thiết bị trước khi tạo lịch đầu tiên; Rules cho phép kiểm tra document plan chưa tồn tại khi thiết bị cùng ID thuộc khu vực AREA_ADMIN được quản lý. Đọc plan hiện có và tạo/cập nhật vẫn theo area, template scoped và các kiểm tra version hiện hành. Thực hiện tuần kiểm tạo `inspectionResults` theo quyền truy cập thiết bị trong area.

Mẫu tuần kiểm mới có `areaIds` không rỗng. Mẫu là danh mục quản trị được ADMIN/AREA_ADMIN đọc; client AREA_ADMIN query và hiển thị theo `areaIds`. Quyền ghi vẫn fail-closed: AREA_ADMIN chỉ tạo/sửa mẫu khi toàn bộ `areaIds` là tập con quyền của mình. Khi lập kế hoạch tuần kiểm, Rules kiểm tra thiết bị thuộc xưởng được quản lý và mẫu có áp dụng cho chính xưởng đó. Mẫu legacy thiếu phạm vi không được AREA_ADMIN sử dụng hoặc sửa.

## Write nhạy cảm

- Resolution/verification cần cặp write nguyên tử và `getAfter()` khớp history/incident.
- Inspection result phải khớp device, plan, version, caller UID và snapshot.
- Device create/update và area/type/template write là ADMIN-only. Maintenance create cho ADMIN, AREA_ADMIN và USER trong area được cấp; update/delete ADMIN-only. Plan tuần kiểm được ADMIN cập nhật toàn hệ thống; AREA_ADMIN chỉ cập nhật plan trong khu vực được giao; USER chỉ đọc plan theo area.
- Client check giúp UX nhưng không thay thế Rules.

## Test bảo mật

`tests/firestore.rules.test.mjs` bao phủ area/device/history, tạo ngoài area, transaction resolution/verification, thu hồi quyền và chuyển area. Năm integration test vẫn **PENDING** vì chưa chạy với Rules Emulator/tooling; không được ghi PASS cho đến khi thực thi thành công.

Các ca cần kiểm thử thêm/duy trì: inactive profile, USER rỗng/multi-area, history legacy thiếu deviceId, query không đủ constraint, chuyển device giữa area, retry transaction, tạo incident từ inspection, USER cố list users/templates.

