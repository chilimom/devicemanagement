# 10 — Changelog đã xác minh

Tài liệu này chỉ ghi mốc có bằng chứng trong source/test/cấu hình hiện hành; không tự đặt semantic version hoặc ngày release.

## Nền tảng và module

- Ứng dụng React/TypeScript/Vite dùng Firebase Auth, Firestore và Hosting.
- Đã có module area, type, device, incident, resolution, verification, maintenance, inspection, QR và quản lý user dạng danh sách.
- Đã có RBAC ADMIN/USER theo profile Firestore và areaIds; Rules dùng area hiện tại của device.

## Workflow sự cố/tuần kiểm

- Resolution/verification dùng transaction và history collection riêng.
- Inspection result lưu `planSnapshot`.
- Đã có luồng tạo incident xác định từ criterion WARNING/FAIL.

## Excel export

- Đã có reader theo scope, transformer thuần TypeScript và ExcelJS workbook dynamic import.
- Cấu trúc cuối: 6 sheet, 63 cột gồm STT theo nhóm mã thiết bị.
- Có bảo vệ formula injection, kiểu Date/text, row limit và regression 26 test.

## Cleanup và quality

- Backup/tài liệu trung gian đã được archive ngoài workspace có manifest/checksum trong các bước cleanup trước.
- Source hiện đạt TypeScript, ESLint và production build ở lần kiểm tra DOCS-01.

## Hosting

- Firebase project/site `quanly-tasklist`, SPA rewrite và `dist` đã cấu hình.
- Người dùng xác nhận ứng dụng đã deploy tại <https://quanly-tasklist.web.app>.
- Firebase CLI đã xác minh release `live`: release `1793846686317000`, version `2346f8b34230a116`, `FINALIZED`, phát hành lúc `2026-11-05 09:44:46` (UTC+7).
- Hosting metadata không chứa commit SHA; commit tương ứng vẫn **CẦN XÁC MINH** từ Git/CI.

## Việc còn mở

- Năm Firestore Rules integration test chưa được xác nhận PASS trên Emulator.
- Chưa có test UI tự động.
- Quản trị category và user/Auth account không có workflow ghi trong source; update plan không tồn tại, update template chưa nối UI và chưa có versioning hoàn chỉnh.
- Port 55000 không phải cấu hình mặc định nhưng CLI override đã chạy thành công; truy cập điện thoại trong mạng công ty còn cần kiểm thử tại chỗ.
