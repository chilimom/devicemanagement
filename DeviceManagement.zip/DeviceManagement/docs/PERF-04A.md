# PERF-04A — Khảo sát cấu hình Firebase và cơ chế truy cập dữ liệu

Ngày khảo sát: 06/11/2026. Phạm vi: đọc repository cục bộ; không truy cập hoặc suy đoán trạng thái Firebase Console; không sửa source, Firebase Auth, Rules, indexes hoặc database; không cài dependency, khởi chạy Emulator hay deploy.

## Kết luận điều hành

- Repository **không có** `firestore.indexes.json`; `firebase.json` cũng không khai báo thuộc tính `firestore.indexes`. Vì vậy repository hiện khai báo **0 composite index**. Trạng thái index thực tế trên Firebase Console **CHƯA THỂ XÁC MINH** từ file local.
- Firebase alias `default` và Firebase Web config cùng trỏ tới project ID `quanly-tasklist`. Hosting phục vụ `dist` và rewrite SPA về `/index.html`.
- Chỉ có Firestore Emulator tại `127.0.0.1:8085`; không có Authentication Emulator hoặc Emulator Suite UI trong cấu hình. Source development không gọi API kết nối Emulator.
- Auth dùng `getAuth(app)` và không gọi `setPersistence()`. Vì vậy source không chọn persistence tường minh; hành vi persistence là mặc định của Firebase Auth Web SDK. Điều này độc lập với Firestore, hiện dùng memory cache mặc định qua `getFirestore(app)`.
- Toàn source có 1 call-site `onSnapshot`, 27 call-site `getDoc`, 57 call-site `getDocs`, và không có `getDoc(s)FromCache` hoặc `getDoc(s)FromServer`. Các số này là call-site tĩnh; helper chạy theo từng `deviceId`/chunk có thể tạo nhiều request runtime.
- Phát hiện **không làm thay đổi hướng thiết kế shared memory cache của PERF-04A**, nhưng bổ sung hai ràng buộc: cache phải phân vùng/invalidate theo UID + role + `areaIds`, và các thao tác quyết định quyền hoặc trước write không được tin dữ liệu shared cache cũ. Shared cache phù hợp nhất cho danh mục và dữ liệu đọc lặp giữa Dashboard/Devices/Inspection; không thay Security Rules hay server revalidation.

## 2.1. Firestore indexes

### Trạng thái repository

Không tìm thấy `firestore.indexes.json` trong repository. Cấu hình Firestore chỉ trỏ tới Rules:

```json
"firestore": {
  "rules": "firestore.rules"
}
```

Bằng chứng: `firebase.json:2-4`. Do không có file indexes và không có `firestore.indexes` trong `firebase.json`, số composite index khai báo trong repository là **0**; không có collection, fields, sort order hoặc query scope nào để thống kê từ manifest local.

Điều này không chứng minh project Firebase không có composite index. Index có thể đã được tạo trực tiếp trên Console hoặc từ một source/deployment khác. Trạng thái deployed index, build status và usage **CẦN XÁC MINH trên Firebase Console hoặc bằng Firebase CLI read-only sau khi được phê duyệt**.

### Đối chiếu query mục tiêu

| Khu vực | Query đã xác nhận | Nhu cầu index quan sát từ source |
| --- | --- | --- |
| Dashboard | ADMIN đọc toàn collection; USER đọc `devices.areaId in areaIds`, area theo document ID, rồi `incidents.deviceId ==` và `maintenances.deviceId ==` cho từng thiết bị | Equality/`in` một field thường dựa vào single-field index tự động. Source không có sort kết hợp. Không có composite index local để đối chiếu. |
| Devices | Cùng query devices/areas theo scope; đọc toàn `deviceCategories`, `deviceTypes` | Không thấy query nhiều field hoặc sort phía Firestore. |
| Incidents | ADMIN đọc toàn `incidents`; USER lấy devices theo `areaId in`, rồi `incidents.deviceId ==` từng thiết bị | Gom thành `deviceId in [...]` không kèm sort về hình dạng chỉ cần index field `deviceId`; khả năng chạy và phù hợp Rules vẫn phải xác minh bằng Emulator. |
| Maintenances | Tương tự Incidents với `maintenances.deviceId ==` | Nhận định tương tự. |
| Inspection Hub | `devices.areaId in areaIds`; areas theo document ID | Không thấy composite query. |
| Inspection templates | `inspectionTemplates orderBy name asc` | Một field; thường dùng single-field index. |
| Inspection history | `inspectionResults where deviceId == ... orderBy createdAt desc` | Đây là query rõ nhất có khả năng cần composite index collection scope gồm `deviceId ASC` + `createdAt DESC`. Repository không khai báo index đó; việc query đang chạy trên project nào và index thực tế tồn tại hay không **CHƯA XÁC MINH**. |

Bằng chứng chính: `src/pages/Dashboard.tsx:31-62, 79-86, 271-303`; `src/pages/Devices.tsx:31-52, 235-248`; `src/pages/Incidents.tsx:31-57, 125-133`; `src/pages/Maintenances.tsx:31-57, 132-140`; `src/pages/InspectionHub.tsx:42-64, 97-108`; `src/services/inspectionService.ts:28-33`; `src/services/inspectionResultService.ts:267-273`.

### Liên quan phương án gom query theo `deviceId`

- Query hiện tại tạo fan-out: một `getDocs(where("deviceId", "==", deviceId))` cho mỗi thiết bị trong Dashboard, Incidents và Maintenances.
- Một phương án `where("deviceId", "in", deviceIdsChunk)` có thể giảm số request. Nếu chỉ filter `deviceId`, source hiện không cho thấy nhu cầu composite index; vẫn phụ thuộc giới hạn toán tử của SDK/backend và khả năng Rules chứng minh quyền cho toàn bộ kết quả.
- Nếu gom query đồng thời thêm `orderBy("createdAt", "desc")`, dự kiến cần composite index theo từng collection, tối thiểu `deviceId` + `createdAt DESC`. Không được tạo index trước khi query shape, Rules Emulator và chi phí đọc được phê duyệt.
- Shared memory cache không giải quyết fan-out lần tải đầu; nó chỉ tránh tải lại khi chuyển route trong cùng phiên/cache scope.

## 2.2. Firebase project và Emulator

| Mục | Đã xác nhận từ repository | Trạng thái Console/runtime |
| --- | --- | --- |
| Project alias | `.firebaserc:2-4`: alias `default` → `quanly-tasklist` | Project đang chọn trong CLI session **CHƯA XÁC MINH**. |
| Web project ID | `src/config/firebase.ts:5-14`: Firebase app config dùng project ID `quanly-tasklist` | Project/resource thực tế trên Console **CHƯA XÁC MINH**. |
| Hosting | `firebase.json:5-17`: public `dist`, ignore config/dotfiles/node_modules, rewrite `**` → `/index.html` | Release/live channel không được kiểm tra trong khảo sát này. |
| Firestore Rules | `firebase.json:2-4`: `firestore.rules` | Rules deployed có khớp local hay không **CHƯA XÁC MINH**. |
| Firestore indexes | Không có `firestore.indexes.json`; không có key `indexes` | Index trên Console **CHƯA XÁC MINH**. |
| Firestore Emulator | `firebase.json:20-25`: `127.0.0.1:8085` | Không khởi chạy theo yêu cầu. |
| Auth Emulator | Không có cấu hình `emulators.auth` | Chưa cấu hình local. |
| Emulator UI | Không có cấu hình `emulators.ui` | Firebase CLI có thể có default tùy phiên bản khi chạy, nhưng repository không cấu hình; runtime **CHƯA XÁC MINH**. |
| Source nối Emulator | Không tìm thấy `connectFirestoreEmulator`, `connectAuthEmulator`, `FIRESTORE_EMULATOR_HOST` hoặc nhánh DEV tương đương | `npm run dev` hiện sẽ dùng backend cấu hình trong Firebase Web config, không tự nối Emulator. |
| Script Rules | `package.json:13-14`: `rules:test`, `rules:test:emulator` | `rules:test:emulator` dùng `firebase emulators:exec --only firestore`; không chạy trong khảo sát. |

Rules integration nằm trong `tests/firestore.rules.test.mjs`. File test dynamic-import `@firebase/rules-unit-testing`; khi thiếu prerequisite, test integration bị skip thay vì chứng minh Rules PASS (`tests/firestore.rules.test.mjs:9-10, 211-212`; `docs/08-TESTING.md:9-20`).

Đề xuất kiểm thử sau này: sau phê duyệt, dùng đúng project test/emulator riêng, cấu hình source test nối cả Auth và Firestore Emulator hoặc giữ UI test tách khỏi production; chạy Rules suite hiện có, bổ sung ca query gom `deviceId in`, USER nhiều area/ngoài area, thay đổi `areaIds`, chuyển thiết bị giữa area và inactive user. Không dùng production database để thay Emulator.

## 2.3. Firebase Authentication persistence

### Luồng đã xác nhận

- `src/config/firebase.ts:14-17`: `initializeApp`, `getAuth(app)`, `getFirestore(app)`. Không dùng `initializeAuth()`.
- Không tìm thấy `setPersistence`, `browserLocalPersistence`, `browserSessionPersistence`, `inMemoryPersistence` hoặc `indexedDBLocalPersistence`. Vì vậy ứng dụng nhận Auth persistence mặc định của Firebase Auth Web SDK; source không cam kết rõ local/session/memory và không có khác biệt development/production.
- `src/pages/Login.tsx:22`: đăng nhập bằng `signInWithEmailAndPassword`.
- `src/App.tsx:58-118`: `onAuthStateChanged`; mỗi lần auth đổi sẽ unsubscribe listener profile trước, xóa `user`, `appUser`, lỗi cũ, rồi gắn `onSnapshot(doc(db, "users", uid))`.
- Profile được parse và kiểm tra `role`, `isActive`, `areaIds`; callback còn kiểm tra `auth.currentUser?.uid === uid` để tránh áp dữ liệu profile cũ sau đổi tài khoản.
- `src/App.tsx:119-125`: cleanup khi App unmount gọi cả unsubscribe profile và unsubscribe Auth.
- `src/components/AppLayout.tsx:73-81` và `src/App.tsx:151-156`: logout chỉ gọi Firebase Auth `signOut`; auth callback sau đó xóa React user/profile state. Không có Firestore persistent cache để xóa ở trạng thái hiện tại.
- Role/`areaIds` cập nhật realtime qua listener profile; các page nhận `appUser` mới và effect phụ thuộc `areaIds`/admin flag sẽ tải lại. Security Rules vẫn là lớp quyết định cuối.

### Phân biệt bốn lớp trạng thái

| Lớp | Trạng thái hiện tại | Vòng đời/phạm vi | Ý nghĩa bảo mật |
| --- | --- | --- | --- |
| Firebase Auth persistence | Mặc định của `getAuth`; source không chọn tường minh | Có thể giữ phiên Auth qua reload theo hành vi SDK/browser | Chỉ giữ trạng thái đăng nhập/token; không phải cache tài liệu Firestore. |
| Firestore memory cache | Mặc định của `getFirestore(app)` | RAM của Firestore instance/tab; mất khi reload/đóng tab | Có thể phục vụ dữ liệu trong phiên nhưng không phải shared React store và không thay Rules. |
| Firestore persistent IndexedDB | Không bật | Không tồn tại theo cấu hình source | Nếu bật sau này, dữ liệu tồn tại qua phiên và không tự phân vùng theo UID; rủi ro máy dùng chung. |
| React RAM | `App` giữ `user`/`appUser`; mỗi page giữ devices/areas/categories/history riêng | Mất khi component unmount hoặc reload; không dùng chung giữa page | Logout/auth change xóa root auth/profile state. Dữ liệu page cũ bị unmount, nhưng thiết kế shared cache sau này phải xóa/phân vùng khi UID/role/`areaIds` đổi. |

Những dữ liệu bắt buộc revalidate: Auth state, `users/{uid}` và `isActive`/role/`areaIds`; document trước write hoặc workflow transaction; quyền area hiện tại của device; dữ liệu ảnh hưởng transaction/validation. Shared cache chỉ hỗ trợ UX, không được dùng để thay Security Rules hoặc quyết định cấp quyền.

## 2.4. Firestore listeners và one-time reads

### Thống kê API

| API | Call-site tĩnh | Ghi chú |
| --- | ---: | --- |
| `onSnapshot` | 1 | Chỉ profile `users/{uid}` trong `App.tsx:78`; có unsubscribe khi auth đổi và App unmount. |
| `getDoc` | 27 | One-time document reads, gồm page và service; một số đọc trước workflow/write. |
| `getDocs` | 57 | One-time collection/query reads; helper theo chunk/device làm số request runtime cao hơn call-site. |
| `getDocFromCache` / `getDocsFromCache` | 0 | Không có cache-only strategy. |
| `getDocFromServer` / `getDocsFromServer` | 0 | Không có server-only strategy. |

### Inventory theo module

| Module | API (call-site) và dữ liệu chính | Realtime / cleanup | Route reload và khả năng shared cache |
| --- | --- | --- | --- |
| `src/App.tsx` | `onSnapshot` (1): `users/{uid}` | Realtime; unsubscribe đúng khi auth đổi/unmount | Không cache thay thế; đây là nguồn invalidate UID/role/`areaIds`. |
| `src/pages/Dashboard.tsx` | `getDocs` (9): devices, areas, categories, types, incidents, maintenances; USER query theo area/device | Không realtime; effect có cờ `cancelled` | Tải lại khi route mount hoặc scope đổi. Chia sẻ devices/areas/categories/types với Devices, Areas, InspectionHub; history với Incidents/Maintenances. |
| `src/pages/Devices.tsx` | `getDocs` (6): devices, areas, categories, types | Không realtime; effect có cờ `cancelled` | Tải lại khi mount/scope đổi. Ứng viên chính cho shared cache cùng Dashboard. |
| `src/pages/Incidents.tsx` | `getDocs` (3): devices theo area và incidents theo `deviceId` hoặc toàn collection | Không realtime; effect cancellation | Tải lại khi mount/scope đổi. Có thể dùng shared devices và incidents snapshot có TTL/invalidation. |
| `src/pages/Maintenances.tsx` | `getDocs` (3): devices theo area và maintenances theo `deviceId` hoặc toàn collection | Không realtime; effect cancellation | Tải lại khi mount/scope đổi. Có thể dùng shared devices/maintenances. |
| `src/pages/InspectionHub.tsx` | `getDocs` (4): devices, areas | Không realtime; effect cancellation | Tải lại khi mount/scope đổi; dùng chung dữ liệu với Dashboard/Devices. |
| `src/services/inspectionService.ts` | `getDocs` (1): templates `orderBy name` | One-time | Danh mục tương đối ổn định, phù hợp cache theo role/TTL; ADMIN-only theo Rules. |
| `src/services/inspectionResultService.ts` | `getDoc` (3): device, plan, result; `getDocs` (1): result history theo device + createdAt | One-time | Device/plan reads trước ghi hoặc thực thi cần dữ liệu mới; history có thể cache để hiển thị nhưng invalidate sau create incident/result. |
| `src/services/deviceInspectionPlanService.ts` | `getDoc` (1): plan với document ID device | One-time | Plan tác động thực thi; cache hiển thị được nhưng cần revalidate trước submit. |
| `src/pages/DeviceInspectionExecute.tsx` | `getDoc` (1): device; gọi service lấy plan/history | One-time; effect cancellation | Có thể reuse device; plan/result cần freshness cao hơn. |
| `src/pages/DeviceInspectionHistory.tsx` | `getDoc` (2): device, incident liên quan; gọi history service | One-time; effect cancellation | Reuse device; invalidate history/incident sau workflow. |
| `src/pages/DeviceInspectionPlan.tsx` | `getDoc` (1): device; gọi template/plan services | One-time; effect cancellation | Reuse device/categories; revalidate plan trước write. |
| `src/pages/DeviceDetail.tsx` | `getDoc` (4), `getDocs` (5): device, area/category/type, incident/maintenance/resolution; có legacy `deviceCode` fallback | Không realtime; effect cancellation | Tải lại khi mount/id/scope đổi. Có thể seed từ shared devices/dictionaries nhưng lịch sử và quyền area hiện tại cần refresh. |
| `src/pages/Areas.tsx` | `getDocs` (4): areas/devices | Không realtime; effect cancellation | Dùng chung Dashboard/Devices; invalidate sau area/device changes. |
| `src/pages/DeviceTypes.tsx` | `getDocs` (3): categories/types/devices | Không realtime | Danh mục phù hợp shared cache; invalidate sau create/update/toggle type. |
| `src/pages/AddDevice.tsx` | `getDoc` (1), `getDocs` (4): dictionaries và validation mới nhất | Không realtime; effect cancellation | UI có thể dùng cached dictionaries; validation trước write phải đọc mới/transaction. |
| `src/pages/DeviceEdit.tsx` | `getDoc` (1), `getDocs` (3): device + dictionaries | Không realtime; effect cancellation | Có thể seed cache; revalidate trước write và invalidate device/dictionaries sau thành công. |
| `src/pages/AreaCreate.tsx` | `getDocs` (1): duplicate code | One-time trước write | Không dùng shared cache để quyết định uniqueness. |
| `src/pages/AreaEdit.tsx` | `getDoc` (1), `getDocs` (2): area, device count, duplicate code | One-time | Revalidate count/duplicate trước write. |
| `src/pages/IncidentCreate.tsx` | `getDoc` (3): device/inspection result; transaction cũng đọc | One-time | Workflow-sensitive; không tin cache cho precondition. Invalidate incidents/dashboard/history sau create. |
| `src/pages/IncidentResolve.tsx` | `getDoc` (2): incident/device | One-time | Workflow-sensitive; transaction/service phải xác nhận server/Rules. |
| `src/pages/IncidentVerify.tsx` | `getDoc` (2): incident/device | One-time | Tương tự resolve; invalidate incident/history/dashboard. |
| `src/pages/MaintenanceCreate.tsx` | `getDoc` (1): device | One-time | Revalidate device/area before write; invalidate maintenance/dashboard/detail. |
| `src/pages/DeviceQrPrint.tsx` | `getDoc` (2): device/area | One-time | Có thể seed device/area; quyền area hiện tại vẫn cần kiểm tra. |
| `src/pages/QrDeviceRedirect.tsx` | `getDocs` (2): device by code, USER thêm areaId `in` | One-time; effect cancellation | Tra cứu điều hướng cần scope mới; không dùng cache không phân vùng. |
| `src/services/userService.ts` | `getDoc` (1), `getDocs` (1): user/profile list | One-time | Profile active dùng listener ở App; admin user list có thể cache ngắn nhưng phải invalidate theo quyền. |
| `src/services/excelExportDataService.ts` | `getDoc` (1), `getDocs` (5) tại helper: toàn collection hoặc theo users/device/area | One-time; helper fan-out/chunk | Export phải là snapshot mới trong scope; không nên lấy từ UI/shared cache nếu yêu cầu đầy đủ/chính xác. |

Các component sử dụng `useEffect` chủ yếu ngăn `setState` sau unmount bằng cờ `cancelled`; one-time `getDoc/getDocs` không có unsubscribe/cancel request. Đây là cleanup hợp lý về React state nhưng request đã phát vẫn có thể hoàn tất. Chỉ listener `onSnapshot` yêu cầu unsubscribe và hiện đã thực hiện đúng.

## 2.5. Bảng tổng hợp

| Thành phần | File cấu hình/source | Trạng thái | Rủi ro | Khuyến nghị |
| --- | --- | --- | --- | --- |
| Composite indexes | Không có `firestore.indexes.json`; `firebase.json:2-4` | 0 index khai báo local; Console chưa xác minh | Query inspection history có thể phụ thuộc index chỉ tồn tại ngoài repo; drift khó phục hồi | Sau phê duyệt, đọc Console/CLI và đưa manifest đã kiểm chứng vào quản lý source; không tạo/deploy trong khảo sát. |
| Project alias | `.firebaserc:2-4` | `default = quanly-tasklist` | Alias local không chứng minh CLI/Console state | Luôn chỉ rõ project cho lệnh read/deploy; xác minh trước mọi thao tác. |
| Hosting | `firebase.json:5-17` | `dist`, SPA rewrite | Không liên quan trực tiếp cache; preview khác origin | Giữ Cloudflare preview tách origin khi thử cache; không suy ra Firebase release từ local. |
| Firestore Rules | `firebase.json:2-4`, `firestore.rules` | Có local config | Deployed Rules có thể drift | So sánh read-only sau phê duyệt; Emulator suite trước thay đổi query/RBAC. |
| Firestore Emulator | `firebase.json:20-25` | Có, port 8085 | Source dev không tự nối; chạy UI có thể vô tình chạm backend thật | Thiết kế test harness/flag explicit; không khởi chạy trong khảo sát. |
| Auth Emulator/UI | `firebase.json` | Chưa cấu hình | Khó smoke test đổi account/profile hoàn toàn local | Đề xuất cấu hình sau phê duyệt; test Auth + Firestore cùng project demo/emulator. |
| Auth persistence | `src/config/firebase.ts:14-17` | `getAuth`, mặc định SDK; không `setPersistence` | Hành vi không được biểu đạt trong code; máy dùng chung cần chính sách rõ | Quyết định local/session/memory theo yêu cầu bảo mật trước khi triển khai shared cache. |
| Profile/RBAC listener | `src/App.tsx:58-125` | Realtime, cleanup đúng | Cache mới có thể giữ data scope cũ nếu không invalidate | Cache key theo UID/role/normalized `areaIds`; clear atomically khi auth/profile scope đổi. |
| Firestore cache | `src/config/firebase.ts:17` | Memory mặc định; không IndexedDB | Không tồn tại qua reload; không phải shared page cache | Không bật persistent cache chỉ để tối ưu route. Shared React/service cache là thay đổi độc lập. |
| Page data reads | Dashboard/Devices/Incidents/Maintenances/Inspection | One-time reads, tải lại khi route mount | Trùng reads và fan-out theo device; dữ liệu có thể đổi giữa cache hits | Shared memory cache có TTL, dedupe in-flight, explicit invalidation; server revalidate cho dữ liệu nhạy cảm. |
| Cache/server APIs | Toàn `src/` | Không có explicit cache-only/server-only | `getDocs` không biểu đạt freshness contract | Khi thiết kế, phân loại từng dataset; không đổi API hàng loạt nếu chưa đo và test. |
| Rules tests | `package.json:13-14`, `tests/firestore.rules.test.mjs` | Script có; integration hiện có thể skip khi thiếu tooling | Exit 0 có thể bị hiểu sai là PASS | Chỉ ghi PASS khi chạy thực qua Emulator với prerequisites. |

## Ảnh hưởng tới thiết kế shared memory cache PERF-04A

Hướng shared memory cache vẫn phù hợp hơn Firestore persistent IndexedDB cho mục tiêu Dashboard ↔ Devices vì nó có thể tránh fetch trùng trong cùng SPA session mà không lưu dữ liệu qua phiên trình duyệt. Thiết kế nên bổ sung:

1. Cache scope key gồm Firebase project/database, UID, role và tập `areaIds` đã normalize; không dùng một global data bucket cho mọi tài khoản.
2. Xóa toàn bộ scope cũ ngay khi `onAuthStateChanged` đổi UID, logout, profile inactive, role hoặc `areaIds` đổi.
3. Cache riêng các dataset: devices, areas, categories, types, incidents, maintenances; dedupe promise đang tải và tránh một cache object tổng hợp khó invalidate.
4. Dùng TTL/stale-while-revalidate cho list read; hiển thị metadata freshness nếu cần. Không coi cached result là bằng chứng quyền.
5. Invalidate có mục tiêu sau write: device/area/type, incident workflow, maintenance và inspection result/plan/template.
6. Không dùng shared cache cho duplicate check, transaction precondition, export cần đầy đủ, profile/RBAC hoặc quyết định cho phép write; các luồng đó phải đọc mới hoặc dựa trên transaction + Rules.
7. Tách bài toán fan-out `deviceId` khỏi shared cache. Benchmark query batching trên Emulator với Rules trước khi đề xuất index hoặc thay query shape.
8. Đo request count, document reads, thời gian first load, route revisit, cache hit và dữ liệu stale cho cả ADMIN và USER multi-area trước khi phê duyệt triển khai.

## Trạng thái xác minh

- Khảo sát file/source local: **PASS**.
- Xác nhận không có `firestore.indexes.json`: **PASS**.
- Xác nhận cấu hình Firebase/Emulator local: **PASS**.
- Kiểm tra Firebase Console/deployed indexes/Rules/Auth settings: **PENDING — CẦN XÁC MINH**.
- Chạy Emulator/Rules integration: **PENDING — không chạy theo yêu cầu**.
- Source/config/Auth/Rules/index/database/dependency/deploy: **KHÔNG THAY ĐỔI**.

**Điểm dừng:** báo cáo khảo sát hoàn tất; chờ phê duyệt trước mọi thay đổi thiết kế hoặc triển khai.
