# PERF-04B.1 — Nền tảng shared RAM cache

Ngày thực hiện: 06/11/2026. Phạm vi: module TypeScript độc lập giao diện và unit tests; chưa tích hợp Dashboard, Devices, DeviceDetail hoặc page nghiệp vụ.

## Kết quả

Đã xây dựng `SharedRamCache`, cache active-scope-only chạy hoàn toàn trong RAM. Module không import React/Firebase, không dùng Web Storage/IndexedDB, không lưu Auth token và không thực hiện quyết định cấp quyền.

### File tạo/sửa

| File | Thay đổi |
| --- | --- |
| `src/services/sharedRamCache.ts` | Module scope, TTL, read/write, invalidation, race guard và request deduplication. |
| `tests/sharedRamCache.test.ts` | Unit tests scope, state machine, invalidation, race, permission và concurrency. |
| `tsconfig.cache-test.json` | Compile riêng test bằng TypeScript + Node test runner hiện có. |
| `package.json` | Thêm lệnh `npm run cache:test`; không đổi dependency. |
| `docs/PERF-04B.1.md` | Báo cáo triển khai. |

Không sửa page, query Firestore, Firebase Auth, Rules, indexes, database, schema, KPI hoặc giao diện.

## API module

| API | Mục đích |
| --- | --- |
| `normalizeAreaIds(areaIds)` | Trim, bỏ rỗng/trùng và sort area IDs. |
| `createCacheScope(input)` | Tạo immutable scope khi profile active; trả `null` nếu inactive/logout. |
| `createCacheScopeFromUser(projectId, user, databaseId?)` | Adapter từ phần profile `AppUser` cần cho scope. |
| `isPermissionDenied(error)` | Nhận diện mã `permission-denied` dạng Firestore hoặc dạng rút gọn. |
| `CACHE_POLICIES` | TTL đã duyệt cho devices/areas/deviceCategories/deviceTypes. |
| `SharedRamCache.activateScope(scope)` | Kích hoạt scope; nếu key đổi thì tăng generation và xóa toàn data/request scope cũ. |
| `read(scope, dataset, now?)` | Đọc đúng active scope và trả `missing/loading/fresh/refreshing/stale/expired`. Expired không trả data. |
| `write(scope, dataset, data, policy, now?)` | Ghi khi scope còn active; caller chỉ gọi sau server success hoặc read thành công. |
| `load(scope, dataset, loader, policy, now?)` | Dedupe request, commit có generation/request guard, evict khi permission denied. |
| `invalidate(scope, dataset)` | Xóa một dataset/variant và vô hiệu request tương ứng. |
| `invalidateCollection(scope, collection)` | Xóa mọi variant và request đang chạy của collection. |
| `clearScope(scope)` / `clearAll()` | Xóa scope active hoặc toàn store và tăng generation. |
| `getActiveScope()` / `getGeneration()` | Phục vụ integration/quan sát lifecycle, không phải API cấp quyền. |

## Scope và TTL

Scope key là JSON tuple gồm:

```text
[projectId, databaseId, uid, role, normalizedAreaIds.join("\u001f")]
```

Module chỉ giữ một active scope. Đổi UID, role, normalized `areaIds` hoặc chuyển active thành false làm scope key đổi/null; integration PERF-04B.2 phải gọi `activateScope` ngay tại auth/profile barrier. Không thể đọc/ghi bằng scope khác active.

TTL:

| Dataset | Fresh | Expire/stale tối đa |
| --- | ---: | ---: |
| devices | 30 giây | 2 phút |
| areas | 5 phút | 15 phút |
| deviceCategories | 10 phút | 30 phút |
| deviceTypes | 5 phút | 15 phút |

`freshForMs <= age < staleForMs` là stale và vẫn có thể hiển thị trong cùng verified scope; từ `staleForMs` trở đi là expired và module không trả data. Khi refresh đang chạy, visible data là `refreshing`; expired reload là `loading` không data.

## Invalidation và race

- Store/data/in-flight map đều chỉ nằm trong instance RAM.
- Mỗi scope transition/clear tăng `generation`.
- Mỗi request có `requestId`; commit yêu cầu generation, scope key và requestId vẫn trùng.
- Request cũ vẫn có thể hoàn tất ở network, nhưng trả `committed: false` và không ghi cache.
- Request cùng active scope + dataset dùng chung đúng một Promise.
- Invalidate dataset/collection xóa cả in-flight registration; kết quả cũ không commit.
- `permission-denied` xóa entry hiện có, không ghi error/data vào cache và rethrow để consumer xử lý UI.
- Lỗi khác không gia hạn TTL; data cũ chỉ còn theo timestamp ban đầu.

Module không biết CRUD đã thành công hay chưa. PERF-04B.2 chỉ được gọi `write`/`invalidate` sau khi Firestore write/transaction resolve thành công.

## Kiểm thử

| Lệnh | Kết quả |
| --- | --- |
| `npm run cache:test` | PASS — 17 tests sau bổ sung state expired reload. |
| `npm run excel` | PASS — 26 tests. |
| `npx tsc --noEmit` | PASS. |
| `npm run lint` | PASS. |
| `npm run build` | PASS; Vite còn cảnh báo chunk >500 kB đã tồn tại, không phát sinh từ module chưa tích hợp. |
| Rules Emulator | PENDING — không đổi Rules/query/quyền nên không chạy trong bước này. |

Unit tests bao phủ normalize/key, hit/miss, fresh/stale/expired/loading/refreshing, collection invalidation, clear scope/all, UID/role/areaIds/active transition, late request, permission denied và concurrent deduplication.

## Điểm tích hợp cho PERF-04B.2

1. Tạo một cache instance/provider duy nhất bên trong auth/profile active barrier của `App`.
2. Tạo scope từ Firebase project ID, database `(default)` và `AppUser`; gọi `activateScope(null)` trước/đồng thời logout, inactive hoặc profile lỗi.
3. Viết hook/controller chuyển `read` state thành UI behavior: fresh dùng ngay; stale dùng ngay + `load`; expired/missing foreground `load`.
4. Tích hợp trước dictionaries rồi devices list; giữ nguyên query ADMIN/USER.
5. DeviceDetail chỉ seed từ same-scope `devices:list`, sau đó vẫn áp `canAccessArea` và revalidate theo thiết kế.
6. Nối invalidation sau create/edit/lifecycle/area/type server success; không patch trước success.
7. Phân loại `permission-denied` ở consumer để block UI và không stale fallback.
8. Thêm integration tests auth/profile transitions và navigation; unit module không thay thế RBAC/Rules tests.

## Rủi ro và rollback

- API `write` nhận generic object theo reference; consumer phải coi cache data là immutable, không mutate ngoài module. Nếu integration cần patch, bổ sung API copy-on-write có test thay vì mutate trực tiếp.
- Scope key chứa UID/area signature trong RAM; không log key ra telemetry/console.
- Module không tự gọi loader khi stale; consumer/provider quyết định background refresh để tránh side effect ngoài kiểm soát.
- Rollback hiện tại chỉ cần xóa module/test/script/config vì chưa có page import. Không có browser storage, migration hay dữ liệu cần dọn.

**Điểm dừng:** nền tảng và tests hoàn tất; chưa tích hợp page. Chờ nghiệm thu trước PERF-04B.2.
