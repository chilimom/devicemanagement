// import react from '@vitejs/plugin-react'
// import { defineConfig } from 'vite'

// // https://vite.dev/config/
// export default defineConfig({
//   plugins: [react()],
// })
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 8000,
    strictPort: true, // báo lỗi nếu port 7000 bận, không tự nhảy sang port khác
    host: true,       // cho phép máy khác trong mạng LAN truy cập (điện thoại)
    proxy: {
      "/__account-admin": {
        target: "http://127.0.0.1:9000",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/__account-admin/, ""),
      },
    },
  },
  preview: {
    port: 9000,
    strictPort: true,
  },
})
