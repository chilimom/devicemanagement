# Hướng dẫn tác nghiệp cho Codex

Áp dụng cho toàn bộ repository.

1. Đọc `README.md` và tài liệu liên quan trong `docs/` trước khi sửa.
2. Đối chiếu source, Rules và test thực tế; không suy đoán collection, field, route hoặc workflow.
3. Phân tích ảnh hưởng đến dữ liệu, RBAC, lịch sử và tương thích legacy trước thay đổi.
4. Không tự ý thay đổi nghiệp vụ, schema/Document ID Firestore, Firebase Authentication, RBAC hoặc Security Rules.
5. Không deploy, migration hoặc ghi dữ liệu production nếu chưa có yêu cầu và phê duyệt rõ ràng.
6. Không xóa test, backup hay tài liệu phục hồi tùy tiện; phải xác minh vai trò và lưu trữ có checksum trước.
7. Không thêm/gỡ/nâng dependency nếu chưa được phê duyệt.
8. Ưu tiên patch nhỏ, cô lập, dễ kiểm tra; không refactor ngoài phạm vi.
9. Giữ ranh giới ADMIN/USER và giới hạn USER theo `areaIds`; client không thay thế Security Rules.
10. Với lịch sử tuần kiểm, dùng `planSnapshot`; không lấy plan hiện hành để viết lại quá khứ.
11. Sau thay đổi code, chạy `npm run excel`, `npx tsc --noEmit`, `npm run lint`, `npm run build`; chạy Rules Emulator suite khi đổi Rules/quyền.
12. Cập nhật tài liệu khi route, field, workflow, lệnh hoặc cấu hình thay đổi.
13. Báo cáo file sửa, kiểm thử PASS/FAIL/PENDING, rủi ro và mục CẦN XÁC MINH.
14. Không đưa API token, mật khẩu, private key, access/refresh token hoặc service-account credential vào tài liệu/log.
