# Device Management

Ứng dụng web quản lý thiết bị, khu vực, sự cố, lịch sử khắc phục/xác minh, bảo trì và tuần kiểm. Frontend React đọc/ghi trực tiếp Firebase Authentication và Cloud Firestore dưới sự kiểm soát của Firestore Security Rules.

- UAT/Hosting: <https://quanly-tasklist.web.app>
- Firebase project và Hosting site: `quanly-tasklist`
- Ngôn ngữ giao diện: tiếng Việt

## Phạm vi hiện có

- Quản lý khu vực, lĩnh vực/loại thiết bị và hồ sơ thiết bị.
- Vòng đời thiết bị: đang sử dụng, ngừng sử dụng, kích hoạt lại.
- Sự cố: tạo thủ công hoặc từ kết quả tuần kiểm bất thường; khắc phục nhiều lần; xác minh một lần để đóng.
- Bảo trì thiết bị; mẫu, kế hoạch, thực hiện và lịch sử tuần kiểm.
- QR theo mã thiết bị và quét QR trên trình duyệt.
- Xuất XLSX gồm 6 sheet, tổng 63 cột, theo phạm vi ADMIN/AREA_ADMIN/USER.

## Công nghệ

- React 19, TypeScript 6, Vite 8 và React Router 7.
- Firebase Web SDK 12: Authentication và Firestore.
- ExcelJS 4.4; `html5-qrcode`; `qrcode.react`.
- ESLint 10 và Node test runner.

## Cấu trúc

```text
src/
  components/       Layout, route guard, lịch sử thiết bị
  config/           Khởi tạo Firebase
  pages/            Các màn hình theo route
  services/         Workflow sự cố, tuần kiểm, người dùng, Excel
  styles/           CSS theo tính năng
  types/            Kiểu user, tuần kiểm và Excel
tests/               Regression Excel và Firestore Rules
docs/                Tài liệu kỹ thuật
firestore.rules      Security Rules hiện hành
firebase.json        Hosting, Rules và Firestore Emulator
```

## Môi trường và chạy local

- Node.js: đã kiểm tra với Node `20.19.6`.
- npm và dependency theo `package-lock.json`.
- Firebase CLI chỉ cần cho Emulator/deploy; lần kiểm tra gần nhất dùng CLI `15.33.0`.
- Không có file `.env`. Firebase Web config nằm tại `src/config/firebase.ts`; không đưa private credential vào source.

```powershell
npm install
npm run dev
```

Vite hiện cấu hình port mặc định `8000`, `strictPort: true`. Nếu quy trình nội bộ yêu cầu port `55000`, chạy:

```powershell
npm run dev -- --port 55000 --strictPort
```

Hai lệnh trên đã được chạy thử ngày 05/11/2026: Vite khởi động thành công ở `8000` và `55000`, đồng thời công bố địa chỉ LAN do `host: true`. Máy/điện thoại khác chỉ truy cập được khi cùng mạng và chính sách Windows Firewall, Domain hoặc client isolation cho phép; điều kiện mạng công ty vẫn **CẦN XÁC MINH tại chỗ**.

## Kiểm tra và build

```powershell
npm run excel
npx tsc --noEmit
npm run lint
npm run build
```

Rules integration cần công cụ được phê duyệt và Firestore Emulator; xem [Testing](docs/08-TESTING.md).

## Tài liệu

- [Kiến trúc](docs/01-ARCHITECTURE.md)
- [Database](docs/02-DATABASE.md)
- [Nghiệp vụ](docs/03-BUSINESS-RULES.md)
- [Phân quyền](docs/04-AUTHORIZATION.md)
- [Tính năng và route](docs/05-FEATURES.md)
- [Phát triển](docs/06-DEVELOPMENT.md)
- [Triển khai](docs/07-DEPLOYMENT.md)
- [Kiểm thử](docs/08-TESTING.md)
- [Xử lý sự cố](docs/09-TROUBLESHOOTING.md)
- [Changelog](docs/10-CHANGELOG.md)
